package com.ctteam.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Dir
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 9D-2b — Manager > Support: what workers wrote (they arrive inside their reports), and your replies.
 * A reply goes on Telegram when the worker has a chat with your bot, or is copied as a signed code to send any other way.
 * Everything is kept here as a history per worker.
 */
private val SM_BAD = Color(0xFFFF8A8A)
private val SM_GOOD = Color(0xFF5FD6A5)

@Composable
fun ManagerSupportScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val allFlow = remember(repos) { repos.db.supportDao().observeRecent() }
    val all by allFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())

    var selected by remember { mutableStateOf<String?>(null) }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var canTelegram by remember { mutableStateOf(false) }

    fun nameOf(id: String): String = workers.firstOrNull { it.id == id }?.fullName() ?: "Worker"

    val sel = selected
    LaunchedEffect(sel, all.size) {
        if (sel != null) {
            canTelegram = repos.telegram.canSendTo(sel)
            repos.db.supportDao().markManagerRead(sel, System.currentTimeMillis())
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (sel == null) {
            ScreenHeader("Support", onBack)
            Text(
                "Messages your workers wrote in the app. They arrive inside the worker's report (import it in Sync or through Telegram).",
                color = CT.TextSoft, fontSize = 13.sp
            )
            val byWorker = all.groupBy { it.workerId }
            if (byWorker.isEmpty()) EmptyState("💬", "No messages yet", "Questions from workers arrive inside their reports.")
            for ((id, msgs) in byWorker.entries.sortedByDescending { e -> e.value.maxOf { it.createdAt } }) {
                val unread = msgs.count { it.direction == Dir.TO_MANAGER && it.readAt == null }
                val last = msgs.maxByOrNull { it.createdAt }
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { selected = id; note = ""; reply = "" }) {
                    Text(nameOf(id) + (if (unread > 0) "   ● $unread new" else ""), color = if (unread > 0) CT.Gold else Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (last != null) {
                        Text((if (last.direction == Dir.TO_MANAGER) "" else "You: ") + last.body.take(90), color = CT.TextSoft, fontSize = 12.sp)
                        Text(fmtTime(last.createdAt), color = CT.TextSoft, fontSize = 11.sp)
                    }
                }
            }
        } else {
            ScreenHeader(nameOf(sel), { selected = null; note = "" })
            val thread = all.filter { it.workerId == sel }.sortedBy { it.createdAt }
            for (m in thread) {
                val fromWorker = m.direction == Dir.TO_MANAGER
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text((if (fromWorker) nameOf(sel) else "You") + " · " + fmtTime(m.createdAt), color = if (fromWorker) CT.GoldLight else CT.TextSoft, fontSize = 11.sp)
                    Text(m.body, color = Color.White, fontSize = 14.sp)
                }
            }
            CTField(reply, { reply = it.take(600) }, "Your reply", singleLine = false, minLines = 3)
            Text(reply.length.toString() + " / 600", color = CT.TextSoft, fontSize = 11.sp)
            if (note.isNotEmpty() && !noteBad) SuccessNote(note)
            if (note.isNotEmpty() && noteBad) Text(note, color = SM_BAD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            if (canTelegram) {
                GoldButton(text = if (busy) "SENDING…" else "SEND ON TELEGRAM", modifier = Modifier.fillMaxWidth(), onClick = {
                    if (busy || reply.isBlank()) return@GoldButton
                    busy = true
                    val text = reply
                    scope.launch {
                        val r = repos.telegram.sendSupportReply(sel, text, actor)
                        note = r.message
                        noteBad = !r.ok
                        if (r.ok) reply = ""
                        busy = false
                    }
                })
            } else {
                Text("This worker has no Telegram chat with your bot yet, so use COPY below and send the code another way.", color = CT.TextSoft, fontSize = 12.sp)
            }
            GhostButton(text = "COPY REPLY CODE", modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy || reply.isBlank()) return@GhostButton
                busy = true
                val text = reply
                scope.launch {
                    when (val r = repos.sync.makeSupportReply(sel, text, actor)) {
                        is Outcome.Err -> { note = r.message; noteBad = true }
                        is Outcome.Ok -> {
                            clipboard.setText(AnnotatedString(r.value.code))
                            repos.sync.saveSupportReply(sel, r.value, text)
                            note = "Copied. Send it to the worker in a private chat. They tap it, Share, CT Team (or copy it and open the app)."
                            noteBad = false
                            reply = ""
                        }
                    }
                    busy = false
                }
            })
            Text(
                "Replies are signed so only this worker's app accepts them. Telegram can read what is sent through it.",
                color = CT.TextSoft, fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}
