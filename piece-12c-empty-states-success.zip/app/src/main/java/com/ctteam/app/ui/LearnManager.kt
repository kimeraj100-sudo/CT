package com.ctteam.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.LearnContentEntity
import com.ctteam.app.data.LearnRepository
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 10A — Manager > Learn & Earn: write lessons (title, category, text, picture link, video link), keep drafts, publish or hide.
 * Piece 10B: SEND TO WORKERS (Telegram to every linked chat, or copy one code for one worker).
 */
private val LM_BAD = Color(0xFFFF8A8A)
private val LM_GOOD = Color(0xFF5FD6A5)

@Composable
fun ManagerLearnScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val allFlow = remember(repos) { repos.db.contentDao().observeAllLearn() }
    val all by allFlow.collectAsState(initial = emptyList())

    var editing by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }
    var video by remember { mutableStateOf("") }
    var wasPublished by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    // 10B: sending
    val chatsFlow = remember(repos) { repos.telegram.observeChats() }
    val chats by chatsFlow.collectAsState(initial = emptyList())
    val keysFlow = remember(repos) { repos.sync.observeKeys() }
    val keys by keysFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())
    var tgOn by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    var sending by remember { mutableStateOf(false) }
    var confirmSend by remember { mutableStateOf(false) }
    var sendMsg by remember { mutableStateOf("") }
    var sendBad by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { tgOn = repos.telegram.token() != null }

    fun openLesson(l: LearnContentEntity?) {
        editId = l?.id
        title = l?.title ?: ""
        category = l?.category ?: ""
        body = l?.body ?: ""
        image = l?.imageUrl ?: ""
        video = l?.videoUrl ?: ""
        wasPublished = l?.published ?: false
        confirmDelete = false
        note = ""
        sendMsg = ""
        confirmSend = false
        editing = true
    }

    fun save(publish: Boolean) {
        if (busy) return
        busy = true
        scope.launch {
            when (val r = repos.learn.save(editId, title, body, category, image, video, publish, actor)) {
                is Outcome.Err -> { note = r.message; noteBad = true }
                is Outcome.Ok -> {
                    editId = r.value
                    if (publish) wasPublished = true
                    note = if (publish) "Saved and published." else "Saved."
                    noteBad = false
                }
            }
            busy = false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!editing) {
            ScreenHeader("Learn & Earn", onBack)
            Text(
                "Lessons for your workers. Pictures and videos are links (https), nothing is uploaded. " +
                    "A lesson is only visible to workers once it is published AND you have sent it to them (open a lesson, then SEND TO WORKERS).",
                color = CT.TextSoft, fontSize = 13.sp
            )
            GoldButton(text = "NEW LESSON", modifier = Modifier.fillMaxWidth(), onClick = { openLesson(null) })
            if (all.isEmpty()) EmptyState("📚", "No lessons yet", "Press NEW LESSON to write the first one.")
            for (l in all) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { openLesson(l) }) {
                    Text(l.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        (if (l.published) "PUBLISHED" else "DRAFT") + (if (l.category.isNotEmpty()) " · " + l.category else "") + " · v" + l.version,
                        color = if (l.published) LM_GOOD else CT.TextSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(l.body.take(100), color = CT.TextSoft, fontSize = 12.sp)
                    Text("Changed " + fmtTime(l.updatedAt), color = CT.TextSoft, fontSize = 11.sp)
                }
            }
        } else {
            ScreenHeader(if (editId == null) "New lesson" else "Edit lesson", { editing = false })
            CTField(title, { title = it.take(LearnRepository.TITLE_MAX) }, "Title")
            CTField(category, { category = it.take(LearnRepository.CATEGORY_MAX) }, "Category (optional, e.g. Getting started)")
            CTField(body, { body = it.take(LearnRepository.BODY_MAX) }, "Lesson text", singleLine = false, minLines = 8)
            Text(body.length.toString() + " / " + LearnRepository.BODY_MAX, color = CT.TextSoft, fontSize = 11.sp)
            CTField(image, { image = it.take(LearnRepository.URL_MAX) }, "Picture link (optional, https://…)", keyboard = KeyboardType.Uri)
            CTField(video, { video = it.take(LearnRepository.URL_MAX) }, "Video link (optional, https://…)", keyboard = KeyboardType.Uri)
            if (note.isNotEmpty() && !noteBad) SuccessNote(note)
            if (note.isNotEmpty() && noteBad) Text(note, color = LM_BAD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (editId == null) "Status: not saved yet" else if (wasPublished) "Status: PUBLISHED. Saving changes raises the version so workers get the new text."
                else "Status: DRAFT (workers cannot see it)",
                color = CT.TextSoft, fontSize = 12.sp
            )
            GoldButton(text = if (busy) "SAVING…" else "SAVE AND PUBLISH", modifier = Modifier.fillMaxWidth(), onClick = { save(true) })
            GhostButton(text = "SAVE", modifier = Modifier.fillMaxWidth(), onClick = { save(false) })
            val id = editId
            if (id != null && wasPublished) {
                GhostButton(text = "HIDE FROM WORKERS", modifier = Modifier.fillMaxWidth(), onClick = {
                    if (busy) return@GhostButton
                    busy = true
                    scope.launch {
                        repos.learn.setPublished(id, false, actor)
                        wasPublished = false
                        note = "Hidden. It is a draft again."
                        noteBad = false
                        busy = false
                    }
                })
            }
            if (id != null) {
                GhostButton(text = if (confirmDelete) "TAP AGAIN TO DELETE FOR GOOD" else "DELETE", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                    if (!confirmDelete) { confirmDelete = true; return@GhostButton }
                    if (busy) return@GhostButton
                    busy = true
                    scope.launch {
                        repos.learn.delete(id, actor)
                        busy = false
                        editing = false
                    }
                })
            }
            if (id != null) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Send to workers", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                    Text(
                        "Workers only get a lesson when you send it. The SAVED version is sent, so save first. A published lesson appears in the worker's Learn & Earn; " +
                            "a hidden or draft lesson is taken back from phones that have it. Send again after every change.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    if (tgOn && chats.isNotEmpty()) {
                        GoldButton(
                            text = if (sending) "SENDING…" else if (confirmSend) "TAP AGAIN TO SEND TO ${chats.size} WORKER" + (if (chats.size == 1) "" else "S") else "SEND ON TELEGRAM TO ALL (${chats.size})",
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                if (sending) return@GoldButton
                                if (!confirmSend) { confirmSend = true; return@GoldButton }
                                sending = true
                                confirmSend = false
                                scope.launch {
                                    val lines = repos.telegram.sendLesson(id, actor)
                                    val good = lines.count { it.report.ok }
                                    sendMsg = good.toString() + " of " + lines.size + " sent." + lines.filter { !it.report.ok }.joinToString("") { "\n" + it.workerName + ": " + it.report.message }
                                    sendBad = good < lines.size
                                    sending = false
                                }
                            }
                        )
                    } else {
                        Text("Telegram is not connected, or no worker has a Telegram chat yet. You can copy a code for one worker below.", color = CT.TextSoft, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Copy a code for one worker", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    if (keys.isEmpty()) Text("No worker is connected yet.", color = CT.TextSoft, fontSize = 12.sp)
                    for (k in keys) {
                        val who = workers.firstOrNull { it.id == k.workerId }?.fullName() ?: "(unknown worker)"
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(who, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            GhostButton(text = "COPY CODE", onClick = {
                                val wid = k.workerId
                                scope.launch {
                                    when (val r = repos.sync.makeLearn(wid, id, actor)) {
                                        is Outcome.Err -> { sendMsg = r.message; sendBad = true }
                                        is Outcome.Ok -> {
                                            clipboard.setText(AnnotatedString(r.value.first))
                                            sendMsg = "Copied the code for " + who + ". Paste it into a private chat with them; they open it in CT Team (Share, or the Use it offer)."
                                            sendBad = false
                                        }
                                    }
                                }
                            })
                        }
                    }
                    if (sendMsg.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        if (sendBad) Text(sendMsg, color = LM_BAD, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) else SuccessNote(sendMsg)
                    }
                }
            }
            GhostButton(text = "BACK TO LIST", modifier = Modifier.fillMaxWidth(), onClick = { editing = false })
        }
        Spacer(Modifier.height(8.dp))
    }
}
