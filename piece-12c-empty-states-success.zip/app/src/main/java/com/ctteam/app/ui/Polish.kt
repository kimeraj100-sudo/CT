package com.ctteam.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Piece 12c — finishing touches.
 *  - [EmptyState]: a friendly card instead of a bare "No ... yet." line.
 *  - [SuccessNote]: a green circle that draws itself, then the check mark, with the message beside it.
 * With phone animations off both just appear.
 */
private val PL_GOOD = Color(0xFF5FD6A5)

@Composable
fun EmptyState(icon: String, title: String, hint: String, modifier: Modifier = Modifier) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 34.sp)
            Spacer(Modifier.height(6.dp))
            Text(title, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(hint, color = CT.TextSoft, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun SuccessNote(text: String, modifier: Modifier = Modifier, size: Dp = 26.dp) {
    val still = ctReduceMotion()
    val p = remember(text) { Animatable(if (still) 1f else 0f) }
    LaunchedEffect(text) {
        if (!still) {
            p.snapTo(0f)
            p.animateTo(1f, tween(durationMillis = 560, easing = FastOutSlowInEasing))
        }
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Canvas(Modifier.size(size)) {
            val v = p.value
            val w = 3.dp.toPx()
            // circle: first 60% of the time
            val circle = (v / 0.6f).coerceIn(0f, 1f)
            val inset = w / 2f
            drawArc(
                color = PL_GOOD, startAngle = -90f, sweepAngle = 360f * circle, useCenter = false,
                topLeft = Offset(inset, inset), size = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w),
                style = Stroke(width = w, cap = StrokeCap.Round)
            )
            // check mark: last 40%, short stroke then long stroke
            val t = ((v - 0.55f) / 0.45f).coerceIn(0f, 1f)
            if (t > 0f) {
                val a = Offset(this.size.width * 0.28f, this.size.height * 0.52f)
                val b = Offset(this.size.width * 0.45f, this.size.height * 0.68f)
                val c = Offset(this.size.width * 0.74f, this.size.height * 0.34f)
                val first = (t / 0.4f).coerceIn(0f, 1f)
                val second = ((t - 0.4f) / 0.6f).coerceIn(0f, 1f)
                drawLine(PL_GOOD, a, Offset(a.x + (b.x - a.x) * first, a.y + (b.y - a.y) * first), strokeWidth = w, cap = StrokeCap.Round)
                if (second > 0f) {
                    drawLine(PL_GOOD, b, Offset(b.x + (c.x - b.x) * second, b.y + (c.y - b.y) * second), strokeWidth = w, cap = StrokeCap.Round)
                }
            }
        }
        Text(text, color = PL_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
