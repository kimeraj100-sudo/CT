package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos
import com.ctteam.app.data.WorkerNotice
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Piece 9B-3 — announcements from the manager (kept on this phone, newest first). Shows nothing when there are none. */
private const val NOTICE_SHOWN = 5

@Composable
fun WorkerNoticesCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<WorkerNotice>>(emptyList()) }

    // looks again every few seconds, so a message that was just imported appears without any button
    LaunchedEffect(workerId) {
        while (true) {
            list = repos.sync.notices(workerId)
            delay(4000)
        }
    }
    if (list.isEmpty()) return

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("📣 Messages from the manager", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (n in list.take(NOTICE_SHOWN)) {
                Column {
                    Text(fmtTime(n.at), color = CT.TextSoft, fontSize = 11.sp)
                    Text(n.text, color = Color.White, fontSize = 14.sp)
                }
            }
            if (list.size > NOTICE_SHOWN) Text("… and " + (list.size - NOTICE_SHOWN) + " older.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        GhostButton(text = "CLEAR", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch { repos.sync.clearNotices(workerId); list = emptyList() }
        })
    }
}
