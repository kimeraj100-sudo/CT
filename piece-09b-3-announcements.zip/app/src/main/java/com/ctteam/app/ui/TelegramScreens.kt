package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TgChatEntity
import com.ctteam.app.data.TgInboxEntity
import com.ctteam.app.data.TgKind
import com.ctteam.app.data.TgState
import kotlinx.coroutines.launch

/**
 * Piece 9A — Manager > Telegram.
 * Connect your own free bot, see that it is being read, and handle the few things that need your tap.
 * Everything a worker sends is checked exactly like copy/paste in Sync: signature, replay protection, your approval for
 * connection and reset requests.
 */

private val TG_BAD = Color(0xFFFF8A8A)
private val TG_GOOD = Color(0xFF5FD6A5)

@Composable
fun TelegramScreen(repos: Repos, actor: String, onBack: () -> Unit, onOpenInSync: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val tg = repos.telegram

    val liveFlow = remember(repos) { tg.live }
    val live by liveFlow.collectAsState()
    val chatsFlow = remember(repos) { tg.observeChats() }
    val chats by chatsFlow.collectAsState(initial = emptyList())
    val inboxFlow = remember(repos) { tg.observeInbox(60) }
    val inbox by inboxFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())

    var botName by remember { mutableStateOf<String?>(null) }
    var configured by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var tokenText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var messageBad by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var newCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var announce by remember { mutableStateOf("") }
    var confirmAnnounce by remember { mutableStateOf(false) }

    LaunchedEffect(refresh) {
        configured = tg.token() != null
        botName = tg.botName()
        paused = tg.isPaused()
    }
    // how many things each linked worker has not been sent yet
    LaunchedEffect(chats, refresh) {
        newCounts = chats.associate { it.workerId to repos.sync.pendingUpdateCount(it.workerId) }
    }

    fun nameOf(id: String?): String = workers.firstOrNull { it.id == id }?.fullName() ?: "Worker"

    val pending = inbox.filter { it.status == TgState.PENDING }
    val log = inbox.filter { it.status != TgState.PENDING }.take(25)

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Telegram", onBack)
        Text(
            "Workers send their signed messages to YOUR bot (the Share button in their app, then Telegram). " +
                "This app reads the bot while the manager area is open and checks every message exactly like Sync: signature, one-time numbers, and your approval for new connections.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (message.isNotEmpty()) Text(message, color = if (messageBad) TG_BAD else TG_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        // ------------------------------------------------------------ connect
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            if (!configured) {
                Text("Connect your bot", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "1. In Telegram open @BotFather and send /newbot.\n2. Choose a name and a username ending in bot.\n3. BotFather sends a token (like 123456789:ABC...). Copy it and paste it below.\n" +
                        "Keep the token secret: whoever has it controls the bot. Only this phone should hold it.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                CTField(tokenText, { tokenText = it.trim() }, "Bot token")
                Spacer(Modifier.height(8.dp))
                GoldButton(text = if (busy) "CHECKING…" else "SAVE AND CHECK THE BOT", modifier = Modifier.fillMaxWidth(), onClick = {
                    if (busy) return@GoldButton
                    busy = true
                    val t = tokenText
                    scope.launch {
                        when (val r = tg.connect(t, actor)) {
                            is Outcome.Ok -> { message = "Connected to @" + r.value + "."; messageBad = false; tokenText = "" }
                            is Outcome.Err -> { message = r.message; messageBad = true }
                        }
                        refresh++
                        busy = false
                    }
                })
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Bot @" + (botName ?: "?"), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    val state = when {
                        paused -> "⏸ paused"
                        live.running && live.lastError == null -> "🟢 reading"
                        live.lastError != null -> "🔴 problem"
                        else -> "⚪ waiting"
                    }
                    Text(state, color = Color.White, fontSize = 13.sp)
                }
                Spacer(Modifier.height(4.dp))
                if (live.lastOkAt > 0L) Text("Last successful check: " + fmtTime(live.lastOkAt), color = CT.TextSoft, fontSize = 12.sp)
                Text("Messages used since this app opened: " + live.handledTotal, color = CT.TextSoft, fontSize = 12.sp)
                live.lastError?.let { Text(it, color = TG_BAD, fontSize = 12.sp) }
                Spacer(Modifier.height(8.dp))
                GhostButton(text = "COPY THE BOT LINK FOR WORKERS", modifier = Modifier.fillMaxWidth(), onClick = {
                    clipboard.setText(AnnotatedString("https://t.me/" + (botName ?: "")))
                    message = "Link copied. Send it to your workers."
                    messageBad = false
                })
                Spacer(Modifier.height(6.dp))
                Text(
                    "Each worker opens the link once and presses START. Then in their CT Team app: make a message, tap SHARE, choose Telegram and this bot.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                GhostButton(text = if (paused) "RESUME READING" else "PAUSE READING", modifier = Modifier.fillMaxWidth(), onClick = {
                    scope.launch { tg.setPaused(!paused, actor); refresh++ }
                })
                Spacer(Modifier.height(6.dp))
                if (!confirmRemove) {
                    GhostButton(text = "REMOVE THE BOT FROM THIS APP", danger = true, modifier = Modifier.fillMaxWidth(), onClick = { confirmRemove = true })
                } else {
                    Text("The token is deleted from this phone. Chats stay linked to workers. You can connect the same or another bot again.", color = CT.TextSoft, fontSize = 12.sp)
                    GhostButton(text = "YES, REMOVE IT", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        scope.launch { tg.disconnect(actor); confirmRemove = false; message = "Bot removed."; messageBad = false; refresh++ }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { confirmRemove = false })
                }
            }
        }

        // ------------------------------------------------------------ waiting for you
        Text("Waiting for you (${pending.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (pending.isEmpty()) Text("Nothing is waiting.", color = CT.TextSoft, fontSize = 13.sp)
        for (p in pending) {
            val chat = chats.firstOrNull { it.workerId == p.workerId }
            PendingCard(
                p = p,
                account = if (chat != null) (if (chat.username != null) "@" + chat.username + " " else "") + "(" + chat.firstName + ")" else null,
                canSend = configured && p.kind == TgKind.RESET_REQ && chat != null,
                sending = sending,
                onApproveSend = {
                    if (!sending) {
                        sending = true
                        val id = p.id
                        scope.launch {
                            val r = tg.approveResetAndSend(id, actor)
                            val code = r.manualCode
                            if (code != null) clipboard.setText(AnnotatedString(code))
                            message = r.message
                            messageBad = !r.sent
                            sending = false
                        }
                    }
                },
                onOpen = { scope.launch { tg.markHandled(p.id)?.let { w -> onOpenInSync(w) } } },
                onDismiss = { scope.launch { tg.markHandled(p.id) } }
            )
        }
        if (pending.isNotEmpty()) {
            Text(
                "Opening an item takes it off this list. If you leave Sync without approving, ask the worker to send the message again.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }

        // ------------------------------------------------------------ announcement (9B-3)
        if (configured && chats.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Announcement to all workers", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                Text(
                    "One short message (up to 600 characters). It is signed separately for each worker and shows on their home screen after they tap it in Telegram and Share it to CT Team.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                CTField(announce, { announce = it.take(600); confirmAnnounce = false }, "Your message", singleLine = false, minLines = 3)
                Text(announce.length.toString() + " / 600", color = CT.TextSoft, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                GoldButton(
                    text = if (sending) "SENDING…" else if (confirmAnnounce) "TAP AGAIN TO SEND TO ${chats.size} WORKER" + (if (chats.size == 1) "" else "S") else "SEND TO ALL (${chats.size})",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (sending || announce.isBlank()) return@GoldButton
                        if (!confirmAnnounce) { confirmAnnounce = true; return@GoldButton }
                        sending = true
                        confirmAnnounce = false
                        val text = announce
                        scope.launch {
                            val lines = tg.sendAnnouncement(text, actor)
                            val good = lines.count { it.report.ok }
                            message = good.toString() + " of " + lines.size + " sent." + lines.filter { !it.report.ok }.joinToString("") { "\n" + it.workerName + ": " + it.report.message }
                            messageBad = good < lines.size
                            if (good == lines.size && lines.isNotEmpty()) announce = ""
                            refresh++
                            sending = false
                        }
                    }
                )
            }
        }

        // ------------------------------------------------------------ chats
        Text("Workers with a Telegram chat (${chats.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (chats.isEmpty()) Text("None yet. A chat is linked after the worker's first NEW signed message is accepted.", color = CT.TextSoft, fontSize = 13.sp)
        val waitingWorkers = newCounts.values.count { it > 0 }
        if (configured && waitingWorkers > 0) {
            GoldButton(
                text = if (sending) "SENDING…" else "SEND UPDATES TO ALL ($waitingWorkers worker" + (if (waitingWorkers == 1) "" else "s") + " with new items)",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (!sending) {
                        sending = true
                        scope.launch {
                            val lines = tg.sendAllPending(actor)
                            val good = lines.count { it.report.ok }
                            message = if (lines.isEmpty()) "Nobody had anything new."
                            else good.toString() + " of " + lines.size + " sent." + lines.filter { !it.report.ok }.joinToString("") { "\n" + it.workerName + ": " + it.report.message }
                            messageBad = good < lines.size
                            refresh++
                            sending = false
                        }
                    }
                }
            )
        }
        for (c in chats) {
            val news = newCounts[c.workerId] ?: 0
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(nameOf(c.workerId), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text((if (c.username != null) "@" + c.username + " · " else "") + c.firstName, color = CT.TextSoft, fontSize = 12.sp)
                Text("Last message: " + fmtTime(c.lastSeenAt), color = CT.TextSoft, fontSize = 12.sp)
                if (configured) {
                    Text("Not sent to this worker yet: $news", color = if (news > 0) CT.GoldLight else CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    GoldButton(
                        text = if (sending) "SENDING…" else if (news > 0) "SEND UPDATE ($news new)" else "SEND UPDATE",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            if (!sending) {
                                sending = true
                                val id = c.workerId
                                scope.launch {
                                    val r = tg.sendUpdate(id, false, actor)
                                    message = r.message
                                    messageBad = !r.ok
                                    refresh++
                                    sending = false
                                }
                            }
                        }
                    )
                }
            }
        }

        // ------------------------------------------------------------ log
        Text("Recent activity", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (log.isEmpty()) Text("Nothing yet.", color = CT.TextSoft, fontSize = 13.sp)
        for (l in log) {
            val good = l.kind == TgKind.OK || l.kind == TgKind.SENT
            val bad = l.kind == TgKind.FAIL || l.kind == TgKind.SEND_FAIL
            Text(
                (if (l.kind == TgKind.OK) "✔ " else if (l.kind == TgKind.SENT) "➤ " else if (bad) "✖ " else "• ") + l.title,
                color = if (good) TG_GOOD else if (bad) TG_BAD else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
            Text(fmtTime(l.receivedAt) + " · " + l.detail, color = CT.TextSoft, fontSize = 11.sp)
        }

        Text(
            "Good to know: Telegram bot chats are not end-to-end encrypted, so every message stays signed but can be read by Telegram. " +
                "Only one phone can read a bot at a time. Messages are read while the manager area is open; Telegram keeps unread ones for about a day. " +
                "Updates you send go to the worker's chat with the bot; they tap the message or file, Share, CT Team (or copy it and open the app). Pictures by Telegram come in the next piece.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PendingCard(
    p: TgInboxEntity, account: String?, canSend: Boolean, sending: Boolean,
    onApproveSend: () -> Unit, onOpen: () -> Unit, onDismiss: () -> Unit
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(p.title, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(p.detail, color = Color.White, fontSize = 13.sp)
        Text("Received " + fmtTime(p.receivedAt), color = CT.TextSoft, fontSize = 11.sp)
        if (account != null) Text("From Telegram account: $account", color = CT.TextSoft, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        if (canSend) {
            Text(
                "Approve only if you know it is really this worker (ask them for the check code). A reset lets whoever holds the code choose a new password and PIN.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(6.dp))
            GoldButton(text = if (sending) "PLEASE WAIT" else "APPROVE AND SEND ON TELEGRAM", modifier = Modifier.fillMaxWidth(), onClick = onApproveSend)
            Spacer(Modifier.height(6.dp))
        }
        val label = when (p.kind) {
            TgKind.ENROLL -> "OPEN IN SYNC TO CHECK AND APPROVE"
            TgKind.RESET_REQ -> "OPEN IN SYNC TO APPROVE THE RESET"
            else -> "TRY AGAIN IN SYNC"
        }
        GoldButton(text = label, modifier = Modifier.fillMaxWidth(), onClick = onOpen)
        Spacer(Modifier.height(6.dp))
        GhostButton(text = "DISMISS", danger = true, modifier = Modifier.fillMaxWidth(), onClick = onDismiss)
    }
}
