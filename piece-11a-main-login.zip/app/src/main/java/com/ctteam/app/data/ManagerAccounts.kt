package com.ctteam.app.data

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Up to 20 manager accounts. Each has a code name, a personal PIN and (from Piece 4B) a password.
 * Exactly one is the MAIN manager (isMain = true). The main manager can add managers (the app creates a
 * random, never-used-before PIN), reset a manager back to default, and disable / enable managers.
 * The main manager can never be disabled, removed or reset.
 *
 * ACTIVATION: a manager whose passHash is null is "not activated" (new, or reset to default). They
 * activate with code name + the issued PIN and create their own password.
 */
@Entity(tableName = "manager_accounts", indices = [Index(value = ["codeName"], unique = true)])
data class ManagerAccountEntity(
    @PrimaryKey val id: String,
    val codeName: String,              // always stored UPPERCASE
    val pinSalt: String,               // hex
    val pinHash: String,               // hex, PBKDF2-HMAC-SHA256
    val iterations: Int,               // PIN iterations (older rows 40 000, new rows 100 000)
    val isMain: Boolean,
    val suspendedUntil: Long?,         // UTC millis; null = not suspended; Long.MAX_VALUE = until re-enabled
    val accessExpiresAt: Long?,        // UTC millis; null = no limit; after this the manager is blocked
    val note: String,
    val createdAt: Long,
    // ---- added in Piece 4B (database version 3)
    val passSalt: String? = null,      // hex; null together with passHash = not activated
    val passHash: String? = null,      // "<iterations>:<hex>"
    @ColumnInfo(defaultValue = "1") val credVersion: Int = 1   // +1 on reset / password change / PIN change
) {
    val activated: Boolean get() = passHash != null && passSalt != null
}

@Dao
interface ManagerAccountDao {
    @Insert suspend fun insert(a: ManagerAccountEntity)
    @Update suspend fun update(a: ManagerAccountEntity)
    @Query("DELETE FROM manager_accounts WHERE id = :id AND isMain = 0") suspend fun deleteNonMain(id: String)
    @Query("SELECT * FROM manager_accounts WHERE id = :id") suspend fun get(id: String): ManagerAccountEntity?
    @Query("SELECT * FROM manager_accounts WHERE isMain = 1 LIMIT 1") suspend fun main(): ManagerAccountEntity?
    @Query("SELECT * FROM manager_accounts ORDER BY isMain DESC, createdAt ASC") suspend fun all(): List<ManagerAccountEntity>
    @Query("SELECT * FROM manager_accounts ORDER BY isMain DESC, createdAt ASC") fun observeAll(): Flow<List<ManagerAccountEntity>>
}

/** Units the main manager can pick when disabling / allowing a manager for a period. */
enum class AccessUnit(val label: String, val millis: Long) {
    HOURS("Hours", 3_600_000L),
    DAYS("Days", 86_400_000L),
    WEEKS("Weeks", 7L * 86_400_000L),
    MONTHS("Months", 30L * 86_400_000L),   // 1 month = 30 days
    YEARS("Years", 365L * 86_400_000L);    // 1 year = 365 days

    fun toMillis(amount: Int): Long = amount.toLong() * millis
}

/** A freshly issued PIN. It is shown ONCE to the main manager and is never stored in readable form. */
data class IssuedAccess(val account: ManagerAccountEntity, val pin: String)

object PinHasher {
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    fun newSaltHex(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return hex(b)
    }

    fun hashHex(pin: String, saltHex: String, iterations: Int): String =
        hex(
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(PBEKeySpec(pin.toCharArray(), unhex(saltHex), iterations, 256))
                .encoded
        )

    fun matches(pin: String, a: ManagerAccountEntity): Boolean {
        if (pin.isEmpty()) return false
        return MessageDigest.isEqual(
            hashHex(pin, a.pinSalt, a.iterations).toByteArray(Charsets.UTF_8),
            a.pinHash.toByteArray(Charsets.UTF_8)
        )
    }
}

private fun nowMs() = System.currentTimeMillis()

private fun fmtEat(ms: Long): String {
    val f = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US)
    f.timeZone = TimeZone.getTimeZone("GMT+03:00")
    return f.format(Date(ms))
}

class ManagerAccountRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.managerAccountDao()
    private val sec = db.securityDao()

    companion object {
        const val MAX_MANAGERS = 20
        const val MAIN_CODE_NAME = "MAIN"
        const val FOREVER = Long.MAX_VALUE
        const val BAD_LOGIN = "Code name, password or PIN is not correct."

        // The main manager's first PIN is NOT stored in the app as text, only as this salted hash
        // (made with the older 40 000 iterations). The main manager activates with it once and then
        // creates a password; change the PIN afterwards in Manager > My security.
        private const val SEED_ITERATIONS = 40_000
        private const val SEED_SALT = "c7a1e93b5d204f68b1d3a9e7042c85f6"
        private const val SEED_HASH = "b10e626acdb842e8f97ed0b61aadfb303535e60b07d2758df44f513ea42f6fe3"

        // Piece 11a: the main manager's first PASSWORD is part of the build too (again only a salted hash,
        // format "<iterations>:<hex>" like every stored password). With it the main account is already
        // activated: sign in with code name MAIN + this password + the seed PIN. Both can be changed in
        // Manager > My security. A phone where the main manager already chose their own password keeps it.
        private const val SEED_PASS_SALT = "84035ef35453560e061a26f8a8da8f54"
        private const val SEED_PASS_HASH = "100000:f93d22ae8d87020057a0a89eb2691f8f24d34e106a6ff82fa153a104499b71dd"
        private const val SEED_PIN_FINGERPRINT = "f28c2c5fe1dfda41bc6770974e9c251d792220c20d6c1bd1b25ca718d6aab9b8"   // ledger entry of the seed PIN (hash only)
    }

    private fun actorOf(a: ManagerAccountEntity) = "manager:" + a.codeName

    /** Makes sure the main manager account exists (created the first time the app needs it). */
    suspend fun ensureMain(at: Long = nowMs()) {
        // Piece 5E: a phone that trusts another phone's main manager has no main manager of its own.
        if (db.metaDao().get(ManagerSyncRepository.K_MANAGER_PHONE) == "1") return
        db.withTransaction<Unit> {
            if (dao.main() == null) {
                dao.insert(
                    ManagerAccountEntity(
                        id = "main", codeName = MAIN_CODE_NAME,
                        pinSalt = SEED_SALT, pinHash = SEED_HASH, iterations = SEED_ITERATIONS,
                        isMain = true, suspendedUntil = null, accessExpiresAt = null,
                        note = "", createdAt = at,
                        passSalt = SEED_PASS_SALT, passHash = SEED_PASS_HASH
                    )
                )
                sec.addLedger(PinLedgerEntity(SEED_PIN_FINGERPRINT, at))
                audit.log("system", "MAIN_MANAGER_CREATED", "manager_account", "main", "built-in password", at)
            } else {
                val m = dao.main()!!
                // an older install that never finished activating: give it the built-in password
                if (!m.activated && m.credVersion == 1 && m.pinHash == SEED_HASH) {
                    dao.update(m.copy(passSalt = SEED_PASS_SALT, passHash = SEED_PASS_HASH))
                    audit.log("system", "MAIN_MANAGER_BUILTIN_PASSWORD", "manager_account", "main", "", at)
                }
            }
        }
    }

    /** Why this manager cannot work right now, or null if they can. The main manager is never blocked. */
    fun blockReason(a: ManagerAccountEntity, at: Long = nowMs()): String? {
        if (a.isMain) return null
        val s = a.suspendedUntil
        if (s != null && at < s) {
            return if (s == FOREVER) "Your manager access was disabled by the main manager until it is re-enabled."
            else "Your manager access is disabled until " + fmtEat(s) + " (East Africa Time)."
        }
        val e = a.accessExpiresAt
        if (e != null && at >= e) return "Your allowed access period ended on " + fmtEat(e) + "."
        return null
    }

    /** Short status line for lists. */
    fun statusText(a: ManagerAccountEntity, at: Long = nowMs()): String {
        if (a.isMain) return if (a.activated) "Main manager · always active" else "Main manager · password not created yet"
        val act = if (a.activated) "" else " · Not activated yet"
        val s = a.suspendedUntil
        if (s != null && at < s) {
            return (if (s == FOREVER) "Disabled until re-enabled" else "Disabled until " + fmtEat(s)) + act
        }
        val e = a.accessExpiresAt
        if (e != null) {
            return (if (at >= e) "Access ended " + fmtEat(e) else "Active until " + fmtEat(e)) + act
        }
        return "Active$act"
    }

    fun isBlocked(a: ManagerAccountEntity, at: Long = nowMs()): Boolean = blockReason(a, at) != null

    // ---------------------------------------------------------------- helpers

    private fun normalizeCode(raw: String): String? {
        val c = raw.trim().replace(Regex("\\s+"), " ").uppercase()
        if (c.length < 2 || c.length > 20) return null
        if (!c.all { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_' }) return null
        return c
    }

    /** True if this PIN was EVER issued (ledger) or is any account's current PIN (covers PINs from before Piece 4B). */
    private suspend fun pinTaken(pin: String): Boolean {
        if (sec.ledgerCount(Secrets.fingerprint(pin)) > 0) return true
        return dao.all().any { PinHasher.matches(pin, it) }
    }

    private suspend fun recordPin(pin: String, at: Long) = sec.addLedger(PinLedgerEntity(Secrets.fingerprint(pin), at))

    private suspend fun newUniquePin(length: Int): String? {
        repeat(300) {
            val p = Secrets.randomPin(length)
            if (!pinTaken(p)) return p
        }
        return null
    }

    private suspend fun trust(a: ManagerAccountEntity, at: Long) =
        sec.putTrust(DeviceTrustEntity(a.id, "MANAGER", at, a.credVersion))

    private fun isTrusted(t: DeviceTrustEntity?, a: ManagerAccountEntity, at: Long): Boolean {
        if (t == null) return false
        val age = at - t.trustedAt
        return t.credVersion == a.credVersion && age in 0 until Secrets.TRUST_MS
    }

    /** True if `secret` is this account's PIN (digits) or password (anything else). */
    private fun secretMatches(a: ManagerAccountEntity, secret: String): Boolean {
        if (secret.isEmpty()) return false
        if (Secrets.isDigits(secret)) return PinHasher.matches(secret, a)
        val ps = a.passSalt
        val ph = a.passHash
        return ps != null && ph != null && Secrets.verifyPassword(secret, ps, ph)
    }

    /** The account that may use quick unlock on this phone (activated + full sign-in under 30 days ago), or null. */
    suspend fun quickCandidate(accountId: String, at: Long = nowMs()): ManagerAccountEntity? {
        val a = dao.get(accountId) ?: return null
        if (!a.activated) return null
        return if (isTrusted(sec.trust(a.id), a, at)) a else null
    }

    // ---------------------------------------------------------------- SIGN-IN

    /** Full sign-in: code name + password + PIN. Counts as the "once a month" sign-in on this phone. */
    suspend fun fullLogin(codeRaw: String, password: String, pin: String, at: Long = nowMs()): Auth<ManagerAccountEntity> {
        ensureMain(at)
        val code = normalizeCode(codeRaw)
        if (code == null || password.isEmpty() || pin.isEmpty()) return Auth.Wrong(BAD_LOGIN)
        val a = dao.all().firstOrNull { it.codeName == code }
        if (a == null) {
            audit.event("MANAGER_LOGIN_FAILED", "", at)
            return Auth.Wrong(BAD_LOGIN)
        }
        val ps = a.passSalt
        val ph = a.passHash
        if (ps == null || ph == null) {
            return Auth.Denied("This account is not activated yet. Tap “First time or after a reset” and use the PIN you were given.")
        }
        val passOk = Secrets.verifyPassword(password, ps, ph)
        val pinOk = PinHasher.matches(pin, a)
        if (!(passOk && pinOk)) {
            audit.event("MANAGER_LOGIN_FAILED", "", at)
            return Auth.Wrong(BAD_LOGIN)
        }
        val reason = blockReason(a, at)
        if (reason != null) {
            audit.log(actorOf(a), "MANAGER_LOGIN_BLOCKED", "manager_account", a.id, reason, at)
            return Auth.Denied(reason)
        }
        trust(a, at)
        audit.log(actorOf(a), "MANAGER_LOGIN", "manager_account", a.id, "full", at)
        return Auth.Ok(a)
    }

    /** Quick unlock on a trusted phone: only the PIN OR only the password. */
    suspend fun quick(accountId: String, secretRaw: String, at: Long = nowMs()): Auth<ManagerAccountEntity> {
        val a = dao.get(accountId) ?: return Auth.Denied("Account not found. Sign in with your code name instead.")
        if (!a.activated) return Auth.Denied("This account is not activated yet.")
        if (!isTrusted(sec.trust(a.id), a, at)) {
            return Auth.Denied("For your security please sign in again with code name, password and PIN.")
        }
        val secret = secretRaw.trim()
        if (!secretMatches(a, secret)) {
            audit.event("MANAGER_LOGIN_FAILED", "", at)
            return Auth.Wrong("Wrong PIN or password.")
        }
        val reason = blockReason(a, at)
        if (reason != null) {
            audit.log(actorOf(a), "MANAGER_LOGIN_BLOCKED", "manager_account", a.id, reason, at)
            return Auth.Denied(reason)
        }
        audit.log(actorOf(a), "MANAGER_LOGIN", "manager_account", a.id, "quick", at)
        return Auth.Ok(a)
    }

    /**
     * First sign-in after the main manager created (or reset) the account: code name + the issued PIN,
     * and the manager creates their own password. Works only while the account is not activated.
     */
    suspend fun activate(codeRaw: String, pin: String, newPassword: String, at: Long = nowMs()): Auth<ManagerAccountEntity> {
        ensureMain(at)
        val code = normalizeCode(codeRaw)
        val a = if (code == null) null else dao.all().firstOrNull { it.codeName == code }
        if (a == null || pin.isEmpty()) {
            audit.event("MANAGER_ACTIVATION_FAILED", "", at)
            return Auth.Wrong("Code name or PIN is not correct.")
        }
        if (a.activated) {
            return Auth.Denied("This account is already activated. Use “Sign in” with your password, or ask the main manager to reset it.")
        }
        if (!PinHasher.matches(pin, a)) {
            audit.event("MANAGER_ACTIVATION_FAILED", "", at)
            return Auth.Wrong("Code name or PIN is not correct.")
        }
        val reason = blockReason(a, at)
        if (reason != null) {
            audit.log(actorOf(a), "MANAGER_LOGIN_BLOCKED", "manager_account", a.id, reason, at)
            return Auth.Denied(reason)
        }
        Secrets.passwordError(newPassword)?.let { return Auth.Denied(it) }
        val salt = Secrets.newSaltHex()
        val u = a.copy(
            passSalt = salt, passHash = Secrets.hashPassword(newPassword, salt),
            credVersion = a.credVersion + 1
        )
        db.withTransaction<Unit> {
            dao.update(u)
            recordPin(pin, at)          // PINs from before Piece 4B enter the "ever used" ledger here
            trust(u, at)
            audit.log(actorOf(u), "MANAGER_ACTIVATED", "manager_account", u.id, "", at)
        }
        return Auth.Ok(u)
    }

    // ---------------------------------------------------------------- MY SECURITY (signed-in manager)

    /** Change my own PIN. Needs my current PIN or password. The new PIN is random-unique-checked too. */
    suspend fun changeOwnPin(accountId: String, current: String, newPin: String, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        val a = dao.get(accountId) ?: return Outcome.Err("Account not found.")
        if (!secretMatches(a, current.trim())) return Outcome.Err("Your current PIN or password is not correct.")
        Secrets.pinError(newPin, Secrets.MANAGER_PIN_MIN, Secrets.MANAGER_PIN_MAX)?.let { return Outcome.Err(it) }
        if (pinTaken(newPin)) return Outcome.Err("That PIN has been used before. Choose a different PIN.")
        val salt = Secrets.newSaltHex()
        val u = a.copy(
            pinSalt = salt, pinHash = Secrets.hashPin(newPin, salt), iterations = Secrets.PIN_ITERATIONS,
            credVersion = a.credVersion + 1
        )
        db.withTransaction<Unit> {
            dao.update(u)
            recordPin(newPin, at)
            trust(u, at)
            audit.log(actorOf(u), "MANAGER_PIN_CHANGED", "manager_account", u.id, "self", at)
        }
        return Outcome.Ok(u)
    }

    /** Change my own password. Needs my current PIN or password (so a forgotten password can be replaced while the PIN still works). */
    suspend fun changeOwnPassword(accountId: String, current: String, newPassword: String, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        val a = dao.get(accountId) ?: return Outcome.Err("Account not found.")
        if (!secretMatches(a, current.trim())) return Outcome.Err("Your current PIN or password is not correct.")
        Secrets.passwordError(newPassword)?.let { return Outcome.Err(it) }
        val salt = Secrets.newSaltHex()
        val u = a.copy(passSalt = salt, passHash = Secrets.hashPassword(newPassword, salt), credVersion = a.credVersion + 1)
        db.withTransaction<Unit> {
            dao.update(u)
            trust(u, at)
            audit.log(actorOf(u), "MANAGER_PASSWORD_CHANGED", "manager_account", u.id, "self", at)
        }
        return Outcome.Ok(u)
    }

    /** Ends the 30-day trust on this phone: next time the manager must do a full sign-in. */
    suspend fun forgetThisDevice(accountId: String) = sec.clearTrust(accountId)

    /** When this phone's full sign-in for the account stops counting, or null if it is not trusted now. */
    suspend fun trustedUntil(a: ManagerAccountEntity, at: Long = nowMs()): Long? {
        val t = sec.trust(a.id)
        return if (isTrusted(t, a, at)) t!!.trustedAt + Secrets.TRUST_MS else null
    }

    // ---------------------------------------------------------------- MAIN MANAGER TOOLS

    /** Creates a manager with a random PIN (6–10 digits) that has never been issued before. Shown once. */
    suspend fun issueNew(by: ManagerAccountEntity, codeNameRaw: String, pinLength: Int, at: Long = nowMs()): Outcome<IssuedAccess> {
        if (!by.isMain) return Outcome.Err("Only the main manager can add managers.")
        val code = normalizeCode(codeNameRaw)
            ?: return Outcome.Err("Code name must be 2 to 20 letters, digits, spaces, - or _.")
        if (pinLength !in Secrets.MANAGER_PIN_MIN..Secrets.MANAGER_PIN_MAX)
            return Outcome.Err("PIN length must be from ${Secrets.MANAGER_PIN_MIN} to ${Secrets.MANAGER_PIN_MAX} digits.")
        return db.withTransaction<Outcome<IssuedAccess>> {
            val all = dao.all()
            if (all.size >= MAX_MANAGERS) return@withTransaction Outcome.Err("The limit of $MAX_MANAGERS managers is reached.")
            if (all.any { it.codeName == code }) return@withTransaction Outcome.Err("That code name is already used.")
            val pin = newUniquePin(pinLength) ?: return@withTransaction Outcome.Err("Could not create a new PIN. Try a longer PIN.")
            val salt = Secrets.newSaltHex()
            val a = ManagerAccountEntity(
                id = UUID.randomUUID().toString(), codeName = code,
                pinSalt = salt, pinHash = Secrets.hashPin(pin, salt), iterations = Secrets.PIN_ITERATIONS,
                isMain = false, suspendedUntil = null, accessExpiresAt = null, note = "", createdAt = at
            )
            dao.insert(a)
            recordPin(pin, at)
            audit.log(actorOf(by), "MANAGER_ADDED", "manager_account", a.id, code + " (PIN issued)", at)
            Outcome.Ok(IssuedAccess(a, pin))
        }
    }

    /**
     * Puts a manager back to default: password removed, a NEW random never-used PIN issued, and every
     * phone's 30-day trust for this manager is void. The manager must activate again with the new PIN.
     */
    suspend fun resetToDefault(by: ManagerAccountEntity, targetId: String, pinLength: Int, at: Long = nowMs()): Outcome<IssuedAccess> {
        if (!by.isMain) return Outcome.Err("Only the main manager can reset managers.")
        if (pinLength !in Secrets.MANAGER_PIN_MIN..Secrets.MANAGER_PIN_MAX)
            return Outcome.Err("PIN length must be from ${Secrets.MANAGER_PIN_MIN} to ${Secrets.MANAGER_PIN_MAX} digits.")
        return db.withTransaction<Outcome<IssuedAccess>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager cannot be reset.")
            val pin = newUniquePin(pinLength) ?: return@withTransaction Outcome.Err("Could not create a new PIN. Try a longer PIN.")
            val salt = Secrets.newSaltHex()
            val u = t.copy(
                pinSalt = salt, pinHash = Secrets.hashPin(pin, salt), iterations = Secrets.PIN_ITERATIONS,
                passSalt = null, passHash = null, credVersion = t.credVersion + 1
            )
            dao.update(u)
            sec.clearTrust(t.id)
            recordPin(pin, at)
            audit.log(actorOf(by), "MANAGER_RESET_TO_DEFAULT", "manager_account", t.id, t.codeName + " (new PIN issued)", at)
            Outcome.Ok(IssuedAccess(u, pin))
        }
    }

    /** Disable a manager for durationMs, or until re-enabled when durationMs is null. */
    suspend fun disable(by: ManagerAccountEntity, targetId: String, durationMs: Long?, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can disable managers.")
        if (durationMs != null && durationMs <= 0) return Outcome.Err("Choose a period longer than zero.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager cannot be disabled.")
            val until = if (durationMs == null) FOREVER else at + durationMs
            val u = t.copy(suspendedUntil = until, accessExpiresAt = null)
            dao.update(u)
            val shown = if (until == FOREVER) "until re-enabled" else "until " + fmtEat(until)
            audit.log(actorOf(by), "MANAGER_DISABLED", "manager_account", t.id, t.codeName + " " + shown, at)
            Outcome.Ok(u)
        }
    }

    /** Allow a manager to work only for durationMs from now; after that they are blocked. */
    suspend fun allowFor(by: ManagerAccountEntity, targetId: String, durationMs: Long, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can change access.")
        if (durationMs <= 0) return Outcome.Err("Choose a period longer than zero.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager is always active.")
            val end = at + durationMs
            val u = t.copy(suspendedUntil = null, accessExpiresAt = end)
            dao.update(u)
            audit.log(actorOf(by), "MANAGER_ALLOWED_FOR_PERIOD", "manager_account", t.id, t.codeName + " until " + fmtEat(end), at)
            Outcome.Ok(u)
        }
    }

    /** Remove every restriction now. */
    suspend fun enableNow(by: ManagerAccountEntity, targetId: String, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can enable managers.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            val u = t.copy(suspendedUntil = null, accessExpiresAt = null)
            dao.update(u)
            audit.log(actorOf(by), "MANAGER_ENABLED", "manager_account", t.id, t.codeName, at)
            Outcome.Ok(u)
        }
    }

    suspend fun rename(by: ManagerAccountEntity, targetId: String, newCodeRaw: String, at: Long = nowMs()): Outcome<Unit> {
        if (!by.isMain) return Outcome.Err("Only the main manager can rename managers.")
        val code = normalizeCode(newCodeRaw)
            ?: return Outcome.Err("Code name must be 2 to 20 letters, digits, spaces, - or _.")
        return db.withTransaction<Outcome<Unit>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (dao.all().any { it.id != t.id && it.codeName == code }) return@withTransaction Outcome.Err("That code name is already used.")
            dao.update(t.copy(codeName = code))
            audit.log(actorOf(by), "MANAGER_RENAMED", "manager_account", t.id, t.codeName + " -> " + code, at)
            Outcome.Ok(Unit)
        }
    }

    suspend fun remove(by: ManagerAccountEntity, targetId: String, at: Long = nowMs()): Outcome<Unit> {
        if (!by.isMain) return Outcome.Err("Only the main manager can remove managers.")
        return db.withTransaction<Outcome<Unit>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager cannot be removed.")
            dao.deleteNonMain(t.id)
            sec.clearTrust(t.id)
            audit.log(actorOf(by), "MANAGER_REMOVED", "manager_account", t.id, t.codeName, at)
            Outcome.Ok(Unit)
        }
    }
}
