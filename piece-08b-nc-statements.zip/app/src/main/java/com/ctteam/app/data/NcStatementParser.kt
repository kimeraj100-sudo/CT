package com.ctteam.app.data

import java.math.BigDecimal
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Piece 8B — reads NC Wallet statement text (pasted, from a text file, or from a PDF via [PdfText]).
 *
 * LAYOUT-FREE, like the Piece 7 payment statement reader: for every line it looks for
 *   - a date and time (read as UTC — NC Wallet statements are in UTC),
 *   - a coin (BNB, USDT ... a known coin symbol, or an UPPERCASE word next to a number),
 *   - the amount, kept as EXACT text (never a float),
 *   - an optional row number at the start of the line.
 * A line that wraps onto the next line(s) is joined back when none of the pieces is a row on its own.
 *
 * It only reads. The amount sign is kept as written (a "-" stays), so Piece 8D can decide what counts.
 */
class NcParsedRow(
    val rowNo: String,
    val coin: String,
    val amountText: String,       // exact text, no commas, no leading +
    val occurredAtUtc: Long,
    val raw: String
)

class NcParseResult(val rows: List<NcParsedRow>, val skippedLines: Int)

object NcStatementParser {
    private val KNOWN = setOf(
        "BNB", "BTC", "ETH", "USDT", "USDC", "BUSD", "TRX", "SOL", "XRP", "ADA", "DOGE", "LTC", "MATIC",
        "DOT", "SHIB", "TON", "AVAX", "LINK", "BCH", "XLM", "DAI", "FDUSD", "TUSD"
    )
    private val STOP = setOf(
        "UTC", "EAT", "GMT", "AM", "PM", "ID", "TX", "TXID", "NA", "FEE", "OK", "USD", "UGX", "TO", "FROM",
        "IN", "OUT", "ROW", "NO", "HASH", "DATE", "TIME", "COIN", "AMOUNT", "TYPE", "STATUS", "DEPOSIT",
        "WITHDRAW", "TRANSFER", "SUCCESS", "COMPLETED", "PENDING", "BSC", "BEP20", "ERC20", "TRC20",
        "NETWORK", "WALLET", "ADDRESS"
    )
    private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

    private val ISO = Regex("(\\d{4})[-/.](\\d{1,2})[-/.](\\d{1,2})[T ,]+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?(?:\\.\\d+)?\\s*(AM|PM|am|pm)?")
    private val DMY = Regex("(\\d{1,2})[-/.](\\d{1,2})[-/.](\\d{4})[T ,]+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*(AM|PM|am|pm)?")
    private val MDY_NAME = Regex("([A-Za-z]{3,9})\\.?\\s+(\\d{1,2}),?\\s+(\\d{4})[T ,]+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*(AM|PM|am|pm)?")
    private val DMY_NAME = Regex("(\\d{1,2})[\\s-]+([A-Za-z]{3,9})\\.?[\\s-]+(\\d{4})[T ,]+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*(AM|PM|am|pm)?")
    private val NUM = Regex("^[+-]?(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?$")
    private val COIN_SHAPE = Regex("^[A-Z]{2,10}$")
    private val GLUE = Regex("(?<![A-Za-z0-9_])([+-]?\\d[\\d,]*(?:\\.\\d+)?)(?=[A-Z]{2,6}(?![A-Za-z0-9]))")   // 0.5BNB -> 0.5 BNB
    private val SPACES = Regex("\\s+")

    private class TimeHit(val millis: Long, val range: IntRange)

    private fun build(y: Int, mo: Int, d: Int, h: Int, mi: Int, s: Int, ap: String): Long? {
        return try {
            var hh = h
            if (ap.isNotEmpty()) {
                if (hh < 1 || hh > 12) return null
                hh %= 12
                if (ap.equals("PM", ignoreCase = true)) hh += 12
            }
            LocalDateTime.of(y, mo, d, hh, mi, s).toInstant(ZoneOffset.UTC).toEpochMilli()
        } catch (e: Exception) {
            null
        }
    }

    private fun monthOf(name: String): Int {
        val i = MONTHS.indexOf(name.take(3).lowercase())
        return if (i < 0) 0 else i + 1
    }

    private fun findTime(line: String): TimeHit? {
        ISO.find(line)?.let { m ->
            val g = m.groupValues
            build(g[1].toInt(), g[2].toInt(), g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7])
                ?.let { return TimeHit(it, m.range) }
        }
        DMY.find(line)?.let { m ->
            val g = m.groupValues
            var day = g[1].toInt()
            var month = g[2].toInt()
            if (month > 12 && day <= 12) { val t = day; day = month; month = t }     // 10/25/2026 style
            build(g[3].toInt(), month, day, g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7])
                ?.let { return TimeHit(it, m.range) }
        }
        MDY_NAME.find(line)?.let { m ->
            val g = m.groupValues
            val month = monthOf(g[1])
            if (month > 0) {
                build(g[3].toInt(), month, g[2].toInt(), g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7])
                    ?.let { return TimeHit(it, m.range) }
            }
        }
        DMY_NAME.find(line)?.let { m ->
            val g = m.groupValues
            val month = monthOf(g[2])
            if (month > 0) {
                build(g[3].toInt(), month, g[1].toInt(), g[4].toInt(), g[5].toInt(), g[6].toIntOrNull() ?: 0, g[7])
                    ?.let { return TimeHit(it, m.range) }
            }
        }
        return null
    }

    /** Reads ONE row out of a line (or of lines joined together). Null when it is not a statement row. */
    fun parseLine(line: String): NcParsedRow? {
        val hit = findTime(line) ?: return null
        val rest = (line.substring(0, hit.range.first) + " " + line.substring(hit.range.last + 1)).replace(GLUE, "\$1 ")
        val tokens = rest.split(SPACES)
            .map { tk -> tk.trim { it in ",;:()[]|\"'" } }
            .filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null

        var nums = tokens.indices.filter { NUM.matches(tokens[it]) }
        var rowNo = ""
        if (0 in nums && nums.size >= 2 && tokens[0].all { it.isDigit() }) {
            rowNo = tokens[0]
            nums = nums.filter { it != 0 }
        }
        if (nums.isEmpty()) return null

        var ci = tokens.indexOfFirst { it.uppercase() in KNOWN && !NUM.matches(it) }
        if (ci < 0) {
            ci = tokens.indices.firstOrNull { i ->
                val tk = tokens[i]
                COIN_SHAPE.matches(tk) && tk !in STOP && ((i - 1) in nums || (i + 1) in nums)
            } ?: -1
        }
        if (ci < 0) return null

        val amountIdx: Int = when {
            (ci - 1) in nums -> ci - 1
            (ci + 1) in nums -> ci + 1
            else -> nums.firstOrNull { '.' in tokens[it] } ?: nums.first()
        }
        val amountText = tokens[amountIdx].replace(",", "").removePrefix("+")
        val value = try { BigDecimal(amountText) } catch (e: Exception) { return null }
        if (value.signum() == 0) return null

        return NcParsedRow(rowNo, tokens[ci].uppercase(), amountText, hit.millis, line.trim())
    }

    fun parse(text: String): NcParseResult {
        val lines = text.replace("\r", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<NcParsedRow>()
        var skipped = 0
        var i = 0
        while (i < lines.size) {
            val one = parseLine(lines[i])
            if (one != null) {
                out.add(one)
                i += 1
                continue
            }
            var merged: NcParsedRow? = null
            var used = 1
            if (i + 1 < lines.size && parseLine(lines[i + 1]) == null) {
                merged = parseLine(lines[i] + " " + lines[i + 1])
                used = 2
                if (merged == null && i + 2 < lines.size && parseLine(lines[i + 2]) == null) {
                    merged = parseLine(lines[i] + " " + lines[i + 1] + " " + lines[i + 2])
                    used = 3
                }
            }
            if (merged != null) {
                out.add(merged)
                i += used
            } else {
                skipped += 1
                i += 1
            }
        }
        return NcParseResult(out, skipped)
    }

    /** "0.50" and "0.5" are the same amount: used inside the row key so the same row is never stored twice. */
    fun normalizedAmount(text: String): String =
        try { BigDecimal(text).stripTrailingZeros().toPlainString() } catch (e: Exception) { text }

    /**
     * `coin|amount|utcMillis` (stops overlapping statements counting a row twice). When one statement really
     * contains the same coin, amount and second twice, the repeats get `#2`, `#3` ...
     */
    fun rowKeys(rows: List<NcParsedRow>): List<String> {
        val seen = HashMap<String, Int>()
        return rows.map { r ->
            val base = r.coin + "|" + normalizedAmount(r.amountText) + "|" + r.occurredAtUtc
            val n = (seen[base] ?: 0) + 1
            seen[base] = n
            if (n == 1) base else "$base#$n"
        }
    }
}
