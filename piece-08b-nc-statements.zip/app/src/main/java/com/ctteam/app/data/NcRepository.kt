package com.ctteam.app.data

import androidx.room.withTransaction

/** What an import did. */
class NcImportResult(
    val statementId: Long,
    val rowsRead: Int,
    val added: Int,
    val alreadyKnown: Int,
    val skippedLines: Int
)

/** How many rows a statement added when it was the first to contain them. */
data class StatementAdded(val statementId: Long, val n: Int)

/**
 * Piece 8B — stores NC Wallet statements and their rows.
 *  - The same statement text twice is refused.
 *  - Rows already known (same coin, amount and UTC second, from an earlier overlapping statement) are not stored again.
 *    A row keeps its matched / unmatched state forever, so a later statement can never undo a match.
 */
class NcRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.ncDao()

    /** Hash of the statement text with spacing ignored, so the same statement pasted twice is recognised. */
    fun textHash(text: String): String =
        Hashing.sha256Hex(text.replace("\r", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n"))

    suspend fun importStatement(
        fileName: String, text: String, actor: String, at: Long = System.currentTimeMillis()
    ): Outcome<NcImportResult> {
        val parsed = NcStatementParser.parse(text)
        if (parsed.rows.isEmpty()) {
            return Outcome.Err("No NC Wallet rows were found. Each row needs a date and time, a coin and an amount.")
        }
        val sha = textHash(text)
        return db.withTransaction<Outcome<NcImportResult>> {
            val before = dao.statementBySha(sha)
            if (before != null) {
                return@withTransaction Outcome.Err("This exact statement was already imported (" + before.fileName + ").")
            }
            val sid = dao.insertStatement(
                NcStatementEntity(
                    fileName = fileName.ifBlank { "Pasted text" }.take(120),
                    fileSha256 = sha, importedAt = at, rowCount = parsed.rows.size
                )
            )
            val keys = NcStatementParser.rowKeys(parsed.rows)
            var added = 0
            var known = 0
            for (i in parsed.rows.indices) {
                val r = parsed.rows[i]
                val id = dao.insertRow(
                    NcRowEntity(
                        statementId = sid, rowKey = keys[i], rowNo = r.rowNo, coin = r.coin,
                        amountText = r.amountText, occurredAtUtc = r.occurredAtUtc
                    )
                )
                if (id == -1L) known += 1 else added += 1
            }
            audit.log(
                actor, "NC_STATEMENT_IMPORTED", "nc_statement", sid.toString(),
                "rows=" + parsed.rows.size + " new=" + added + " known=" + known, at
            )
            Outcome.Ok(NcImportResult(sid, parsed.rows.size, added, known, parsed.skippedLines))
        }
    }
}
