package com.ctteam.app.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.text.input.KeyboardType
import com.ctteam.app.data.LockoutStore
import com.ctteam.app.data.Auth
import com.ctteam.app.data.JoinPreview
import com.ctteam.app.data.Secrets
import com.ctteam.app.data.WorkerEntity
import com.ctteam.app.data.MetaEntity
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.EnrollPreview
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ReportResult
import com.ctteam.app.data.SyncIncoming
import com.ctteam.app.data.SyncRepository
import com.ctteam.app.data.SyncStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Piece 5A — screens for the signed-message core. Piece 5B adds worker reports and the manager's payout list. Piece 5C adds manager updates (tasks, decisions, payments, account on/off). Piece 5D adds username uniqueness, reset codes and JOIN codes.
 *  - Worker phone: [WorkerSyncCard] shows the key code, makes the enrollment message and a test message.
 *  - Manager phone: [ManagerSyncScreen] imports pasted text or a file, asks approval for enrollments,
 *    verifies test messages, lists connected workers.
 * Messages move by copy / share / save-as-file; nothing here needs internet.
 */

private val OK_GREEN = Color(0xFF3DDC97)
private val BAD_RED = Color(0xFFFF8A8A)
private const val MAX_IMPORT_BYTES = 300_000

/** Shows one generated message with COPY / SHARE / SAVE AS FILE. */
@Composable
private fun CodeOutput(label: String, code: String, fileName: String, who: String = "the manager") {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var note by remember(code) { mutableStateOf("") }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) } != null
                    } catch (ex: Exception) {
                        false
                    }
                }
                note = if (ok) "File saved." else "Could not save the file."
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            code.take(48) + "…  (" + code.length + " characters)",
            color = CT.TextSoft, fontSize = 11.sp, fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = "COPY",
            modifier = Modifier.fillMaxWidth(),
            onClick = { clipboard.setText(AnnotatedString(code)); note = "Copied. Paste it into a private chat with $who." }
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "SHARE", modifier = Modifier.weight(1f), onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, code)
                }
                context.startActivity(Intent.createChooser(send, "Send to $who"))
            })
            GhostButton(text = "SAVE AS FILE", modifier = Modifier.weight(1f), onClick = { saver.launch(fileName) })
        }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(note, color = OK_GREEN, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ WORKER PHONE

@Composable
private fun ConnectCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    var keyCheck by remember { mutableStateOf("") }
    var enrollment by remember { mutableStateOf<String?>(null) }
    var test by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(false) }

    LaunchedEffect(workerId) {
        val k = repos.sync.ensureKey(workerId)
        keyCheck = repos.sync.keyCheckOf(k.keyHex)
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Connect to the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Your reports and the manager's replies travel as signed messages that only you and the manager can make. " +
                "Do this once: send your connection code to the manager in a PRIVATE chat, never in a group.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        if (keyCheck.isNotEmpty()) InfoRow("Your key code", keyCheck)
        Text("The manager sees the same code when adding you. Read it to them by phone to be sure nobody swapped the message.", color = CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        if (!open) {
            GhostButton(text = "SHOW CONNECTION OPTIONS", modifier = Modifier.fillMaxWidth(), onClick = { open = true })
        } else {
            GoldButton(text = "MAKE MY CONNECTION CODE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeEnrollment(workerId)) {
                        is Outcome.Ok -> { enrollment = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            enrollment?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Connection code (send to the manager once)", it, "ct-connect.txt") }
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "MAKE A TEST MESSAGE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeTest(workerId, "Test from the worker app")) {
                        is Outcome.Ok -> { test = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            test?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Test message (each one can be accepted only once)", it, "ct-test.txt") }
            if (message.isNotEmpty()) Text(message, color = BAD_RED, fontSize = 12.sp)
        }
    }
}

/** Cards on the worker home screen (real worker only, never in the demo): connect + send reports. */
@Composable
fun WorkerSyncCard(repos: Repos, workerId: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ConnectCard(repos, workerId)
        ReportCard(repos, workerId)
        UpdatesCard(repos, workerId)
        UsernameCard(repos, workerId)
    }
}

@Composable
private fun ReportCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val dm = LocalContext.current.resources.displayMetrics
    val device = dm.widthPixels.toString() + "x" + dm.heightPixels
    val subsFlow = remember(repos, workerId) { repos.db.submissionDao().observeForWorker(workerId) }
    val subs by subsFlow.collectAsState(initial = emptyList())
    val paysFlow = remember(repos, workerId) { repos.db.payoutDao().observeForWorker(workerId) }
    val pays by paysFlow.collectAsState(initial = emptyList())
    var unsent by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var choice by remember { mutableStateOf(SyncRepository.SCOPE_NEW) }
    var report by remember { mutableStateOf<ReportResult?>(null) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(subs, pays, tick) { unsent = repos.sync.unsentCount(workerId) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Reports to the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Send your submissions, payout requests and payout-number changes to the manager as signed messages. " +
                "The manager can only pay what they approve on their own phone.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        InfoRow("Not reported yet", unsent.toString())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("New only", choice == SyncRepository.SCOPE_NEW, { choice = SyncRepository.SCOPE_NEW }, Modifier.weight(1f))
            CTChip("This week", choice == SyncRepository.SCOPE_THIS_WEEK, { choice = SyncRepository.SCOPE_THIS_WEEK }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("Last week", choice == SyncRepository.SCOPE_LAST_WEEK, { choice = SyncRepository.SCOPE_LAST_WEEK }, Modifier.weight(1f))
            CTChip("Everything", choice == SyncRepository.SCOPE_ALL, { choice = SyncRepository.SCOPE_ALL }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (choice == SyncRepository.SCOPE_NEW) "Only things never reported before."
            else "Makes the same messages again (a weekly file). Messages the manager already has are ignored, so sending twice is safe.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(text = "MAKE REPORT", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                error = ""
                when (val r = repos.sync.makeReport(workerId, choice, device)) {
                    is Outcome.Ok -> { report = r.value; tick++ }
                    is Outcome.Err -> { report = null; error = r.message }
                }
            }
        })
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(error, color = BAD_RED, fontSize = 12.sp)
        }
        report?.let { r ->
            Spacer(Modifier.height(8.dp))
            Text(
                r.total.toString() + " message(s) in " + r.parts.size + " part(s), " + r.newCount + " new. Send EVERY part to the manager in a PRIVATE chat.",
                color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
            r.parts.forEachIndexed { i, part ->
                Spacer(Modifier.height(8.dp))
                CodeOutput("Part " + (i + 1) + " of " + r.parts.size + " (" + part.messages + " messages)", part.text, "ct-report-" + (i + 1) + ".txt")
            }
            if (r.parts.size > 1) {
                Spacer(Modifier.height(8.dp))
                CodeOutput("Everything in one file", r.fullText, "ct-report.txt")
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "A report holds fingerprints and details of your screenshots, not the pictures. If the manager asks for the original pictures, send them as a File/Document (not as a photo).",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun UpdatesCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var pasted by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<SyncIncoming.Done>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    fun process(text: String) {
        if (busy) return
        busy = true
        results = emptyList()
        scope.launch {
            results = repos.sync.receiveFromManager(workerId, text)
            busy = false
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { ins ->
                            val buf = ByteArray(MAX_IMPORT_BYTES + 1)
                            var n = 0
                            while (n < buf.size) {
                                val r = ins.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            if (n > MAX_IMPORT_BYTES) null else String(buf, 0, n, Charsets.UTF_8)
                        }
                    } catch (ex: Exception) {
                        null
                    }
                }
                if (text == null) results = listOf(SyncIncoming.Done(false, "Could not read the file", "The file is unreadable or too large for a CT Team update."))
                else process(text)
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Updates from the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "New tasks, approvals and rejections, payments and account changes arrive as signed messages. " +
                "Paste or open everything the manager sent you; only messages made for you are used, and each only once.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        CTField(pasted, { pasted = it }, "Paste the manager's update here", singleLine = false, minLines = 2)
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "USE PASTED UPDATE",
            modifier = Modifier.fillMaxWidth(),
            onClick = { if (pasted.isNotBlank()) { val t = pasted; pasted = ""; process(t) } }
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.weight(1f), onClick = {
                val t = clipboard.getText()?.text ?: ""
                if (t.isNotBlank()) process(t)
                else results = listOf(SyncIncoming.Done(false, "Clipboard is empty", "Copy the manager's update first."))
            })
            GhostButton(text = "OPEN FILE", modifier = Modifier.weight(1f), onClick = { picker.launch(arrayOf("*/*")) })
        }
        if (results.isNotEmpty()) {
            val good = results.count { it.ok }
            Spacer(Modifier.height(8.dp))
            Text(
                results.size.toString() + " checked: " + good + " accepted, " + (results.size - good) + " not accepted.",
                color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
            for (r in results) {
                Spacer(Modifier.height(6.dp))
                Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) OK_GREEN else BAD_RED, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(r.detail, color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun UsernameCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    var current by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(workerId, tick) { current = repos.workerAuth.username(workerId) ?: "" }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Change my username", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Every worker needs a username nobody else has. If the manager tells you yours is taken, change it here, then send a new report or connection code.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        if (current.isNotEmpty()) InfoRow("Current username", current)
        CTField(newName, { newName = it }, "New username")
        Spacer(Modifier.height(6.dp))
        CTField(secret, { secret = it }, "Current PIN or password", keyboard = KeyboardType.Password, secret = true)
        if (message.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(message, color = if (message.startsWith("Done")) OK_GREEN else BAD_RED, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        GhostButton(text = "CHANGE USERNAME", modifier = Modifier.fillMaxWidth(), onClick = {
            val n = newName; val c = secret
            scope.launch {
                when (val r = repos.sync.changeUsername(workerId, n, c)) {
                    is Outcome.Ok -> { message = "Done. Your username is now " + r.value + "."; newName = ""; secret = ""; tick++ }
                    is Outcome.Err -> message = r.message
                }
            }
        })
    }
}

private fun waitText(ms: Long): String = if (ms >= 60_000L) ((ms + 59_999L) / 60_000L).toString() + " min" else ((ms + 999L) / 1000L).toString() + " s"

/** Forgot password or PIN, for a worker whose manager has their key: needs a one-time reset code made by the manager. */
@Composable
fun RecoverWithCodeScreen(repos: Repos, worker: WorkerEntity, onDone: () -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var code by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:worker-recover") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Forgot password or PIN", onBack)
        Text(
            "Phone the manager and ask for a RESET CODE for you. They make it in their app and send it to you privately. " +
                "It works once and for 3 days. Paste it here, then choose a new password and PIN. Your username stays the same.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(code, { code = it }, "Paste the reset code here", singleLine = false, minLines = 3)
        GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.fillMaxWidth(), onClick = { code = clipboard.getText()?.text ?: "" })
        CTField(pass, { pass = it }, "New password", keyboard = KeyboardType.Password, secret = true)
        CTField(pass2, { pass2 = it }, "Repeat new password", keyboard = KeyboardType.Password, secret = true)
        CTField(pin, { pin = it.filter { c -> c.isDigit() }.take(Secrets.WORKER_PIN_MAX) }, "New PIN (" + Secrets.WORKER_PIN_MIN + "–" + Secrets.WORKER_PIN_MAX + " digits)", keyboard = KeyboardType.NumberPassword, secret = true)
        CTField(pin2, { pin2 = it.filter { c -> c.isDigit() }.take(Secrets.WORKER_PIN_MAX) }, "Repeat new PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        if (message.isNotEmpty()) Text(message, color = BAD_RED, fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "RESET MY LOGIN",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (!busy) {
                    message = ""
                    if (code.isBlank()) message = "Paste the reset code first."
                    else if (pass != pass2) message = "The two passwords do not match."
                    else if (pin != pin2) message = "The two PINs do not match."
                    else {
                        busy = true
                        val t = code; val a = pass; val b = pin
                        scope.launch {
                            val rem = lock.remainingMs()
                            if (rem > 0) {
                                message = "Too many wrong tries. Wait " + waitText(rem) + "."
                                busy = false
                                return@launch
                            }
                            val r = withContext(Dispatchers.Default) { repos.sync.recoverWithCode(worker.id, t, a, b) }
                            busy = false
                            when (r) {
                                is Auth.Ok -> { lock.clear(); onDone() }
                                is Auth.Wrong -> {
                                    message = r.message
                                    val l = lock.recordFailure()
                                    if (l > 0) message = "Too many wrong tries. Locked for " + waitText(l) + "."
                                }
                                is Auth.Denied -> message = r.message
                            }
                        }
                    }
                }
            }
        )
    }
}

/** New phone / reinstall: the manager made a JOIN code; the worker checks the key code by voice, then creates a new login. */
@Composable
fun JoinWorkerScreen(repos: Repos, onJoined: (String) -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var code by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<JoinPreview?>(null) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Join with a code from the manager", onBack)
        Text(
            "Use this on a NEW phone (or after reinstalling) if you already work for the manager. Ask them for a JOIN code. " +
                "It brings your name and payout number to this phone. You then choose a new username, password and PIN.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(code, { code = it; preview = null }, "Paste the JOIN code here", singleLine = false, minLines = 3)
        GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.fillMaxWidth(), onClick = { code = clipboard.getText()?.text ?: ""; preview = null })
        GoldButton(text = if (busy) "PLEASE WAIT" else "CHECK THE CODE", modifier = Modifier.fillMaxWidth(), onClick = {
            if (!busy && code.isNotBlank()) {
                busy = true
                message = ""
                val t = code
                scope.launch {
                    when (val r = repos.sync.previewJoin(t)) {
                        is Outcome.Ok -> preview = r.value
                        is Outcome.Err -> { preview = null; message = r.message }
                    }
                    busy = false
                }
            }
        })
        if (message.isNotEmpty()) Text(message, color = BAD_RED, fontSize = 13.sp)
        preview?.let { p ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                InfoRow("Name", p.fullName)
                InfoRow("Payout number", p.phoneLocal + " (" + p.network + ")")
                InfoRow("KEY CODE", p.keyCheck)
                Spacer(Modifier.height(4.dp))
                Text("Read the key code to the manager by phone. Continue only if it is identical to the code they see for you.", color = CT.TextSoft, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                if (p.problem != null) {
                    Text("Cannot join: " + p.problem, color = BAD_RED, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    GoldButton(text = if (busy) "PLEASE WAIT" else "KEY CODE MATCHES — JOIN", modifier = Modifier.fillMaxWidth(), onClick = {
                        if (!busy) {
                            busy = true
                            val t = code
                            scope.launch {
                                when (val r = repos.sync.acceptJoin(t)) {
                                    is Outcome.Ok -> {
                                        repos.db.metaDao().put(MetaEntity(WORKER_META_KEY, r.value))
                                        onJoined(r.value)
                                    }
                                    is Outcome.Err -> message = r.message
                                }
                                busy = false
                            }
                        }
                    })
                }
            }
        }
    }
}

// ------------------------------------------------------------------ MANAGER PHONE

private class SyncRow(val workerId: String, val name: String, val status: SyncStatus?, val news: Int)

@Composable
private fun EnrollCard(preview: EnrollPreview, busy: Boolean, onApprove: () -> Unit, onCancel: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("New connection request", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        InfoRow("Name", preview.fullName)
        InfoRow("National ID", preview.nationalId)
        InfoRow("Payout number", preview.phoneLocal + " (" + preview.network + ")")
        InfoRow("KEY CODE", preview.keyCheck)
        Spacer(Modifier.height(4.dp))
        Text(
            "Ask the worker to read their key code aloud (phone call). Approve only if it is identical to the code above.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (preview.warning != null) {
            Spacer(Modifier.height(6.dp))
            Text(preview.warning, color = CT.GoldLight, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (preview.problem != null) {
            Text("Cannot approve: " + preview.problem, color = BAD_RED, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else if (preview.mode == "ALREADY") {
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else {
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "KEY CODE MATCHES — APPROVE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (!busy) onApprove() }
            )
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CANCEL", onClick = onCancel, modifier = Modifier.fillMaxWidth(), danger = true)
        }
    }
}

@Composable
fun ManagerSyncScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var pasted by remember { mutableStateOf("") }
    var queue by remember { mutableStateOf<List<SyncIncoming.Enroll>>(emptyList()) }
    var results by remember { mutableStateOf<List<SyncIncoming.Done>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var resetAsk by remember { mutableStateOf<String?>(null) }
    var held by remember { mutableStateOf<List<String>>(emptyList()) }
    var payAsk by remember { mutableStateOf<String?>(null) }
    var payMsg by remember { mutableStateOf("") }
    var updateFor by remember { mutableStateOf<String?>(null) }
    var update by remember { mutableStateOf<ReportResult?>(null) }
    var updateErr by remember { mutableStateOf("") }
    var codeFor by remember { mutableStateOf<String?>(null) }
    var codeKind by remember { mutableStateOf("") }
    var codeText by remember { mutableStateOf("") }
    var codeErr by remember { mutableStateOf("") }
    val payFlow = remember(repos) { repos.db.payoutDao().observeInProgress() }
    val payouts by payFlow.collectAsState(initial = emptyList())

    val keysFlow = remember(repos) { repos.sync.observeKeys() }
    val keys by keysFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())
    var rows by remember { mutableStateOf<List<SyncRow>>(emptyList()) }
    LaunchedEffect(keys, workers, refresh) {
        rows = keys.map { k ->
            SyncRow(k.workerId, workers.firstOrNull { it.id == k.workerId }?.fullName() ?: "(unknown)", repos.sync.status(k.workerId), repos.sync.pendingUpdateCount(k.workerId))
        }
    }

    fun process(text: String) {
        if (busy) return
        busy = true
        results = emptyList()
        queue = emptyList()
        held = emptyList()
        scope.launch {
            val all = repos.sync.receiveAll(text, actor)
            queue = all.filterIsInstance<SyncIncoming.Enroll>()
            results = all.filterIsInstance<SyncIncoming.Done>()
            held = results.mapNotNull { it.retryWire }
            refresh++
            busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { ins ->
                            val buf = ByteArray(MAX_IMPORT_BYTES + 1)
                            var n = 0
                            while (n < buf.size) {
                                val r = ins.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            if (n > MAX_IMPORT_BYTES) null else String(buf, 0, n, Charsets.UTF_8)
                        }
                    } catch (ex: Exception) {
                        null
                    }
                }
                if (text == null) results = listOf(SyncIncoming.Done(false, "Could not read the file", "The file is unreadable or too large for a CT Team message."))
                else process(text)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Sync", onBack)
        Text(
            "Messages from workers arrive as text or a small file (copy, Telegram, share). Paste or open them here, one or many at once. " +
                "Every message is checked with the worker's secret key and can only be accepted once. " +
                "Submissions go to Review; amounts always come from YOUR tasks and YOUR approvals, never from the worker's phone.",
            color = CT.TextSoft, fontSize = 13.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Import a message", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            CTField(pasted, { pasted = it }, "Paste one or many messages here", singleLine = false, minLines = 3)
            Spacer(Modifier.height(8.dp))
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "CHECK PASTED MESSAGE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (pasted.isNotBlank()) { val t = pasted; pasted = ""; process(t) } }
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.weight(1f), onClick = {
                    val t = clipboard.getText()?.text ?: ""
                    if (t.isNotBlank()) process(t)
                    else results = listOf(SyncIncoming.Done(false, "Clipboard is empty", "Copy the worker's message first."))
                })
                GhostButton(text = "OPEN FILE", modifier = Modifier.weight(1f), onClick = { filePicker.launch(arrayOf("*/*")) })
            }
        }

        queue.firstOrNull()?.let { p ->
            if (queue.size > 1) Text("Connection request 1 of " + queue.size, color = CT.TextSoft, fontSize = 12.sp)
            EnrollCard(
                preview = p.preview, busy = busy,
                onCancel = { queue = queue.drop(1) },
                onApprove = {
                    busy = true
                    val t = p.wire
                    scope.launch {
                        val r = repos.sync.acceptEnrollment(t, actor)
                        results = results + when (r) {
                            is Outcome.Ok -> SyncIncoming.Done(true, "Worker connected", r.value)
                            is Outcome.Err -> SyncIncoming.Done(false, "Not approved", r.message)
                        }
                        val rest = queue.drop(1)
                        queue = rest
                        if (rest.isEmpty() && held.isNotEmpty()) {
                            // messages that were only waiting for this worker to be connected are tried again now
                            val again = repos.sync.receiveAll(held.joinToString("\n"), actor).filterIsInstance<SyncIncoming.Done>()
                            held = again.mapNotNull { it.retryWire }
                            results = results.filter { it.retryWire == null } + again
                        }
                        refresh++
                        busy = false
                    }
                }
            )
        }

        if (results.size > 1) {
            val good = results.count { it.ok }
            Text(
                results.size.toString() + " messages checked: " + good + " accepted, " + (results.size - good) + " not accepted.",
                color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
        }
        for (r in results) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) OK_GREEN else BAD_RED, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(r.detail, color = Color.White, fontSize = 13.sp)
            }
        }

        val importedCount = results.count { it.imported }
        if (importedCount > 0) {
            Text(
                importedCount.toString() + " item(s) imported. New submissions are waiting in \"Review submissions\" on the dashboard; read any ⚠ lines before approving.",
                color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
        }

        Text("Payout requests waiting (${payouts.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (payouts.isEmpty()) Text("None. A worker's payout request appears here after you import their report.", color = CT.TextSoft, fontSize = 13.sp)
        if (payMsg.isNotEmpty()) Text(payMsg, color = BAD_RED, fontSize = 12.sp)
        for (p in payouts) {
            val wn = workers.firstOrNull { it.id == p.workerId }?.fullName() ?: "(unknown worker)"
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(wn, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                InfoRow("Amount", ugx(p.amountUgx))
                InfoRow("Send to", "0" + p.phone.substring(3) + " (" + p.network + ")")
                InfoRow("Week of", p.weekKey)
                InfoRow("Requested", fmtTime(p.requestedAt))
                if (p.note.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ " + p.note, color = CT.GoldLight, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (payAsk == p.id) {
                    Text("Tap YES only after the money was really sent. A paid record cannot be changed back.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    GoldButton(text = "YES, I SENT IT — MARK PAID", modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = p.id
                        scope.launch {
                            val r = repos.payouts.confirmPaid(id, "MANUAL", null, null, "Marked paid by hand (Sync screen)", actor)
                            payMsg = if (r is Outcome.Err) r.message else ""
                            payAsk = null
                        }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { payAsk = null })
                } else {
                    GhostButton(text = "MARK AS PAID", modifier = Modifier.fillMaxWidth(), onClick = { payAsk = p.id })
                }
            }
        }

        Text("Connected workers (${rows.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (rows.isEmpty()) Text("No worker is connected yet. A worker makes a connection code in their app (Connect to the manager).", color = CT.TextSoft, fontSize = 13.sp)
        for (row in rows) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(row.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                row.status?.let {
                    InfoRow("Key code", it.keyCheck)
                    InfoRow("Messages received", it.received.toString() + (if (it.lastSeq > 0) " (latest #" + it.lastSeq + ")" else ""))
                }
                Spacer(Modifier.height(6.dp))
                InfoRow("Updates not sent yet", row.news.toString())
                Spacer(Modifier.height(6.dp))
                GoldButton(
                    text = if (row.news > 0) "MAKE UPDATE (" + row.news + " new)" else "MAKE UPDATE",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val id = row.workerId
                        scope.launch {
                            updateErr = ""
                            updateFor = id
                            when (val r = repos.sync.makeUpdate(id, false)) {
                                is Outcome.Ok -> { update = r.value; refresh++ }
                                is Outcome.Err -> { update = null; updateErr = r.message }
                            }
                        }
                    }
                )
                Spacer(Modifier.height(6.dp))
                GhostButton(text = "SEND EVERYTHING AGAIN", modifier = Modifier.fillMaxWidth(), onClick = {
                    val id = row.workerId
                    scope.launch {
                        updateErr = ""
                        updateFor = id
                        when (val r = repos.sync.makeUpdate(id, true)) {
                            is Outcome.Ok -> { update = r.value; refresh++ }
                            is Outcome.Err -> { update = null; updateErr = r.message }
                        }
                    }
                })
                if (updateFor == row.workerId) {
                    if (updateErr.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(updateErr, color = BAD_RED, fontSize = 12.sp)
                    }
                    update?.let { u ->
                        Spacer(Modifier.height(8.dp))
                        Text(
                            u.total.toString() + " message(s) in " + u.parts.size + " part(s), " + u.newCount + " new. Send EVERY part to " + row.name + " in a PRIVATE chat. Only " + row.name + "'s phone accepts them.",
                            color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                        )
                        u.parts.forEachIndexed { i, part ->
                            Spacer(Modifier.height(8.dp))
                            CodeOutput("Part " + (i + 1) + " of " + u.parts.size + " (" + part.messages + " messages)", part.text, "ct-update-" + (i + 1) + ".txt", row.name)
                        }
                        if (u.parts.size > 1) {
                            Spacer(Modifier.height(8.dp))
                            CodeOutput("Everything in one file", u.fullText, "ct-update.txt", row.name)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton(text = "RESET CODE", modifier = Modifier.weight(1f), onClick = {
                        val id = row.workerId
                        scope.launch {
                            codeFor = id; codeKind = "RESET"; codeErr = ""; codeText = ""
                            when (val r = repos.sync.makeResetCode(id, actor)) {
                                is Outcome.Ok -> codeText = r.value
                                is Outcome.Err -> codeErr = r.message
                            }
                        }
                    })
                    GhostButton(text = "JOIN CODE", modifier = Modifier.weight(1f), onClick = {
                        val id = row.workerId
                        scope.launch {
                            codeFor = id; codeKind = "JOIN"; codeErr = ""; codeText = ""
                            when (val r = repos.sync.makeJoinCode(id, actor)) {
                                is Outcome.Ok -> codeText = r.value
                                is Outcome.Err -> codeErr = r.message
                            }
                        }
                    })
                }
                if (codeFor == row.workerId) {
                    if (codeErr.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(codeErr, color = BAD_RED, fontSize = 12.sp)
                    }
                    if (codeText.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        if (codeKind == "RESET") {
                            Text(
                                "Give this reset code ONLY to " + row.name + ", after you are sure it is really them (call them). It works once and for 3 days.",
                                color = CT.GoldLight, fontSize = 12.sp
                            )
                            Spacer(Modifier.height(6.dp))
                            CodeOutput("Reset code for " + row.name, codeText, "ct-reset.txt", row.name)
                        } else {
                            Text(
                                "Send this JOIN code privately to " + row.name + " for a NEW phone. They must read you the key code " +
                                    (row.status?.keyCheck ?: "") + " to confirm. Then use SEND EVERYTHING AGAIN to give the new phone the tasks. Valid for 3 days; if it leaks, use RESET SYNC KEY.",
                                color = CT.GoldLight, fontSize = 12.sp
                            )
                            Spacer(Modifier.height(6.dp))
                            CodeOutput("Join code for " + row.name, codeText, "ct-join.txt", row.name)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (resetAsk == row.workerId) {
                    Text(
                        "This forgets the worker's key and message history. They must connect again and you must compare the key code. Use it only after a reinstall or a new phone.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "YES, RESET SYNC KEY", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = row.workerId
                        scope.launch { repos.sync.resetKey(id, actor); resetAsk = null; refresh++ }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = null })
                } else {
                    GhostButton(text = "RESET SYNC KEY", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = row.workerId })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
