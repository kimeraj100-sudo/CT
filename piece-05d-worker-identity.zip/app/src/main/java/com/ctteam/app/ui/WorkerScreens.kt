package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Auth
import com.ctteam.app.data.LockoutStore
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PayoutStatus
import com.ctteam.app.data.ProofInput
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TimeUtil
import com.ctteam.app.data.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Key in the `meta` table that remembers which worker is registered on THIS phone. */
const val WORKER_META_KEY = "this_device_worker_id"

private sealed interface WPhase {
    object Loading : WPhase
    object Register : WPhase
    class Setup(val workerId: String) : WPhase
    class Gate(val workerId: String, val quickName: String?) : WPhase
    class Recover(val workerId: String) : WPhase
    class Home(val workerId: String) : WPhase
    object Demo : WPhase
    object Existing : WPhase
    object Join : WPhase
}

private suspend fun decidePhase(repos: Repos): WPhase {
    val id = repos.db.metaDao().get(WORKER_META_KEY) ?: return WPhase.Register
    if (!repos.workerAuth.hasCredentials(id)) return WPhase.Setup(id)
    val quick = repos.workerAuth.quickAvailable(id)
    val name = repos.db.workerDao().get(id)?.firstName
    return WPhase.Gate(id, if (quick) (name ?: "") else null)
}

/**
 * Entry point of Worker mode (Piece 4B, demo added in 4C1):
 * register once on this phone (with username, password and PIN) -> every time Worker mode opens the worker
 * unlocks with PIN or password (quick, for 30 days after a full sign-in) or username + password + PIN.
 * Typing "demo" in every sign-in field opens the in-memory demo worker (never touches the database).
 */
@Composable
fun WorkerArea(onExit: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val repos = remember { ServiceLocator.get(context) }
    val areaScope = rememberCoroutineScope()
    var phase by remember { mutableStateOf<WPhase>(WPhase.Loading) }

    LaunchedEffect(Unit) { phase = decidePhase(repos) }

    when (val p = phase) {
        is WPhase.Loading -> {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Opening…", color = CT.TextSoft)
            }
        }
        is WPhase.Register -> RegisterWorkerScreen(
            repos = repos, onExit = onExit,
            onRegistered = { newId -> phase = WPhase.Home(newId) },
            onDemo = { phase = WPhase.Demo },
            onExisting = { phase = WPhase.Existing },
            onJoin = { phase = WPhase.Join }
        )
        is WPhase.Join -> JoinWorkerScreen(
            repos = repos,
            onJoined = { id -> phase = WPhase.Setup(id) },
            onBack = { areaScope.launch { phase = decidePhase(repos) } }
        )
        is WPhase.Existing -> ExistingWorkerLoginScreen(
            repos = repos,
            onDone = { id -> phase = WPhase.Home(id) },
            onDemo = { phase = WPhase.Demo },
            onBack = { areaScope.launch { phase = decidePhase(repos) } }
        )
        is WPhase.Setup -> {
            var worker by remember(p.workerId) { mutableStateOf<WorkerEntity?>(null) }
            LaunchedEffect(p.workerId) { worker = repos.db.workerDao().get(p.workerId) }
            val w = worker
            if (w != null) {
                SetupWorkerLoginScreen(repos = repos, worker = w, onDone = { phase = WPhase.Home(p.workerId) }, onExit = onExit)
            }
        }
        is WPhase.Gate -> {
            val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:worker") }
            CredentialGate(
                title = "Worker sign-in",
                subtitle = "Sign in with your username, password and PIN.",
                idLabel = "Username",
                notice = "",
                quickName = p.quickName,
                lock = lock,
                onQuick = { secret -> repos.workerAuth.quick(p.workerId, secret).toGate() },
                onFull = { id, password, pin -> repos.workerAuth.fullLogin(p.workerId, id, password, pin).toGate() },
                onActivate = null,
                onForgot = { phase = WPhase.Recover(p.workerId) },
                onDone = { phase = WPhase.Home(p.workerId) },
                onExit = onExit,
                allowDemo = true,
                onDemo = { phase = WPhase.Demo }
            )
        }
        is WPhase.Recover -> {
            var worker by remember(p.workerId) { mutableStateOf<WorkerEntity?>(null) }
            LaunchedEffect(p.workerId) { worker = repos.db.workerDao().get(p.workerId) }
            var connected by remember(p.workerId) { mutableStateOf<Boolean?>(null) }
            LaunchedEffect(p.workerId) { connected = repos.sync.hasHeardFromManager(p.workerId) }
            val w = worker
            val c = connected
            if (w != null && c != null) {
                if (c) {
                    // the manager holds this worker's key: only a manager-made reset code can reset the login
                    RecoverWithCodeScreen(
                        repos = repos, worker = w,
                        onDone = { phase = WPhase.Home(p.workerId) },
                        onBack = { phase = WPhase.Gate(p.workerId, null) }
                    )
                } else {
                    RecoverWorkerScreen(
                        repos = repos, worker = w,
                        onDone = { phase = WPhase.Home(p.workerId) },
                        onBack = { phase = WPhase.Gate(p.workerId, null) }
                    )
                }
            }
        }
        is WPhase.Home -> WorkerHomeScreen(repos = repos, workerId = p.workerId, onExit = onExit)
        is WPhase.Demo -> WorkerDemoScreen(onLeave = { areaScope.launch { phase = decidePhase(repos) } })
    }
}

// ------------------------------------------------------------------ REGISTRATION

@Composable
private fun RegisterWorkerScreen(repos: Repos, onExit: () -> Unit, onRegistered: (String) -> Unit, onDemo: () -> Unit, onExisting: () -> Unit, onJoin: () -> Unit) {
    val scope = rememberCoroutineScope()
    var nin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var middle by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var ownName by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Register as a worker", onExit)
        GhostButton(text = "I ALREADY HAVE AN ACCOUNT", onClick = onExisting, modifier = Modifier.fillMaxWidth())
        GhostButton(text = "I HAVE A JOIN CODE FROM THE MANAGER", onClick = onJoin, modifier = Modifier.fillMaxWidth())
        Text(
            "Fill in your details exactly as they appear on your National ID. You only do this once on this phone.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        Text(
            "Just looking around? Type demo in the username, password and PIN boxes below, then tap REGISTER to open a demo worker.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        CTField(nin, { nin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(14) }, "National ID number")
        CTField(first, { first = it }, "First name")
        CTField(middle, { middle = it }, "Middle name (optional)")
        CTField(last, { last = it }, "Last name")
        CTField(phone, { phone = it }, "MTN or Airtel number (e.g. 0772123456)", keyboard = KeyboardType.Phone)
        Text(
            "Payouts go to this number. It must be registered in your own name. " +
                "You can change it only once a week, and never while a payout is in progress.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("This number is in my own name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(checked = ownName, onCheckedChange = { ownName = it })
        }
        Text("Create your login", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "You sign in with your username, password and PIN. After that, on this phone you can unlock with just your PIN or just your password for 30 days.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        WorkerLoginFields(username, { username = it }, pass, { pass = it }, pass2, { pass2 = it }, pin, { pin = it }, pin2, { pin2 = it }, allowDemo = true)
        if (message.isNotEmpty()) Text(message, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "REGISTER",
            onClick = {
                if (!busy) {
                    message = ""
                    if (WorkerDemo.isDemoLogin(username, pass, pin)) {
                        onDemo()
                    } else if (!ownName) {
                        message = "Please confirm the number is registered in your own name."
                    } else if (pass != pass2) {
                        message = "The two passwords do not match."
                    } else if (pin != pin2) {
                        message = "The two PINs do not match."
                    } else {
                        busy = true
                        scope.launch {
                            val loginError = withContext(Dispatchers.Default) { repos.workerAuth.checkNew(username, pass, pin) }
                            if (loginError != null) {
                                message = loginError
                                busy = false
                                return@launch
                            }
                            val r = repos.workers.register(nin, first, middle, last, phone)
                            if (r is Outcome.Err) {
                                message = r.message
                            } else if (r is Outcome.Ok) {
                                repos.db.metaDao().put(MetaEntity(WORKER_META_KEY, r.value.id))
                                val c = withContext(Dispatchers.Default) { repos.workerAuth.create(r.value.id, username, pass, pin) }
                                if (c is Outcome.Err) {
                                    message = c.message
                                } else {
                                    onRegistered(r.value.id)
                                }
                            }
                            busy = false
                        }
                    }
                }
            }
        )
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ HOME (shared by the real worker and the demo)

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier, onClick: (() -> Unit)? = null) {
    GlassCard(modifier = modifier, onClick = onClick) {
        Text(value, color = CT.GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CT.TextSoft, fontSize = 12.sp)
    }
}

/**
 * Worker home + the small route state (WRoute). Real data and demo data both come in as WorkerHomeData.
 * `extra` is drawn at the bottom of the home screen (real: change payout number + security; demo: exit button).
 * Tasks, Submit, History and Payout are all real screens (4C1–4C4).
 */
@Composable
private fun WorkerShell(
    data: WorkerHomeData,
    demo: Boolean,
    onExit: () -> Unit,
    onSend: suspend (taskId: String, proofs: List<ProofInput>, reference: String, explanation: String) -> Outcome<Unit>,
    loadProofs: suspend (submissionId: String) -> List<WProof>,
    onRequestPayout: suspend (weekKey: String) -> Outcome<Unit>,
    extra: @Composable ColumnScope.() -> Unit
) {
    var route by remember { mutableStateOf<WRoute>(WRoute.Home) }

    BackHandler(enabled = route !is WRoute.Home) {
        route = when (val r = route) {
            is WRoute.Submit -> WRoute.TaskDetail(r.taskId)
            is WRoute.TaskDetail -> WRoute.Tasks
            else -> WRoute.Home
        }
    }

    val tasks = if (data.active) data.tasks else emptyList()

    when (val r = route) {
        is WRoute.Home -> {
            val ready = tasks.count { it.state == TaskState.AVAILABLE }
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ScreenHeader("Hello, " + data.firstName, onExit)
                if (demo) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("DEMO MODE", color = CT.Gold, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 14.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Everything here is made up so you can see how the worker side looks. Nothing is saved and nothing is real.",
                            color = CT.TextSoft, fontSize = 13.sp
                        )
                    }
                }
                if (!data.active) {
                    Text("Your account is disabled by the manager. Contact support.", color = Color(0xFFFF8A8A), fontSize = 13.sp)
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    InfoRow("Name", data.fullName)
                    if (data.username.isNotBlank()) InfoRow("Username", data.username)
                    InfoRow("National ID", data.nationalId)
                    InfoRow("Payout number", data.payoutNumber + " (" + data.network + ")")
                    InfoRow("Registered", fmtTime(data.registeredAt))
                }

                Text("This week (Mon–Sun)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SummaryTile("Expected payout", ugx(data.expectedUgx), Modifier.weight(1f), onClick = { route = WRoute.Payout })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SummaryTile("Pending", data.pending.toString(), Modifier.weight(1f), onClick = { route = WRoute.History })
                    SummaryTile("Approved", data.approved.toString(), Modifier.weight(1f), onClick = { route = WRoute.History })
                    SummaryTile("Rejected", data.rejected.toString(), Modifier.weight(1f), onClick = { route = WRoute.History })
                }
                val inProgress = data.payouts.firstOrNull { it.status == PayoutStatus.IN_PROGRESS }
                if (inProgress != null) {
                    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { route = WRoute.Payout }) {
                        Text("🟡 Payout in progress", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            ugx(inProgress.amountUgx) + " to " + inProgress.phone + ". Waiting for the manager to send it.",
                            color = CT.TextSoft, fontSize = 12.sp
                        )
                    }
                }

                GoldButton(
                    text = if (ready > 0) "MY TASKS ($ready)" else "MY TASKS",
                    onClick = { route = WRoute.Tasks },
                    modifier = Modifier.fillMaxWidth()
                )
                GhostButton(text = "SUBMISSIONS & EARNINGS", onClick = { route = WRoute.History }, modifier = Modifier.fillMaxWidth())
                GhostButton(text = "REQUEST PAYOUT", onClick = { route = WRoute.Payout }, modifier = Modifier.fillMaxWidth())

                extra()
            }
        }
        is WRoute.Tasks -> WorkerTaskListScreen(
            tasks = tasks,
            accountActive = data.active,
            onOpen = { id -> route = WRoute.TaskDetail(id) },
            onBack = { route = WRoute.Home }
        )
        is WRoute.TaskDetail -> WorkerTaskDetailScreen(
            task = tasks.firstOrNull { it.id == r.taskId },
            accountActive = data.active,
            onSubmit = { route = WRoute.Submit(r.taskId) },
            onBack = { route = WRoute.Tasks }
        )
        is WRoute.Submit -> WorkerSubmitScreen(
            task = tasks.firstOrNull { it.id == r.taskId },
            demo = demo,
            onSend = onSend,
            onBackToTasks = { route = WRoute.Tasks },
            onBack = { route = WRoute.TaskDetail(r.taskId) }
        )
        is WRoute.History -> WorkerHistoryScreen(
            subs = data.submissions,
            loadProofs = loadProofs,
            onBack = { route = WRoute.Home }
        )
        is WRoute.Payout -> WorkerPayoutScreen(
            subs = data.submissions,
            payouts = data.payouts,
            payoutNumber = data.payoutNumber,
            network = data.network,
            accountActive = data.active,
            onRequest = onRequestPayout,
            onBack = { route = WRoute.Home }
        )
    }
}

// ------------------------------------------------------------------ REAL WORKER HOME

@Composable
private fun WorkerHomeScreen(repos: Repos, workerId: String, onExit: () -> Unit) {
    val scope = rememberCoroutineScope()
    val workerFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workerFlow.collectAsState(initial = emptyList())
    val worker = workers.firstOrNull { it.id == workerId }

    val subFlow = remember(repos, workerId) { repos.db.submissionDao().observeForWorker(workerId) }
    val subs by subFlow.collectAsState(initial = emptyList())

    val payoutFlow = remember(repos, workerId) { repos.db.payoutDao().observeForWorker(workerId) }
    val payoutRows by payoutFlow.collectAsState(initial = emptyList())

    val taskFlow = remember(repos) { repos.db.taskDao().observeAll() }
    val allTasks by taskFlow.collectAsState(initial = emptyList())

    // Re-check the clock every 30 s so daily tasks come back (and the week rolls over) while the screen is open.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            nowMs = System.currentTimeMillis()
        }
    }
    val week = TimeUtil.weekKey(nowMs)
    val day = TimeUtil.dayKey(nowMs)

    var expected by remember { mutableStateOf(0L) }
    var username by remember { mutableStateOf("") }
    LaunchedEffect(workerId) { username = repos.workerAuth.username(workerId) ?: "" }
    var newPhone by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(subs, payoutRows, workerId, week) { expected = repos.submissions.expectedForWeek(workerId, week) }
    val cards = remember(allTasks, subs, day) { buildTaskCards(allTasks, subs, nowMs) }
    val subCards = remember(allTasks, subs) { buildSubCards(subs, allTasks) }
    val payoutCards = remember(payoutRows) { payoutRows.map { toWPayout(it) } }
    val weekSubs = subs.filter { it.weekKey == week && !it.superseded }

    if (worker == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            ScreenHeader("Worker", onExit)
            Text("Loading…", color = CT.TextSoft)
        }
        return
    }

    val data = WorkerHomeData(
        firstName = worker.firstName,
        fullName = worker.fullName(),
        username = username,
        nationalId = worker.nationalId,
        payoutNumber = "0" + worker.phone.substring(3),
        network = worker.network,
        registeredAt = worker.createdAt,
        active = worker.active,
        expectedUgx = expected,
        pending = weekSubs.count { it.status == SubStatus.PENDING },
        approved = weekSubs.count { it.status == SubStatus.APPROVED },
        rejected = weekSubs.count { it.status == SubStatus.REJECTED },
        tasks = cards,
        submissions = subCards,
        payouts = payoutCards
    )

    WorkerShell(
        data = data, demo = false, onExit = onExit,
        onSend = { taskId, proofs, reference, explanation ->
            when (val r = repos.submissions.submit(worker.id, taskId, proofs, reference, explanation)) {
                is Outcome.Ok -> Outcome.Ok(Unit)
                is Outcome.Err -> Outcome.Err(r.message)
            }
        },
        loadProofs = { id -> repos.db.submissionDao().proofsFor(id).map { toWProof(it) } },
        onRequestPayout = { weekKey ->
            when (val r = repos.payouts.request(worker.id, weekKey)) {
                is Outcome.Ok -> Outcome.Ok(Unit)
                is Outcome.Err -> Outcome.Err(r.message)
            }
        }
    ) {
        Text("Change payout number", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Allowed once per week, and not while a payout is in progress. The number must be in your own name.", color = CT.TextSoft, fontSize = 12.sp)
        CTField(newPhone, { newPhone = it }, "New MTN / Airtel number", keyboard = KeyboardType.Phone)
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)
        GhostButton(text = "CHANGE NUMBER", onClick = {
            scope.launch {
                val r = repos.workers.changePhone(worker.id, newPhone, "worker:" + worker.id)
                if (r is Outcome.Err) {
                    message = r.message
                } else {
                    message = "Phone number changed."
                    newPhone = ""
                }
            }
        })
        Spacer(Modifier.height(8.dp))
        WorkerSyncCard(repos = repos, workerId = worker.id)
        Spacer(Modifier.height(8.dp))
        WorkerSecurityCard(repos = repos, workerId = worker.id)
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ DEMO WORKER (in memory only)

@Composable
private fun WorkerDemoScreen(onLeave: () -> Unit) {
    var data by remember { mutableStateOf(WorkerDemo.homeData()) }
    WorkerShell(
        data = data, demo = true, onExit = onLeave,
        onSend = { taskId, _, _, _ ->
            // Memory only: the task simply moves to "waiting for review" in the demo.
            val d = data
            val t = d.tasks.firstOrNull { it.id == taskId }
            val now = System.currentTimeMillis()
            val added = if (t == null) emptyList() else listOf(
                WSub(
                    id = "demo-new-" + now, taskName = t.name, payUgx = t.payUgx, status = SubStatus.PENDING,
                    weekKey = TimeUtil.weekKey(now), submittedAt = now, decidedAt = null, decisionNote = "",
                    referenceText = "", explanation = "", inPayout = false, superseded = false
                )
            )
            data = d.copy(
                submissions = added + d.submissions,
                pending = d.pending + 1,
                tasks = d.tasks.map {
                    if (it.id == taskId) it.copy(state = TaskState.WAITING, note = "Your proof was sent. The manager has not reviewed it yet.") else it
                }.sortedBy { it.state.ordinal }
            )
            Outcome.Ok(Unit)
        },
        loadProofs = { id -> WorkerDemo.proofsFor(id) },
        onRequestPayout = { weekKey ->
            // Memory only: nothing is written anywhere. The made-up payout stays In progress until the demo is left.
            val d = data
            val ready = d.submissions.filter { it.weekKey == weekKey && it.status == SubStatus.APPROVED && !it.inPayout && !it.superseded }
            val total = ready.sumOf { it.payUgx }
            when {
                d.payouts.any { it.status == PayoutStatus.IN_PROGRESS } ->
                    Outcome.Err("You already have a payout in progress.")
                d.payouts.any { it.weekKey == weekKey } ->
                    Outcome.Err("A payout for that week was already requested.")
                total <= 0 ->
                    Outcome.Err("Nothing approved to pay for that week yet.")
                else -> {
                    val now = System.currentTimeMillis()
                    val newSubs = d.submissions.map {
                        if (it in ready) it.copy(inPayout = true) else it
                    }
                    val p = WPayout(
                        id = "demo-p-" + now, weekKey = weekKey, amountUgx = total, phone = d.payoutNumber,
                        network = d.network, status = PayoutStatus.IN_PROGRESS, requestedAt = now, paidAt = null
                    )
                    data = d.copy(
                        submissions = newSubs,
                        payouts = listOf(p) + d.payouts,
                        expectedUgx = newSubs.filter {
                            it.weekKey == TimeUtil.weekKey(now) && it.status == SubStatus.APPROVED && !it.inPayout && !it.superseded
                        }.sumOf { it.payUgx }
                    )
                    Outcome.Ok(Unit)
                }
            }
        }
    ) {
        GhostButton(text = "EXIT DEMO", onClick = onLeave, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ SIGN IN TO AN EXISTING ACCOUNT

/** From the register screen: username + password OR PIN for an account that already exists. Typing demo in both opens the demo. */
@Composable
private fun ExistingWorkerLoginScreen(repos: Repos, onDone: (String) -> Unit, onDemo: () -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:worker") }
    var username by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Sign in to my account", onBack)
        Text(
            "Already have a CT Team worker account? Enter your username and your password or your PIN.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(username, { username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '.' || c == '_' }.take(20) }, "Username")
        CTField(secret, { secret = it }, "Password or PIN", keyboard = KeyboardType.Password, secret = true)
        if (message.isNotEmpty()) Text(message, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "SIGN IN",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (busy) return@GoldButton
                message = ""
                if (WorkerDemo.isDemoWord(username) && WorkerDemo.isDemoWord(secret)) {
                    onDemo()
                    return@GoldButton
                }
                if (username.isBlank() || secret.isEmpty()) {
                    message = "Enter your username and your password or PIN."
                    return@GoldButton
                }
                busy = true
                val u = username
                val s = secret
                scope.launch {
                    val rem = lock.remainingMs()
                    if (rem > 0) {
                        message = "Too many wrong tries. Wait " + ((rem + 999) / 1000) + " seconds."
                        busy = false
                        return@launch
                    }
                    val r = withContext(Dispatchers.Default) { repos.workerAuth.loginExisting(u, s) }
                    when (r) {
                        is Auth.Ok -> {
                            lock.clear()
                            repos.db.metaDao().put(MetaEntity(WORKER_META_KEY, r.value))
                            secret = ""
                            onDone(r.value)
                        }
                        is Auth.Wrong -> {
                            message = r.message
                            val l = lock.recordFailure()
                            if (l > 0) message = "Too many wrong tries. Locked for " + ((l + 999) / 1000) + " seconds."
                        }
                        is Auth.Denied -> message = r.message
                    }
                    busy = false
                }
            }
        )
        GhostButton(text = "BACK TO REGISTER", onClick = onBack, modifier = Modifier.fillMaxWidth())
        Text(
            "Accounts live on the phone where they were created. If your account is not found here, register on this phone instead.",
            color = CT.TextSoft, fontSize = 12.sp
        )
    }
}
