package com.ctteam.app.data

import android.content.res.Resources

/**
 * PIECE 6 — runs the automatic screenshot checks on the manager phone and stores the verdict on each proof.
 * Safe to run again at any time (it only rewrites the verdict and notes of SCREENSHOT proofs). The manager's own
 * decision (approve / reject) is never changed by this.
 */
class VerificationRepository(private val db: CTDatabase) {
    private val dao = db.submissionDao()

    companion object {
        private val SCREEN_IN_TEXT = Regex("Worker phone screen: ([0-9]{3,5}x[0-9]{3,5})")

        private fun rank(v: String): Int = when (v) {
            Verdict.DONT_TRUST -> 3
            Verdict.CHECK -> 2
            Verdict.OK -> 1
            else -> 0
        }
    }

    /** Screen size of THIS phone (used for submissions made on this same phone). */
    private fun thisScreen(): String? {
        val dm = Resources.getSystem().displayMetrics
        return if (dm.widthPixels > 0 && dm.heightPixels > 0) dm.widthPixels.toString() + "x" + dm.heightPixels else null
    }

    private suspend fun refOf(p: ProofEntity, what: (String) -> String = { it }): DupRef? {
        val s = dao.get(p.submissionId) ?: return null
        val who = db.workerDao().get(s.workerId)?.fullName() ?: "unknown worker"
        val task = db.taskDao().get(s.taskId)?.name ?: "a task"
        return DupRef(who, what(task), s.submittedAt)
    }

    /** Checks every screenshot of one submission; returns the worst verdict seen (Verdict.NONE if there is no screenshot). */
    suspend fun verify(submissionId: String): String {
        val sub = dao.get(submissionId) ?: return Verdict.NONE
        val proofs = dao.proofsFor(submissionId)

        val syncRow = proofs.firstOrNull { it.kind == "TEXT" && (it.textValue ?: "").startsWith("Arrived by sync") }
        val screen: String? =
            if (syncRow != null) SCREEN_IN_TEXT.find(syncRow.textValue ?: "")?.groupValues?.get(1)
            else thisScreen()

        val others = dao.proofsWithDhash(submissionId)
        var worst = Verdict.NONE

        for (p in proofs) {
            if (p.kind != "SCREENSHOT") {
                // keep warnings that were attached when the submission arrived (e.g. different pay, task switched off)
                if (rank(p.verdict) > rank(worst) && rank(p.verdict) >= 2) worst = p.verdict
                continue
            }

            val exact = ArrayList<DupRef>()
            val sha = p.sha256
            if (sha != null) {
                for (d in dao.proofsBySha(sha)) {
                    if (d.submissionId == submissionId) continue
                    val r = refOf(d)
                    if (r != null) exact.add(r)
                }
            }
            val near = ArrayList<DupRef>()
            val dh = p.dhash
            if (dh != null) {
                for (o in others) {
                    val od = o.dhash ?: continue
                    if (sha != null && o.sha256 == sha) continue   // already reported as an exact copy
                    val dist = ScreenshotChecker.hamming(dh, od) ?: continue
                    if (dist <= ScreenshotChecker.NEAR_MAX) {
                        val r = refOf(o)
                        if (r != null) near.add(DupRef(r.who, r.what, r.at, dist))
                    }
                    if (near.size >= 3) break
                }
            }

            val result = ScreenshotChecker.evaluate(
                CheckInput(
                    sha256 = sha, dhash = dh, fileName = p.fileName, fileSize = p.fileSize,
                    width = p.width, height = p.height, modifiedAt = p.fileModifiedAt, mime = p.mime,
                    tags = p.metadataTags, claimAt = sub.submittedAt, screen = screen,
                    exact = exact, near = near
                )
            )
            val notes = result.notes.joinToString("\n")
            if (p.verdict != result.verdict || p.verdictNotes != notes) {
                dao.updateProof(p.copy(verdict = result.verdict, verdictNotes = notes))
            }
            if (rank(result.verdict) > rank(worst)) worst = result.verdict
        }
        return worst
    }

    /** Checks every submission waiting for review. Returns submission id -> worst verdict. */
    suspend fun verifyAll(): Map<String, String> {
        val out = HashMap<String, String>()
        for (s in dao.pendingNow()) out[s.id] = verify(s.id)
        return out
    }

    /** Number of waiting submissions that have at least one yellow or red proof. */
    suspend fun issuesCount(): Int {
        verifyAll()
        return dao.issuesCount()
    }
}
