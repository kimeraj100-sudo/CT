package com.ctteam.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import java.util.Locale

/**
 * PIECE 6 — runs on the WORKER phone when a screenshot is picked. Produces the facts the manager phone needs:
 *  - dHash: a 64-bit fingerprint of what the picture LOOKS like (survives re-saving/compression, unlike SHA-256);
 *  - tags: "fmt=png;sw=<software name>;ed=<editor keyword>" read from the file's hidden data.
 * Nothing here decides anything; ScreenshotChecker does that on the manager phone.
 */
object ProofAnalyzer {
    private const val HEAD_BYTES = 2 * 1024 * 1024

    /** Difference hash on a 9x8 grid of average brightness (cells are averaged, so it is stable). */
    fun dHash(context: Context, uri: Uri): String? {
        try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 256 && bounds.outHeight / (sample * 2) >= 256) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val w = bmp.width
            val h = bmp.height
            if (w < 9 || h < 8) {
                bmp.recycle()
                return null
            }
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            bmp.recycle()

            val cell = IntArray(72)
            for (cy in 0 until 8) {
                val y0 = cy * h / 8
                val y1 = maxOf(y0 + 1, (cy + 1) * h / 8)
                for (cx in 0 until 9) {
                    val x0 = cx * w / 9
                    val x1 = maxOf(x0 + 1, (cx + 1) * w / 9)
                    var sum = 0L
                    var count = 0
                    for (y in y0 until y1) {
                        for (x in x0 until x1) {
                            val p = px[y * w + x]
                            val r = (p shr 16) and 0xFF
                            val g = (p shr 8) and 0xFF
                            val b = p and 0xFF
                            sum += (299 * r + 587 * g + 114 * b) / 1000
                            count++
                        }
                    }
                    cell[cy * 9 + cx] = if (count > 0) (sum / count).toInt() else 0
                }
            }
            var bits = 0L
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    bits = bits shl 1
                    if (cell[y * 9 + x] > cell[y * 9 + x + 1]) bits = bits or 1L
                }
            }
            return String.format(Locale.US, "%016x", bits)
        } catch (e: Throwable) {
            return null
        }
    }

    private fun sniff(b: ByteArray): String {
        fun at(i: Int) = if (i < b.size) b[i].toInt() and 0xFF else -1
        if (at(0) == 0x89 && at(1) == 0x50 && at(2) == 0x4E && at(3) == 0x47) return "png"
        if (at(0) == 0xFF && at(1) == 0xD8 && at(2) == 0xFF) return "jpeg"
        if (at(0) == 'G'.code && at(1) == 'I'.code && at(2) == 'F'.code) return "gif"
        if (at(0) == 'R'.code && at(1) == 'I'.code && at(2) == 'F'.code && at(3) == 'F'.code &&
            at(8) == 'W'.code && at(9) == 'E'.code && at(10) == 'B'.code && at(11) == 'P'.code
        ) return "webp"
        return "other"
    }

    private fun readHead(context: Context, uri: Uri): ByteArray {
        try {
            context.contentResolver.openInputStream(uri)?.use { s ->
                val buf = ByteArray(HEAD_BYTES)
                var n = 0
                while (n < buf.size) {
                    val r = s.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
                return buf.copyOf(n)
            }
        } catch (e: Exception) {
            // fall through
        }
        return ByteArray(0)
    }

    private fun be32(b: ByteArray, p: Int): Int =
        ((b[p].toInt() and 0xFF) shl 24) or ((b[p + 1].toInt() and 0xFF) shl 16) or
            ((b[p + 2].toInt() and 0xFF) shl 8) or (b[p + 3].toInt() and 0xFF)

    /** Text chunks of a PNG (tEXt / iTXt). Returns (Software value or null, all hidden text joined). */
    private fun pngText(b: ByteArray): Pair<String?, String> {
        var software: String? = null
        val all = StringBuilder()
        var pos = 8
        var guard = 0
        while (pos + 12 <= b.size && guard++ < 5000) {
            val len = be32(b, pos)
            if (len < 0 || pos + 12 + len > b.size) break
            val type = String(b, pos + 4, 4, Charsets.ISO_8859_1)
            if (type == "tEXt" || type == "iTXt") {
                val data = String(b, pos + 8, minOf(len, 65536), Charsets.ISO_8859_1)
                all.append(data).append('\n')
                if (type == "tEXt") {
                    val k = data.indexOf('\u0000')
                    if (k > 0 && data.substring(0, k).equals("Software", ignoreCase = true)) software = data.substring(k + 1)
                }
            }
            pos += 12 + len
        }
        return Pair(software, all.toString())
    }

    /** Text inside the APPn / COM segments of a JPEG (before the picture data). */
    private fun jpegText(b: ByteArray): String {
        val all = StringBuilder()
        var pos = 2
        var guard = 0
        while (pos + 4 <= b.size && guard++ < 200) {
            if ((b[pos].toInt() and 0xFF) != 0xFF) break
            val marker = b[pos + 1].toInt() and 0xFF
            if (marker == 0xFF) { pos++; continue }
            if (marker == 0xDA || marker == 0xD9) break
            val len = ((b[pos + 2].toInt() and 0xFF) shl 8) or (b[pos + 3].toInt() and 0xFF)
            if (len < 2 || pos + 2 + len > b.size) break
            if ((marker in 0xE0..0xEF) || marker == 0xFE) {
                all.append(String(b, pos + 4, minOf(len - 2, 65536), Charsets.ISO_8859_1)).append('\n')
            }
            pos += 2 + len
        }
        return all.toString()
    }

    private fun clean(s: String): String =
        s.filter { it.code in 32..126 }.replace(';', ' ').replace('=', ' ').trim().take(60)

    /** "fmt=png;sw=Name;ed=keyword" (parts that are not found are left out). Never throws. */
    fun tags(context: Context, uri: Uri): String {
        val parts = ArrayList<String>()
        try {
            val head = readHead(context, uri)
            val fmt = sniff(head)
            parts.add("fmt=$fmt")
            var software: String? = null
            var hidden = ""
            if (fmt == "png" && head.size > 8) {
                val r = pngText(head)
                software = r.first
                hidden = r.second
            } else if (fmt == "jpeg") {
                hidden = jpegText(head)
                try {
                    context.contentResolver.openInputStream(uri)?.use { s ->
                        software = ExifInterface(s).getAttribute(ExifInterface.TAG_SOFTWARE)
                    }
                } catch (e: Exception) {
                    // no EXIF is normal for screenshots
                }
            }
            val sw = software
            if (sw != null && clean(sw).isNotEmpty()) parts.add("sw=" + clean(sw))
            val editor = EditorTags.find(hidden + "\n" + (sw ?: ""))
            if (editor != null) parts.add("ed=$editor")
        } catch (e: Throwable) {
            // facts are best effort
        }
        return parts.joinToString(";")
    }
}
