package com.ctteam.app.data

import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDateTime
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * PIECE 6 — automatic screenshot checks.
 *
 * HONESTY RULE: these checks only look for warning signs. They can never prove a screenshot is genuine, and a
 * green result means "nothing suspicious was found", not "this is real". The manager always decides.
 *
 * Facts are collected on the WORKER phone (hash, picture fingerprint, hidden-data tags — see ProofAnalyzer) and
 * travel inside the signed report. The VERDICT is worked out on the MANAGER phone from those facts plus what that
 * phone already knows (earlier submissions), by [ScreenshotChecker.evaluate] (pure Kotlin, no Android needed).
 */

object EditorTags {
    /** Lower-case names of photo editors. Found in a file's hidden data = strong warning. */
    val KEYWORDS: List<String> = listOf(
        "photoshop", "lightroom", "illustrator", "gimp", "canva", "snapseed", "picsart", "pixlr", "photopea",
        "faceapp", "paint.net", "meitu", "beautyplus", "facetune", "remini", "polarr", "fotor", "inpaint",
        "photoscape", "pixelmator", "affinity photo", "krita"
    )

    fun find(text: String): String? {
        val t = text.lowercase(Locale.ROOT)
        return KEYWORDS.firstOrNull { t.contains(it) }
    }
}

/** An earlier proof that looks like the one being checked. */
class DupRef(val who: String, val what: String, val at: Long, val distance: Int = 0)

class CheckInput(
    val sha256: String?, val dhash: String?, val fileName: String?, val fileSize: Long?,
    val width: Int?, val height: Int?, val modifiedAt: Long?, val mime: String?, val tags: String?,
    val claimAt: Long,            // when the worker says the proof was sent (manager phone sanity-checked)
    val screen: String?,          // "WxH" of the worker's phone, if known
    val exact: List<DupRef>,      // same SHA-256 in another submission
    val near: List<DupRef>        // similar picture fingerprint in another submission
)

/** verdict is one of Verdict.OK / CHECK / DONT_TRUST. notes is plain text for the manager. */
class CheckResult(val verdict: String, val notes: List<String>)

object ScreenshotChecker {
    /** dHash difference (out of 64 bits) up to which two pictures count as "almost the same". */
    const val NEAR_MAX = 6
    private const val MINUTE = 60_000L
    private const val DAY = 86_400_000L
    private const val MIN_SIZE = 15L * 1024

    private val NAME_TIME_1 = Regex("(?<![0-9])(20[0-9]{2})(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])[-_ .T]?([01][0-9]|2[0-3])([0-5][0-9])([0-5][0-9])(?![0-9])")
    private val NAME_TIME_2 = Regex("(20[0-9]{2})-([0-9]{2})-([0-9]{2})[-_ T]([0-9]{2})[-.:]([0-9]{2})[-.:]([0-9]{2})")

    /** Number of differing bits between two 16-hex-digit fingerprints, or null if they cannot be compared. */
    fun hamming(a: String, b: String): Int? {
        if (a.length != b.length || a.length > 16) return null
        return try {
            java.lang.Long.bitCount(java.lang.Long.parseUnsignedLong(a, 16) xor java.lang.Long.parseUnsignedLong(b, 16))
        } catch (e: NumberFormatException) {
            null
        }
    }

    /** Time written in a file name such as Screenshot_20261007-232846.png (phone local time, taken as East Africa Time). */
    fun nameTime(fileName: String): Long? {
        val m = NAME_TIME_1.find(fileName) ?: NAME_TIME_2.find(fileName) ?: return null
        return try {
            val g = m.groupValues
            LocalDateTime.of(g[1].toInt(), g[2].toInt(), g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt())
                .atZone(TimeUtil.EAT).toInstant().toEpochMilli()
        } catch (e: Exception) {
            null
        }
    }

    /** True/false if the picture size fits the phone screen (either orientation, allowing for bars); null if unknown. */
    fun screenMatches(width: Int, height: Int, screen: String): Boolean? {
        val parts = screen.split("x")
        if (parts.size != 2) return null
        val sw = parts[0].toIntOrNull() ?: return null
        val sh = parts[1].toIntOrNull() ?: return null
        if (sw <= 0 || sh <= 0) return null
        val a = minOf(width, height)
        val b = maxOf(width, height)
        val sa = minOf(sw, sh)
        val sb = maxOf(sw, sh)
        val shortOk = Math.abs(a - sa) <= sa * 0.02
        val longOk = Math.abs(b - sb) <= sb * 0.12
        return shortOk && longOk
    }

    fun tagValue(tags: String, key: String): String? {
        for (part in tags.split(";")) {
            val p = part.trim()
            if (p.startsWith("$key=")) return p.substring(key.length + 1).trim().ifBlank { null }
        }
        return null
    }

    fun fmt(ms: Long): String {
        val f = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US)
        f.timeZone = TimeZone.getTimeZone("GMT+03:00")
        return f.format(Date(ms))
    }

    fun evaluate(i: CheckInput): CheckResult {
        val red = ArrayList<String>()
        val yellow = ArrayList<String>()
        val info = ArrayList<String>()

        // 1. the very same file was used before
        for (d in i.exact.take(3)) {
            red.add("Exactly the same file was already submitted (" + d.what + " by " + d.who + ", " + fmt(d.at) + ").")
        }
        // 2. a very similar picture was used before
        for (d in i.near.take(3)) {
            yellow.add("Looks almost the same as an earlier screenshot (" + d.what + " by " + d.who + ", " + fmt(d.at) + "; difference " + d.distance + " of 64). A real task can look the same every day, so compare them.")
        }

        // 3. hidden data
        val tags = i.tags ?: ""
        val editor = EditorTags.find(tags)
        if (editor != null) red.add("The file's hidden data mentions an editing program (" + editor + ").")
        val fmtTag = tagValue(tags, "fmt")
        if (fmtTag != null && fmtTag != "png") {
            yellow.add("This is a " + fmtTag.uppercase(Locale.ROOT) + " file. Phone screenshots are normally PNG; other formats can mean the picture was saved again or compressed.")
        }
        val mime = (i.mime ?: "").lowercase(Locale.ROOT).removePrefix("image/").replace("jpg", "jpeg")
        if (fmtTag != null && fmtTag != "other" && mime.isNotEmpty() && mime != fmtTag) {
            yellow.add("The file says it is \"" + mime + "\" but its content is " + fmtTag + ".")
        }

        // 4. size
        val w = i.width
        val h = i.height
        if (w == null || h == null) {
            yellow.add("The picture size could not be read, so this may not be a normal image.")
        } else if (i.screen != null) {
            val ok = screenMatches(w, h, i.screen)
            if (ok == false) {
                yellow.add("The picture is " + w + "×" + h + " but the worker's phone screen is " + i.screen + ". It may be cropped or from another device.")
            }
        } else {
            info.add("The worker's phone screen size was not known, so the picture size was not compared.")
        }
        val size = i.fileSize
        if (size != null && size < MIN_SIZE) {
            yellow.add("The file is very small (" + (size / 1024) + " KB) for a phone screenshot.")
        }

        // 5. dates
        val claim = i.claimAt
        val dayStart = Instant.ofEpochMilli(claim).atZone(TimeUtil.EAT).toLocalDate()
            .atStartOfDay(TimeUtil.EAT).toInstant().toEpochMilli()
        val mod = i.modifiedAt
        val named = i.fileName?.let { nameTime(it) }
        var dateSeen = false
        for ((label, t) in listOf("The file date" to mod, "The date in the file name" to named)) {
            if (t == null) continue
            dateSeen = true
            if (t > claim + 10 * MINUTE) {
                yellow.add(label + " (" + fmt(t) + ") is after the time the proof was sent.")
            } else if (claim - t > 3 * DAY) {
                red.add(label + " (" + fmt(t) + ") is " + ((claim - t) / DAY) + " days before the proof was sent.")
            } else if (t < dayStart) {
                yellow.add(label + " (" + fmt(t) + ") is from an earlier day than the submission.")
            }
        }
        if (mod != null && named != null && Math.abs(mod - named) > DAY) {
            yellow.add("The file date and the date in the file name are more than a day apart.")
        }
        if (!dateSeen) info.add("No date information was available for this file.")

        // 6. old app versions did not collect everything
        if (i.dhash == null && i.tags == null) {
            info.add("Made by an older app version: the similar-picture and hidden-data checks were not available.")
        }

        val verdict = when {
            red.isNotEmpty() -> Verdict.DONT_TRUST
            yellow.isNotEmpty() -> Verdict.CHECK
            else -> Verdict.OK
        }
        val notes = ArrayList<String>()
        for (n in red) notes.add("🔴 $n")
        for (n in yellow) notes.add("🟡 $n")
        if (verdict == Verdict.OK) notes.add("🟢 No problem found by the automatic checks. This does not prove the screenshot is genuine.")
        for (n in info) notes.add("ℹ $n")
        return CheckResult(verdict, notes)
    }
}
