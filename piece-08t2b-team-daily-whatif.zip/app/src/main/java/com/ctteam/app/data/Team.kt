package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.math.BigDecimal
import java.math.RoundingMode

/*
 * PIECE T1 — TEAM MINING: contributions ledger, decayed shares, 70/30 split, UGX rates.
 *
 * Idea: workers put crypto they mined into the shared NC Wallet. Every claim the manager VERIFIES (Piece 8D match,
 * or manual link with a reason) becomes one CONTRIBUTION. Its UGX value is fixed when it is verified, using the
 * rate the manager had set then; the rate is stored on the row and never changes later.
 *   weight  = sum( valueUgx * 0.5 ^ (ageDays / halfLifeDays) )     age counted from the deposit time on the statement
 *   share   = worker weight / total weight of all workers
 *   split   = mined amount -> workers' pool (default 70 %) and manager (the rest); pool shared by `share`
 * EVERYTHING produced here is an ESTIMATE. Rates are typed by the manager (the app has no internet yet).
 */

object TeamStatus { const val ACTIVE = "ACTIVE"; const val VOIDED = "VOIDED" }
object TeamVoidKind { const val UNLINKED = "UNLINKED"; const val MANAGER = "MANAGER" }

@Entity(
    tableName = "team_contributions",
    indices = [Index(value = ["claimId"], unique = true), Index("workerId"), Index("status")]
)
data class TeamContributionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val claimId: Long,                // nc_claims.id (one contribution per claim)
    val claimUid: String? = null,
    val workerId: String,
    val coin: String,
    val amountText: String,           // exact decimal text from the claim
    val contributedAtUtc: Long,       // deposit time (statement row time) — used for the decay
    val verifiedAt: Long,
    val rateText: String? = null,     // UGX per 1 coin used to price it; null = not priced yet
    val rateSetAt: Long? = null,      // when the manager set that rate
    val valueUgx: Long? = null,       // fixed once priced
    val status: String = TeamStatus.ACTIVE,
    val voidKind: String? = null,
    val voidNote: String = "",
    val voidedAt: Long? = null,
    val createdAt: Long
)

@Entity(tableName = "team_rates", indices = [Index("coin")])
data class TeamRateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val coin: String,
    val ugxPerUnitText: String,       // exact decimal text, UGX for 1 coin
    val setAt: Long,
    val setBy: String,
    val note: String = ""
)

@Dao
interface TeamDao {
    @Insert suspend fun insertContribution(c: TeamContributionEntity): Long
    @Update suspend fun updateContribution(c: TeamContributionEntity)
    @Query("SELECT * FROM team_contributions WHERE claimId = :claimId LIMIT 1") suspend fun byClaim(claimId: Long): TeamContributionEntity?
    @Query("SELECT * FROM team_contributions WHERE id = :contributionId") suspend fun contribution(contributionId: Long): TeamContributionEntity?
    @Query("SELECT * FROM team_contributions WHERE status = 'ACTIVE' ORDER BY contributedAtUtc ASC") suspend fun active(): List<TeamContributionEntity>
    @Query("SELECT * FROM team_contributions WHERE status = 'ACTIVE' AND valueUgx IS NULL ORDER BY contributedAtUtc ASC") suspend fun unpriced(): List<TeamContributionEntity>
    @Query("SELECT * FROM team_contributions ORDER BY contributedAtUtc DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<TeamContributionEntity>>
    @Query("SELECT * FROM team_contributions WHERE workerId = :workerId ORDER BY contributedAtUtc DESC") fun observeOfWorker(workerId: String): Flow<List<TeamContributionEntity>>

    @Insert suspend fun insertRate(r: TeamRateEntity): Long
    @Query("SELECT * FROM team_rates WHERE coin = :coin AND setAt <= :at ORDER BY setAt DESC, id DESC LIMIT 1") suspend fun rateAt(coin: String, at: Long): TeamRateEntity?
    @Query("SELECT * FROM team_rates ORDER BY setAt DESC, id DESC") fun observeRates(): Flow<List<TeamRateEntity>>
}

// ------------------------------------------------------------------ FORMULAS (pure, no database)

class TeamShare(
    val workerId: String,
    val allTimeUgx: Long,        // everything ever contributed (priced, active)
    val weight: Double,          // what counts towards the share after decay (UGX equivalent)
    val share: Double,           // 0.0 .. 1.0
    val contributions: Int
)

class TeamSplit(val minedUgx: Long, val workersPoolUgx: Long, val managerUgx: Long)

object TeamMath {
    private const val DAY_MS = 86_400_000.0

    /** amount (exact text) x rate (UGX per coin, exact text) -> whole UGX, rounded half up. Null if a number is not valid. */
    fun valueUgx(amountText: String, rateText: String): Long? = try {
        val a = BigDecimal(amountText.trim().replace(",", ""))
        val r = BigDecimal(rateText.trim().replace(",", ""))
        if (a.signum() <= 0 || r.signum() <= 0) null
        else a.multiply(r).setScale(0, RoundingMode.HALF_UP).longValueExact()
    } catch (ex: Exception) {
        null
    }

    fun weightOf(valueUgx: Long, contributedAtUtc: Long, now: Long, halfLifeDays: Double): Double {
        val ageDays = maxOf(0.0, (now - contributedAtUtc) / DAY_MS)
        return valueUgx.toDouble() * Math.pow(0.5, ageDays / halfLifeDays)
    }

    /** Only ACTIVE, priced contributions count. Result is sorted by share, biggest first. */
    fun shares(list: List<TeamContributionEntity>, now: Long, halfLifeDays: Double): List<TeamShare> {
        val counted = list.filter { it.status == TeamStatus.ACTIVE && it.valueUgx != null && it.valueUgx > 0L }
        val byWorker = counted.groupBy { it.workerId }
        val weights = byWorker.mapValues { (_, l) -> l.sumOf { weightOf(it.valueUgx ?: 0L, it.contributedAtUtc, now, halfLifeDays) } }
        val total = weights.values.sum()
        return byWorker.map { (w, l) ->
            val wt = weights[w] ?: 0.0
            TeamShare(w, l.sumOf { it.valueUgx ?: 0L }, wt, if (total > 0.0) wt / total else 0.0, l.size)
        }.sortedWith(compareByDescending<TeamShare> { it.share }.thenBy { it.workerId })
    }

    /** Mined amount (whole UGX) -> workers' pool and manager. The pool is rounded down, the manager gets the rest, so the parts always add up. */
    fun split(minedUgx: Long, poolPercent: Int): TeamSplit {
        val mined = maxOf(0L, minedUgx)
        val pool = mined / 100L * poolPercent + (mined % 100L) * poolPercent / 100L
        return TeamSplit(mined, pool, mined - pool)
    }

    /** Shares the pool between workers so that the whole pool is paid out exactly (largest remainder method, ties by id). */
    fun distribute(poolUgx: Long, shares: List<TeamShare>): Map<String, Long> {
        if (poolUgx <= 0L || shares.isEmpty()) return emptyMap()
        val totalShare = shares.sumOf { it.share }
        if (totalShare <= 0.0) return emptyMap()
        val raw = shares.map { it.workerId to poolUgx.toDouble() * (it.share / totalShare) }
        val floors = raw.associate { (id, v) -> id to Math.floor(v).toLong() }.toMutableMap()
        var left = poolUgx - floors.values.sum()
        val order = raw.sortedWith(compareByDescending<Pair<String, Double>> { it.second - Math.floor(it.second) }.thenBy { it.first })
        var i = 0
        while (left > 0L && order.isNotEmpty()) {
            val id = order[i % order.size].first
            floors[id] = (floors[id] ?: 0L) + 1L
            left--
            i++
        }
        return floors
    }
}

class TeamSnapshot(
    val now: Long,
    val halfLifeDays: Int,
    val poolPercent: Int,
    val shares: List<TeamShare>,
    val totalAllTimeUgx: Long,
    val totalWeight: Double,
    val unpricedCount: Int,
    val activeCount: Int
)

// ------------------------------------------------------------------ REPOSITORY

class TeamRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.teamDao()
    private val meta = db.metaDao()

    companion object {
        const val DEFAULT_HALF_LIFE_DAYS = 180
        const val DEFAULT_POOL_PERCENT = 70
        const val MIN_HALF_LIFE_DAYS = 7
        const val MAX_HALF_LIFE_DAYS = 3650
        private const val KEY_HALF_LIFE = "team:halfLifeDays"
        private const val KEY_POOL = "team:poolPercent"
        const val KEY_DAILY_MINED = "team:dailyMinedUgx"
        const val MAX_DAILY_MINED_UGX = 1_000_000_000_000L
        private val RATE_RULE = Regex("^[0-9]{1,15}(\\.[0-9]{1,8})?$")
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- settings

    suspend fun halfLifeDays(): Int = meta.get(KEY_HALF_LIFE)?.toIntOrNull()?.coerceIn(MIN_HALF_LIFE_DAYS, MAX_HALF_LIFE_DAYS) ?: DEFAULT_HALF_LIFE_DAYS
    suspend fun poolPercent(): Int = meta.get(KEY_POOL)?.toIntOrNull()?.coerceIn(1, 99) ?: DEFAULT_POOL_PERCENT

    suspend fun setHalfLife(days: Int, actor: String): Outcome<Int> {
        if (days < MIN_HALF_LIFE_DAYS || days > MAX_HALF_LIFE_DAYS)
            return Outcome.Err("The half-life must be between $MIN_HALF_LIFE_DAYS and $MAX_HALF_LIFE_DAYS days.")
        val before = halfLifeDays()
        if (before == days) return Outcome.Ok(days)
        meta.put(MetaEntity(KEY_HALF_LIFE, days.toString()))
        audit.log(actor, "TEAM_HALF_LIFE_CHANGED", "team", "settings", "$before -> $days days")
        return Outcome.Ok(days)
    }

    suspend fun setPoolPercent(percent: Int, actor: String): Outcome<Int> {
        if (percent < 1 || percent > 99) return Outcome.Err("The workers' share must be between 1 and 99 percent.")
        val before = poolPercent()
        if (before == percent) return Outcome.Ok(percent)
        meta.put(MetaEntity(KEY_POOL, percent.toString()))
        audit.log(actor, "TEAM_POOL_PERCENT_CHANGED", "team", "settings", "$before -> $percent percent")
        return Outcome.Ok(percent)
    }

    /** The manager's ESTIMATE of what the whole team mines per day, in whole UGX. Null = not entered. T3 replaces it with real daily amounts. */
    suspend fun dailyMinedUgx(): Long? = meta.get(KEY_DAILY_MINED)?.toLongOrNull()?.takeIf { it > 0L }

    /** Enter the estimate, or pass null / 0 to remove it. Every change is written to the audit log. */
    suspend fun setDailyMined(ugx: Long?, actor: String): Outcome<Long?> {
        val v = if (ugx == null || ugx <= 0L) null else ugx
        if (v != null && v > MAX_DAILY_MINED_UGX) return Outcome.Err("That amount is too large.")
        val before = dailyMinedUgx()
        if (before == v) return Outcome.Ok(v)
        meta.put(MetaEntity(KEY_DAILY_MINED, (v ?: 0L).toString()))
        audit.log(actor, "TEAM_DAILY_MINED_CHANGED", "team", "settings", (before?.toString() ?: "none") + " -> " + (v?.toString() ?: "none") + " UGX per day")
        return Outcome.Ok(v)
    }

    // ---------------------------------------------------------------- rates

    fun observeRates(): Flow<List<TeamRateEntity>> = dao.observeRates()

    suspend fun currentRate(coin: String, at: Long = now()): TeamRateEntity? = dao.rateAt(coin, at)

    /** The manager types today's rate (UGX for 1 coin). Old rates stay in the history; contributions keep the rate they were priced with. */
    suspend fun setRate(coinRaw: String, rateRaw: String, actor: String, note: String = ""): Outcome<TeamRateEntity> {
        val coin = coinRaw.trim().uppercase()
        if (!NcRepository.COIN_RULE.matches(coin)) return Outcome.Err("The coin must be 2 to 10 letters or digits, for example BNB.")
        val text = rateRaw.trim().replace(",", "").replace(" ", "")
        if (!RATE_RULE.matches(text) || BigDecimal(text).signum() <= 0)
            return Outcome.Err("Enter the rate as UGX for 1 coin: digits and at most one dot, more than zero.")
        val r = TeamRateEntity(coin = coin, ugxPerUnitText = text, setAt = now(), setBy = actor, note = note.trim().take(200))
        val id = dao.insertRate(r)
        audit.log(actor, "TEAM_RATE_SET", "team_rate", coin, "1 $coin = UGX $text")
        return Outcome.Ok(r.copy(id = id))
    }

    // ---------------------------------------------------------------- contributions

    private suspend fun price(coin: String, amountText: String, at: Long): Triple<String, Long, Long>? {
        val rate = dao.rateAt(coin, at) ?: return null
        val v = TeamMath.valueUgx(amountText, rate.ugxPerUnitText) ?: return null
        return Triple(rate.ugxPerUnitText, rate.setAt, v)
    }

    /** Called by the NC matching code (inside its transaction) when a claim becomes verified. */
    suspend fun onClaimVerified(c: NcClaimEntity, row: NcRowEntity, actor: String) {
        val at = now()
        val priced = price(c.coin, c.amountText, at)
        val old = dao.byClaim(c.id)
        if (old == null) {
            dao.insertContribution(
                TeamContributionEntity(
                    claimId = c.id, claimUid = c.claimUid, workerId = c.workerId, coin = c.coin, amountText = c.amountText,
                    contributedAtUtc = row.occurredAtUtc, verifiedAt = at,
                    rateText = priced?.first, rateSetAt = priced?.second, valueUgx = priced?.third, createdAt = at
                )
            )
            audit.log(actor, "TEAM_CONTRIBUTION_ADDED", "nc_claim", c.claimUid ?: c.id.toString(),
                c.coin + " " + c.amountText + (if (priced != null) " = UGX " + priced.third else " (no rate yet)"))
            return
        }
        // the manager removed this one from the team on purpose: a new link does not bring it back
        if (old.status == TeamStatus.VOIDED && old.voidKind == TeamVoidKind.MANAGER) return
        dao.updateContribution(
            old.copy(
                workerId = c.workerId, coin = c.coin, amountText = c.amountText, contributedAtUtc = row.occurredAtUtc, verifiedAt = at,
                rateText = priced?.first, rateSetAt = priced?.second, valueUgx = priced?.third,
                status = TeamStatus.ACTIVE, voidKind = null, voidNote = "", voidedAt = null
            )
        )
        audit.log(actor, "TEAM_CONTRIBUTION_ADDED", "nc_claim", c.claimUid ?: c.id.toString(), "verified again")
    }

    /** Called when a match is undone: the contribution stops counting until the claim is verified again. */
    suspend fun onClaimUnlinked(claimId: Long, note: String, actor: String) {
        val c = dao.byClaim(claimId) ?: return
        if (c.status != TeamStatus.ACTIVE) return
        dao.updateContribution(c.copy(status = TeamStatus.VOIDED, voidKind = TeamVoidKind.UNLINKED, voidNote = note.take(300), voidedAt = now()))
        audit.log(actor, "TEAM_CONTRIBUTION_VOIDED", "nc_claim", c.claimUid ?: claimId.toString(), "unlinked")
    }

    /** The manager says: this verified deposit is not a team contribution (a task payment, a mistake, ...). A reason is required. */
    suspend fun voidByManager(contributionId: Long, note: String, actor: String): Outcome<Unit> {
        if (note.trim().length < 3) return Outcome.Err("Write a short reason.")
        return db.withTransaction<Outcome<Unit>> {
            val c = dao.contribution(contributionId) ?: return@withTransaction Outcome.Err("Contribution not found.")
            if (c.status != TeamStatus.ACTIVE) return@withTransaction Outcome.Err("This contribution does not count already.")
            dao.updateContribution(c.copy(status = TeamStatus.VOIDED, voidKind = TeamVoidKind.MANAGER, voidNote = note.trim().take(300), voidedAt = now()))
            audit.log(actor, "TEAM_CONTRIBUTION_VOIDED", "nc_claim", c.claimUid ?: c.claimId.toString(), "manager: " + note.trim().take(300))
            Outcome.Ok(Unit)
        }
    }

    /** Puts a contribution the manager removed back. It is priced again with the rate of today. */
    suspend fun restore(contributionId: Long, note: String, actor: String): Outcome<Unit> {
        if (note.trim().length < 3) return Outcome.Err("Write a short reason.")
        return db.withTransaction<Outcome<Unit>> {
            val c = dao.contribution(contributionId) ?: return@withTransaction Outcome.Err("Contribution not found.")
            if (c.status != TeamStatus.VOIDED) return@withTransaction Outcome.Err("This contribution already counts.")
            val claim = db.ncDao().claimById(c.claimId)
            if (claim == null || claim.status == NcStatus.UNMATCHED)
                return@withTransaction Outcome.Err("The claim is not verified any more, so it cannot count. Link it to a statement row first.")
            val at = now()
            val priced = price(c.coin, c.amountText, at)
            dao.updateContribution(
                c.copy(
                    status = TeamStatus.ACTIVE, voidKind = null, voidNote = "", voidedAt = null, verifiedAt = at,
                    rateText = priced?.first, rateSetAt = priced?.second, valueUgx = priced?.third
                )
            )
            audit.log(actor, "TEAM_CONTRIBUTION_RESTORED", "nc_claim", c.claimUid ?: c.claimId.toString(), note.trim().take(300))
            Outcome.Ok(Unit)
        }
    }

    /** Prices contributions that were verified before the manager had set a rate. Each keeps the rate used now, from now on. */
    suspend fun priceUnpriced(actor: String): Outcome<Int> = db.withTransaction<Outcome<Int>> {
        val list = dao.unpriced()
        var n = 0
        val at = now()
        for (c in list) {
            val p = price(c.coin, c.amountText, at) ?: continue
            dao.updateContribution(c.copy(rateText = p.first, rateSetAt = p.second, valueUgx = p.third))
            n++
        }
        if (n == 0) return@withTransaction Outcome.Err("Nothing could be priced. Set a rate for the coin first.")
        audit.log(actor, "TEAM_CONTRIBUTIONS_PRICED", "team", "ledger", "$n contributions priced")
        Outcome.Ok(n)
    }

    // ---------------------------------------------------------------- numbers for the screens

    fun observeRecent(limit: Int): Flow<List<TeamContributionEntity>> = dao.observeRecent(limit)
    fun observeOfWorker(workerId: String): Flow<List<TeamContributionEntity>> = dao.observeOfWorker(workerId)

    suspend fun snapshot(at: Long = now()): TeamSnapshot {
        val half = halfLifeDays()
        val all = dao.active()
        val shares = TeamMath.shares(all, at, half.toDouble())
        return TeamSnapshot(
            now = at, halfLifeDays = half, poolPercent = poolPercent(), shares = shares,
            totalAllTimeUgx = shares.sumOf { it.allTimeUgx }, totalWeight = shares.sumOf { it.weight },
            unpricedCount = all.count { it.valueUgx == null }, activeCount = all.size
        )
    }
}
