package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Dir
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 9D-2 (worker) — "Ask the manager": a small chat. What the worker writes is kept here and travels to the manager inside the
 * next report (MAKE REPORT), signed like everything else. The manager's answers arrive as updates (Share / USE IT / paste) and land here.
 */
private val SUP_BAD = Color(0xFFFF8A8A)
private const val SUP_SHOWN = 8

@Composable
fun WorkerSupportCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val threadFlow = remember(repos, workerId) { repos.db.supportDao().observeThread(workerId) }
    val thread by threadFlow.collectAsState(initial = emptyList())
    val unreadFlow = remember(repos, workerId) { repos.db.supportDao().observeUnreadForWorker(workerId) }
    val unread by unreadFlow.collectAsState(initial = 0)

    var open by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var waiting by remember { mutableStateOf(0) }

    LaunchedEffect(thread.size) { waiting = repos.sync.unsentSupportCount(workerId) }
    // opening the chat = reading it
    LaunchedEffect(open, thread.size) { if (open) repos.db.supportDao().markWorkerRead(workerId, System.currentTimeMillis()) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(
            "💬 Ask the manager" + (if (unread > 0) "  ($unread new)" else ""),
            color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp
        )
        if (!open) {
            val last = thread.lastOrNull()
            Text(
                if (last == null) "Stuck or something looks wrong? Write to the manager here."
                else (if (last.direction == Dir.TO_MANAGER) "You: " else "Manager: ") + last.body.take(80),
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "OPEN CHAT", modifier = Modifier.fillMaxWidth(), onClick = { open = true })
            return@GlassCard
        }
        Spacer(Modifier.height(6.dp))
        if (thread.isEmpty()) Text("No messages yet.", color = CT.TextSoft, fontSize = 12.sp)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (m in thread.takeLast(SUP_SHOWN)) {
                val mine = m.direction == Dir.TO_MANAGER
                Column {
                    Text((if (mine) "You" else "Manager") + " · " + fmtTime(m.createdAt), color = if (mine) CT.TextSoft else CT.GoldLight, fontSize = 11.sp)
                    Text(m.body, color = Color.White, fontSize = 14.sp)
                }
            }
            if (thread.size > SUP_SHOWN) Text("… and " + (thread.size - SUP_SHOWN) + " older.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        CTField(text, { text = it.take(600) }, "Your message to the manager", singleLine = false, minLines = 3)
        Spacer(Modifier.height(6.dp))
        GoldButton(text = "SAVE MESSAGE", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                when (val r = repos.sync.askSupport(workerId, text)) {
                    is Outcome.Ok -> { text = ""; note = "Saved. It is sent to the manager with your next report: tap MAKE REPORT in “Reports to the manager” and send it."; noteBad = false; waiting = repos.sync.unsentSupportCount(workerId) }
                    is Outcome.Err -> { note = r.message; noteBad = true }
                }
            }
        })
        if (waiting > 0) Text("$waiting message(s) not sent yet. Use MAKE REPORT to send them.", color = CT.GoldLight, fontSize = 12.sp)
        if (note.isNotEmpty()) Text(note, color = if (noteBad) SUP_BAD else CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        GhostButton(text = "CLOSE", modifier = Modifier.fillMaxWidth(), onClick = { open = false })
    }
}
