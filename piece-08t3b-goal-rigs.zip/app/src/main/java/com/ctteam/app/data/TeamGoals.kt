package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.DayOfWeek
import java.time.LocalDate

/*
 * PIECE T3b — TEAM MINING: weekly hash goal + rig ledger.
 *   team_goals : one target hash rate per Monday-to-Sunday week (exact decimal text + unit).
 *   team_rigs  : the machines the team owns (name, hash rate, cost, when bought, what paid for it, status).
 * Capacity = sum of the hash rates of the ACTIVE rigs. One unit only: rigs in different units are never added together.
 * Progress = capacity / target. Everything the manager types is his own figure; the app cannot see the machines.
 * Every change is written to the audit log (before -> after).
 */

object RigStatus { const val ACTIVE = "ACTIVE"; const val SOLD = "SOLD"; const val BROKEN = "BROKEN" }

object HashUnits {
    val ALL: List<String> = listOf("H/s", "KH/s", "MH/s", "GH/s", "TH/s", "PH/s", "EH/s")
}

@Entity(tableName = "team_goals")
data class TeamGoalEntity(
    @PrimaryKey val weekKey: String,   // Monday of the week, yyyy-MM-dd (East Africa)
    val targetText: String,            // exact decimal, e.g. 120 or 12.5
    val unit: String,                  // one of HashUnits.ALL
    val note: String,
    val setBy: String,
    val setAt: Long
)

@Entity(tableName = "team_rigs", indices = [Index("status")])
data class TeamRigEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val hashText: String,              // exact decimal, in `unit`
    val unit: String,
    val costUgx: Long? = null,
    val boughtAt: Long,
    val fundedNote: String = "",       // what paid for it (e.g. "contributions of September")
    val status: String = RigStatus.ACTIVE,
    val soldAt: Long? = null,          // when it stopped being active (sold or broken)
    val setBy: String,
    val createdAt: Long
)

@Dao
interface TeamGoalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertGoal(g: TeamGoalEntity)
    @Query("SELECT * FROM team_goals WHERE weekKey = :weekKey") suspend fun goal(weekKey: String): TeamGoalEntity?
    @Query("DELETE FROM team_goals WHERE weekKey = :weekKey") suspend fun deleteGoal(weekKey: String)
    @Query("SELECT * FROM team_goals ORDER BY weekKey DESC LIMIT :limit") fun observeGoals(limit: Int): Flow<List<TeamGoalEntity>>

    @Insert suspend fun insertRig(r: TeamRigEntity): Long
    @Update suspend fun updateRig(r: TeamRigEntity)
    @Query("SELECT * FROM team_rigs WHERE id = :rigId") suspend fun rig(rigId: Long): TeamRigEntity?
    @Query("SELECT * FROM team_rigs ORDER BY boughtAt DESC, id DESC") fun observeRigs(): Flow<List<TeamRigEntity>>
    @Query("SELECT * FROM team_rigs WHERE status = 'ACTIVE'") suspend fun activeRigs(): List<TeamRigEntity>
}

// ------------------------------------------------------------------ FORMULAS (pure)

object TeamGoalMath {
    val HASH_RULE = Regex("^[0-9]{1,12}(\\.[0-9]{1,6})?$")
    private val WEEK_RULE = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")

    /** Exact decimal text -> BigDecimal, or null if it is not a valid amount above zero. */
    fun parse(text: String): BigDecimal? {
        val t = text.trim().replace(",", "").replace(" ", "")
        if (!HASH_RULE.matches(t)) return null
        val v = BigDecimal(t)
        return if (v.signum() > 0) v else null
    }

    fun plain(v: BigDecimal): String = if (v.signum() == 0) "0" else v.stripTrailingZeros().toPlainString()

    /** Sum of the ACTIVE rigs that are counted in [unit]. */
    fun capacity(rigs: List<TeamRigEntity>, unit: String): BigDecimal {
        var sum = BigDecimal.ZERO
        for (r in rigs) {
            if (r.status != RigStatus.ACTIVE || r.unit != unit) continue
            val v = parse(r.hashText) ?: continue
            sum = sum.add(v)
        }
        return sum
    }

    /** capacity / target as a plain number (1.0 = goal reached, can be more than 1). */
    fun progress(capacity: BigDecimal, target: BigDecimal): Double =
        if (target.signum() <= 0) 0.0 else capacity.divide(target, 6, RoundingMode.HALF_UP).toDouble()

    fun isMonday(weekKey: String): Boolean {
        if (!WEEK_RULE.matches(weekKey)) return false
        return try { LocalDate.parse(weekKey).dayOfWeek == DayOfWeek.MONDAY } catch (ex: Exception) { false }
    }
}

/** The goal of one week with the capacity measured against it (what the worker message carries). */
class GoalInfo(
    val weekKey: String,
    val targetText: String,
    val unit: String,
    val note: String,
    val capacityText: String,
    val progress: Double,
    val reached: Boolean,
    val otherUnitRigs: Int            // active rigs in a different unit: not counted
)

// ------------------------------------------------------------------ REPOSITORY

class TeamGoalRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.teamGoalDao()
    private val meta = db.metaDao()

    companion object {
        const val KEY_SHOW_TOP = "team:showTop"
        const val MAX_COST_UGX = 1_000_000_000_000L

        /** The goal for the week of [now] with the capacity of the ACTIVE rigs in the goal's unit. Null if no goal was set for that week. */
        suspend fun goalInfo(db: CTDatabase, now: Long = System.currentTimeMillis()): GoalInfo? {
            val g = db.teamGoalDao().goal(TimeUtil.weekKey(now)) ?: return null
            val target = TeamGoalMath.parse(g.targetText) ?: return null
            val active = db.teamGoalDao().activeRigs()
            val cap = TeamGoalMath.capacity(active, g.unit)
            val p = TeamGoalMath.progress(cap, target)
            return GoalInfo(
                weekKey = g.weekKey, targetText = TeamGoalMath.plain(target), unit = g.unit, note = g.note,
                capacityText = TeamGoalMath.plain(cap), progress = p, reached = cap.compareTo(target) >= 0,
                otherUnitRigs = active.count { it.unit != g.unit }
            )
        }
    }

    private fun now() = System.currentTimeMillis()

    fun observeGoals(limit: Int): Flow<List<TeamGoalEntity>> = dao.observeGoals(limit)
    fun observeRigs(): Flow<List<TeamRigEntity>> = dao.observeRigs()
    suspend fun goalInfo(at: Long = now()): GoalInfo? = Companion.goalInfo(db, at)

    // ---------------------------------------------------------------- consent switch for the top contributors list

    suspend fun showTop(): Boolean = meta.get(KEY_SHOW_TOP) == "1"

    suspend fun setShowTop(on: Boolean, actor: String) {
        if (showTop() == on) return
        meta.put(MetaEntity(KEY_SHOW_TOP, if (on) "1" else "0"))
        audit.log(actor, "TEAM_SHOW_TOP_CHANGED", "team", "settings", if (on) "top contributors may be shown to workers" else "top contributors hidden")
    }

    // ---------------------------------------------------------------- goal

    /** Sets (or replaces) the goal of one week. Only the current week or a later one; the week must be given as its Monday. */
    suspend fun setGoal(weekKey: String, targetRaw: String, unit: String, note: String, actor: String, at: Long = now()): Outcome<TeamGoalEntity> {
        val week = weekKey.trim()
        if (!TeamGoalMath.isMonday(week)) return Outcome.Err("The week must be given as its Monday, like 2026-10-12.")
        val thisWeek = TimeUtil.weekKey(at)
        if (week < thisWeek) return Outcome.Err("A goal cannot be set for a week that has passed.")
        if (LocalDate.parse(week).isAfter(LocalDate.parse(thisWeek).plusWeeks(8))) return Outcome.Err("Goals can be set at most 8 weeks ahead.")
        if (unit !in HashUnits.ALL) return Outcome.Err("Choose a hash-rate unit.")
        val target = TeamGoalMath.parse(targetRaw)
            ?: return Outcome.Err("Enter the target as a number above zero, at most 12 digits and 6 decimals (for example 120 or 12.5).")
        return db.withTransaction<Outcome<TeamGoalEntity>> {
            val active = dao.activeRigs()
            val other = active.map { it.unit }.distinct().filter { it != unit }
            if (other.isNotEmpty()) {
                return@withTransaction Outcome.Err("Your active rigs are counted in " + other.joinToString(", ") + ". Set the goal in that unit, or change the rigs first.")
            }
            val before = dao.goal(week)
            val g = TeamGoalEntity(week, TeamGoalMath.plain(target), unit, note.trim().take(120), actor, at)
            dao.upsertGoal(g)
            audit.log(actor, "TEAM_GOAL_SET", "team_goal", week,
                (if (before != null) before.targetText + " " + before.unit else "none") + " -> " + g.targetText + " " + unit)
            Outcome.Ok(g)
        }
    }

    suspend fun deleteGoal(weekKey: String, actor: String): Outcome<Unit> = db.withTransaction<Outcome<Unit>> {
        val before = dao.goal(weekKey) ?: return@withTransaction Outcome.Err("There is no goal for that week.")
        dao.deleteGoal(weekKey)
        audit.log(actor, "TEAM_GOAL_DELETED", "team_goal", weekKey, before.targetText + " " + before.unit + " removed")
        Outcome.Ok(Unit)
    }

    // ---------------------------------------------------------------- rigs

    /** Unit the active rigs are counted in, or null when there is no active rig. */
    suspend fun rigUnit(): String? = dao.activeRigs().map { it.unit }.distinct().firstOrNull()

    suspend fun addRig(
        nameRaw: String, hashRaw: String, unit: String, costUgx: Long?, boughtAt: Long, fundedNote: String, actor: String, at: Long = now()
    ): Outcome<TeamRigEntity> {
        val name = nameRaw.trim()
        if (name.length < 2 || name.length > 40) return Outcome.Err("Give the rig a name of 2 to 40 characters.")
        if (unit !in HashUnits.ALL) return Outcome.Err("Choose a hash-rate unit.")
        val hash = TeamGoalMath.parse(hashRaw)
            ?: return Outcome.Err("Enter the hash rate as a number above zero (at most 12 digits and 6 decimals).")
        if (costUgx != null && (costUgx < 0L || costUgx > MAX_COST_UGX)) return Outcome.Err("The cost must be whole UGX from 0 to $MAX_COST_UGX.")
        if (boughtAt > at + 86_400_000L) return Outcome.Err("The purchase date cannot be in the future.")
        return db.withTransaction<Outcome<TeamRigEntity>> {
            val used = dao.activeRigs().map { it.unit }.distinct()
            if (used.isNotEmpty() && used.any { it != unit }) {
                return@withTransaction Outcome.Err("Your active rigs are counted in " + used.joinToString(", ") + ". Rigs in different units are never added together: use the same unit.")
            }
            val r = TeamRigEntity(
                name = name, hashText = TeamGoalMath.plain(hash), unit = unit, costUgx = costUgx, boughtAt = boughtAt,
                fundedNote = fundedNote.trim().take(160), setBy = actor, createdAt = at
            )
            val id = dao.insertRig(r)
            audit.log(actor, "TEAM_RIG_ADDED", "team_rig", id.toString(), name + " " + r.hashText + " " + unit + (if (costUgx != null) ", cost UGX $costUgx" else ""))
            Outcome.Ok(r.copy(id = id))
        }
    }

    /** ACTIVE <-> SOLD / BROKEN. A rig is never deleted, so the ledger stays complete. */
    suspend fun setRigStatus(rigId: Long, status: String, actor: String, at: Long = now()): Outcome<TeamRigEntity> {
        if (status != RigStatus.ACTIVE && status != RigStatus.SOLD && status != RigStatus.BROKEN) return Outcome.Err("Unknown status.")
        return db.withTransaction<Outcome<TeamRigEntity>> {
            val r = dao.rig(rigId) ?: return@withTransaction Outcome.Err("Rig not found.")
            if (r.status == status) return@withTransaction Outcome.Ok(r)
            if (status == RigStatus.ACTIVE) {
                val used = dao.activeRigs().map { it.unit }.distinct()
                if (used.isNotEmpty() && used.any { it != r.unit }) {
                    return@withTransaction Outcome.Err("Your active rigs are counted in " + used.joinToString(", ") + ", this rig is in " + r.unit + ". It cannot be added to them.")
                }
            }
            val u = r.copy(status = status, soldAt = if (status == RigStatus.ACTIVE) null else at)
            dao.updateRig(u)
            audit.log(actor, "TEAM_RIG_STATUS", "team_rig", rigId.toString(), r.name + ": " + r.status + " -> " + status)
            Outcome.Ok(u)
        }
    }
}
