package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.HashUnits
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.RigStatus
import com.ctteam.app.data.TeamGoalMath
import com.ctteam.app.data.TeamRigEntity
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Locale

/*
 * PIECE T3b — manager screen sections: weekly hash goal and rig ledger (inside Manager > Team mining).
 * Figures are typed by the manager. The app cannot see the machines or the hash rate; it only adds up what is entered.
 */

private val GOAL_WARN = Color(0xFFFF8A8A)
private val GOAL_GOOD = Color(0xFF5FD6A5)

private fun mondayOf(offsetWeeks: Long): String =
    LocalDate.parse(TimeUtil.weekKey(System.currentTimeMillis())).plusWeeks(offsetWeeks).toString()

@Composable
fun TeamGoalSection(repos: Repos, actor: String) {
    val scope = rememberCoroutineScope()
    val goalsFlow = remember(repos) { repos.teamGoals.observeGoals(6) }
    val rigsFlow = remember(repos) { repos.teamGoals.observeRigs() }
    val goals by goalsFlow.collectAsState(initial = emptyList())
    val rigs by rigsFlow.collectAsState(initial = emptyList())

    // goal form
    var weekChoice by remember { mutableStateOf(0) }            // 0 = this week, 1 = next week
    var goalTarget by remember { mutableStateOf("") }
    var goalUnit by remember { mutableStateOf("TH/s") }
    var goalNote by remember { mutableStateOf("") }
    var goalMsg by remember { mutableStateOf("") }
    var showTop by remember { mutableStateOf(false) }
    var deleteAsk by remember { mutableStateOf<String?>(null) }

    // rig form
    var rigName by remember { mutableStateOf("") }
    var rigHash by remember { mutableStateOf("") }
    var rigUnit by remember { mutableStateOf("TH/s") }
    var rigCost by remember { mutableStateOf("") }
    var rigBought by remember { mutableStateOf(LocalDate.parse(TimeUtil.dayKey(System.currentTimeMillis())).toString()) }
    var rigFunded by remember { mutableStateOf("") }
    var rigMsg by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { showTop = repos.teamGoals.showTop() }

    val thisWeek = mondayOf(0)
    val activeRigs = rigs.filter { it.status == RigStatus.ACTIVE }
    val activeUnits = activeRigs.map { it.unit }.distinct()
    val capacityUnit = activeUnits.firstOrNull() ?: goalUnit
    val capacity = TeamGoalMath.capacity(rigs, capacityUnit)
    val currentGoal = goals.firstOrNull { it.weekKey == thisWeek }

    // ------------------------------------------------------------ goal card
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Weekly hash goal", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Set the team's target hash rate for a week (Monday to Sunday). Capacity is the sum of your ACTIVE rigs below. Workers see the progress bar after your next update.",
            color = CT.TextSoft, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        InfoRow("Capacity now", TeamGoalMath.plain(capacity) + " " + capacityUnit + " (" + activeRigs.size + " active rig" + (if (activeRigs.size == 1) "" else "s") + ")")
        val cg = currentGoal
        if (cg != null) {
            val t = TeamGoalMath.parse(cg.targetText)
            val cap2 = TeamGoalMath.capacity(rigs, cg.unit)
            if (t != null) {
                val p = TeamGoalMath.progress(cap2, t)
                InfoRow("This week's goal", cg.targetText + " " + cg.unit)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF))) {
                    Box(Modifier.fillMaxWidth(minOf(1.0, maxOf(0.0, p)).toFloat()).height(12.dp).clip(RoundedCornerShape(6.dp)).background(CT.Gold))
                }
                Text(
                    String.format(Locale.US, "%.1f", p * 100.0) + "% of the goal" + (if (p >= 1.0) " — reached 🎉" else ""),
                    color = if (p >= 1.0) GOAL_GOOD else CT.TextSoft, fontSize = 12.sp
                )
            }
        } else {
            Text("No goal is set for this week.", color = CT.TextSoft, fontSize = 12.sp)
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("This week", weekChoice == 0, { weekChoice = 0 })
            CTChip("Next week", weekChoice == 1, { weekChoice = 1 })
        }
        Text("Week of " + mondayOf(weekChoice.toLong()), color = CT.TextSoft, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        CTField(goalTarget, { goalTarget = it.filter { c -> c.isDigit() || c == '.' }.take(19) }, "Target hash rate", keyboard = KeyboardType.Decimal)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (u in HashUnits.ALL) CTChip(u, goalUnit == u, { goalUnit = u })
        }
        CTField(goalNote, { goalNote = it.take(120) }, "Note for the team (optional)")
        Spacer(Modifier.height(6.dp))
        GoldButton(text = "SAVE GOAL", modifier = Modifier.fillMaxWidth(), onClick = {
            val week = mondayOf(weekChoice.toLong())
            scope.launch {
                val r = repos.teamGoals.setGoal(week, goalTarget, goalUnit, goalNote, actor)
                goalMsg = if (r is Outcome.Err) r.message else "Goal saved for the week of $week."
            }
        })
        if (goalMsg.isNotEmpty()) Text(goalMsg, color = CT.GoldLight, fontSize = 12.sp)

        if (goals.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text("Goals", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            for (g in goals) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(g.weekKey + ": " + g.targetText + " " + g.unit, color = Color.White, fontSize = 12.sp)
                    if (deleteAsk == g.weekKey) {
                        GhostButton(text = "YES, REMOVE", danger = true, onClick = {
                            val wk = g.weekKey
                            scope.launch {
                                val r = repos.teamGoals.deleteGoal(wk, actor)
                                goalMsg = if (r is Outcome.Err) r.message else "Goal removed."
                                deleteAsk = null
                            }
                        })
                    } else {
                        GhostButton(text = "REMOVE", danger = true, onClick = { deleteAsk = g.weekKey })
                    }
                }
                if (g.note.isNotBlank()) Text(g.note, color = CT.TextSoft, fontSize = 11.sp)
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Show top contributors to workers", color = Color.White, fontSize = 13.sp)
                Text(
                    "Off by default. When ON and the weekly goal is reached, workers see the first name and last initial of the top 3 contributors. Only turn it on if the team agreed.",
                    color = CT.TextSoft, fontSize = 11.sp
                )
            }
            Switch(checked = showTop, onCheckedChange = { on ->
                showTop = on
                scope.launch { repos.teamGoals.setShowTop(on, actor) }
            })
        }
        Text("Every change is written to the audit log.", color = CT.TextSoft, fontSize = 11.sp)
    }

    // ------------------------------------------------------------ rig ledger card
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Rig ledger", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "The machines the team owns. Only ACTIVE rigs count towards capacity. Rigs are never deleted: mark them sold or broken so the history stays complete. One hash-rate unit at a time.",
            color = CT.TextSoft, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        if (rigs.isEmpty()) Text("No rigs entered yet.", color = CT.TextSoft, fontSize = 12.sp)
        for (r in rigs) RigCard(r, onStatus = { st ->
            scope.launch {
                val res = repos.teamGoals.setRigStatus(r.id, st, actor)
                rigMsg = if (res is Outcome.Err) res.message else ""
            }
        })

        Spacer(Modifier.height(10.dp))
        Text("Add a rig", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        CTField(rigName, { rigName = it.take(40) }, "Name (for example Rig 1)")
        CTField(rigHash, { rigHash = it.filter { c -> c.isDigit() || c == '.' }.take(19) }, "Hash rate", keyboard = KeyboardType.Decimal)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (u in HashUnits.ALL) CTChip(u, rigUnit == u, { rigUnit = u })
        }
        CTField(rigCost, { rigCost = it.filter { c -> c.isDigit() }.take(13) }, "Cost in UGX (optional)", keyboard = KeyboardType.Number)
        CTField(rigBought, { rigBought = it.take(10) }, "Bought on (yyyy-MM-dd)")
        CTField(rigFunded, { rigFunded = it.take(160) }, "What paid for it (optional)")
        Spacer(Modifier.height(6.dp))
        GoldButton(text = "ADD RIG", modifier = Modifier.fillMaxWidth(), onClick = {
            val day = try { LocalDate.parse(rigBought.trim()) } catch (ex: Exception) { null }
            if (day == null) {
                rigMsg = "Write the date like 2026-10-09."
            } else {
                val boughtAt = day.atStartOfDay(TimeUtil.EAT).toInstant().toEpochMilli()
                val cost = rigCost.toLongOrNull()
                scope.launch {
                    val r = repos.teamGoals.addRig(rigName, rigHash, rigUnit, cost, boughtAt, rigFunded, actor)
                    if (r is Outcome.Err) {
                        rigMsg = r.message
                    } else {
                        rigMsg = "Rig added."
                        rigName = ""
                        rigHash = ""
                        rigCost = ""
                        rigFunded = ""
                    }
                }
            }
        })
        if (rigMsg.isNotEmpty()) Text(rigMsg, color = GOAL_WARN, fontSize = 12.sp)
    }
}

@Composable
private fun RigCard(r: TeamRigEntity, onStatus: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                when (r.status) {
                    RigStatus.ACTIVE -> "ACTIVE"
                    RigStatus.SOLD -> "SOLD"
                    else -> "BROKEN"
                },
                color = if (r.status == RigStatus.ACTIVE) GOAL_GOOD else GOAL_WARN, fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }
        Text(r.hashText + " " + r.unit + (if (r.costUgx != null) " · cost " + ugx(r.costUgx) else ""), color = CT.TextSoft, fontSize = 12.sp)
        Text("Bought " + fmtTime(r.boughtAt).take(11).trim(), color = CT.TextSoft, fontSize = 11.sp)
        if (r.fundedNote.isNotBlank()) Text("Paid by: " + r.fundedNote, color = CT.TextSoft, fontSize = 11.sp)
        val ended = r.soldAt
        if (ended != null) Text("Stopped " + fmtTime(ended).take(11).trim(), color = CT.TextSoft, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (r.status == RigStatus.ACTIVE) {
                GhostButton(text = "MARK SOLD", onClick = { onStatus(RigStatus.SOLD) })
                GhostButton(text = "MARK BROKEN", danger = true, onClick = { onStatus(RigStatus.BROKEN) })
            } else {
                GhostButton(text = "MAKE ACTIVE AGAIN", onClick = { onStatus(RigStatus.ACTIVE) })
            }
        }
    }
}
