package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TeamView
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.delay

private val TEAM_RED = Color(0xFFFF8A8A)

/**
 * Team mining on the worker's home screen (T2a): my share, what I contributed, the team totals and my contributions.
 * The figures come from the manager's signed update (Updates from the manager card). Everything is an ESTIMATE.
 * T2b adds the expected daily payout, a "what if I contribute" calculator and the team capacity.
 */
@Composable
fun WorkerTeamCard(repos: Repos, workerId: String) {
    var view by remember { mutableStateOf<TeamView?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }
    var whatIfText by remember { mutableStateOf("") }

    // The update card sits on the same screen, so look again every few seconds.
    LaunchedEffect(workerId) {
        while (true) {
            view = com.ctteam.app.data.TeamViewCodec.load(repos.db, workerId)
            loaded = true
            delay(4000)
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Team mining", color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(4.dp))
        val v = view
        if (!loaded) {
            Text("Loading…", color = CT.TextSoft, fontSize = 12.sp)
        } else if (v == null) {
            Text(
                "No team figures on this phone yet. They arrive with the manager's next update: paste it in “Updates from the manager” below. " +
                    "Your own deposits count once the manager has verified them.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else {
            Text("Your share (estimate)", color = CT.TextSoft, fontSize = 12.sp)
            Text(v.sharePercentText(), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 34.sp)
            Spacer(Modifier.height(6.dp))
            InfoRow("You contributed (all time)", ugx(v.myAllTimeUgx))
            InfoRow("Counts towards your share", ugx(v.myWeight))
            InfoRow("Figures made", fmtTime(v.asOf))
            Spacer(Modifier.height(8.dp))

            // ---- expected daily payout (T2b)
            val daily = v.expectedDailyUgx()
            Text("Expected payout per day (estimate)", color = CT.TextSoft, fontSize = 12.sp)
            if (daily != null) {
                Text(ugx(daily), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                Text(
                    "Based on the manager's estimate of " + ugx(v.dailyMinedUgx ?: 0L) + " mined per day: " + v.poolPercent +
                        "% goes to the workers (" + ugx(v.dailyPoolUgx() ?: 0L) + "), shared by share, rounded down. Real mining can be more or less, so this can change every day.",
                    color = CT.TextSoft, fontSize = 11.sp
                )
            } else {
                Text("The manager has not entered a daily mining estimate yet.", color = CT.TextSoft, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))

            // ---- gifts from the manager (T3c)
            val todayKey = TimeUtil.dayKey(System.currentTimeMillis())
            val withGift = v.expectedDailyWithGiftUgx(todayKey)
            val mult = v.activeMultiplier(todayKey)
            if (withGift != null && mult != null) {
                Spacer(Modifier.height(6.dp))
                Text("🎁 With the manager's gift (×" + mult.toPlainString() + " today)", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("about " + ugx(withGift) + " today (estimate)", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            if (v.gifts.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Gifts from the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                for (g in v.gifts) {
                    val what = if (g.multiplier != null) {
                        "×" + g.multiplier + " on your expected daily payout, " + g.fromDay + " to " + g.toDay
                    } else {
                        "Extra " + ugx(g.fixedUgx ?: 0L) + " (one time), given " + g.fromDay
                    }
                    val state = when {
                        g.multiplier == null -> ""
                        todayKey < g.fromDay -> " (starts " + g.fromDay + ")"
                        todayKey > g.toDay -> " (ended)"
                        else -> " (active now)"
                    }
                    Text("Gift from the manager: " + what + state, color = Color.White, fontSize = 12.sp)
                    Text("Reason: " + g.reason, color = CT.TextSoft, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    "Gifts are the manager's own choice. They are not promised, can be changed or taken back, and they do not change your share or your contributions.",
                    color = CT.TextSoft, fontSize = 11.sp
                )
            }
            Spacer(Modifier.height(10.dp))

            // ---- what if I contribute X (T2b)
            Text("What if I contribute more?", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Type a value in UGX (for example the crypto you plan to deposit, at the manager's rate).", color = CT.TextSoft, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            CTField(whatIfText, { whatIfText = it.filter { c -> c.isDigit() }.take(12) }, "Extra contribution in UGX")
            val extra = whatIfText.toLongOrNull()
            if (extra != null && extra > 0L) {
                Spacer(Modifier.height(6.dp))
                InfoRow("Your share would be about", String.format(java.util.Locale.US, "%.2f", v.shareIfAdded(extra) * 100.0) + "%")
                val d2 = v.expectedDailyIfAdded(extra)
                if (d2 != null && daily != null) {
                    InfoRow("Expected per day would be about", ugx(d2) + " (" + (if (d2 >= daily) "+" else "-") + ugx(Math.abs(d2 - daily)).removePrefix("UGX ") + ")")
                }
                Text(
                    "Only an estimate: it assumes nobody else contributes or changes, ignores decay, and only counts once the manager has verified your deposit.",
                    color = CT.TextSoft, fontSize = 11.sp
                )
            }
            Spacer(Modifier.height(10.dp))

            // ---- team capacity (T2b; hash-rate capacity needs the rig ledger of T3)
            Text("Team capacity", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            InfoRow("Team contributed (all time)", ugx(v.teamAllTimeUgx))
            InfoRow("Counts towards shares now", ugx(v.teamWeight))
            InfoRow("Contributors", v.contributors.toString())
            val gp = v.goalProgress()
            Spacer(Modifier.height(8.dp))
            Text("Weekly hash goal", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (v.goalTarget != null && gp != null) {
                Text("Week of " + v.goalWeek + ": target " + v.goalTarget + " " + v.goalUnit, color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                val frac = minOf(1.0, maxOf(0.0, gp)).toFloat()
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF))) {
                    Box(Modifier.fillMaxWidth(frac).height(12.dp).clip(RoundedCornerShape(6.dp)).background(CT.Gold))
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Team capacity now: " + v.goalCapacity + " " + v.goalUnit + " (" + String.format(java.util.Locale.US, "%.1f", gp * 100.0) + "% of the goal)",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                if (v.goalNote.isNotBlank()) Text(v.goalNote, color = CT.TextSoft, fontSize = 11.sp)
                if (v.goalReached()) {
                    Spacer(Modifier.height(4.dp))
                    Text("🎉 The team reached this week's goal!", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (v.topNames.isNotEmpty()) {
                        Text("Top contributors: " + v.topNames.joinToString(", "), color = CT.GoldLight, fontSize = 12.sp)
                    }
                }
            } else {
                Text("The manager has not set a hash goal for this week.", color = CT.TextSoft, fontSize = 12.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Older contributions count a little less over time: after " + v.halfLifeDays + " days a contribution counts half. " +
                    "The mined amount is split " + v.poolPercent + "% to the workers by share and the rest to the manager. " +
                    "These are estimates. Values use rates set by the manager, they are not a promise of payment, and they refresh only when you import the manager's next update.",
                color = CT.TextSoft, fontSize = 11.sp
            )
            Spacer(Modifier.height(8.dp))
            GhostButton(
                text = if (showList) "HIDE MY CONTRIBUTIONS" else "SHOW MY CONTRIBUTIONS (" + v.contributions.size + (if (v.moreCount > 0) "+" else "") + ")",
                onClick = { showList = !showList },
                modifier = Modifier.fillMaxWidth()
            )
            if (showList) {
                Spacer(Modifier.height(8.dp))
                if (v.contributions.isEmpty()) {
                    Text("You have no verified contributions yet.", color = CT.TextSoft, fontSize = 12.sp)
                }
                for (c in v.contributions) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.coin + " " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                if (c.active) (if (c.valueUgx != null) "≈ " + ugx(c.valueUgx) else "not priced yet") else "not counted",
                                color = if (c.active) CT.GoldLight else TEAM_RED, fontSize = 12.sp
                            )
                        }
                        Text(
                            "Deposited " + fmtTime(c.contributedAtUtc) +
                                (if (c.active && c.rateText.isNotEmpty()) " · rate UGX " + c.rateText + " per " + c.coin else ""),
                            color = CT.TextSoft, fontSize = 11.sp
                        )
                        if (!c.active) {
                            Text(
                                "Not counted" + (if (c.voidNote.isNotBlank()) ": " + c.voidNote else "."),
                                color = TEAM_RED, fontSize = 11.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                if (v.moreCount > 0) {
                    Text(v.moreCount.toString() + " older contribution(s) are not listed here.", color = CT.TextSoft, fontSize = 11.sp)
                }
            }
        }
    }
}
