package com.ctteam.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.GiftKind
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TeamGiftEntity
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.launch
import java.time.LocalDate

/*
 * PIECE T3c — manager screen section: gifts to workers (inside Manager > Team mining).
 * A gift always has a reason. A multiplier only changes the worker's EXPECTED DAILY payout estimate for its days;
 * a fixed gift is one extra amount. Neither changes contributions or shares. Gifts are not promised.
 */

private val GIFT_WARN = Color(0xFFFF8A8A)
private val GIFT_GOOD = Color(0xFF5FD6A5)

@Composable
fun TeamGiftSection(repos: Repos, actor: String) {
    val scope = rememberCoroutineScope()
    val giftsFlow = remember(repos) { repos.teamGifts.observeGifts(20) }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val gifts by giftsFlow.collectAsState(initial = emptyList())
    val workers by workersFlow.collectAsState(initial = emptyList())

    val today = TimeUtil.dayKey(System.currentTimeMillis())
    var workerId by remember { mutableStateOf<String?>(null) }
    var kind by remember { mutableStateOf(GiftKind.MULTIPLIER) }
    var multiplier by remember { mutableStateOf("1.10") }
    var fromDay by remember { mutableStateOf(today) }
    var toDay by remember { mutableStateOf(LocalDate.parse(today).plusDays(6).toString()) }
    var fixedText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var voidAsk by remember { mutableStateOf<Long?>(null) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Gifts to workers", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Reward a worker with a multiplier on their EXPECTED DAILY payout for some days, or with one extra amount. A reason is required and the worker sees it. " +
                "A gift never changes contributions or shares, and it is not a promise of payment: it is only shown as a gift from you.",
            color = CT.TextSoft, fontSize = 11.sp
        )
        Spacer(Modifier.height(8.dp))
        Text("Worker", color = CT.TextSoft, fontSize = 11.sp)
        if (workers.isEmpty()) Text("No workers yet.", color = CT.TextSoft, fontSize = 12.sp)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (w in workers) {
                if (!w.active) continue
                CTChip(w.fullName(), workerId == w.id, { workerId = w.id })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("Multiplier", kind == GiftKind.MULTIPLIER, { kind = GiftKind.MULTIPLIER })
            CTChip("Extra amount", kind == GiftKind.FIXED, { kind = GiftKind.FIXED })
        }
        Spacer(Modifier.height(6.dp))
        if (kind == GiftKind.MULTIPLIER) {
            CTField(multiplier, { multiplier = it.filter { c -> c.isDigit() || c == '.' }.take(4) }, "Multiplier (1.01 to 3.00)", keyboard = KeyboardType.Decimal)
            CTField(fromDay, { fromDay = it.take(10) }, "First day (yyyy-MM-dd)")
            CTField(toDay, { toDay = it.take(10) }, "Last day (yyyy-MM-dd, at most 90 days)")
            Text("Example: 1.10 means 10% more on the worker's expected daily payout during those days.", color = CT.TextSoft, fontSize = 11.sp)
        } else {
            CTField(fixedText, { fixedText = it.filter { c -> c.isDigit() }.take(10) }, "Extra amount in UGX", keyboard = KeyboardType.Number)
            Text("A one-time figure shown to the worker as a gift today.", color = CT.TextSoft, fontSize = 11.sp)
        }
        CTField(reason, { reason = it.take(160) }, "Reason (required, shown to the worker)", singleLine = false, minLines = 2)
        Spacer(Modifier.height(6.dp))
        GoldButton(text = "GIVE GIFT", modifier = Modifier.fillMaxWidth(), onClick = {
            val id = workerId
            if (id == null) {
                msg = "Choose a worker first."
            } else {
                scope.launch {
                    val r: Outcome<TeamGiftEntity> = if (kind == GiftKind.MULTIPLIER) {
                        repos.teamGifts.giveMultiplier(id, multiplier, fromDay, toDay, reason, actor)
                    } else {
                        val ugx = fixedText.toLongOrNull() ?: 0L
                        repos.teamGifts.giveFixed(id, ugx, reason, actor)
                    }
                    if (r is Outcome.Err) {
                        msg = r.message
                    } else {
                        msg = "Gift saved. The worker sees it after your next update."
                        reason = ""
                        fixedText = ""
                    }
                }
            }
        })
        if (msg.isNotEmpty()) Text(msg, color = CT.GoldLight, fontSize = 12.sp)

        Spacer(Modifier.height(10.dp))
        Text("Gifts given (newest 20)", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (gifts.isEmpty()) Text("No gifts yet.", color = CT.TextSoft, fontSize = 12.sp)
        for (g in gifts) {
            val who = workers.firstOrNull { it.id == g.workerId }?.fullName() ?: "(unknown worker)"
            val what = if (g.kind == GiftKind.MULTIPLIER) "×" + g.multiplierText + ", " + g.fromDay + " to " + g.toDay else "Extra " + ugx(g.fixedUgx ?: 0L) + " on " + g.fromDay
            val status = when {
                g.voidedAt != null -> "VOIDED"
                g.kind == GiftKind.FIXED -> "GIVEN"
                today < g.fromDay -> "UPCOMING"
                today > g.toDay -> "ENDED"
                else -> "ACTIVE"
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(who, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(status, color = if (status == "VOIDED") GIFT_WARN else GIFT_GOOD, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(what, color = CT.TextSoft, fontSize = 12.sp)
                Text("Reason: " + g.reason, color = CT.TextSoft, fontSize = 11.sp)
                Text("Given by " + g.createdBy + " on " + fmtTime(g.createdAt), color = CT.TextSoft, fontSize = 11.sp)
                if (g.voidedAt == null) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (voidAsk == g.id) {
                            GhostButton(text = "YES, VOID IT", danger = true, onClick = {
                                val gid = g.id
                                scope.launch {
                                    val r = repos.teamGifts.void(gid, actor)
                                    msg = if (r is Outcome.Err) r.message else "Gift voided. The worker stops seeing it after your next update."
                                    voidAsk = null
                                }
                            })
                            GhostButton(text = "CANCEL", onClick = { voidAsk = null })
                        } else {
                            GhostButton(text = "VOID", danger = true, onClick = { voidAsk = g.id })
                        }
                    }
                }
            }
        }
        Text("Create and void are written to the audit log.", color = CT.TextSoft, fontSize = 11.sp)
    }
}
