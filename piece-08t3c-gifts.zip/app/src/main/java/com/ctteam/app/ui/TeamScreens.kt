package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TeamContributionEntity
import com.ctteam.app.data.TeamMath
import com.ctteam.app.data.TeamSnapshot
import com.ctteam.app.data.TeamStatus
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Piece T1 — Manager > Team mining.
 * Shows the contribution ledger, each worker's share (with decay), the manager-typed UGX rates and a split calculator.
 * Every figure is an ESTIMATE. Rates are typed by the manager (the app has no internet), so crypto amounts are shown
 * with "≈ UGX" and the date of the rate used. Nothing here is a promise of any return.
 */

private val TWARN = Color(0xFFFF8A8A)
private val TGOOD = Color(0xFF5FD6A5)

private fun pct(x: Double): String = String.format(Locale.US, "%.2f%%", x * 100.0)
private fun ugxD(x: Double): String = ugx(Math.round(x))

@Composable
fun TeamMiningScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val team = repos.team

    val recentFlow = remember(repos) { team.observeRecent(60) }
    val ratesFlow = remember(repos) { team.observeRates() }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val recent by recentFlow.collectAsState(initial = emptyList())
    val rates by ratesFlow.collectAsState(initial = emptyList())
    val workers by workersFlow.collectAsState(initial = emptyList())

    var snap by remember { mutableStateOf<TeamSnapshot?>(null) }
    var refresh by remember { mutableStateOf(0) }
    var halfText by remember { mutableStateOf("") }
    var poolText by remember { mutableStateOf("") }
    var dailyText by remember { mutableStateOf("") }
    var coinText by remember { mutableStateOf("BNB") }
    var rateText by remember { mutableStateOf("") }
    var calcText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var messageBad by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    // T3a: real daily mined amounts
    val daysFlow = remember(repos) { team.observeMinedDays(60) }
    val days by daysFlow.collectAsState(initial = emptyList())
    var dayText by remember { mutableStateOf(TimeUtil.dayKey(System.currentTimeMillis())) }
    var minedText by remember { mutableStateOf("") }
    var dayNote by remember { mutableStateOf("") }
    var convCoin by remember { mutableStateOf("BNB") }
    var convAmount by remember { mutableStateOf("") }
    var openDay by remember { mutableStateOf<String?>(null) }
    var estimate by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(days, refresh) { estimate = team.estimateDaily() }

    LaunchedEffect(recent, rates, refresh) {
        val s = team.snapshot()
        snap = s
        if (!loaded) {
            halfText = s.halfLifeDays.toString()
            poolText = s.poolPercent.toString()
            dailyText = (team.dailyMinedUgx() ?: 0L).let { if (it > 0L) it.toString() else "" }
            loaded = true
        }
    }

    fun who(id: String) = workers.firstOrNull { it.id == id }?.fullName() ?: "Worker"

    fun report(r: Outcome<*>, ok: String) {
        when (r) {
            is Outcome.Ok -> { message = ok; messageBad = false; reason = "" }
            is Outcome.Err -> { message = r.message; messageBad = true }
        }
        refresh++
    }

    val s = snap
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Team mining", onBack)
        Text(
            "Workers contribute crypto to the shared NC Wallet. A contribution counts only after YOU verify it (a matched claim or a manual link with a reason). " +
                "Every figure on this screen is an ESTIMATE based on rates you type yourself. It is not a promise of any payment or return.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (message.isNotEmpty()) Text(message, color = if (messageBad) TWARN else TGOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        // ------------------------------------------------------------ settings
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Settings", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            CTField(halfText, { halfText = it.filter { c -> c.isDigit() }.take(4) }, "Half-life in days (older contributions count less)")
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "SAVE HALF-LIFE", modifier = Modifier.fillMaxWidth(), onClick = {
                val d = halfText.toIntOrNull()
                if (d == null) { message = "Enter a number of days."; messageBad = true }
                else scope.launch { report(team.setHalfLife(d, actor), "Half-life saved.") }
            })
            Spacer(Modifier.height(8.dp))
            CTField(poolText, { poolText = it.filter { c -> c.isDigit() }.take(2) }, "Workers' share of mined crypto in percent (manager gets the rest)")
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "SAVE WORKERS' SHARE", modifier = Modifier.fillMaxWidth(), onClick = {
                val p = poolText.toIntOrNull()
                if (p == null) { message = "Enter a whole number."; messageBad = true }
                else scope.launch { report(team.setPoolPercent(p, actor), "Saved.") }
            })
            Spacer(Modifier.height(8.dp))
            CTField(dailyText, { dailyText = it.filter { c -> c.isDigit() }.take(13) }, "Fallback estimate per day, in UGX (used only when no daily amount was entered in the last 7 days)")
            Text(
                "Workers see their expected daily payout from the average of your real daily amounts (card below). This fallback is used only if you entered none in the last 7 days. It is YOUR estimate, not a promise.",
                color = CT.TextSoft, fontSize = 11.sp
            )
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "SAVE DAILY ESTIMATE", modifier = Modifier.fillMaxWidth(), onClick = {
                val v = if (dailyText.isBlank()) 0L else dailyText.toLongOrNull()
                if (v == null) { message = "Enter whole UGX."; messageBad = true }
                else scope.launch { report(team.setDailyMined(v, actor), if (v > 0L) "Daily estimate saved. Workers get it with their next update." else "Daily estimate removed.") }
            })
            Spacer(Modifier.height(4.dp))
            Text("All changes are written to the audit log.", color = CT.TextSoft, fontSize = 11.sp)
        }

        // ------------------------------------------------------------ T3b: weekly hash goal + rig ledger
        TeamGoalSection(repos = repos, actor = actor)

        // ------------------------------------------------------------ T3c: gifts
        TeamGiftSection(repos = repos, actor = actor)

        // ------------------------------------------------------------ T3a: daily mined amounts
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Daily mined amounts", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(
                "Enter what the whole team really mined on a day, in whole UGX (your own conversion). Workers see the AVERAGE of the days you entered in the last 7 days " +
                    "(a day you did not enter is skipped, not counted as zero). An average of past days is an ESTIMATE, not a promise about tomorrow.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(6.dp))
            val est = estimate
            InfoRow("Figure sent to workers now", if (est != null) ugx(est) + " per day" else "none")
            val now0 = System.currentTimeMillis()
            val wk = TimeUtil.weekKey(now0)
            val prevWk = java.time.LocalDate.parse(wk).minusDays(7).toString()
            InfoRow("Mined this week (Mon–Sun)", ugx(days.filter { it.day >= wk }.sumOf { it.minedUgx }))
            InfoRow("Mined last week", ugx(days.filter { it.day >= prevWk && it.day < wk }.sumOf { it.minedUgx }))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton(text = "TODAY", onClick = { dayText = TimeUtil.dayKey(System.currentTimeMillis()) })
                GhostButton(text = "YESTERDAY", onClick = { dayText = TimeUtil.dayKey(System.currentTimeMillis() - 86_400_000L) })
            }
            Spacer(Modifier.height(6.dp))
            CTField(dayText, { dayText = it.take(10) }, "Day (yyyy-MM-dd, East Africa time)")
            Spacer(Modifier.height(6.dp))
            CTField(minedText, { minedText = it.filter { c -> c.isDigit() }.take(13) }, "Mined that day, in whole UGX")
            Spacer(Modifier.height(6.dp))
            Text("Or work it out from the crypto you mined:", color = CT.TextSoft, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CTField(convCoin, { convCoin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(10) }, "Coin", modifier = Modifier.weight(1f))
                CTField(convAmount, { convAmount = it }, "Amount", modifier = Modifier.weight(2f))
            }
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CONVERT WITH MY RATE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    val rate = team.currentRate(convCoin)
                    val v = if (rate == null) null else TeamMath.valueUgx(convAmount, rate.ugxPerUnitText)
                    if (rate == null) { message = "Set a UGX rate for " + convCoin + " first (card below)."; messageBad = true }
                    else if (v == null) { message = "Enter the amount as a number, for example 0.0045."; messageBad = true }
                    else { minedText = v.toString(); message = "≈ UGX " + v + " at your rate of " + fmtTime(rate.setAt) + ". Check it, then save the day."; messageBad = false }
                }
            })
            Spacer(Modifier.height(6.dp))
            CTField(dayNote, { dayNote = it }, "Note (optional)")
            Spacer(Modifier.height(6.dp))
            GoldButton(text = "SAVE THIS DAY", modifier = Modifier.fillMaxWidth(), onClick = {
                val v = minedText.toLongOrNull()
                if (v == null) { message = "Enter the mined amount in whole UGX (0 is allowed)."; messageBad = true }
                else scope.launch {
                    val r = team.setMinedDay(dayText, v, dayNote, actor)
                    report(r, "Saved. Workers get the new average with their next update.")
                    if (r is Outcome.Ok) { minedText = ""; dayNote = "" }
                }
            })
            Spacer(Modifier.height(4.dp))
            Text("Saving a day that already exists replaces it. Every change is in the audit log with the old value.", color = CT.TextSoft, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Text("Days entered (newest first)", color = CT.TextSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            if (days.isEmpty()) Text("None yet.", color = CT.TextSoft, fontSize = 13.sp)
            for (d in days.take(14)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(d.day, color = Color.White, fontSize = 13.sp)
                    Text(ugx(d.minedUgx), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                if (d.note.isNotEmpty()) Text(d.note, color = CT.TextSoft, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton(text = if (openDay == d.day) "HIDE SPLIT" else "SHOW SPLIT", onClick = { openDay = if (openDay == d.day) null else d.day })
                    GhostButton(text = "EDIT", onClick = { dayText = d.day; minedText = d.minedUgx.toString(); dayNote = d.note })
                    GhostButton(text = "DELETE", danger = true, onClick = { val k = d.day; scope.launch { report(team.deleteMinedDay(k, actor), "Day removed.") } })
                }
                if (openDay == d.day && s != null) {
                    val sp = TeamMath.split(d.minedUgx, s.poolPercent)
                    val pay = TeamMath.distribute(sp.workersPoolUgx, s.shares)
                    InfoRow("Workers' pool (" + s.poolPercent + "%)", ugx(sp.workersPoolUgx))
                    InfoRow("Manager (" + (100 - s.poolPercent) + "%)", ugx(sp.managerUgx))
                    for (sh in s.shares) InfoRow(who(sh.workerId), ugx(pay[sh.workerId] ?: 0L))
                    Text("Split with TODAY'S shares, as an estimate. It is not a payment.", color = CT.TextSoft, fontSize = 11.sp)
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        // ------------------------------------------------------------ rates
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("UGX rates (typed by you)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(
                "A contribution is priced when it is verified, with the newest rate for its coin. That rate stays on the contribution and never changes later.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(6.dp))
            val latestPerCoin = rates.groupBy { it.coin }.map { (_, l) -> l.first() }
            if (latestPerCoin.isEmpty()) Text("No rate set yet.", color = CT.TextSoft, fontSize = 13.sp)
            for (r in latestPerCoin) {
                InfoRow("1 " + r.coin, "≈ UGX " + r.ugxPerUnitText)
                Text("Rate set by the manager on " + fmtTime(r.setAt) + " (estimate)", color = CT.TextSoft, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            CTField(coinText, { coinText = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(10) }, "Coin, for example BNB")
            Spacer(Modifier.height(6.dp))
            CTField(rateText, { rateText = it }, "UGX for 1 coin, for example 2300000")
            Spacer(Modifier.height(6.dp))
            GoldButton(text = "SAVE NEW RATE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = team.setRate(coinText, rateText, actor)) {
                        is Outcome.Ok -> { message = "Rate saved for " + r.value.coin + "."; messageBad = false; rateText = "" }
                        is Outcome.Err -> { message = r.message; messageBad = true }
                    }
                    refresh++
                }
            })
            if (rates.size > latestPerCoin.size) {
                Spacer(Modifier.height(8.dp))
                Text("Earlier rates", color = CT.TextSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                for (r in rates.take(8)) Text(fmtTime(r.setAt) + " · 1 " + r.coin + " = UGX " + r.ugxPerUnitText, color = CT.TextSoft, fontSize = 11.sp)
            }
        }

        // ------------------------------------------------------------ unpriced banner
        if (s != null && s.unpricedCount > 0) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "⚠ " + s.unpricedCount + " verified contribution(s) have no UGX value yet because no rate was set for their coin. They do not count towards shares until priced.",
                    color = Color(0xFFFFD27A), fontSize = 13.sp
                )
                Spacer(Modifier.height(6.dp))
                GhostButton(text = "PRICE THEM WITH TODAY'S RATES", modifier = Modifier.fillMaxWidth(), onClick = {
                    scope.launch { report(team.priceUnpriced(actor), "Priced.") }
                })
            }
        }

        // ------------------------------------------------------------ shares
        Text("Shares", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (s == null) {
            Text("Calculating…", color = CT.TextSoft)
        } else {
            Text(
                "All-time = everything contributed. Counts towards share = value after decay (half-life " + s.halfLifeDays + " days). Estimates only.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            if (s.shares.isEmpty()) Text("No priced, verified contribution yet.", color = CT.TextSoft, fontSize = 13.sp)
            for (sh in s.shares) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(who(sh.workerId), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(pct(sh.share), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    InfoRow("All-time contributed", "≈ " + ugx(sh.allTimeUgx))
                    InfoRow("Counts towards share", "≈ " + ugxD(sh.weight))
                    InfoRow("Contributions", sh.contributions.toString())
                }
            }
            if (s.shares.isNotEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    InfoRow("Team all-time", "≈ " + ugx(s.totalAllTimeUgx))
                    InfoRow("Team counts towards shares", "≈ " + ugxD(s.totalWeight))
                }
            }

            // -------------------------------------------------------- calculator
            Text("Split calculator (estimate)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Type what the team mined (whole UGX, for example the day's mined crypto at your rate). The app shows how it would be shared. You can also enter the real amount of each day in the card above.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(6.dp))
                CTField(calcText, { calcText = it.filter { c -> c.isDigit() }.take(12) }, "Mined amount in UGX")
                val mined = calcText.toLongOrNull()
                if (mined != null && mined > 0L) {
                    val sp = TeamMath.split(mined, s.poolPercent)
                    val pay = TeamMath.distribute(sp.workersPoolUgx, s.shares)
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Workers' pool (" + s.poolPercent + "%)", ugx(sp.workersPoolUgx))
                    InfoRow("Manager (" + (100 - s.poolPercent) + "%)", ugx(sp.managerUgx))
                    if (pay.isEmpty()) {
                        Text("No worker has a share yet, so the workers' pool stays unassigned.", color = CT.TextSoft, fontSize = 12.sp)
                    }
                    for (sh in s.shares) {
                        val v = pay[sh.workerId] ?: 0L
                        InfoRow(who(sh.workerId), ugx(v))
                    }
                    Text("The parts add up exactly to the mined amount. ESTIMATE, not a payment.", color = CT.TextSoft, fontSize = 11.sp)
                }
            }
        }

        // ------------------------------------------------------------ ledger
        Text("Contribution ledger (newest ${recent.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        CTField(reason, { reason = it }, "Reason (needed to remove or restore a contribution)", singleLine = false, minLines = 2)
        if (recent.isEmpty()) Text("No verified claim yet. Verify claims in NC Wallet > Matching.", color = CT.TextSoft, fontSize = 13.sp)
        for (c in recent) LedgerCard(c, who(c.workerId), onVoid = {
            val id = c.id
            val why = reason
            scope.launch { report(team.voidByManager(id, why, actor), "Removed from the team count.") }
        }, onRestore = {
            val id = c.id
            val why = reason
            scope.launch { report(team.restore(id, why, actor), "Restored.") }
        })
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun LedgerCard(c: TeamContributionEntity, name: String, onVoid: () -> Unit, onRestore: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(c.coin + "  " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (c.status == TeamStatus.ACTIVE) Text("counts", color = TGOOD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            else Text("not counted", color = TWARN, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text(name, color = CT.TextSoft, fontSize = 12.sp)
        Text("Deposit time (EAT) " + fmtTime(c.contributedAtUtc), color = CT.TextSoft, fontSize = 12.sp)
        val v = c.valueUgx
        if (v != null) {
            Text("≈ " + ugx(v) + " (estimate)", color = Color.White, fontSize = 13.sp)
            val at = c.rateSetAt
            Text("Rate used: 1 " + c.coin + " = UGX " + c.rateText + (if (at != null) ", set by the manager on " + fmtTime(at) else ""), color = CT.TextSoft, fontSize = 11.sp)
        } else {
            Text("No UGX value yet (no rate was set for " + c.coin + " when it was verified).", color = Color(0xFFFFD27A), fontSize = 12.sp)
        }
        if (c.status == TeamStatus.VOIDED) {
            Text("Not counted: " + (if (c.voidKind == "UNLINKED") "the match was undone" else "removed by the manager") +
                (if (c.voidNote.isNotBlank()) " (" + c.voidNote + ")" else ""), color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(6.dp))
        if (c.status == TeamStatus.ACTIVE) {
            GhostButton(text = "NOT A TEAM CONTRIBUTION (reason required)", danger = true, modifier = Modifier.fillMaxWidth(), onClick = onVoid)
        } else {
            GhostButton(text = "RESTORE (reason required)", modifier = Modifier.fillMaxWidth(), onClick = onRestore)
        }
    }
}
