package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.math.BigDecimal
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/*
 * PIECE T3c — TEAM MINING: gifts from the manager to one worker, always with a reason.
 *   MULTIPLIER : the worker's EXPECTED DAILY payout estimate is multiplied (1.01 .. 3.00) for a period of days.
 *                It never changes the contributions or the share, only that estimate, only inside the period.
 *   FIXED      : one extra amount in UGX, given once (shown to the worker for a while as a gift).
 * Gifts are the manager's own choice: not promised, can be voided. Create and void are written to the audit log.
 * They reach the worker phone inside the normal TEAM_VIEW update (optional field `gf`).
 */

object GiftKind { const val MULTIPLIER = "MULTIPLIER"; const val FIXED = "FIXED" }

@Entity(tableName = "team_gifts", indices = [Index("workerId")])
data class TeamGiftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val kind: String,                  // GiftKind
    val multiplierText: String? = null, // e.g. 1.10 (two decimals), only for MULTIPLIER
    val fixedUgx: Long? = null,         // only for FIXED
    val fromDay: String,               // yyyy-MM-dd East Africa, first day of the gift
    val toDay: String,                 // last day (same as fromDay for FIXED)
    val reason: String,                // required, 5 or more characters
    val createdBy: String,
    val createdAt: Long,
    val voidedAt: Long? = null,
    val voidedBy: String? = null
)

@Dao
interface TeamGiftDao {
    @Insert suspend fun insert(g: TeamGiftEntity): Long
    @Update suspend fun update(g: TeamGiftEntity)
    @Query("SELECT * FROM team_gifts WHERE id = :giftId") suspend fun get(giftId: Long): TeamGiftEntity?
    @Query("SELECT * FROM team_gifts ORDER BY id DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<TeamGiftEntity>>

    /** Gifts that are not voided and have not ended more than a week ago: what the worker phone is told about. */
    @Query("SELECT * FROM team_gifts WHERE workerId = :workerId AND voidedAt IS NULL AND toDay >= :since ORDER BY id DESC LIMIT 10")
    suspend fun recentFor(workerId: String, since: String): List<TeamGiftEntity>

    @Query("SELECT COUNT(*) FROM team_gifts WHERE workerId = :workerId AND kind = 'MULTIPLIER' AND voidedAt IS NULL AND fromDay <= :periodEnd AND toDay >= :periodStart")
    suspend fun overlapping(workerId: String, periodStart: String, periodEnd: String): Int
}

class TeamGiftRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.teamGiftDao()

    companion object {
        const val MAX_FIXED_UGX = 1_000_000_000L
        const val MAX_PERIOD_DAYS = 90
        const val MAX_DAYS_AHEAD = 60L
        val MULT_RULE = Regex("^[1-3](\\.[0-9]{1,2})?$")

        /** Gifts the worker phone should know about (not voided, not ended more than 7 days ago). */
        suspend fun activeFor(db: CTDatabase, workerId: String, now: Long = System.currentTimeMillis()): List<TeamGiftEntity> {
            val since = LocalDate.parse(TimeUtil.dayKey(now)).minusDays(7).toString()
            return db.teamGiftDao().recentFor(workerId, since)
        }

        /** "1.1" -> "1.10". Null if it is not a number from 1.01 to 3.00 with at most two decimals. */
        fun cleanMultiplier(raw: String): String? {
            val t = raw.trim().replace(',', '.')
            if (!MULT_RULE.matches(t)) return null
            val v = BigDecimal(t)
            if (v.compareTo(BigDecimal("1.01")) < 0 || v.compareTo(BigDecimal("3.00")) > 0) return null
            return v.setScale(2).toPlainString()
        }
    }

    private fun now() = System.currentTimeMillis()

    fun observeGifts(limit: Int): Flow<List<TeamGiftEntity>> = dao.observeRecent(limit)

    private fun cleanReason(raw: String): String? {
        val r = raw.replace('\n', ' ').trim()
        return if (r.length < 5 || r.length > 160) null else r
    }

    private suspend fun workerName(workerId: String): String? {
        val w = db.workerDao().get(workerId) ?: return null
        return if (w.active) w.fullName() else null
    }

    suspend fun giveMultiplier(
        workerId: String, multiplierRaw: String, fromDayRaw: String, toDayRaw: String, reasonRaw: String, actor: String, at: Long = now()
    ): Outcome<TeamGiftEntity> {
        val reason = cleanReason(reasonRaw) ?: return Outcome.Err("Write the reason for the gift (5 to 160 characters).")
        val m = cleanMultiplier(multiplierRaw) ?: return Outcome.Err("The multiplier must be from 1.01 to 3.00, for example 1.10.")
        val from = try { LocalDate.parse(fromDayRaw.trim()) } catch (ex: Exception) { return Outcome.Err("Write the first day like 2026-10-12.") }
        val to = try { LocalDate.parse(toDayRaw.trim()) } catch (ex: Exception) { return Outcome.Err("Write the last day like 2026-10-18.") }
        val today = LocalDate.parse(TimeUtil.dayKey(at))
        if (from.isBefore(today)) return Outcome.Err("A gift cannot start in the past.")
        if (from.isAfter(today.plusDays(MAX_DAYS_AHEAD))) return Outcome.Err("A gift can start at most $MAX_DAYS_AHEAD days ahead.")
        if (to.isBefore(from)) return Outcome.Err("The last day cannot be before the first day.")
        if (ChronoUnit.DAYS.between(from, to) + 1 > MAX_PERIOD_DAYS) return Outcome.Err("A multiplier can last at most $MAX_PERIOD_DAYS days.")
        return db.withTransaction<Outcome<TeamGiftEntity>> {
            val name = workerName(workerId) ?: return@withTransaction Outcome.Err("Choose an active worker.")
            if (dao.overlapping(workerId, from.toString(), to.toString()) > 0) {
                return@withTransaction Outcome.Err("This worker already has a multiplier in that period. Void it first.")
            }
            val g = TeamGiftEntity(
                workerId = workerId, kind = GiftKind.MULTIPLIER, multiplierText = m, fromDay = from.toString(), toDay = to.toString(),
                reason = reason, createdBy = actor, createdAt = at
            )
            val id = dao.insert(g)
            audit.log(actor, "TEAM_GIFT_GIVEN", "team_gift", id.toString(), name + ": x" + m + " from " + from + " to " + to + " - " + reason)
            Outcome.Ok(g.copy(id = id))
        }
    }

    suspend fun giveFixed(workerId: String, ugx: Long, reasonRaw: String, actor: String, at: Long = now()): Outcome<TeamGiftEntity> {
        val reason = cleanReason(reasonRaw) ?: return Outcome.Err("Write the reason for the gift (5 to 160 characters).")
        if (ugx < 1L || ugx > MAX_FIXED_UGX) return Outcome.Err("Enter whole UGX from 1 to $MAX_FIXED_UGX.")
        val day = TimeUtil.dayKey(at)
        return db.withTransaction<Outcome<TeamGiftEntity>> {
            val name = workerName(workerId) ?: return@withTransaction Outcome.Err("Choose an active worker.")
            val g = TeamGiftEntity(
                workerId = workerId, kind = GiftKind.FIXED, fixedUgx = ugx, fromDay = day, toDay = day,
                reason = reason, createdBy = actor, createdAt = at
            )
            val id = dao.insert(g)
            audit.log(actor, "TEAM_GIFT_GIVEN", "team_gift", id.toString(), name + ": extra UGX " + ugx + " - " + reason)
            Outcome.Ok(g.copy(id = id))
        }
    }

    /** Takes a gift back. The record stays (voided), the worker phone stops showing it after the next update. */
    suspend fun void(giftId: Long, actor: String, at: Long = now()): Outcome<Unit> = db.withTransaction<Outcome<Unit>> {
        val g = dao.get(giftId) ?: return@withTransaction Outcome.Err("Gift not found.")
        if (g.voidedAt != null) return@withTransaction Outcome.Err("This gift was already voided.")
        dao.update(g.copy(voidedAt = at, voidedBy = actor))
        val name = db.workerDao().get(g.workerId)?.fullName() ?: g.workerId
        audit.log(actor, "TEAM_GIFT_VOIDED", "team_gift", giftId.toString(), name + ": " + (if (g.kind == GiftKind.MULTIPLIER) "x" + g.multiplierText else "UGX " + g.fixedUgx))
        Outcome.Ok(Unit)
    }
}
