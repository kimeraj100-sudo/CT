package com.ctteam.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.BotConfig
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Piece C1 — worker home: the whole connection in a few taps.
 * 1. OPEN THE BOT (Telegram opens the manager's bot; the worker taps START once, Telegram's own rule).
 * 2. SEND MY CONNECTION (makes the connection code, copies it, opens Telegram's send screen with it filled in; pick the bot, tap send).
 * The card hides itself when the first update from the manager has arrived. The bot name comes from [BotConfig].
 */
private const val QC_SENT = "qc:sent:"

@Composable
fun QuickConnectCard(repos: Repos, workerId: String) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val bot = BotConfig.username()

    var show by remember { mutableStateOf(false) }
    var sent by remember { mutableStateOf(false) }
    var ref by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(workerId) {
        ref = repos.sync.referralCodeTyped(workerId)
        while (true) {
            show = repos.sync.managerMessagesReceived(workerId) == 0
            sent = repos.db.metaDao().get(QC_SENT + workerId) == "1"
            delay(4000)
        }
    }
    if (!show) return

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("🔗 Connect to the manager", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (sent) {
            Text(
                "✓ Sent. Waiting for the manager to connect you. This card goes away when the manager's first message arrives. Nothing sent yet? Tap SEND again.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else {
            Text(
                if (bot.isNotEmpty()) "Two taps in this app, then send in Telegram. Do 1 only the first time." else "Ask your manager for the bot name, open it in Telegram and tap START, then tap SEND below.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(8.dp))
        if (bot.isNotEmpty()) {
            GhostButton(text = "1  OPEN THE BOT, TAP START", modifier = Modifier.fillMaxWidth(), onClick = {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$bot")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    message = ""
                } catch (e: Exception) {
                    message = "Could not open Telegram. Is it installed?"
                }
            })
            Spacer(Modifier.height(8.dp))
        }
        CTField(ref, { ref = it.take(14) }, "Friend's referral code (optional)")
        Spacer(Modifier.height(8.dp))
        GoldButton(text = (if (bot.isNotEmpty()) "2  " else "") + "SEND MY CONNECTION", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                repos.sync.setReferralCodeTyped(workerId, ref)
                when (val r = repos.sync.makeEnrollment(workerId)) {
                    is Outcome.Ok -> {
                        clipboard.setText(AnnotatedString(r.value))
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, r.value)
                        }
                        try {
                            ctx.startActivity(Intent(send).setPackage("org.telegram.messenger"))
                        } catch (e: ActivityNotFoundException) {
                            ctx.startActivity(Intent.createChooser(send, "Send to the manager's bot"))
                        }
                        repos.db.metaDao().put(MetaEntity(QC_SENT + workerId, "1"))
                        sent = true
                        message = ""
                    }
                    is Outcome.Err -> message = r.message
                }
            }
        })
        if (message.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(message, color = CT.Gold, fontSize = 12.sp)
        }
        Text("Never send this in a group.", color = CT.TextSoft, fontSize = 11.sp)
    }
}
