package com.ctteam.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.BackupFormat
import com.ctteam.app.data.BackupRepository
import com.ctteam.app.data.BackupRestorer
import com.ctteam.app.data.CTRestart
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.RestorePreview
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 11c — the restore part of Manager > Backup (the screen is for the main manager only).
 * Step 1: passphrase + choose the file. The file is opened and checked completely and a PREVIEW is shown. Nothing changes yet.
 * Step 2: type RESTORE. The app keeps a safety copy of today's data, replaces the database and restarts.
 * UNDO puts the safety copy back (type UNDO).
 */
private val RS_GOOD = Color(0xFF5FD6A5)
private val RS_BAD = Color(0xFFFF8A8A)

@Composable
fun RestoreSection(repos: Repos, actor: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val restorer = remember(repos) { BackupRestorer(repos.db) }

    var pass by remember { mutableStateOf("") }
    var fileBytes by remember { mutableStateOf<ByteArray?>(null) }
    var preview by remember { mutableStateOf<RestorePreview?>(null) }
    var confirm by remember { mutableStateOf("") }
    var undoConfirm by remember { mutableStateOf("") }
    var safetyAt by remember { mutableStateOf<Long?>(null) }
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) { safetyAt = restorer.safetyTime(context) }

    fun say(ok: Boolean, text: String) { good = ok; message = text }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                preview = null
                fileBytes = null
                confirm = ""
                val bytes = try {
                    context.contentResolver.openInputStream(uri)?.use { BackupRepository.readLimited(it, BackupFormat.MAX_DB_BYTES + 1_000_000) }
                } catch (e: Exception) {
                    null
                }
                if (bytes == null) {
                    say(false, "The file could not be read, or it is larger than the backup limit.")
                } else {
                    when (val r = restorer.preview(context, bytes, pass)) {
                        is Outcome.Ok -> {
                            fileBytes = bytes
                            preview = r.value
                            say(true, "")
                        }
                        is Outcome.Err -> say(false, r.message)
                    }
                }
                busy = false
            }
        }
    }

    fun finish(ok: Boolean, text: String, restart: Boolean) {
        if (ok) {
            done = true
            say(true, text)
        } else {
            say(false, text)
        }
        if (restart) CTRestart.now(context)
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Restore from a backup", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Replaces EVERYTHING in the app on this phone with what is inside a backup file: workers, tasks, payouts, managers, keys. " +
                "Before it does, the app keeps a safety copy of today's data so you can undo it.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))

        if (done) {
            Text(message, color = RS_GOOD, fontSize = 13.sp)
        } else {
            CTField(pass, { pass = it; preview = null; fileBytes = null; confirm = "" }, "Passphrase of the backup to restore", secret = true)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "CHOOSE BACKUP FILE", modifier = Modifier.fillMaxWidth(), onClick = {
                if (!busy) {
                    if (pass.isEmpty()) say(false, "Type the passphrase of that backup first.") else { message = ""; pick.launch(arrayOf("*/*")) }
                }
            })

            val p = preview
            if (p != null) {
                Spacer(Modifier.height(10.dp))
                Text("✓ The file is complete and can be restored.", color = RS_GOOD, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Backup made " + fmtTime(p.info.createdAt) + " (East Africa Time)", color = Color.White, fontSize = 13.sp)
                Text(
                    "App build " + p.info.appVersionCode + ", database version " + p.info.dbVersion + ", " + (p.info.dbBytes / 1024) + " KB",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(6.dp))
                Text("What is on this phone now  →  what the backup holds", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                for ((t, thenN) in p.info.counts) {
                    val nowN = p.currentCounts.firstOrNull { it.first == t }?.second
                    Text(
                        t.replace('_', ' ') + ":  " + (nowN?.toString() ?: "–") + "  →  " + thenN,
                        color = if (nowN != null && nowN > thenN) RS_BAD else Color.White, fontSize = 12.sp
                    )
                }
                Spacer(Modifier.height(8.dp))
                for (w in p.warnings) Text("⚠ " + w, color = RS_BAD, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("To go on, type  RESTORE  below (capital letters).", color = Color.White, fontSize = 13.sp)
                CTField(confirm, { confirm = it.take(10) }, "Type RESTORE")
                Spacer(Modifier.height(6.dp))
                GoldButton(text = if (busy) "RESTORING…" else "RESTORE NOW", modifier = Modifier.fillMaxWidth(), onClick = {
                    val bytes = fileBytes
                    if (busy || bytes == null) return@GoldButton
                    if (confirm != "RESTORE") {
                        say(false, "Type RESTORE exactly, in capital letters.")
                        return@GoldButton
                    }
                    busy = true
                    scope.launch {
                        val r = restorer.restore(context, bytes, pass, actor)
                        pass = ""
                        fileBytes = null
                        preview = null
                        confirm = ""
                        busy = false
                        finish(
                            r.ok,
                            if (r.ok) "Restore finished. The app is restarting. If it does not open by itself, open it again, then sign in with the manager name, password and PIN from the backup."
                            else r.message,
                            r.restart
                        )
                    }
                })
            }
        }

        val s = safetyAt
        if (s != null && !done) {
            Spacer(Modifier.height(14.dp))
            Text("Undo the last restore", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(
                "A safety copy of the data from before the last restore was made " + fmtTime(s) + ". Putting it back replaces what is on the phone now " +
                    "(and keeps that as the new safety copy). Type  UNDO  to confirm.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            CTField(undoConfirm, { undoConfirm = it.take(10) }, "Type UNDO")
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "PUT BACK THE DATA FROM BEFORE", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy) return@GhostButton
                if (undoConfirm != "UNDO") {
                    say(false, "Type UNDO exactly, in capital letters.")
                    return@GhostButton
                }
                busy = true
                scope.launch {
                    val r = restorer.undo(context, actor)
                    undoConfirm = ""
                    busy = false
                    finish(
                        r.ok,
                        if (r.ok) "The earlier data was put back. The app is restarting. If it does not open by itself, open it again." else r.message,
                        r.restart
                    )
                }
            })
        }

        if (message.isNotEmpty() && !done) {
            Spacer(Modifier.height(6.dp))
            Text(message, color = if (good) RS_GOOD else RS_BAD, fontSize = 13.sp)
        }
    }
}
