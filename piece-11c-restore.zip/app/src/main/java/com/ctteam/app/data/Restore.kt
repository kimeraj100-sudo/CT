package com.ctteam.app.data

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/*
 * PIECE 11c — RESTORE (main manager's phone only; the screen is inside Manager > Backup).
 *
 * Steps, in this order, and nothing is changed before step 5:
 *   1. open the file: passphrase, AES-GCM seal, SHA-256 (BackupFormat.open from 11b);
 *   2. refuse a backup whose DATABASE version is newer than this app's (an older one is upgraded by Room's migrations at the next start);
 *   3. write the database to a temporary file next to the real one and run SQLite's own integrity check on it;
 *   4. in that temporary file only: move the sync counters FORWARD and add an audit row (see below);
 *   5. make a SAFETY COPY of the current database (kept in filesDir/restore-safety, one slot), close the database,
 *      delete its -wal/-shm/-journal files, put the new file in place;
 *   6. restart the app.
 * UNDO uses the safety copy the same way (and keeps what it replaces as the new safety copy, so undo can be undone).
 *
 * SYNC NUMBERS. Replay protection is a set of already-seen message numbers on each phone. If an OLD backup is restored, the manager phone's
 * outgoing counters (`sync:out:M2W:<worker>`) would be lower than numbers the workers already accepted, and the workers would refuse every new
 * update as a copy. So for each outgoing counter the restored value becomes max(restored, value before the restore) + 20. The worker sees,
 * once, a note that some updates "have not arrived", which is harmless. The same max rule keeps the Telegram read position (`tg:offset`).
 * What the restore cannot know: reports the manager imported AFTER the backup was made are forgotten on the manager phone, so a worker
 * who sends the same report again gets it imported again (items carry their own ids, so nothing is counted twice).
 */
class RestorePreview(
    val info: BackupInfo,
    val currentDbVersion: Int,
    val currentCounts: List<Pair<String, Int>>,
    val warnings: List<String>
)

class RestoreOutcome(val ok: Boolean, val message: String, val restart: Boolean)

class BackupRestorer(private val db: CTDatabase) {

    companion object {
        const val SAFETY_DIR = "restore-safety"
        const val SAFETY_NAME = "ctteam-before-restore.db"
        const val K_RESTORED_AT = "restore:lastAt"
        const val K_RESTORED_FROM = "restore:fromCreated"
        private const val NUMBER_MARGIN = 20L
        private const val DAY_MS = 24L * 60 * 60 * 1000
        private val COUNT_TABLES = listOf(
            "workers", "tasks", "submissions", "payout_requests", "payments",
            "nc_rows", "nc_claims", "manager_accounts", "audit_log"
        )
    }

    private fun now() = System.currentTimeMillis()

    fun safetyFile(context: Context): File = File(File(context.filesDir, SAFETY_DIR), SAFETY_NAME)

    /** When the safety copy was made (= the moment of the last restore), or null if there is none. */
    fun safetyTime(context: Context): Long? = safetyFile(context).takeIf { it.exists() && it.length() > 0 }?.lastModified()

    private fun currentVersion(): Int = db.openHelper.readableDatabase.version

    private fun liveCounts(): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        val d = db.openHelper.readableDatabase
        for (t in COUNT_TABLES) {
            try {
                d.query("SELECT COUNT(*) FROM $t").use { c -> if (c.moveToFirst()) out.add(t to c.getInt(0)) }
            } catch (e: Exception) {
                // table not there: leave it out
            }
        }
        return out
    }

    /** The counters that must never move backwards. Read from the LIVE database before anything is replaced. */
    private fun liveNumbers(): Map<String, Long> {
        val out = HashMap<String, Long>()
        db.openHelper.readableDatabase
            .query("SELECT `key`, `value` FROM meta WHERE `key` LIKE 'sync:out:%' OR `key` = 'tg:offset'")
            .use { c ->
                while (c.moveToNext()) {
                    val v = c.getString(1)?.toLongOrNull()
                    if (v != null) out[c.getString(0)] = v
                }
            }
        return out
    }

    private fun integrityOk(f: File): Boolean {
        return try {
            val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                var ok = false
                d.rawQuery("PRAGMA integrity_check", null).use { c -> if (c.moveToFirst()) ok = c.getString(0) == "ok" }
                ok
            } finally {
                d.close()
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun deleteSidecars(f: File) {
        File(f.path + "-wal").delete(); File(f.path + "-shm").delete(); File(f.path + "-journal").delete()
    }

    // ---------------------------------------------------------------- preview (changes nothing)

    suspend fun preview(context: Context, file: ByteArray, pass: String): Outcome<RestorePreview> = withContext(Dispatchers.IO) {
        val opened = when (val o = BackupFormat.open(file, pass)) {
            is Outcome.Err -> return@withContext Outcome.Err(o.message)
            is Outcome.Ok -> o.value
        }
        val info = BackupFormat.infoOf(opened.header)
        val cur = currentVersion()
        if (info.dbVersion > cur) {
            return@withContext Outcome.Err(
                "This backup was made by a newer version of the app (database version ${info.dbVersion}, this app has $cur). Update the app first, then try again."
            )
        }
        if (info.dbVersion < 1) return@withContext Outcome.Err("This backup does not say which database version it holds.")
        val tmp = File(context.cacheDir, "ctb-preview-" + now() + ".db")
        val good = try {
            tmp.writeBytes(opened.db)
            integrityOk(tmp)
        } finally {
            tmp.delete(); deleteSidecars(tmp)
        }
        if (!good) return@withContext Outcome.Err("The file decrypts, but the database inside does not pass SQLite's check. It will not be restored.")

        val live = liveCounts()
        val warnings = ArrayList<String>()
        val ageDays = (now() - info.createdAt) / DAY_MS
        if (ageDays >= 1) warnings.add("This backup is $ageDays day" + (if (ageDays == 1L) "" else "s") + " old. Everything done on this phone since then is replaced.")
        for ((t, nowN) in live) {
            val thenN = info.counts.firstOrNull { it.first == t }?.second ?: continue
            if (nowN > thenN) warnings.add(t.replace('_', ' ') + ": " + nowN + " now, " + thenN + " in the backup. " + (nowN - thenN) + " will be gone.")
        }
        if (info.dbVersion < cur) warnings.add("The backup uses an older database version (${info.dbVersion}). It is upgraded automatically when the app restarts.")
        warnings.add("After the restart, sign in with the manager name, password and PIN that exist INSIDE the backup.")
        warnings.add("Workers' phones keep working. The app moves its message numbers forward so workers do not refuse the next update.")
        Outcome.Ok(RestorePreview(info, cur, live, warnings))
    }

    // ---------------------------------------------------------------- restore + undo

    suspend fun restore(context: Context, file: ByteArray, pass: String, actor: String): RestoreOutcome = withContext(Dispatchers.IO) {
        val opened = when (val o = BackupFormat.open(file, pass)) {
            is Outcome.Err -> return@withContext RestoreOutcome(false, o.message, false)
            is Outcome.Ok -> o.value
        }
        val ver = opened.header.optInt("db", 0)
        val cur = currentVersion()
        if (ver > cur) return@withContext RestoreOutcome(false, "This backup was made by a newer version of the app. Update the app first.", false)
        if (ver < 1) return@withContext RestoreOutcome(false, "This backup does not say which database version it holds.", false)
        val created = opened.header.optLong("created")
        install(context, opened.db, actor, "BACKUP_RESTORED", "from backup made $created, database version $ver", created)
    }

    /** Puts back the data that was on this phone just before the last restore. */
    suspend fun undo(context: Context, actor: String): RestoreOutcome = withContext(Dispatchers.IO) {
        val s = safetyFile(context)
        if (!s.exists() || s.length() == 0L) return@withContext RestoreOutcome(false, "There is no safety copy on this phone.", false)
        if (s.length() > BackupFormat.MAX_DB_BYTES) return@withContext RestoreOutcome(false, "The safety copy is larger than the limit.", false)
        val bytes = try { s.readBytes() } catch (e: Exception) { return@withContext RestoreOutcome(false, "The safety copy could not be read.", false) }
        install(context, bytes, actor, "RESTORE_UNDONE", "data from before the last restore was put back", null)
    }

    private fun install(context: Context, bytes: ByteArray, actor: String, action: String, details: String, fromCreated: Long?): RestoreOutcome {
        val dbFile = context.getDatabasePath(CTDatabase.NAME)
        val dir = dbFile.parentFile ?: return RestoreOutcome(false, "The database folder was not found.", false)
        val tmp = File(dir, CTDatabase.NAME + ".restore-tmp")
        tmp.delete(); deleteSidecars(tmp)
        try {
            // ---- 3 + 4: prepare the new file completely BEFORE touching the real one
            tmp.writeBytes(bytes)
            val liveNums = liveNumbers()
            val d = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                var ok = false
                d.rawQuery("PRAGMA integrity_check", null).use { c -> if (c.moveToFirst()) ok = c.getString(0) == "ok" }
                if (!ok) {
                    return RestoreOutcome(false, "The database inside does not pass SQLite's check. Nothing was changed.", false)
                }
                d.beginTransaction()
                try {
                    val restored = HashMap<String, Long>()
                    d.rawQuery("SELECT `key`, `value` FROM meta WHERE `key` LIKE 'sync:out:%' OR `key` = 'tg:offset'", null).use { c ->
                        while (c.moveToNext()) {
                            val v = c.getString(1)?.toLongOrNull()
                            if (v != null) restored[c.getString(0)] = v
                        }
                    }
                    for ((k, live) in liveNums) {
                        val r = restored[k] ?: 0L
                        val n = if (k.startsWith("sync:out:" + SyncCodec.M2W + ":")) maxOf(r, live) + NUMBER_MARGIN else maxOf(r, live)
                        d.execSQL("INSERT OR REPLACE INTO meta(`key`, `value`) VALUES(?, ?)", arrayOf<Any>(k, n.toString()))
                    }
                    val at = now()
                    d.execSQL("INSERT OR REPLACE INTO meta(`key`, `value`) VALUES(?, ?)", arrayOf<Any>(K_RESTORED_AT, at.toString()))
                    if (fromCreated != null) {
                        d.execSQL("INSERT OR REPLACE INTO meta(`key`, `value`) VALUES(?, ?)", arrayOf<Any>(K_RESTORED_FROM, fromCreated.toString()))
                    }
                    var prev = "GENESIS"
                    d.rawQuery("SELECT hash FROM audit_log ORDER BY id DESC LIMIT 1", null).use { c -> if (c.moveToFirst()) prev = c.getString(0) }
                    val h = Hashing.sha256Hex("$prev|$actor|$action|backup|db|$details|$at")
                    d.execSQL(
                        "INSERT INTO audit_log (actor, action, entityType, entityId, details, createdAt, prevHash, hash) VALUES (?,?,?,?,?,?,?,?)",
                        arrayOf<Any>(actor, action, "backup", "db", details, at, prev, h)
                    )
                    d.setTransactionSuccessful()
                } finally {
                    d.endTransaction()
                }
                d.rawQuery("PRAGMA wal_checkpoint(TRUNCATE)", null).use { it.moveToFirst() }
            } finally {
                d.close()
            }
            deleteSidecars(tmp)
            if (tmp.length() == 0L) return RestoreOutcome(false, "The prepared database is empty. Nothing was changed.", false)

            // ---- 5a: safety copy of what is on the phone now
            val safety = safetyFile(context)
            safety.parentFile?.mkdirs()
            db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").use { it.moveToFirst() }
            val safetyNew = File(safety.path + ".new")
            dbFile.copyTo(safetyNew, overwrite = true)
            if (safetyNew.length() != dbFile.length()) {
                safetyNew.delete()
                return RestoreOutcome(false, "The safety copy could not be written completely (is the phone full?). Nothing was changed.", false)
            }
            safety.delete()
            if (!safetyNew.renameTo(safety)) {
                safetyNew.copyTo(safety, overwrite = true)
                safetyNew.delete()
            }

            // ---- 5b: close the database and put the new file in place
            db.close()
            deleteSidecars(dbFile)
            var placed = tmp.renameTo(dbFile)
            if (!placed) {
                try {
                    tmp.copyTo(dbFile, overwrite = true)
                    tmp.delete()
                    placed = dbFile.length() > 0L
                } catch (e: Exception) {
                    placed = false
                }
            }
            if (!placed) {
                // put the previous data back so the next start still works
                try {
                    deleteSidecars(dbFile)
                    safety.copyTo(dbFile, overwrite = true)
                } catch (e: Exception) {
                    // nothing more can be done here; the safety copy stays in filesDir/restore-safety
                }
                return RestoreOutcome(false, "The new database could not be put in place. The previous data was put back. Restart the app.", true)
            }
            return RestoreOutcome(true, "Done.", true)
        } catch (e: Exception) {
            tmp.delete(); deleteSidecars(tmp)
            return RestoreOutcome(false, "The restore stopped before any change was made: " + (e.message ?: e.javaClass.simpleName), false)
        }
    }
}

/** Starts the app again and ends this process, so the next start opens the restored database cleanly. */
object CTRestart {
    fun now(context: Context) {
        val app = context.applicationContext
        val launch = app.packageManager.getLaunchIntentForPackage(app.packageName)
        if (launch?.component != null) {
            try {
                app.startActivity(Intent.makeRestartActivityTask(launch.component))
            } catch (e: Exception) {
                // the user can open the app again by hand
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({ Runtime.getRuntime().exit(0) }, 300L)
    }
}
