package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PointsReqKind
import com.ctteam.app.data.PointsReqStatus
import com.ctteam.app.data.PointsRequestEntity
import com.ctteam.app.data.ReferralView
import com.ctteam.app.data.ReferralViewCodec
import com.ctteam.app.data.Repos
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Piece R4b — worker: "Use my points". Ask to use points as a cash-out or a gift, and see the answers.
 * The request is saved here and travels to the manager with the normal report (Sync). The manager decides; nothing is promised.
 */
private val WPU_GOOD = Color(0xFF5FD6A5)
private val WPU_WAIT = Color(0xFFFFD166)
private val WPU_BAD = Color(0xFFFF8A8A)

@Composable
fun WorkerPointsUseCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val flow = remember(repos, workerId) { repos.pointsRequests.observeOf(workerId) }
    val requests by flow.collectAsState(initial = emptyList())
    var view by remember { mutableStateOf<ReferralView?>(null) }
    var sentKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var kind by remember { mutableStateOf(PointsReqKind.CASHOUT) }
    var pointsText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(true) }

    // looks again every few seconds: new figures and "has this request been put in a report yet"
    LaunchedEffect(workerId) {
        while (true) {
            view = ReferralViewCodec.load(repos.db, workerId)
            sentKeys = repos.db.syncDao().outboxOf(workerId).map { it.itemKey }.toSet()
            delay(4000)
        }
    }
    val v = view ?: return
    val shown = requests.filter { it.status != PointsReqStatus.CANCELLED }
    val open = shown.firstOrNull { it.status == PointsReqStatus.OPEN }
    val pts = pointsText.toIntOrNull() ?: 0

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Use my points", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "You can ask the manager to use your points as money (cash-out) or for a gift. The manager decides if and when this is possible, " +
                "and the rate (UGX per point) can change, so any amount shown here is an estimate, not a promise.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        if (open != null) {
            Text(
                "You already have a request waiting (" + open.points + " points). You can ask again after the manager answers.",
                color = WPU_WAIT, fontSize = 13.sp
            )
        } else if (v.balance <= 0) {
            Text("You have no points to use yet.", color = CT.TextSoft, fontSize = 13.sp)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CTChip("Cash-out", kind == PointsReqKind.CASHOUT, { kind = PointsReqKind.CASHOUT })
                CTChip("Gift", kind == PointsReqKind.GIFT, { kind = PointsReqKind.GIFT })
            }
            Spacer(Modifier.height(6.dp))
            CTField(pointsText, { pointsText = it.filter { c -> c.isDigit() }.take(6) }, "Points to use (you have " + v.balance + ")", keyboard = KeyboardType.Number)
            if (kind == PointsReqKind.CASHOUT && pts > 0 && v.ugxPerPoint > 0L) {
                Text("About " + ugx(pts.toLong() * v.ugxPerPoint) + " at today's rate (estimate; the rate at the time of approval counts).", color = CT.TextSoft, fontSize = 12.sp)
            }
            CTField(
                note, { note = it.take(300) },
                if (kind == PointsReqKind.GIFT) "What gift would you like?" else "Note for the manager (optional)"
            )
            Spacer(Modifier.height(8.dp))
            GoldButton(text = "SEND REQUEST", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.pointsRequests.request(workerId, pts, kind, note)) {
                        is Outcome.Ok -> {
                            good = true
                            message = "Request saved. It reaches the manager with your next report: open Sync and send it."
                            pointsText = ""; note = ""
                        }
                        is Outcome.Err -> { good = false; message = r.message }
                    }
                }
            })
        }
        if (message.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(message, color = if (good) WPU_GOOD else WPU_BAD, fontSize = 13.sp)
        }

        if (shown.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("My requests", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            for (r in shown.take(10)) {
                Spacer(Modifier.height(8.dp))
                WpuLine(r, sent = ("PTR:" + r.uid) in sentKeys, onCancel = {
                    scope.launch {
                        when (val c = repos.pointsRequests.cancel(workerId, r.uid)) {
                            is Outcome.Ok -> { good = true; message = "Request taken back." }
                            is Outcome.Err -> { good = false; message = c.message }
                        }
                    }
                })
            }
        }
    }
}

@Composable
private fun WpuLine(r: PointsRequestEntity, sent: Boolean, onCancel: () -> Unit) {
    val what = (if (r.kind == PointsReqKind.CASHOUT) "Cash-out" else "Gift") + " · " + r.points + " points"
    Text(what, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    Text(fmtTime(r.createdAt), color = CT.TextSoft, fontSize = 11.sp)
    when (r.status) {
        PointsReqStatus.OPEN -> {
            if (sent) {
                Text("Waiting for the manager's answer.", color = WPU_WAIT, fontSize = 13.sp)
            } else {
                Text("Not sent yet. Open Sync and send your report so the manager can see it.", color = WPU_WAIT, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                GhostButton(text = "TAKE IT BACK", onClick = onCancel, modifier = Modifier.fillMaxWidth())
            }
        }
        PointsReqStatus.APPROVED -> {
            val value = if (r.kind == PointsReqKind.CASHOUT) "UGX " + String.format(java.util.Locale.US, "%,d", r.ugxAmount ?: 0L) else r.giftText
            Text("✓ Approved: " + value, color = WPU_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            val p = r.paidAt
            Text(
                if (p != null) (if (r.kind == PointsReqKind.CASHOUT) "Paid " else "Given ") + fmtTime(p)
                else (if (r.kind == PointsReqKind.CASHOUT) "Waiting for the manager to pay it." else "Waiting for the manager to give it."),
                color = CT.TextSoft, fontSize = 12.sp
            )
            if (r.kind == PointsReqKind.CASHOUT && p == null) {
                val how = when (r.payMethod) {
                    "GIFT" -> "It also shows as an extra payout in your team figures."
                    "WEEKLY" -> if (r.payRef != null) "It is included in your weekly payout." else "It will be added to your next weekly payout request."
                    else -> ""
                }
                if (how.isNotEmpty()) Text(how, color = CT.TextSoft, fontSize = 12.sp)
            }
            if (r.decisionNote.isNotBlank()) Text("Manager: " + r.decisionNote, color = CT.TextSoft, fontSize = 12.sp)
        }
        PointsReqStatus.REJECTED -> {
            Text("Not approved" + (if (r.decisionNote.isNotBlank()) ": " + r.decisionNote else "."), color = WPU_BAD, fontSize = 13.sp)
            Text("Your points were not used.", color = CT.TextSoft, fontSize = 12.sp)
        }
    }
}
