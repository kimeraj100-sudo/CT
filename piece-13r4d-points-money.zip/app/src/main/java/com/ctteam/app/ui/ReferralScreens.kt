package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.ReferralLine
import com.ctteam.app.data.ReferralRules
import com.ctteam.app.data.RefStatus
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece R1 — Manager > Referrals: link a worker to the code they used, award points when the referred worker has real approved work,
 * see points and status, change the settings. Workers do not see anything yet (pieces R2 to R4).
 */
private val RF_BAD = Color(0xFFFF8A8A)

@Composable
private fun RfPick(items: List<Pair<String, String>>, selected: String?, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((id, label) in items) {
            val on = id == selected
            Text(
                label, color = if (on) CT.Navy else Color.White, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (on) CT.Gold else Color(0x20FFFFFF)).clickable { onPick(id) }.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
fun ManagerReferralScreen(repos: Repos, actor: String, isMain: Boolean, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())
    val refFlow = remember(repos) { repos.referral.observeReferrals() }
    val referrals by refFlow.collectAsState(initial = emptyList())
    val balFlow = remember(repos) { repos.referral.observeBalances() }
    val balances by balFlow.collectAsState(initial = emptyList())
    val entriesFlow = remember(repos) { repos.referral.observeEntries(40) }
    val entries by entriesFlow.collectAsState(initial = emptyList())
    val openReqFlow = remember(repos) { repos.pointsRequests.observeOpenCount() }
    val openReq by openReqFlow.collectAsState(initial = 0)

    var tab by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var lines by remember { mutableStateOf<List<ReferralLine>>(emptyList()) }
    var codes by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var awarded by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    // link form
    var referredId by remember { mutableStateOf<String?>(null) }
    var codeText by remember { mutableStateOf("") }
    var rejectFor by remember { mutableStateOf<String?>(null) }
    var rejectNote by remember { mutableStateOf("") }
    // points form
    var pointsWorker by remember { mutableStateOf<String?>(null) }
    var pointsText by remember { mutableStateOf("") }
    var pointsNote by remember { mutableStateOf("") }
    // settings
    var sPoints by remember { mutableStateOf("") }
    var sNeed by remember { mutableStateOf("") }
    var sUgx by remember { mutableStateOf("") }
    var sRate by remember { mutableStateOf("") }      // percent, one decimal allowed
    var sFloor by remember { mutableStateOf("") }
    var sScope by remember { mutableStateOf(ReferralRules.SCOPE_TEAM) }
    var sT by remember { mutableStateOf(listOf("", "", "", "")) }
    var mins by remember { mutableStateOf(ReferralRules.DEFAULT_THRESHOLDS) }

    fun nameOf(id: String) = workers.firstOrNull { it.id == id }?.fullName() ?: "Unknown"
    fun say(m: String, bad: Boolean) { note = m; noteBad = bad }

    LaunchedEffect(referrals, workers.size, tick) { lines = repos.referral.lines() }
    LaunchedEffect(workers.size, tick) {
        codes = workers.associate { it.id to repos.referral.codeFor(it.id) }
        awarded = workers.associate { it.id to repos.referral.awardedCount(it.id) }
    }
    LaunchedEffect(tick) {
        val st = repos.referral.settings()
        sPoints = st.points.toString()
        sNeed = st.need.toString()
        sUgx = st.ugxPerPoint.toString()
        sRate = (st.ratePermille / 10.0).toString().removeSuffix(".0")
        sFloor = st.floor.toString()
        sScope = st.scope
        sT = st.thresholds.map { it.toString() }
        mins = st.thresholds
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Referrals", onBack)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("Referrals", tab == 0, { tab = 0; note = "" })
            CTChip("Points", tab == 1, { tab = 1; note = "" })
            CTChip("Codes", tab == 2, { tab = 2; note = "" })
            CTChip("Rules", tab == 3, { tab = 3; note = "" })
            CTChip(if (openReq > 0) "Requests ($openReq)" else "Requests", tab == 4, { tab = 4; note = "" })
        }
        if (note.isNotEmpty()) { if (noteBad) Text(note, color = RF_BAD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) else SuccessNote(note) }

        when (tab) {
            0 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Record a referral", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "Pick the NEW worker, then type the code they were given by the worker who invited them. Nothing is paid yet: the referral waits for real approved work.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    val free = workers.filter { w -> referrals.none { it.referredId == w.id } }
                    if (free.isEmpty()) Text("Every worker already has a referrer or there are no workers.", color = CT.TextSoft, fontSize = 12.sp)
                    else RfPick(free.map { it.id to it.fullName() }, referredId) { referredId = it }
                    Spacer(Modifier.height(8.dp))
                    CTField(codeText, { codeText = it.take(12) }, "Code (CT-XXXXX)")
                    Spacer(Modifier.height(6.dp))
                    GoldButton(text = "RECORD REFERRAL", modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = referredId
                        if (busy) return@GoldButton
                        if (id == null) { say("Pick the new worker first.", true); return@GoldButton }
                        busy = true
                        scope.launch {
                            when (val r = repos.referral.link(id, codeText, actor)) {
                                is Outcome.Err -> say(r.message, true)
                                is Outcome.Ok -> { say("Recorded. It becomes ready after enough approved work.", false); codeText = ""; referredId = null; tick++ }
                            }
                            busy = false
                        }
                    })
                }
                if (lines.isEmpty()) EmptyState("🤝", "No referrals yet", "Record one above when a new worker used someone's code.")
                val order = lines.sortedBy { if (it.ready) 0 else if (it.referral.status == RefStatus.PENDING) 1 else 2 }
                for (l in order) {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(l.referrerName + "  →  " + l.referredName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        val state = when {
                            l.referral.status == RefStatus.AWARDED -> "AWARDED"
                            l.referral.status == RefStatus.REJECTED -> "REJECTED" + (if (l.referral.note.isNotEmpty()) ": " + l.referral.note else "")
                            l.ready -> "READY: " + l.approved + " approved submissions · worth " + l.points + " points"
                            else -> "WAITING: " + l.approved + " of " + l.need + " approved submissions · worth " + l.points + " points"
                        }
                        Text(state, color = if (l.ready) CT.Teal else CT.TextSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Code " + l.referral.code + " · " + fmtTime(l.referral.createdAt), color = CT.TextSoft, fontSize = 11.sp)
                        if (l.referral.status == RefStatus.PENDING) {
                            Spacer(Modifier.height(6.dp))
                            if (l.ready) {
                                GoldButton(text = "AWARD POINTS", modifier = Modifier.fillMaxWidth(), onClick = {
                                    if (busy) return@GoldButton
                                    busy = true
                                    scope.launch {
                                        when (val r = repos.referral.award(l.referral.referredId, actor)) {
                                            is Outcome.Err -> say(r.message, true)
                                            is Outcome.Ok -> { say(r.value.toString() + " points added to " + l.referrerName + ".", false); tick++ }
                                        }
                                        busy = false
                                    }
                                })
                            }
                            if (rejectFor == l.referral.referredId) {
                                CTField(rejectNote, { rejectNote = it.take(120) }, "Reason (required)")
                                GhostButton(text = "CONFIRM REJECT", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                                    scope.launch {
                                        when (val r = repos.referral.reject(l.referral.referredId, rejectNote, actor)) {
                                            is Outcome.Err -> say(r.message, true)
                                            is Outcome.Ok -> { say("Rejected.", false); rejectFor = null; rejectNote = ""; tick++ }
                                        }
                                    }
                                })
                            } else {
                                GhostButton(text = "REJECT", danger = true, modifier = Modifier.fillMaxWidth(), onClick = { rejectFor = l.referral.referredId; rejectNote = "" })
                            }
                        }
                    }
                }
            }
            1 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Points and status", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Status comes from awarded referrals and never drops when points are spent.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    if (workers.isEmpty()) Text("No workers yet.", color = CT.TextSoft, fontSize = 12.sp)
                    for (w in workers) {
                        val bal = balances.firstOrNull { it.workerId == w.id }?.total ?: 0
                        val st = ReferralRules.tierOf(awarded[w.id] ?: 0, mins).name
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(w.fullName(), color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text("$st · $bal pts", color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Add or remove points", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("For a campaign bonus or a correction. A reason is required and goes in the audit log.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    RfPick(workers.map { it.id to it.fullName() }, pointsWorker) { pointsWorker = it }
                    Spacer(Modifier.height(6.dp))
                    CTField(pointsText, { pointsText = it.filter { c -> c.isDigit() }.take(6) }, "Points (a number)", keyboard = KeyboardType.Number)
                    CTField(pointsNote, { pointsNote = it.take(120) }, "Reason (required)")
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GoldButton(text = "ADD", modifier = Modifier.weight(1f), onClick = {
                            val id = pointsWorker; val n = pointsText.toIntOrNull()
                            if (busy) return@GoldButton
                            if (id == null || n == null || n <= 0) { say("Pick a worker and type the points.", true); return@GoldButton }
                            busy = true
                            scope.launch {
                                when (val r = repos.referral.adjust(id, n, pointsNote, actor)) {
                                    is Outcome.Err -> say(r.message, true)
                                    is Outcome.Ok -> { say("$n points added to " + nameOf(id) + ".", false); pointsText = ""; pointsNote = ""; tick++ }
                                }
                                busy = false
                            }
                        })
                        GhostButton(text = "REMOVE", danger = true, modifier = Modifier.weight(1f), onClick = {
                            val id = pointsWorker; val n = pointsText.toIntOrNull()
                            if (busy) return@GhostButton
                            if (id == null || n == null || n <= 0) { say("Pick a worker and type the points.", true); return@GhostButton }
                            busy = true
                            scope.launch {
                                when (val r = repos.referral.adjust(id, -n, pointsNote, actor)) {
                                    is Outcome.Err -> say(r.message, true)
                                    is Outcome.Ok -> { say("$n points removed from " + nameOf(id) + ".", false); pointsText = ""; pointsNote = ""; tick++ }
                                }
                                busy = false
                            }
                        })
                    }
                }
                Text("Latest entries", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                if (entries.isEmpty()) Text("Nothing yet.", color = CT.TextSoft, fontSize = 12.sp)
                for (e in entries) {
                    Text(
                        fmtTime(e.createdAt) + "  " + nameOf(e.workerId) + "  " + (if (e.points > 0) "+" else "") + e.points + "  " + e.note,
                        color = if (e.points > 0) CT.Teal else RF_BAD, fontSize = 12.sp
                    )
                }
            }
            2 -> {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Referral codes", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Each worker has one code that never changes. Give it to the worker; they share it with people they invite.", color = CT.TextSoft, fontSize = 12.sp)
                }
                if (workers.isEmpty()) EmptyState("👥", "No workers yet", "Codes appear when you add workers.")
                for (w in workers) {
                    val c = codes[w.id] ?: "…"
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(w.fullName(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(c, color = CT.Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                            GhostButton(text = "COPY", onClick = { clipboard.setText(AnnotatedString(c)); say("Copied " + c + " for " + w.fullName() + ".", false) })
                        }
                    }
                }
            }
            4 -> RfRequestsTab(repos = repos, actor = actor, isMain = isMain, names = workers.associate { it.id to it.fullName() }, say = { m, bad -> say(m, bad) })
            else -> {
                val pointsN = sPoints.toIntOrNull() ?: 0
                val rateP = ((sRate.replace(',', '.').toDoubleOrNull() ?: 0.0) * 10.0).let { Math.floor(it + 0.5).toInt() }
                val floorN = sFloor.toIntOrNull() ?: 0
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Referral rules", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        if (isMain) "Only the main manager can change these. Every change is written to the audit log."
                        else "Only the main manager can change these. You can read them here.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    CTField(sPoints, { if (isMain) sPoints = it.filter { c -> c.isDigit() }.take(6) }, "Points for the FIRST referral", keyboard = KeyboardType.Number)
                    CTField(sRate, { if (isMain) sRate = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(5) }, "Reduction for each earlier referral, % (0 = no reduction)", keyboard = KeyboardType.Decimal)
                    CTField(sFloor, { if (isMain) sFloor = it.filter { c -> c.isDigit() }.take(6) }, "Never less than (points)", keyboard = KeyboardType.Number)
                    Text("Who is counted for the reduction?", color = CT.TextSoft, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CTChip("The whole team", sScope == ReferralRules.SCOPE_TEAM, { if (isMain) sScope = ReferralRules.SCOPE_TEAM })
                        CTChip("Each worker's own", sScope == ReferralRules.SCOPE_WORKER, { if (isMain) sScope = ReferralRules.SCOPE_WORKER })
                    }
                    Text(
                        if (sScope == ReferralRules.SCOPE_TEAM) "Team: the earlier a referral comes in compared with ALL referrals, the more it pays. Acting early pays."
                        else "Own: each worker's first referrals pay the most, then less and less.",
                        color = CT.TextSoft, fontSize = 11.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    CTField(sNeed, { if (isMain) sNeed = it.filter { c -> c.isDigit() }.take(3) }, "Approved submissions the new worker needs first", keyboard = KeyboardType.Number)
                    CTField(sUgx, { if (isMain) sUgx = it.filter { c -> c.isDigit() }.take(7) }, "UGX paid for 1 point (only when you approve a cash-out)", keyboard = KeyboardType.Number)
                    Text("Status steps: awarded referrals needed for", color = CT.TextSoft, fontSize = 12.sp)
                    for (i in 0 until 4) {
                        CTField(sT[i], { v -> if (isMain) sT = sT.mapIndexed { j, old -> if (j == i) v.filter { c -> c.isDigit() }.take(4) else old } }, ReferralRules.TIERS[i + 1].name, keyboard = KeyboardType.Number)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (isMain) {
                        GoldButton(text = "SAVE RULES", modifier = Modifier.fillMaxWidth(), onClick = {
                            scope.launch {
                                val st = com.ctteam.app.data.ReferralRepository.RefSettings(
                                    points = pointsN, need = sNeed.toIntOrNull() ?: 0, ugxPerPoint = sUgx.toLongOrNull() ?: -1L,
                                    ratePermille = rateP, floor = floorN, scope = sScope, thresholds = sT.map { it.toIntOrNull() ?: 0 }
                                )
                                val r = repos.referral.saveSettings(st, isMain, actor)
                                if (r is Outcome.Err) say(r.message, true) else { say("Rules saved.", false); tick++ }
                            }
                        })
                    }
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("What a referral pays (preview)", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("By its place in line, with the numbers typed above.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    for (n in listOf(1, 2, 5, 10, 20, 50, 100)) {
                        val p = if (pointsN > 0) ReferralRules.pointsFor(pointsN, rateP.coerceIn(0, 500), floorN.coerceIn(0, pointsN), n - 1) else 0
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Referral number $n", color = Color.White, fontSize = 13.sp)
                            Text("$p points", color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Status ladder", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Counted from awarded referrals (one level only, never from a referral's own referrals).", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    for ((i, t) in ReferralRules.TIERS.withIndex()) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(t.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(if (i == 0) "start" else ReferralRules.thresholdFor(i, mins).toString() + "+ referrals", color = CT.TextSoft, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
