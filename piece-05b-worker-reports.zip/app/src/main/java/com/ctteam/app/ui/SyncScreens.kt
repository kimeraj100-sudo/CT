package com.ctteam.app.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.EnrollPreview
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ReportResult
import com.ctteam.app.data.SyncIncoming
import com.ctteam.app.data.SyncRepository
import com.ctteam.app.data.SyncStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Piece 5A — screens for the signed-message core. Piece 5B adds worker reports and the manager's payout list.
 *  - Worker phone: [WorkerSyncCard] shows the key code, makes the enrollment message and a test message.
 *  - Manager phone: [ManagerSyncScreen] imports pasted text or a file, asks approval for enrollments,
 *    verifies test messages, lists connected workers.
 * Messages move by copy / share / save-as-file; nothing here needs internet.
 */

private val OK_GREEN = Color(0xFF3DDC97)
private val BAD_RED = Color(0xFFFF8A8A)
private const val MAX_IMPORT_BYTES = 300_000

/** Shows one generated message with COPY / SHARE / SAVE AS FILE. */
@Composable
private fun CodeOutput(label: String, code: String, fileName: String) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var note by remember(code) { mutableStateOf("") }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) } != null
                    } catch (ex: Exception) {
                        false
                    }
                }
                note = if (ok) "File saved." else "Could not save the file."
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            code.take(48) + "…  (" + code.length + " characters)",
            color = CT.TextSoft, fontSize = 11.sp, fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = "COPY",
            modifier = Modifier.fillMaxWidth(),
            onClick = { clipboard.setText(AnnotatedString(code)); note = "Copied. Paste it into a private chat with the manager." }
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "SHARE", modifier = Modifier.weight(1f), onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, code)
                }
                context.startActivity(Intent.createChooser(send, "Send to the manager"))
            })
            GhostButton(text = "SAVE AS FILE", modifier = Modifier.weight(1f), onClick = { saver.launch(fileName) })
        }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(note, color = OK_GREEN, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ WORKER PHONE

@Composable
private fun ConnectCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    var keyCheck by remember { mutableStateOf("") }
    var enrollment by remember { mutableStateOf<String?>(null) }
    var test by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(false) }

    LaunchedEffect(workerId) {
        val k = repos.sync.ensureKey(workerId)
        keyCheck = repos.sync.keyCheckOf(k.keyHex)
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Connect to the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Your reports and the manager's replies travel as signed messages that only you and the manager can make. " +
                "Do this once: send your connection code to the manager in a PRIVATE chat, never in a group.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        if (keyCheck.isNotEmpty()) InfoRow("Your key code", keyCheck)
        Text("The manager sees the same code when adding you. Read it to them by phone to be sure nobody swapped the message.", color = CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        if (!open) {
            GhostButton(text = "SHOW CONNECTION OPTIONS", modifier = Modifier.fillMaxWidth(), onClick = { open = true })
        } else {
            GoldButton(text = "MAKE MY CONNECTION CODE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeEnrollment(workerId)) {
                        is Outcome.Ok -> { enrollment = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            enrollment?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Connection code (send to the manager once)", it, "ct-connect.txt") }
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "MAKE A TEST MESSAGE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeTest(workerId, "Test from the worker app")) {
                        is Outcome.Ok -> { test = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            test?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Test message (each one can be accepted only once)", it, "ct-test.txt") }
            if (message.isNotEmpty()) Text(message, color = BAD_RED, fontSize = 12.sp)
        }
    }
}

/** Cards on the worker home screen (real worker only, never in the demo): connect + send reports. */
@Composable
fun WorkerSyncCard(repos: Repos, workerId: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ConnectCard(repos, workerId)
        ReportCard(repos, workerId)
    }
}

@Composable
private fun ReportCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val dm = LocalContext.current.resources.displayMetrics
    val device = dm.widthPixels.toString() + "x" + dm.heightPixels
    val subsFlow = remember(repos, workerId) { repos.db.submissionDao().observeForWorker(workerId) }
    val subs by subsFlow.collectAsState(initial = emptyList())
    val paysFlow = remember(repos, workerId) { repos.db.payoutDao().observeForWorker(workerId) }
    val pays by paysFlow.collectAsState(initial = emptyList())
    var unsent by remember { mutableStateOf(0) }
    var tick by remember { mutableStateOf(0) }
    var choice by remember { mutableStateOf(SyncRepository.SCOPE_NEW) }
    var report by remember { mutableStateOf<ReportResult?>(null) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(subs, pays, tick) { unsent = repos.sync.unsentCount(workerId) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Reports to the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Send your submissions, payout requests and payout-number changes to the manager as signed messages. " +
                "The manager can only pay what they approve on their own phone.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        InfoRow("Not reported yet", unsent.toString())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("New only", choice == SyncRepository.SCOPE_NEW, { choice = SyncRepository.SCOPE_NEW }, Modifier.weight(1f))
            CTChip("This week", choice == SyncRepository.SCOPE_THIS_WEEK, { choice = SyncRepository.SCOPE_THIS_WEEK }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip("Last week", choice == SyncRepository.SCOPE_LAST_WEEK, { choice = SyncRepository.SCOPE_LAST_WEEK }, Modifier.weight(1f))
            CTChip("Everything", choice == SyncRepository.SCOPE_ALL, { choice = SyncRepository.SCOPE_ALL }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (choice == SyncRepository.SCOPE_NEW) "Only things never reported before."
            else "Makes the same messages again (a weekly file). Messages the manager already has are ignored, so sending twice is safe.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(text = "MAKE REPORT", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                error = ""
                when (val r = repos.sync.makeReport(workerId, choice, device)) {
                    is Outcome.Ok -> { report = r.value; tick++ }
                    is Outcome.Err -> { report = null; error = r.message }
                }
            }
        })
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(error, color = BAD_RED, fontSize = 12.sp)
        }
        report?.let { r ->
            Spacer(Modifier.height(8.dp))
            Text(
                r.total.toString() + " message(s) in " + r.parts.size + " part(s), " + r.newCount + " new. Send EVERY part to the manager in a PRIVATE chat.",
                color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
            r.parts.forEachIndexed { i, part ->
                Spacer(Modifier.height(8.dp))
                CodeOutput("Part " + (i + 1) + " of " + r.parts.size + " (" + part.messages + " messages)", part.text, "ct-report-" + (i + 1) + ".txt")
            }
            if (r.parts.size > 1) {
                Spacer(Modifier.height(8.dp))
                CodeOutput("Everything in one file", r.fullText, "ct-report.txt")
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "A report holds fingerprints and details of your screenshots, not the pictures. If the manager asks for the original pictures, send them as a File/Document (not as a photo).",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
    }
}

// ------------------------------------------------------------------ MANAGER PHONE

private class SyncRow(val workerId: String, val name: String, val status: SyncStatus?)

@Composable
private fun EnrollCard(preview: EnrollPreview, busy: Boolean, onApprove: () -> Unit, onCancel: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("New connection request", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        InfoRow("Name", preview.fullName)
        InfoRow("National ID", preview.nationalId)
        InfoRow("Payout number", preview.phoneLocal + " (" + preview.network + ")")
        InfoRow("KEY CODE", preview.keyCheck)
        Spacer(Modifier.height(4.dp))
        Text(
            "Ask the worker to read their key code aloud (phone call). Approve only if it is identical to the code above.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (preview.warning != null) {
            Spacer(Modifier.height(6.dp))
            Text(preview.warning, color = CT.GoldLight, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (preview.problem != null) {
            Text("Cannot approve: " + preview.problem, color = BAD_RED, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else if (preview.mode == "ALREADY") {
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else {
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "KEY CODE MATCHES — APPROVE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (!busy) onApprove() }
            )
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CANCEL", onClick = onCancel, modifier = Modifier.fillMaxWidth(), danger = true)
        }
    }
}

@Composable
fun ManagerSyncScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var pasted by remember { mutableStateOf("") }
    var queue by remember { mutableStateOf<List<SyncIncoming.Enroll>>(emptyList()) }
    var results by remember { mutableStateOf<List<SyncIncoming.Done>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var resetAsk by remember { mutableStateOf<String?>(null) }
    var held by remember { mutableStateOf<List<String>>(emptyList()) }
    var payAsk by remember { mutableStateOf<String?>(null) }
    var payMsg by remember { mutableStateOf("") }
    val payFlow = remember(repos) { repos.db.payoutDao().observeInProgress() }
    val payouts by payFlow.collectAsState(initial = emptyList())

    val keysFlow = remember(repos) { repos.sync.observeKeys() }
    val keys by keysFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())
    var rows by remember { mutableStateOf<List<SyncRow>>(emptyList()) }
    LaunchedEffect(keys, workers, refresh) {
        rows = keys.map { k ->
            SyncRow(k.workerId, workers.firstOrNull { it.id == k.workerId }?.fullName() ?: "(unknown)", repos.sync.status(k.workerId))
        }
    }

    fun process(text: String) {
        if (busy) return
        busy = true
        results = emptyList()
        queue = emptyList()
        held = emptyList()
        scope.launch {
            val all = repos.sync.receiveAll(text, actor)
            queue = all.filterIsInstance<SyncIncoming.Enroll>()
            results = all.filterIsInstance<SyncIncoming.Done>()
            held = results.mapNotNull { it.retryWire }
            refresh++
            busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { ins ->
                            val buf = ByteArray(MAX_IMPORT_BYTES + 1)
                            var n = 0
                            while (n < buf.size) {
                                val r = ins.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            if (n > MAX_IMPORT_BYTES) null else String(buf, 0, n, Charsets.UTF_8)
                        }
                    } catch (ex: Exception) {
                        null
                    }
                }
                if (text == null) results = listOf(SyncIncoming.Done(false, "Could not read the file", "The file is unreadable or too large for a CT Team message."))
                else process(text)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Sync", onBack)
        Text(
            "Messages from workers arrive as text or a small file (copy, Telegram, share). Paste or open them here, one or many at once. " +
                "Every message is checked with the worker's secret key and can only be accepted once. " +
                "Submissions go to Review; amounts always come from YOUR tasks and YOUR approvals, never from the worker's phone.",
            color = CT.TextSoft, fontSize = 13.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Import a message", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            CTField(pasted, { pasted = it }, "Paste one or many messages here", singleLine = false, minLines = 3)
            Spacer(Modifier.height(8.dp))
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "CHECK PASTED MESSAGE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (pasted.isNotBlank()) { val t = pasted; pasted = ""; process(t) } }
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.weight(1f), onClick = {
                    val t = clipboard.getText()?.text ?: ""
                    if (t.isNotBlank()) process(t)
                    else results = listOf(SyncIncoming.Done(false, "Clipboard is empty", "Copy the worker's message first."))
                })
                GhostButton(text = "OPEN FILE", modifier = Modifier.weight(1f), onClick = { filePicker.launch(arrayOf("*/*")) })
            }
        }

        queue.firstOrNull()?.let { p ->
            if (queue.size > 1) Text("Connection request 1 of " + queue.size, color = CT.TextSoft, fontSize = 12.sp)
            EnrollCard(
                preview = p.preview, busy = busy,
                onCancel = { queue = queue.drop(1) },
                onApprove = {
                    busy = true
                    val t = p.wire
                    scope.launch {
                        val r = repos.sync.acceptEnrollment(t, actor)
                        results = results + when (r) {
                            is Outcome.Ok -> SyncIncoming.Done(true, "Worker connected", r.value)
                            is Outcome.Err -> SyncIncoming.Done(false, "Not approved", r.message)
                        }
                        val rest = queue.drop(1)
                        queue = rest
                        if (rest.isEmpty() && held.isNotEmpty()) {
                            // messages that were only waiting for this worker to be connected are tried again now
                            val again = repos.sync.receiveAll(held.joinToString("\n"), actor).filterIsInstance<SyncIncoming.Done>()
                            held = again.mapNotNull { it.retryWire }
                            results = results.filter { it.retryWire == null } + again
                        }
                        refresh++
                        busy = false
                    }
                }
            )
        }

        if (results.size > 1) {
            val good = results.count { it.ok }
            Text(
                results.size.toString() + " messages checked: " + good + " accepted, " + (results.size - good) + " not accepted.",
                color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
        }
        for (r in results) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) OK_GREEN else BAD_RED, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(r.detail, color = Color.White, fontSize = 13.sp)
            }
        }

        val importedCount = results.count { it.imported }
        if (importedCount > 0) {
            Text(
                importedCount.toString() + " item(s) imported. New submissions are waiting in \"Review submissions\" on the dashboard; read any ⚠ lines before approving.",
                color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
            )
        }

        Text("Payout requests waiting (${payouts.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (payouts.isEmpty()) Text("None. A worker's payout request appears here after you import their report.", color = CT.TextSoft, fontSize = 13.sp)
        if (payMsg.isNotEmpty()) Text(payMsg, color = BAD_RED, fontSize = 12.sp)
        for (p in payouts) {
            val wn = workers.firstOrNull { it.id == p.workerId }?.fullName() ?: "(unknown worker)"
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(wn, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                InfoRow("Amount", ugx(p.amountUgx))
                InfoRow("Send to", "0" + p.phone.substring(3) + " (" + p.network + ")")
                InfoRow("Week of", p.weekKey)
                InfoRow("Requested", fmtTime(p.requestedAt))
                if (p.note.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ " + p.note, color = CT.GoldLight, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (payAsk == p.id) {
                    Text("Tap YES only after the money was really sent. A paid record cannot be changed back.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    GoldButton(text = "YES, I SENT IT — MARK PAID", modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = p.id
                        scope.launch {
                            val r = repos.payouts.confirmPaid(id, "MANUAL", null, null, "Marked paid by hand (Sync screen)", actor)
                            payMsg = if (r is Outcome.Err) r.message else ""
                            payAsk = null
                        }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { payAsk = null })
                } else {
                    GhostButton(text = "MARK AS PAID", modifier = Modifier.fillMaxWidth(), onClick = { payAsk = p.id })
                }
            }
        }

        Text("Connected workers (${rows.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (rows.isEmpty()) Text("No worker is connected yet. A worker makes a connection code in their app (Connect to the manager).", color = CT.TextSoft, fontSize = 13.sp)
        for (row in rows) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(row.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                row.status?.let {
                    InfoRow("Key code", it.keyCheck)
                    InfoRow("Messages received", it.received.toString() + (if (it.lastSeq > 0) " (latest #" + it.lastSeq + ")" else ""))
                }
                Spacer(Modifier.height(6.dp))
                if (resetAsk == row.workerId) {
                    Text(
                        "This forgets the worker's key and message history. They must connect again and you must compare the key code. Use it only after a reinstall or a new phone.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "YES, RESET SYNC KEY", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = row.workerId
                        scope.launch { repos.sync.resetKey(id, actor); resetAsk = null; refresh++ }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = null })
                } else {
                    GhostButton(text = "RESET SYNC KEY", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = row.workerId })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
