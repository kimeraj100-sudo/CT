package com.ctteam.app.data

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import org.json.JSONObject

/**
 * Piece U1 — "a new version is ready".
 * The manager types the download link and the new version number; it travels as a normal signed announcement (NOTICE) with three
 * extra fields. The worker phone keeps the newest one here, shows a banner with a DOWNLOAD button and, about once a day, a
 * notification, until the installed app is at least that version. No server, nothing is installed by the app itself:
 * the link just opens in the browser and the person installs the file.
 */
class UpdateInfo(val code: Int, val name: String, val link: String, val at: Long)

object AppUpdate {
    const val KEY = "update:latest"
    const val KEY_REMIND_AT = "update:remind:at"
    const val ID_UPDATE = 9105
    const val LINK_MAX = 300
    private const val REMIND_EVERY_MS = 20L * 3600_000L

    /** Only secure, single-word links. */
    fun validLink(s: String): Boolean =
        s.length in 12..LINK_MAX && s.startsWith("https://") && s.none { it.isWhitespace() || it.isISOControl() }

    fun installedCode(ctx: Context): Int = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0)).toInt()
    } catch (e: Exception) { 0 }

    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }

    suspend fun latest(db: CTDatabase): UpdateInfo? {
        val raw = db.metaDao().get(KEY) ?: return null
        return try {
            val o = JSONObject(raw)
            val code = o.optInt("uv", 0)
            val link = o.optString("ul")
            if (code <= 0 || !validLink(link)) null else UpdateInfo(code, o.optString("un"), link, o.optLong("at", 0L))
        } catch (e: Exception) { null }
    }

    /** Keeps the highest version announced so far (an older announcement arriving late never replaces a newer one). */
    suspend fun save(db: CTDatabase, code: Int, name: String, link: String, at: Long): Boolean {
        if (code <= 0 || !validLink(link)) return false
        val old = latest(db)
        if (old != null && old.code >= code) return false
        db.metaDao().put(MetaEntity(KEY, JSONObject().put("uv", code).put("un", name.take(20)).put("ul", link).put("at", at).toString()))
        db.metaDao().put(MetaEntity(KEY_REMIND_AT, "0"))
        return true
    }

    /** The announced version if this phone is older than it, otherwise null. */
    suspend fun pending(ctx: Context, db: CTDatabase): UpdateInfo? {
        val u = latest(db) ?: return null
        return if (u.code > installedCode(ctx)) u else null
    }

    /** At most one notification per 20 hours, and only while the phone is still on an older version. */
    suspend fun remind(ctx: Context, db: CTDatabase) {
        val u = pending(ctx, db) ?: return
        val last = db.metaDao().get(KEY_REMIND_AT)?.toLongOrNull() ?: 0L
        val now = System.currentTimeMillis()
        if (now - last < REMIND_EVERY_MS) return
        if (!CTNotify.canPost(ctx)) return
        db.metaDao().put(MetaEntity(KEY_REMIND_AT, now.toString()))
        val label = if (u.name.isNotBlank()) " " + u.name else ""
        CTNotify.post(
            ctx, ID_UPDATE, CTNotify.CH_WORKER, "CT Team: please update",
            "A new version$label is ready. Open CT Team and tap DOWNLOAD UPDATE."
        )
    }
}

/** Background job (about every 6 hours): shows the daily "please update" reminder when it is due. */
class UpdateReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            AppUpdate.remind(applicationContext, ServiceLocator.get(applicationContext).db)
        } catch (e: Exception) {
            // tried again next time
        }
        return Result.success()
    }
}
