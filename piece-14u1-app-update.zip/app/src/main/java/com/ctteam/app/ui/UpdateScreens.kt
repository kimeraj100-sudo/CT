package com.ctteam.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import com.ctteam.app.data.AppUpdate
import com.ctteam.app.data.CTNotify
import com.ctteam.app.data.Repos
import com.ctteam.app.data.UpdateInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val UPD_BAD = Color(0xFFFF8A8A)

/** Worker home: shows while this phone runs an older version than the one the manager announced. */
@Composable
fun WorkerUpdateBanner(repos: Repos) {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf<UpdateInfo?>(null) }
    var failed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            info = AppUpdate.pending(ctx, repos.db)
            delay(4000)
        }
    }
    val u = info ?: return
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("⬇️ New version ready" + (if (u.name.isNotBlank()) " (" + u.name + ")" else ""), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "You have " + AppUpdate.installedName(ctx) + ". Tap the button, download the file, open it and install. Your tasks and records stay on the phone. If the phone asks, allow installing from your browser.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (!CTNotify.canPost(ctx)) {
            Spacer(Modifier.height(4.dp))
            Text("Turn on notifications (menu > Reminders) to get a daily reminder.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        GoldButton(text = "DOWNLOAD UPDATE", modifier = Modifier.fillMaxWidth(), onClick = {
            failed = try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                false
            } catch (e: Exception) { true }
        })
        if (failed) Text("Could not open the link. Ask the manager to send it another way.", color = UPD_BAD, fontSize = 12.sp)
    }
}

/** Manager: announce a new version (download link + version number) to every worker with a linked Telegram chat. */
@Composable
fun ManagerReleaseCard(repos: Repos, actor: String, workerCount: Int, onResult: (String, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf(AppUpdate.installedCode(ctx).toString()) }
    var name by remember { mutableStateOf(AppUpdate.installedName(ctx)) }
    var link by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Release a new version", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Upload the new app file anywhere with a direct https link (for example GitHub Releases), paste the link here and send it. Workers on an older version get a banner with a DOWNLOAD button and a daily reminder until they update. The two boxes below start with the version on THIS phone: change them to the new version.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        CTField(code, { code = it.filter { c -> c.isDigit() }.take(6); confirm = false }, "New version code (a number, e.g. 69)", keyboard = KeyboardType.Number)
        Spacer(Modifier.height(6.dp))
        CTField(name, { name = it.take(20); confirm = false }, "New version name (e.g. 0.68.0)")
        Spacer(Modifier.height(6.dp))
        CTField(link, { link = it.trim().take(AppUpdate.LINK_MAX); confirm = false; err = "" }, "Download link (https://…)")
        Spacer(Modifier.height(6.dp))
        CTField(note, { note = it.take(200); confirm = false }, "What is new (optional)", singleLine = false, minLines = 2)
        if (err.isNotEmpty()) Text(err, color = UPD_BAD, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = if (sending) "SENDING…" else if (confirm) "TAP AGAIN TO SEND TO $workerCount" else "ANNOUNCE UPDATE ($workerCount)",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (sending) return@GoldButton
                val c = code.toIntOrNull() ?: 0
                if (c <= 0) { err = "Enter the new version code."; return@GoldButton }
                if (!AppUpdate.validLink(link)) { err = "The link must start with https:// and have no spaces."; return@GoldButton }
                if (!confirm) { confirm = true; return@GoldButton }
                sending = true; confirm = false; err = ""
                val text = "⬇️ New CT Team version" + (if (name.isNotBlank()) " " + name else "") + " is ready. Open CT Team and tap DOWNLOAD UPDATE, or download here: " +
                    link + (if (note.isNotBlank()) "\n" + note.trim() else "")
                scope.launch {
                    val lines = repos.telegram.sendAnnouncement(text, actor, c, name, link)
                    val good = lines.count { it.report.ok }
                    onResult(
                        good.toString() + " of " + lines.size + " sent." + lines.filter { !it.report.ok }.joinToString("") { "\n" + it.workerName + ": " + it.report.message },
                        good < lines.size
                    )
                    sending = false
                }
            }
        )
    }
}
