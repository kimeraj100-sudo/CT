package com.ctteam.app.ui

import com.ctteam.app.data.SyncCodec
import com.ctteam.app.data.SyncRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Piece 9B — text or a small file that was SHARED INTO the app (Android share sheet, for example from Telegram).
 *
 * MainActivity puts it here; the screen that can use it takes it:
 *  - a manager update / reset code (made for a worker)  -> Worker mode, used as soon as the worker is signed in
 *  - a worker's report or request (made for the manager) -> Manager mode, opened in Sync once a manager is signed in
 * Nothing here is trusted: every message still goes through the normal checks (signature, replay protection, approvals).
 * Memory only: nothing is stored, and the text is gone when the app is closed.
 */
object ShareInbox {
    const val MAX_CHARS = 300_000

    enum class Target { WORKER, MANAGER }

    private val box = MutableStateFlow<String?>(null)
    val pending: StateFlow<String?> get() = box

    /** When the clipboard was last looked at / which clipboard text the worker already used or turned down (see WorkerIncomingCard). */
    @Volatile var lastClipboardCheckAt: Long = 0L
    @Volatile var lastClipboardHash: Int = 0

    /** Called by MainActivity. Only text that really holds a CT Team message is kept; anything else is ignored. */
    fun offer(raw: String?) {
        val t = raw?.take(MAX_CHARS) ?: return
        if (!t.contains("CT1.")) return
        if (SyncCodec.parseAll(t).isEmpty()) return
        box.value = t
    }

    fun clear() { box.value = null }

    /** Where this text belongs, or null when it holds both kinds (the person then opens the right mode themselves). */
    fun targetOf(text: String): Target? {
        val all = SyncCodec.parseAll(text)
        val toWorker = all.any { it.direction == SyncCodec.M2W }
        val toManager = all.any { it.direction == SyncCodec.W2M }
        return when {
            toWorker && !toManager -> Target.WORKER
            toManager && !toWorker -> Target.MANAGER
            else -> null
        }
    }

    fun anyForWorkers(text: String): Boolean = SyncCodec.parseAll(text).any { it.direction == SyncCodec.M2W }

    fun hasResetCodeFor(text: String, workerId: String): Boolean =
        SyncCodec.parseAll(text).any { it.direction == SyncCodec.M2W && it.workerId == workerId && it.type == SyncRepository.TYPE_RESET }

    /** Updates the worker's app can use right now: made for this worker, and not a reset or join code. */
    fun countUpdatesFor(text: String, workerId: String): Int =
        SyncCodec.parseAll(text).count {
            it.direction == SyncCodec.M2W && it.workerId == workerId && it.type in SyncRepository.WORKER_TYPES
        }
}
