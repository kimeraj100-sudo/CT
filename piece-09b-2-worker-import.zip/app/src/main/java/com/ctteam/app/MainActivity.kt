package com.ctteam.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.ui.CTApp
import com.ctteam.app.ui.CTTheme
import com.ctteam.app.ui.ShareInbox

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Open the local database in the background and record the app start.
        // A database problem must never crash the screen.
        val appContext = applicationContext
        Thread {
            try {
                val version = appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName ?: "?"
                kotlinx.coroutines.runBlocking {
                    ServiceLocator.get(appContext).audit.event("APP_START", "v$version")
                }
            } catch (e: Throwable) {
                android.util.Log.e("CTTeam", "Database start failed", e)
            }
        }.start()

        // Piece 9B: text or a small file shared INTO the app (Share > CT Team). A rotation re-delivers the same intent, so only
        // the first start reads it; a share that arrives while the app is open comes through the listener below.
        if (savedInstanceState == null) readShared(intent)
        addOnNewIntentListener { readShared(it) }

        setContent {
            CTTheme {
                CTApp()
            }
        }
    }

    /** Reads shared text and/or a shared text file (at most 300 KB) and hands it to [ShareInbox], which keeps it only if it holds a CT Team message. */
    private fun readShared(shared: Intent?) {
        if (shared == null || shared.action != Intent.ACTION_SEND) return
        val text = shared.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() ?: ""
        @Suppress("DEPRECATION")
        val stream = shared.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (stream == null) {
            ShareInbox.offer(text)
            return
        }
        val resolver = contentResolver
        Thread {
            val fileText = try {
                resolver.openInputStream(stream)?.use { ins ->
                    val buf = ByteArray(ShareInbox.MAX_CHARS + 1)
                    var n = 0
                    while (n < buf.size) {
                        val r = ins.read(buf, n, buf.size - n)
                        if (r < 0) break
                        n += r
                    }
                    if (n > ShareInbox.MAX_CHARS) "" else String(buf, 0, n, Charsets.UTF_8)
                } ?: ""
            } catch (e: Exception) {
                ""
            }
            ShareInbox.offer(text + "\n" + fileText)
        }.start()
    }
}
