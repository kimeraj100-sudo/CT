package com.ctteam.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.SubmissionEntity
import com.ctteam.app.data.TaskEntity
import com.ctteam.app.data.TaskType
import com.ctteam.app.data.TimeUtil

/**
 * Piece 4C1 — worker task list + task detail.
 *
 * The screens in this file only know plain UI models (WTask, WorkerHomeData). The real worker feeds them from the
 * database (buildTaskCards); the demo feeds them from WorkerDemo. That way the demo looks exactly like the real thing
 * and never touches the database.
 */

enum class TaskState { AVAILABLE, WAITING, DONE }

data class WTask(
    val id: String,
    val name: String,
    val description: String,
    val payUgx: Long,
    val type: String,                 // TaskType
    val exampleVideoUrl: String,
    val exampleLinkUrl: String,
    val proofRequirements: String,
    val state: TaskState,
    val note: String = ""
) {
    val isDaily: Boolean get() = type == TaskType.DAILY
    val typeLabel: String get() = if (isDaily) "Daily" else "One-time"
    val stateLabel: String
        get() = when (state) {
            TaskState.AVAILABLE -> "Ready to do"
            TaskState.WAITING -> "Waiting for review"
            TaskState.DONE -> if (isDaily) "Done today" else "Completed"
        }
}

/** Everything the worker home + task screens need, whether it comes from the database or from the demo. */
data class WorkerHomeData(
    val firstName: String,
    val fullName: String,
    val username: String,
    val nationalId: String,
    val payoutNumber: String,
    val network: String,
    val registeredAt: Long,
    val active: Boolean,
    val expectedUgx: Long,
    val pending: Int,
    val approved: Int,
    val rejected: Int,
    val tasks: List<WTask>,
    val submissions: List<WSub> = emptyList()     // Piece 4C3
)

sealed interface WRoute {
    object Home : WRoute
    object Tasks : WRoute
    class TaskDetail(val taskId: String) : WRoute
    class Submit(val taskId: String) : WRoute      // Piece 4C2
    object History : WRoute                         // Piece 4C3
    object Payout : WRoute                          // Piece 4C4
}

/**
 * Turns the active tasks + this worker's submissions into list cards.
 * Same rules as SubmissionRepository.availableTasks: a daily task is used up for the current East Africa day by a
 * PENDING or APPROVED submission, a one-time task by one forever; a REJECTED submission frees the task again.
 */
fun buildTaskCards(tasks: List<TaskEntity>, subs: List<SubmissionEntity>, nowMs: Long): List<WTask> {
    val day = TimeUtil.dayKey(nowMs)
    return tasks
        .filter { it.active }
        .sortedBy { it.createdAt }
        .map { t ->
            val daily = t.type == TaskType.DAILY
            val mine = subs.filter { it.taskId == t.id && !it.superseded && (!daily || it.dayKey == day) }
            val (state, note) = when {
                mine.any { it.status == SubStatus.PENDING } ->
                    Pair(TaskState.WAITING, "Your proof was sent. The manager has not reviewed it yet.")
                mine.any { it.status == SubStatus.APPROVED } ->
                    Pair(
                        TaskState.DONE,
                        if (daily) "Approved. This task comes back tomorrow." else "Approved. This is a one-time task, so it is finished."
                    )
                else -> {
                    val rejected = mine.filter { it.status == SubStatus.REJECTED }.maxByOrNull { it.submittedAt }
                    val text = if (rejected == null) "" else
                        "Your last proof was rejected" +
                            (if (rejected.decisionNote.isNotBlank()) ": " + rejected.decisionNote else ".") +
                            " You can submit again."
                    Pair(TaskState.AVAILABLE, text)
                }
            }
            WTask(
                id = t.id, name = t.name, description = t.description, payUgx = t.payUgx, type = t.type,
                exampleVideoUrl = t.exampleVideoUrl, exampleLinkUrl = t.exampleLinkUrl,
                proofRequirements = t.proofRequirements, state = state, note = note
            )
        }
        .sortedBy { it.state.ordinal }
}

private val RED = Color(0xFFFF8A8A)

@Composable
private fun Tag(text: String, colour: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(colour.copy(alpha = 0.22f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = colour, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun stateColour(s: TaskState): Color = when (s) {
    TaskState.AVAILABLE -> CT.Teal
    TaskState.WAITING -> CT.Gold
    TaskState.DONE -> Color(0xFF7BD88F)
}

// ------------------------------------------------------------------ TASK LIST

@Composable
fun WorkerTaskListScreen(
    tasks: List<WTask>,
    accountActive: Boolean,
    onOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    val ready = tasks.count { it.state == TaskState.AVAILABLE }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("My tasks", onBack)
        if (!accountActive) {
            Text("Your account is disabled by the manager. You cannot see tasks. Contact support.", color = RED, fontSize = 14.sp)
        } else if (tasks.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("No tasks right now", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text("The manager has not published any tasks yet. Check again later.", color = CT.TextSoft, fontSize = 13.sp)
            }
        } else {
            Text(
                if (ready == 0) "Nothing to do right now. Daily tasks come back every day (East Africa time)."
                else "$ready task" + (if (ready == 1) "" else "s") + " ready to do. Daily tasks come back every day (East Africa time).",
                color = CT.TextSoft, fontSize = 13.sp
            )
            for (t in tasks) {
                GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpen(t.id) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            t.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f).padding(end = 10.dp)
                        )
                        Text(ugx(t.payUgx), color = CT.GoldLight, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Tag(t.typeLabel, Color(0xFFB79BFF))
                        Tag(t.stateLabel, stateColour(t.state))
                    }
                    if (t.note.isNotBlank() && t.state == TaskState.AVAILABLE) {
                        Spacer(Modifier.height(8.dp))
                        Text(t.note, color = RED, fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ TASK DETAIL

/** Opens a manager-supplied link in the browser / matching app. Only http(s) links are allowed. */
private fun openLink(context: Context, raw: String): Boolean {
    val u = raw.trim()
    if (u.isEmpty()) return false
    val lower = u.lowercase()
    val url = when {
        lower.startsWith("http://") || lower.startsWith("https://") -> u
        u.contains("://") -> return false
        else -> "https://$u"
    }
    return try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        true
    } catch (e: Exception) {
        false
    }
}

@Composable
fun WorkerTaskDetailScreen(
    task: WTask?,
    accountActive: Boolean,
    onSubmit: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var linkMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(task?.name ?: "Task", onBack)
        if (task == null || !accountActive) {
            Text(
                if (!accountActive) "Your account is disabled by the manager. Contact support."
                else "This task is no longer available.",
                color = RED, fontSize = 14.sp
            )
            Spacer(Modifier.height(8.dp))
            return@Column
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Pay", ugx(task.payUgx))
            InfoRow("Type", if (task.isDaily) "Daily — comes back every day" else "One-time — only once")
            InfoRow("Status", task.stateLabel)
        }

        if (task.note.isNotBlank()) {
            Text(task.note, color = if (task.state == TaskState.AVAILABLE) RED else CT.GoldLight, fontSize = 13.sp)
        }

        Text("What to do", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            if (task.description.isBlank()) "No description was added for this task." else task.description,
            color = Color.White, fontSize = 14.sp
        )

        Text("Proof you must send", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            if (task.proofRequirements.isBlank()) "Send a clear screenshot showing that you did the task."
            else task.proofRequirements,
            color = Color.White, fontSize = 14.sp
        )
        Text(
            "Use your own screenshots, uncropped and unedited. The system only flags problems — the manager makes the final decision.",
            color = CT.TextSoft, fontSize = 12.sp
        )

        if (task.exampleVideoUrl.isNotBlank() || task.exampleLinkUrl.isNotBlank()) {
            Text("Examples", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            if (task.exampleVideoUrl.isNotBlank()) {
                GhostButton(
                    text = "WATCH EXAMPLE VIDEO",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        linkMessage = if (openLink(context, task.exampleVideoUrl)) "" else "Could not open the video link."
                    }
                )
            }
            if (task.exampleLinkUrl.isNotBlank()) {
                GhostButton(
                    text = "OPEN EXAMPLE LINK",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        linkMessage = if (openLink(context, task.exampleLinkUrl)) "" else "Could not open the link."
                    }
                )
            }
            if (linkMessage.isNotEmpty()) Text(linkMessage, color = RED, fontSize = 13.sp)
        }

        Spacer(Modifier.height(4.dp))
        when (task.state) {
            TaskState.AVAILABLE -> GoldButton(text = "SUBMIT PROOF", onClick = onSubmit, modifier = Modifier.fillMaxWidth())
            TaskState.WAITING -> Text("You already sent proof for this task. Wait for the manager's decision.", color = CT.GoldLight, fontSize = 13.sp)
            TaskState.DONE -> Text(
                if (task.isDaily) "Done for today. Come back tomorrow." else "This one-time task is finished.",
                color = CT.GoldLight, fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ PLACEHOLDER for pieces still to come

@Composable
fun WorkerComingSoonScreen(title: String, piece: String, text: String, onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(title, onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Coming in $piece", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(text, color = CT.TextSoft, fontSize = 13.sp)
        }
    }
}
