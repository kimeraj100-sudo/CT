package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ProofEntity
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.SubmissionEntity
import com.ctteam.app.data.TaskEntity
import com.ctteam.app.data.TimeUtil
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Piece 4C3 — worker submissions + earnings history.
 * Like the task screens, this file only knows plain UI models (WSub, WProof). The real worker feeds them from the
 * database, the demo from WorkerDemo (memory only).
 */

class WProof(
    val kind: String,              // SCREENSHOT, REFERENCE, TEXT
    val fileName: String,
    val size: Long?,
    val width: Int?,
    val height: Int?,
    val modifiedAt: Long?,
    val mime: String,
    val fingerprint: String,       // first characters of the SHA-256
    val text: String
)

data class WSub(
    val id: String,
    val taskName: String,
    val payUgx: Long,
    val status: String,            // SubStatus
    val weekKey: String,
    val submittedAt: Long,
    val decidedAt: Long?,
    val decisionNote: String,
    val referenceText: String,
    val explanation: String,
    val inPayout: Boolean,         // approved money already attached to a payout request
    val superseded: Boolean
)

fun buildSubCards(subs: List<SubmissionEntity>, tasks: List<TaskEntity>): List<WSub> {
    val names = tasks.associate { it.id to it.name }
    return subs.map {
        WSub(
            id = it.id, taskName = names[it.taskId] ?: "Task", payUgx = it.payUgx, status = it.status,
            weekKey = it.weekKey, submittedAt = it.submittedAt, decidedAt = it.decidedAt,
            decisionNote = it.decisionNote, referenceText = it.referenceText, explanation = it.explanation,
            inPayout = it.payoutId != null, superseded = it.superseded
        )
    }
}

fun toWProof(p: ProofEntity): WProof = WProof(
    kind = p.kind, fileName = p.fileName ?: "", size = p.fileSize, width = p.width, height = p.height,
    modifiedAt = p.fileModifiedAt, mime = p.mime ?: "", fingerprint = (p.sha256 ?: "").take(12), text = p.textValue ?: ""
)

private val RED = Color(0xFFFF8A8A)
private val GREEN = Color(0xFF7BD88F)

private fun statusLabel(s: String) = when (s) {
    SubStatus.APPROVED -> "Approved"
    SubStatus.REJECTED -> "Rejected"
    else -> "Pending"
}

private fun statusColour(s: String): Color = when (s) {
    SubStatus.APPROVED -> GREEN
    SubStatus.REJECTED -> RED
    else -> CT.Gold
}

private fun weekLabel(weekKey: String): String = try {
    val start = LocalDate.parse(weekKey)
    val end = start.plusDays(6)
    val f = DateTimeFormatter.ofPattern("d MMM", Locale.US)
    f.format(start) + " – " + f.format(end) + " " + end.year
} catch (ex: Exception) {
    weekKey
}

private fun sizeText(bytes: Long): String =
    if (bytes >= 1024 * 1024) String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    else String.format(Locale.US, "%d KB", maxOf(1L, bytes / 1024))

@Composable
private fun StatusChip(status: String) {
    val c = statusColour(status)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.22f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(statusLabel(status), color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private sealed interface HRow {
    class Week(val key: String, val subs: List<WSub>) : HRow
    class Item(val sub: WSub) : HRow
}

private fun buildRows(subs: List<WSub>): List<HRow> {
    val out = mutableListOf<HRow>()
    val weeks = subs.groupBy { it.weekKey }.toSortedMap(compareByDescending<String> { it })
    for ((key, list) in weeks) {
        val sorted = list.sortedByDescending { it.submittedAt }
        out.add(HRow.Week(key, sorted))
        for (s in sorted) out.add(HRow.Item(s))
    }
    return out
}

@Composable
private fun WeekCard(row: HRow.Week) {
    val approved = row.subs.filter { it.status == SubStatus.APPROVED }
    val pending = row.subs.filter { it.status == SubStatus.PENDING }
    val rejected = row.subs.filter { it.status == SubStatus.REJECTED }
    val expected = approved.filter { !it.inPayout }.sumOf { it.payUgx }
    val inPayout = approved.filter { it.inPayout }.sumOf { it.payUgx }
    val thisWeek = row.key == TimeUtil.weekKey(System.currentTimeMillis())

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(
            (if (thisWeek) "This week · " else "") + weekLabel(row.key),
            color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp
        )
        Spacer(Modifier.height(6.dp))
        InfoRow("Approved (${approved.size})", ugx(approved.sumOf { it.payUgx }))
        InfoRow("Pending (${pending.size})", ugx(pending.sumOf { it.payUgx }))
        InfoRow("Rejected (${rejected.size})", "not paid")
        InfoRow("Expected payout", ugx(expected))
        if (inPayout > 0) InfoRow("Already in a payout request", ugx(inPayout))
    }
}

@Composable
private fun SubCard(sub: WSub, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                sub.taskName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            )
            Text(ugx(sub.payUgx), color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusChip(sub.status)
            Text(fmtTime(sub.submittedAt), color = CT.TextSoft, fontSize = 12.sp)
        }
        if (sub.status == SubStatus.REJECTED && sub.decisionNote.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text("Manager's note: " + sub.decisionNote, color = RED, fontSize = 12.sp)
        }
    }
}

@Composable
fun WorkerHistoryScreen(
    subs: List<WSub>,
    loadProofs: suspend (submissionId: String) -> List<WProof>,
    onBack: () -> Unit
) {
    var openId by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = openId != null) { openId = null }

    val rows = remember(subs) { buildRows(subs) }
    val open = subs.firstOrNull { it.id == openId }
    if (open != null) {
        SubmissionDetail(sub = open, loadProofs = loadProofs, onBack = { openId = null })
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, top = 20.dp)) {
        ScreenHeader("Submissions & earnings", onBack)
        if (rows.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Nothing sent yet", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text("When you send proof for a task it appears here with its status.", color = CT.TextSoft, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(rows) { row ->
                    when (row) {
                        is HRow.Week -> WeekCard(row)
                        is HRow.Item -> SubCard(row.sub) { openId = row.sub.id }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubmissionDetail(sub: WSub, loadProofs: suspend (String) -> List<WProof>, onBack: () -> Unit) {
    var proofs by remember(sub.id) { mutableStateOf<List<WProof>?>(null) }
    LaunchedEffect(sub.id) {
        proofs = try {
            loadProofs(sub.id)
        } catch (ex: Exception) {
            emptyList()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(sub.taskName, onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusChip(sub.status)
                Text(ugx(sub.payUgx), color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            InfoRow("Sent", fmtTime(sub.submittedAt))
            val decided = sub.decidedAt
            if (decided != null) InfoRow(if (sub.status == SubStatus.APPROVED) "Approved" else "Rejected", fmtTime(decided))
            InfoRow("Week", weekLabel(sub.weekKey))
            if (sub.status == SubStatus.APPROVED) InfoRow("Payout", if (sub.inPayout) "In a payout request" else "Not requested yet")
            if (sub.superseded) InfoRow("Note", "Task was re-assigned by the manager")
        }

        if (sub.status == SubStatus.REJECTED) {
            Text(
                if (sub.decisionNote.isNotBlank()) "Manager's note: " + sub.decisionNote else "The manager rejected this proof without a note.",
                color = RED, fontSize = 14.sp
            )
        } else if (sub.status == SubStatus.APPROVED && sub.decisionNote.isNotBlank()) {
            Text("Manager's note: " + sub.decisionNote, color = CT.GoldLight, fontSize = 14.sp)
        } else if (sub.status == SubStatus.PENDING) {
            Text("Waiting for the manager to review this proof.", color = CT.GoldLight, fontSize = 14.sp)
        }

        if (sub.referenceText.isNotBlank()) {
            Text("Reference", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(sub.referenceText, color = Color.White, fontSize = 14.sp)
        }
        if (sub.explanation.isNotBlank()) {
            Text("Your explanation", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(sub.explanation, color = Color.White, fontSize = 14.sp)
        }

        Text("Proof sent", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        val list = proofs
        if (list == null) {
            Text("Loading…", color = CT.TextSoft, fontSize = 13.sp)
        } else if (list.isEmpty()) {
            Text("No files were recorded.", color = CT.TextSoft, fontSize = 13.sp)
        } else {
            for (p in list) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    if (p.kind == "SCREENSHOT") {
                        Text(p.fileName.ifBlank { "Screenshot" }, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        val dims = if (p.width != null && p.height != null) "${p.width}×${p.height}" else ""
                        val size = p.size?.let { sizeText(it) } ?: ""
                        val line = listOf(dims, size, p.mime).filter { it.isNotBlank() }.joinToString(" · ")
                        if (line.isNotBlank()) Text(line, color = CT.TextSoft, fontSize = 12.sp)
                        if (p.modifiedAt != null) Text("File date: " + fmtTime(p.modifiedAt), color = CT.TextSoft, fontSize = 12.sp)
                        if (p.fingerprint.isNotBlank()) Text("Fingerprint: " + p.fingerprint + "…", color = CT.TextSoft, fontSize = 12.sp)
                    } else {
                        Text(p.text.ifBlank { p.kind }, color = Color.White, fontSize = 14.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
