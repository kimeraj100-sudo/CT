package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/*
 * PIECE 9A — TELEGRAM, manager side: connect a bot, read what workers send it, import it automatically.
 *
 * HOW IT WORKS (no server, no cost):
 *  - The manager makes a free bot with @BotFather and pastes its token into this app. ONLY the manager phone holds the token.
 *  - A worker shares a CT Team message (the SHARE button already in the worker app) into the bot's chat. The manager app
 *    reads the bot's messages (getUpdates, long polling, only while the manager area is open) and runs every CT1 message
 *    through the SAME checks as copy/paste: HMAC, replay protection, manager approval for enrollments and reset requests.
 *  - A text file (.txt / .ctt) sent to the bot is read the same way.
 *  - After a worker's NEW signed message is accepted, the app remembers that worker's Telegram chat so Piece 9B can send back.
 *
 * HONEST LIMITS: Telegram bot chats are not end-to-end encrypted, so every message stays signed (it cannot be forged or
 * replayed) but is readable by Telegram. The token is stored in this app's private database (not the Android Keystore) and
 * must be treated as a password: anyone holding it controls the bot. Only ONE program may read a bot at a time. The app
 * reads messages only while the manager area is open; Telegram keeps unread messages for about 24 hours.
 */

// ------------------------------------------------------------------ TABLES

/** Which Telegram chat belongs to which worker. Only set after a NEW message signed with that worker's key was accepted. */
@Entity(tableName = "tg_chats")
data class TgChatEntity(
    @PrimaryKey val workerId: String,
    val chatId: Long,
    val username: String?,
    val firstName: String,
    val boundAt: Long,
    val lastSeenAt: Long
)

object TgKind {
    const val OK = "OK"                  // log: a message was used
    const val FAIL = "FAIL"              // log: a message was refused
    const val ENROLL = "ENROLL"          // needs the manager (Sync screen)
    const val RESET_REQ = "RESET_REQ"    // needs the manager (Sync screen)
    const val HELD = "HELD"              // could not be used yet (worker not connected); try again later
    const val FILE = "FILE"              // log: a file that is not a CT message
}

object TgState {
    const val PENDING = "PENDING"
    const val DONE = "DONE"
}

@Entity(tableName = "tg_inbox", indices = [Index("status")])
data class TgInboxEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receivedAt: Long,
    val chatId: Long,
    val workerId: String?,
    val kind: String,
    val status: String,
    val title: String,
    val detail: String,
    val wire: String?,                // the signed message itself, kept only while it still needs the manager
    val handledAt: Long?
)

@Dao
interface TgDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putChat(c: TgChatEntity)
    @Query("SELECT * FROM tg_chats WHERE workerId = :workerId") suspend fun chat(workerId: String): TgChatEntity?
    @Query("SELECT COUNT(*) FROM tg_chats WHERE chatId = :telegramChatId") suspend fun boundCount(telegramChatId: Long): Int
    @Query("SELECT * FROM tg_chats ORDER BY lastSeenAt DESC") fun observeChats(): Flow<List<TgChatEntity>>

    @Insert suspend fun addInbox(e: TgInboxEntity): Long
    @Query("SELECT * FROM tg_inbox ORDER BY id DESC LIMIT :limit") fun observeInbox(limit: Int): Flow<List<TgInboxEntity>>
    @Query("SELECT COUNT(*) FROM tg_inbox WHERE status = 'PENDING'") fun observePendingCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM tg_inbox WHERE wire = :wire AND status = 'PENDING'") suspend fun pendingWithWire(wire: String): Int
    @Query("SELECT * FROM tg_inbox WHERE id = :rowId") suspend fun inbox(rowId: Long): TgInboxEntity?
    @Query("UPDATE tg_inbox SET status = :state, handledAt = :at, wire = NULL WHERE id = :rowId") suspend fun setInboxState(rowId: Long, state: String, at: Long)
    @Query("DELETE FROM tg_inbox WHERE status != 'PENDING' AND id NOT IN (SELECT id FROM tg_inbox ORDER BY id DESC LIMIT 300)") suspend fun trimInbox()
}

// ------------------------------------------------------------------ BOT API CLIENT (plain HttpURLConnection, no extra library)

sealed class TgResult<out T> {
    class Ok<T>(val value: T) : TgResult<T>()
    class Err(val code: Int, val message: String) : TgResult<Nothing>()
}

class TelegramClient(token: String) {
    private val base = "https://api.telegram.org/bot$token/"
    private val fileBase = "https://api.telegram.org/file/bot$token/"

    private fun call(method: String, params: JSONObject, readTimeoutMs: Int): TgResult<Any?> {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(base + method).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = readTimeoutMs
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use { it.write(params.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            val json = try { JSONObject(body) } catch (ex: Exception) { null }
            if (code in 200..299 && json != null && json.optBoolean("ok")) {
                TgResult.Ok(json.opt("result"))
            } else {
                val desc = json?.optString("description")?.takeIf { it.isNotBlank() } ?: ("HTTP " + code)
                TgResult.Err(json?.optInt("error_code", code) ?: code, desc)
            }
        } catch (ex: UnknownHostException) {
            TgResult.Err(0, "No internet connection.")
        } catch (ex: SocketTimeoutException) {
            TgResult.Err(0, "The connection to Telegram timed out.")
        } catch (ex: IOException) {
            TgResult.Err(0, "Network error while talking to Telegram.")
        } catch (ex: Exception) {
            TgResult.Err(0, "Unexpected error while talking to Telegram.")
        } finally {
            conn?.disconnect()
        }
    }

    fun getMe(): TgResult<JSONObject> = when (val r = call("getMe", JSONObject(), 20_000)) {
        is TgResult.Ok -> (r.value as? JSONObject)?.let { TgResult.Ok(it) } ?: TgResult.Err(0, "Unexpected answer from Telegram.")
        is TgResult.Err -> r
    }

    /** getUpdates and a webhook cannot both be used, so the webhook is removed (messages already waiting are kept). */
    fun deleteWebhook(): TgResult<Unit> = when (val r = call("deleteWebhook", JSONObject().put("drop_pending_updates", false), 20_000)) {
        is TgResult.Ok -> TgResult.Ok(Unit)
        is TgResult.Err -> r
    }

    fun getUpdates(offset: Long, timeoutSec: Int): TgResult<JSONArray> {
        val p = JSONObject().put("offset", offset).put("timeout", timeoutSec).put("limit", 50)
            .put("allowed_updates", JSONArray().put("message"))
        return when (val r = call("getUpdates", p, (timeoutSec + 20) * 1000)) {
            is TgResult.Ok -> (r.value as? JSONArray)?.let { TgResult.Ok(it) } ?: TgResult.Err(0, "Unexpected answer from Telegram.")
            is TgResult.Err -> r
        }
    }

    /** Downloads a file a user sent to the bot (Telegram allows bots to download up to 20 MB). */
    fun downloadFile(fileId: String, maxBytes: Int): TgResult<ByteArray> {
        val info = call("getFile", JSONObject().put("file_id", fileId), 20_000)
        val path = when (info) {
            is TgResult.Ok -> (info.value as? JSONObject)?.optString("file_path")?.takeIf { it.isNotBlank() }
                ?: return TgResult.Err(0, "Telegram gave no file path.")
            is TgResult.Err -> return info
        }
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(fileBase + path).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
            }
            if (conn.responseCode !in 200..299) return TgResult.Err(conn.responseCode, "Could not download the file.")
            val buf = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(8192)
            conn.inputStream.use { ins ->
                while (true) {
                    val n = ins.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                    if (buf.size() > maxBytes) return TgResult.Err(0, "The file is too large.")
                }
            }
            TgResult.Ok(buf.toByteArray())
        } catch (ex: Exception) {
            TgResult.Err(0, "Could not download the file.")
        } finally {
            conn?.disconnect()
        }
    }
}

// ------------------------------------------------------------------ REPOSITORY

class TgLive(
    val running: Boolean = false,
    val lastOkAt: Long = 0L,
    val lastError: String? = null,
    val handledTotal: Int = 0
)

class TgPollResult(val handled: Int, val error: String?)

class TelegramRepository(
    private val db: CTDatabase,
    private val audit: AuditRepository,
    private val sync: SyncRepository
) {
    private val meta = db.metaDao()
    private val dao = db.tgDao()
    private val loopLock = Mutex()
    private val liveState = MutableStateFlow(TgLive())

    /** Live status for the screen (in memory only). */
    val live: StateFlow<TgLive> get() = liveState

    companion object {
        private const val KEY_TOKEN = "tg:token"
        private const val KEY_BOT = "tg:bot"
        private const val KEY_OFFSET = "tg:offset"
        private const val KEY_PAUSED = "tg:paused"
        private val TOKEN_RULE = Regex("^[0-9]{6,12}:[A-Za-z0-9_-]{30,60}$")
        private const val MAX_TEXT_FILE = 3_000_000
        private const val POLL_SECONDS = 25
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- connect / settings

    suspend fun token(): String? = meta.get(KEY_TOKEN)?.takeIf { TOKEN_RULE.matches(it) }
    suspend fun botName(): String? = meta.get(KEY_BOT)?.takeIf { it.isNotBlank() }
    suspend fun isPaused(): Boolean = meta.get(KEY_PAUSED) == "1"

    suspend fun setPaused(paused: Boolean, actor: String) {
        meta.put(MetaEntity(KEY_PAUSED, if (paused) "1" else "0"))
        audit.log(actor, if (paused) "TG_PAUSED" else "TG_RESUMED", "telegram", "bot", "")
    }

    /** Checks the token with Telegram (getMe) and keeps it. The token is never written to the audit log. */
    suspend fun connect(tokenRaw: String, actor: String): Outcome<String> {
        val t = tokenRaw.trim()
        if (!TOKEN_RULE.matches(t)) return Outcome.Err("That does not look like a bot token. It looks like 123456789:ABC... and comes from @BotFather.")
        val me = withContext(Dispatchers.IO) {
            val c = TelegramClient(t)
            when (val r = c.getMe()) {
                is TgResult.Err -> r
                is TgResult.Ok -> {
                    c.deleteWebhook()
                    r
                }
            }
        }
        val name: String = when (me) {
            is TgResult.Err -> return Outcome.Err(friendly(me))
            is TgResult.Ok -> me.value.optString("username")
        }
        if (name.isBlank()) return Outcome.Err("Telegram did not return a bot name. Is this a bot token?")
        meta.put(MetaEntity(KEY_TOKEN, t))
        meta.put(MetaEntity(KEY_BOT, name))
        meta.put(MetaEntity(KEY_PAUSED, "0"))
        audit.log(actor, "TG_CONNECTED", "telegram", "bot", "bot @$name")
        return Outcome.Ok(name)
    }

    suspend fun disconnect(actor: String) {
        val name = botName()
        meta.put(MetaEntity(KEY_TOKEN, ""))
        meta.put(MetaEntity(KEY_BOT, ""))
        audit.log(actor, "TG_DISCONNECTED", "telegram", "bot", "bot @" + (name ?: "?"))
        liveState.value = TgLive()
    }

    private fun friendly(e: TgResult.Err): String = when (e.code) {
        401 -> "Telegram refused the bot token. It is wrong or was revoked. Paste a new token from @BotFather."
        409 -> "Another program is reading this bot (a second phone, or a webhook). Only one phone can read a bot at a time."
        429 -> "Telegram says: too many requests. The app will wait and try again."
        else -> e.message
    }

    // ---------------------------------------------------------------- the reading loop

    /** Runs until cancelled. Started while the manager is signed in; stops when the manager area closes. */
    suspend fun pollLoop(actorOf: () -> String) {
        loopLock.withLock {
            try {
                while (currentCoroutineContext().isActive) {
                    if (token() == null || isPaused()) {
                        liveState.value = TgLive(running = false, lastOkAt = liveState.value.lastOkAt, lastError = null, handledTotal = liveState.value.handledTotal)
                        delay(4000)
                        continue
                    }
                    val before = liveState.value
                    liveState.value = TgLive(true, before.lastOkAt, before.lastError, before.handledTotal)
                    val r = pollOnce(actorOf(), POLL_SECONDS)
                    val s = liveState.value
                    if (r.error != null) {
                        liveState.value = TgLive(true, s.lastOkAt, r.error, s.handledTotal)
                        delay(15_000)
                    } else {
                        liveState.value = TgLive(true, now(), null, s.handledTotal + r.handled)
                    }
                }
            } finally {
                val s = liveState.value
                liveState.value = TgLive(false, s.lastOkAt, s.lastError, s.handledTotal)
            }
        }
    }

    private suspend fun pollOnce(actor: String, timeoutSec: Int): TgPollResult {
        val t = token() ?: return TgPollResult(0, "No bot is connected.")
        val client = TelegramClient(t)
        val offset = meta.get(KEY_OFFSET)?.toLongOrNull() ?: 0L
        val r = withContext(Dispatchers.IO) { client.getUpdates(offset, timeoutSec) }
        val arr: JSONArray = when (r) {
            is TgResult.Err -> return TgPollResult(0, friendly(r))
            is TgResult.Ok -> r.value
        }
        var handled = 0
        for (i in 0 until arr.length()) {
            val u = arr.optJSONObject(i) ?: continue
            val uid = u.optLong("update_id", -1L)
            try {
                if (handleUpdate(client, u, actor)) handled++
            } catch (ex: Exception) {
                audit.event("TG_UPDATE_ERROR", ex.javaClass.simpleName)
            }
            if (uid >= 0L) meta.put(MetaEntity(KEY_OFFSET, (uid + 1L).toString()))
        }
        dao.trimInbox()
        return TgPollResult(handled, null)
    }

    // ---------------------------------------------------------------- one update

    private suspend fun handleUpdate(client: TelegramClient, u: JSONObject, actor: String): Boolean {
        val m = u.optJSONObject("message") ?: return false
        val chat = m.optJSONObject("chat") ?: return false
        if (chat.optString("type") != "private") return false          // groups and channels are ignored
        val chatId = chat.optLong("id", 0L)
        if (chatId == 0L) return false
        val from = m.optJSONObject("from")
        val username = from?.optString("username")?.takeIf { it.isNotBlank() }
        val firstName = (from?.optString("first_name") ?: "").take(60)

        var text = m.optString("text").ifEmpty { m.optString("caption") }
        val doc = m.optJSONObject("document")
        var docName = ""
        if (doc != null) {
            docName = doc.optString("file_name").take(80)
            val lower = docName.lowercase()
            val mime = doc.optString("mime_type")
            val size = doc.optLong("file_size", 0L)
            val textual = lower.endsWith(".txt") || lower.endsWith(".ctt") || mime.startsWith("text/")
            if (textual && size in 1L..MAX_TEXT_FILE.toLong()) {
                val got = withContext(Dispatchers.IO) { client.downloadFile(doc.optString("file_id"), MAX_TEXT_FILE) }
                when (got) {
                    is TgResult.Ok -> text = text + "\n" + String(got.value, Charsets.UTF_8)
                    is TgResult.Err -> {
                        log(chatId, null, TgKind.FAIL, "File not read: $docName", got.message + " Ask the sender to send it again.")
                        return true
                    }
                }
            }
        }

        if (!text.contains("CT1.")) {
            if (doc != null && isBound(chatId)) {
                log(chatId, null, TgKind.FILE, "File received: " + docName.ifBlank { "(no name)" },
                    "It is not a CT Team message. Pictures and other files are not used yet.")
                return true
            }
            return false          // strangers and chatter: ignored in silence
        }

        // remember what was already accepted, so a replayed copy can never move a worker's chat
        val envelopes = SyncCodec.parseAll(text).filter { it.direction == SyncCodec.W2M && it.type != SyncRepository.TYPE_ENROLL }
        val before = HashMap<String, Long>()
        for (e in envelopes) if (e.workerId !in before) before[e.workerId] = db.syncDao().maxSeen(e.workerId, SyncCodec.W2M)

        val results = sync.receiveAll(text, actor)

        for (e in envelopes) {
            val key = sync.keyOf(e.workerId) ?: continue
            if (SyncCodec.verify(key.keyHex, e) && e.seq > (before[e.workerId] ?: Long.MAX_VALUE)) bind(e.workerId, chatId, username, firstName, actor)
        }
        for (res in results) record(res, chatId)
        return true
    }

    private suspend fun isBound(chatId: Long): Boolean = dao.boundCount(chatId) > 0

    private suspend fun bind(workerId: String, chatId: Long, username: String?, firstName: String, actor: String) {
        val old = dao.chat(workerId)
        val at = now()
        if (old == null) {
            dao.putChat(TgChatEntity(workerId, chatId, username, firstName, at, at))
            audit.log(actor, "TG_CHAT_BOUND", "worker", workerId, "Telegram chat linked")
        } else {
            if (old.chatId != chatId) audit.log(actor, "TG_CHAT_CHANGED", "worker", workerId, "the worker now writes from another Telegram account")
            dao.putChat(old.copy(chatId = chatId, username = username ?: old.username, firstName = firstName.ifBlank { old.firstName }, lastSeenAt = at))
        }
    }

    private suspend fun log(chatId: Long, workerId: String?, kind: String, title: String, detail: String) {
        dao.addInbox(TgInboxEntity(receivedAt = now(), chatId = chatId, workerId = workerId, kind = kind, status = TgState.DONE,
            title = title.take(120), detail = detail.take(400), wire = null, handledAt = now()))
    }

    private suspend fun pend(chatId: Long, workerId: String?, kind: String, title: String, detail: String, wire: String) {
        if (dao.pendingWithWire(wire) > 0) return           // the same message sent twice
        dao.addInbox(TgInboxEntity(receivedAt = now(), chatId = chatId, workerId = workerId, kind = kind, status = TgState.PENDING,
            title = title.take(120), detail = detail.take(400), wire = wire, handledAt = null))
    }

    private suspend fun record(res: SyncIncoming, chatId: Long) {
        when (res) {
            is SyncIncoming.Enroll -> {
                val p = res.preview
                pend(chatId, p.workerId, TgKind.ENROLL, "Connection request: " + p.fullName,
                    "Key code " + p.keyCheck + (if (p.problem != null) ". Problem: " + p.problem else ""), res.wire)
            }
            is SyncIncoming.ResetRequest ->
                pend(chatId, res.workerId, TgKind.RESET_REQ, "Reset request: " + res.workerName, "Check code " + res.checkCode, res.wire)
            is SyncIncoming.Done ->
                if (res.retryWire != null) pend(chatId, null, TgKind.HELD, res.title, res.detail, res.retryWire)
                else log(chatId, null, if (res.ok) TgKind.OK else TgKind.FAIL, res.title, res.detail)
        }
    }

    // ---------------------------------------------------------------- for the screen

    fun observeChats(): Flow<List<TgChatEntity>> = dao.observeChats()
    fun observeInbox(limit: Int): Flow<List<TgInboxEntity>> = dao.observeInbox(limit)
    fun observePendingCount(): Flow<Int> = dao.observePendingCount()

    /** The manager opened the item in Sync (or dismissed it). The signed text is dropped from the inbox. */
    suspend fun markHandled(rowId: Long): String? {
        val row = dao.inbox(rowId) ?: return null
        dao.setInboxState(rowId, TgState.DONE, now())
        return row.wire
    }
}
