package com.ctteam.app.data

import android.content.Context

/** One place to get the database and all repositories: ServiceLocator.get(context). */
class Repos(val db: CTDatabase) {
    val audit = AuditRepository(db)
    val workers = WorkerRepository(db, audit)
    val tasks = TaskRepository(db, audit)
    val submissions = SubmissionRepository(db, audit)
    val payouts = PayoutRepository(db, audit)
    val manager = ManagerRepository(db, audit)                // legacy single-PIN table (unused since piece 4A)
    val managerAccounts = ManagerAccountRepository(db, audit) // up to 20 managers: code name + password + PIN
    val workerAuth = WorkerAuthRepository(db, audit)          // worker username + password + PIN (piece 4B)
    val sync = SyncRepository(db, audit)                      // signed messages between phones (piece 5)
    val managerSync = ManagerSyncRepository(db, audit)        // signed manager access codes between phones (piece 5E)
    val verification = VerificationRepository(db)             // automatic screenshot checks (piece 6)
    val nc = NcRepository(db, audit)                          // NC Wallet statements and rows (piece 8B)
    val team = TeamRepository(db, audit)                      // team mining ledger, shares, rates (piece T1)
    val teamGoals = TeamGoalRepository(db, audit)             // weekly hash goal + rig ledger (piece T3b)
    val teamGifts = TeamGiftRepository(db, audit)             // gifts from the manager to a worker (piece T3c)
    val teamBoard = TeamBoardRepository(db, audit)            // leaderboard, quiet workers, weekly summary (piece T4)
    val telegram = TelegramRepository(db, audit, sync)        // Telegram bot: read worker messages, chats (piece 9A)
}

object ServiceLocator {
    @Volatile private var instance: Repos? = null

    fun get(context: Context): Repos =
        instance ?: synchronized(this) {
            instance ?: Repos(CTDatabase.build(context)).also { instance = it }
        }
}
