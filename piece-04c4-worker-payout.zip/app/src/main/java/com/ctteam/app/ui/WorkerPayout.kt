package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PayoutRequestEntity
import com.ctteam.app.data.PayoutStatus
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TimeUtil
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.launch

/**
 * Piece 4C4 — payout request + payout status.
 * Like the other worker screens this file only knows plain UI models (WPayout). The real worker feeds them from the
 * database (`PayoutDao.observeForWorker`), the demo from memory.
 */

data class WPayout(
    val id: String,
    val weekKey: String,
    val amountUgx: Long,
    val phone: String,             // number the money goes to, frozen when the request was made (local format)
    val network: String,
    val status: String,            // PayoutStatus
    val requestedAt: Long,
    val paidAt: Long?
)

fun toWPayout(p: PayoutRequestEntity): WPayout = WPayout(
    id = p.id, weekKey = p.weekKey, amountUgx = p.amountUgx,
    phone = if (p.phone.length > 3) "0" + p.phone.substring(3) else p.phone,
    network = p.network, status = p.status, requestedAt = p.requestedAt, paidAt = p.paidAt
)

private val PAY_GREEN = Color(0xFF3DDC97)
private val PAY_RED = Color(0xFFFF8A8A)

private fun payWeekLabel(weekKey: String): String = try {
    val start = LocalDate.parse(weekKey)
    val end = start.plusDays(6)
    val f = DateTimeFormatter.ofPattern("d MMM", Locale.US)
    f.format(start) + " – " + f.format(end) + " " + end.year
} catch (ex: Exception) {
    weekKey
}

/** One week that still has approved money that is not part of any payout request. */
private class ReadyWeek(val key: String, val amount: Long, val alreadyHasPayout: Boolean)

/** Same rule as the database query: approved, not yet attached to a payout (superseded ones are not counted). */
private fun readyWeeks(subs: List<WSub>, payouts: List<WPayout>): List<ReadyWeek> =
    subs.filter { it.status == SubStatus.APPROVED && !it.inPayout && !it.superseded }
        .groupBy { it.weekKey }
        .map { (key, list) -> ReadyWeek(key, list.sumOf { it.payUgx }, payouts.any { it.weekKey == key }) }
        .filter { it.amount > 0 }
        .sortedByDescending { it.key }

@Composable
private fun PayChip(status: String) {
    val paid = status == PayoutStatus.PAID
    val c = if (paid) PAY_GREEN else CT.Gold
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.22f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(if (paid) "✅ Paid" else "🟡 In progress", color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun WorkerPayoutScreen(
    subs: List<WSub>,
    payouts: List<WPayout>,
    payoutNumber: String,
    network: String,
    accountActive: Boolean,
    onRequest: suspend (weekKey: String) -> Outcome<Unit>,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var confirmWeek by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var messageIsError by remember { mutableStateOf(false) }

    val inProgress = payouts.firstOrNull { it.status == PayoutStatus.IN_PROGRESS }
    val weeks = readyWeeks(subs, payouts)
    val thisWeek = TimeUtil.weekKey(System.currentTimeMillis())

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Request payout", onBack)

        if (!accountActive) {
            Text("Your account is disabled by the manager. Contact support.", color = PAY_RED, fontSize = 13.sp)
        }

        if (message.isNotEmpty()) {
            Text(message, color = if (messageIsError) PAY_RED else PAY_GREEN, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }

        // ---- payout in progress (only one allowed at a time)
        if (inProgress != null) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Payout in progress", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    PayChip(inProgress.status)
                }
                Spacer(Modifier.height(6.dp))
                InfoRow("Amount", ugx(inProgress.amountUgx))
                InfoRow("Week", payWeekLabel(inProgress.weekKey))
                InfoRow("Sending to", inProgress.phone + " (" + inProgress.network + ")")
                InfoRow("Requested", fmtTime(inProgress.requestedAt))
                Spacer(Modifier.height(4.dp))
                Text(
                    "The manager sends the money and then marks it as paid here. You cannot request another payout, " +
                        "or change your payout number, until this one is paid.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
            }
        }

        // ---- weeks that can be requested
        Text("Ready to request", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (weeks.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Nothing approved is waiting for a payout.", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Only tasks the manager has approved count. Check Submissions & earnings to see what is still pending.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
            }
        }
        for (w in weeks) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    (if (w.key == thisWeek) "This week · " else "") + payWeekLabel(w.key),
                    color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Spacer(Modifier.height(6.dp))
                InfoRow("Approved, not yet requested", ugx(w.amount))
                InfoRow("Will be sent to", payoutNumber + " (" + network + ")")
                Spacer(Modifier.height(6.dp))
                when {
                    w.alreadyHasPayout -> Text(
                        "A payout for this week was already requested, so this extra amount cannot be requested on its own. " +
                            "Ask the manager about it.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    !accountActive -> Text("Disabled accounts cannot request a payout.", color = CT.TextSoft, fontSize = 12.sp)
                    inProgress != null -> Text("Available once your payout in progress is paid.", color = CT.TextSoft, fontSize = 12.sp)
                    confirmWeek == w.key -> {
                        Text(
                            "Request " + ugx(w.amount) + " to " + payoutNumber + "? The money is sent to this number. " +
                                "You cannot change the number while the payout is in progress.",
                            color = Color.White, fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        GoldButton(
                            text = if (busy) "PLEASE WAIT" else "YES, REQUEST PAYOUT",
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                if (busy) return@GoldButton
                                busy = true
                                message = ""
                                val key = w.key
                                scope.launch {
                                    when (val r = onRequest(key)) {
                                        is Outcome.Ok -> {
                                            messageIsError = false
                                            message = "Payout requested. The manager will send it and mark it paid."
                                        }
                                        is Outcome.Err -> {
                                            messageIsError = true
                                            message = r.message
                                        }
                                    }
                                    confirmWeek = null
                                    busy = false
                                }
                            }
                        )
                        Spacer(Modifier.height(6.dp))
                        GhostButton(text = "CANCEL", onClick = { confirmWeek = null }, modifier = Modifier.fillMaxWidth())
                    }
                    else -> GoldButton(
                        text = "REQUEST PAYOUT",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { message = ""; confirmWeek = w.key }
                    )
                }
            }
        }

        // ---- history of requests
        Text("My payout requests", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (payouts.isEmpty()) {
            Text("No payout requests yet.", color = CT.TextSoft, fontSize = 13.sp)
        }
        for (p in payouts.sortedByDescending { it.requestedAt }) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(ugx(p.amountUgx), color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    PayChip(p.status)
                }
                Spacer(Modifier.height(6.dp))
                InfoRow("Week", payWeekLabel(p.weekKey))
                InfoRow("Number", p.phone + " (" + p.network + ")")
                InfoRow("Requested", fmtTime(p.requestedAt))
                if (p.status == PayoutStatus.PAID && p.paidAt != null) InfoRow("Paid", fmtTime(p.paidAt))
            }
        }

        Text(
            "Payout weeks run Monday to Sunday (East Africa Time). A payout is only final when the manager marks it Paid.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
    }
}
