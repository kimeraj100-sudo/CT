package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.BadgeInput
import com.ctteam.app.data.Repos
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TeamBadges
import com.ctteam.app.data.TeamLevels
import com.ctteam.app.data.TeamStreaks
import com.ctteam.app.data.TeamView
import com.ctteam.app.data.TeamViewCodec
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.delay
import java.time.LocalDate

/**
 * Piece T4 — the worker's level, rank, streaks, badges and week summary.
 * Everything is worked out ON THIS PHONE from the team figures the manager sent (TeamView) and the worker's own submissions,
 * so it needs no new message except the rank and, if the manager allows it, the top 5 names. Levels follow the all-time
 * contribution and never go down. Nothing here promises any payment.
 */

private val GREEN = Color(0xFF7BD88F)

/** Real worker: loads the newest team figures (same 4-second look as the team card) and draws the card. */
@Composable
fun WorkerTeamBoardCard(repos: Repos, workerId: String, subs: List<WSub>) {
    var view by remember { mutableStateOf<TeamView?>(null) }
    LaunchedEffect(workerId) {
        while (true) {
            view = TeamViewCodec.load(repos.db, workerId)
            delay(4000)
        }
    }
    TeamBoardContent(view = view, subs = subs, demo = false)
}

private class WeekFigures(val label: String, val tasks: Int, val taskUgx: Long, val deposits: Int, val depositUgx: Long)

private fun weekFigures(label: String, weekKey: String, subs: List<WSub>, view: TeamView?): WeekFigures {
    val done = subs.filter { it.weekKey == weekKey && it.status == SubStatus.APPROVED && !it.superseded }
    val startMs = LocalDate.parse(weekKey).atStartOfDay(TimeUtil.EAT).toInstant().toEpochMilli()
    val endMs = startMs + 7L * 24 * 60 * 60 * 1000
    val dep = view?.contributions?.filter { it.active && it.contributedAtUtc in startMs until endMs } ?: emptyList()
    return WeekFigures(label, done.size, done.sumOf { it.payUgx }, dep.size, dep.sumOf { it.valueUgx ?: 0L })
}

@Composable
fun TeamBoardContent(view: TeamView?, subs: List<WSub>, demo: Boolean) {
    var picked by remember { mutableStateOf<String?>(null) }
    val now = System.currentTimeMillis()

    val activeDeposits = view?.contributions?.filter { it.active } ?: emptyList()
    val allTime = view?.myAllTimeUgx ?: 0L
    val level = TeamLevels.forUgx(allTime)
    val nextLevel = TeamLevels.next(level)
    val weekStreak = TeamStreaks.weekStreak(activeDeposits.map { it.contributedAtUtc }, now)
    val doneDays = subs.filter { it.status == SubStatus.APPROVED && !it.superseded }.map { TimeUtil.dayKey(it.submittedAt) }.toSet()
    val dayStreak = TeamStreaks.dayStreak(doneDays, now)
    val approvedTasks = subs.count { it.status == SubStatus.APPROVED && !it.superseded }
    val rank = view?.rank
    val prev = view?.prevRank
    val rankedUp = rank != null && prev != null && rank < prev
    val depositCount = activeDeposits.size + (view?.moreCount ?: 0)
    val badgeInput = BadgeInput(
        allTimeUgx = allTime, deposits = depositCount, weekStreak = weekStreak, dayStreak = dayStreak, approvedTasks = approvedTasks,
        rank = rank, ranked = view?.contributors ?: 0, rankedUp = rankedUp,
        goalReachedWithMyDeposit = (view?.goalReached() ?: false) && activeDeposits.isNotEmpty(),
        hasGift = (view?.gifts?.isNotEmpty() ?: false)
    )
    val earned = TeamBadges.earned(badgeInput)

    val thisWeekKey = TimeUtil.weekKey(now)
    val lastWeekKey = LocalDate.parse(thisWeekKey).minusWeeks(1).toString()
    val lastWeek = weekFigures("Last week", lastWeekKey, subs, view)
    val thisWeek = weekFigures("This week", thisWeekKey, subs, view)

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("My level, streaks and badges", color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))

        // ---- level
        Text(level.emoji + "  " + level.name, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        if (nextLevel != null) {
            val p = TeamLevels.progress(allTime).toFloat()
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(p.coerceIn(0.02f, 1f)).height(10.dp).clip(RoundedCornerShape(50)).background(CT.Gold))
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "UGX " + String.format(java.util.Locale.US, "%,d", maxOf(0L, nextLevel.minUgx - allTime)) + " more verified deposits to reach " +
                    nextLevel.emoji + " " + nextLevel.name + ". Levels follow everything you have ever contributed and never go down.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else {
            Text("Top level reached. Levels never go down.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))

        // ---- rank
        if (rank != null && (view?.contributors ?: 0) > 0) {
            Text("Rank among contributors", color = CT.TextSoft, fontSize = 12.sp)
            Text("#" + rank + " of " + view?.contributors, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            if (prev != null && prev != rank) {
                if (rank < prev) Text("▲ Up " + (prev - rank) + (if (prev - rank == 1) " place" else " places") + " since the update before", color = GREEN, fontSize = 12.sp)
                else Text("▼ Down " + (rank - prev) + (if (rank - prev == 1) " place" else " places") + " since the update before", color = CT.TextSoft, fontSize = 12.sp)
            }
            Text("The ranking follows your share (verified deposits, with the slow decay). It is an estimate from the manager's figures.", color = CT.TextSoft, fontSize = 11.sp)
        } else {
            Text("You are not ranked yet. Your rank appears after the manager verifies your first deposit and sends the next update.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))

        // ---- streaks
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StreakTile("🔥", weekStreak.toString(), if (weekStreak == 1) "week with a deposit in a row" else "weeks with a deposit in a row", Modifier.weight(1f))
            StreakTile("📅", dayStreak.toString(), if (dayStreak == 1) "day with an approved task in a row" else "days with an approved task in a row", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        // ---- badges
        Text("Badges (" + earned.size + " of " + TeamBadges.ALL.size + ")", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        val chunks = TeamBadges.ALL.chunked(3)
        for (row in chunks) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (b in row) {
                    val got = b.id in earned
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (picked == b.id) Color(0x33FFD700) else Color(0x1AFFFFFF))
                            .clickable { picked = if (picked == b.id) null else b.id }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(if (got) b.emoji else "🔒", fontSize = 22.sp)
                        Text(
                            b.title, color = if (got) Color.White else CT.TextSoft, fontSize = 10.sp,
                            fontWeight = if (got) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center
                        )
                    }
                }
                for (i in row.size until 3) Spacer(Modifier.weight(1f))
            }
        }
        val pb = TeamBadges.ALL.firstOrNull { it.id == picked }
        if (pb != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                pb.emoji + " " + pb.title + ": " + pb.how + (if (pb.id in earned) "  ✅ You have it." else ""),
                color = CT.GoldLight, fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(10.dp))

        // ---- week summary
        Text("My weeks", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        for (w in listOf(thisWeek, lastWeek)) {
            Spacer(Modifier.height(4.dp))
            Text(w.label, color = CT.Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            InfoRow("Tasks approved", w.tasks.toString() + " (" + ugx(w.taskUgx) + ")")
            InfoRow("Deposits verified", w.deposits.toString() + " (" + ugx(w.depositUgx) + ")")
        }
        Spacer(Modifier.height(10.dp))

        // ---- leaderboard (only when the manager switched it on)
        val board = view?.board ?: emptyList()
        if (board.isNotEmpty()) {
            Text("Top contributors", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text("Shown with the manager's permission: names and levels only, no amounts.", color = CT.TextSoft, fontSize = 11.sp)
            for ((i, e) in board.withIndex()) {
                val lv = TeamLevels.byIndex(e.level)
                Text((i + 1).toString() + ".  " + e.name + "   " + lv.emoji + " " + lv.name, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp))
            }
        } else {
            Text("The manager has not turned on the top contributors list.", color = CT.TextSoft, fontSize = 11.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Levels, badges and ranks are for motivation. They are estimates from the manager's figures and are not a promise of payment.",
            color = CT.TextSoft, fontSize = 11.sp
        )
        if (demo) Text("Demo: made-up figures.", color = CT.TextSoft, fontSize = 11.sp)
    }
}

@Composable
private fun StreakTile(emoji: String, value: String, label: String, modifier: Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x1AFFFFFF)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji + " " + value, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text(label, color = CT.TextSoft, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}
