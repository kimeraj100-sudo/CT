package com.ctteam.app.data

import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/*
 * PIECE T4 — TEAM MINING: levels, streaks, badges, leaderboard, quiet-worker alerts, weekly summary.
 * NO database change. Everything is computed from data that already exists:
 *   - levels / badges / streaks are computed on the WORKER phone from the team figures it already has (TEAM_VIEW) and the
 *     worker's own submissions, so they work without any new message;
 *   - the only new things sent to a worker are `rk` (my rank) and, only if the manager switched it on, `lb` (the top 5:
 *     first name + last initial + level, never amounts or shares);
 *   - the manager's leaderboard, quiet-worker list and weekly summary text are computed on the manager phone.
 * Levels follow the ALL-TIME verified contribution, so a level never goes down. Nothing here promises any payment.
 */

object TeamLevels {
    class Level(val index: Int, val name: String, val emoji: String, val minUgx: Long)

    val ALL: List<Level> = listOf(
        Level(0, "Starter", "🌱", 0L),
        Level(1, "Bronze", "🥉", 1L),
        Level(2, "Silver", "🥈", 100_000L),
        Level(3, "Gold", "🥇", 500_000L),
        Level(4, "Platinum", "💠", 2_000_000L),
        Level(5, "Diamond", "💎", 10_000_000L)
    )

    fun forUgx(allTimeUgx: Long): Level = ALL.last { allTimeUgx >= it.minUgx }
    fun byIndex(i: Int): Level = ALL[i.coerceIn(0, ALL.size - 1)]
    fun next(l: Level): Level? = ALL.getOrNull(l.index + 1)

    /** 0.0 .. 1.0 towards the next level (1.0 at the top level). */
    fun progress(allTimeUgx: Long): Double {
        val cur = forUgx(allTimeUgx)
        val nxt = next(cur) ?: return 1.0
        val span = (nxt.minUgx - cur.minUgx).toDouble()
        return ((allTimeUgx - cur.minUgx).toDouble() / span).coerceIn(0.0, 1.0)
    }
}

object TeamStreaks {
    /**
     * Number of Monday-to-Sunday weeks in a row with at least one deposit, counting back from this week.
     * If this week has no deposit yet, the count starts from last week (the week is not over, the streak is not broken yet).
     */
    fun weekStreak(depositTimesUtc: List<Long>, now: Long): Int {
        val weeks = depositTimesUtc.map { TimeUtil.weekKey(it) }.toSet()
        var cur = LocalDate.parse(TimeUtil.weekKey(now))
        if (cur.toString() !in weeks) cur = cur.minusWeeks(1)
        var n = 0
        while (cur.toString() in weeks) {
            n++
            cur = cur.minusWeeks(1)
        }
        return n
    }

    /** Days in a row (East Africa) with at least one approved task, counting back from today (or from yesterday if today has none yet). */
    fun dayStreak(approvedDays: Set<String>, now: Long): Int {
        var cur = LocalDate.parse(TimeUtil.dayKey(now))
        if (cur.toString() !in approvedDays) cur = cur.minusDays(1)
        var n = 0
        while (cur.toString() in approvedDays) {
            n++
            cur = cur.minusDays(1)
        }
        return n
    }
}

class Badge(val id: String, val emoji: String, val title: String, val how: String)

/** What the badge rules look at. All of it is known on the worker phone. */
class BadgeInput(
    val allTimeUgx: Long,
    val deposits: Int,
    val weekStreak: Int,
    val dayStreak: Int,
    val approvedTasks: Int,
    val rank: Int?,
    val ranked: Int,
    val rankedUp: Boolean,
    val goalReachedWithMyDeposit: Boolean,
    val hasGift: Boolean
)

object TeamBadges {
    val ALL: List<Badge> = listOf(
        Badge("first", "🌟", "First deposit", "Have your first deposit verified by the manager."),
        Badge("five", "🔟", "Five deposits", "Have 5 deposits verified."),
        Badge("silver", "🥈", "Silver level", "Contribute UGX 100,000 in total."),
        Badge("gold", "🥇", "Gold level", "Contribute UGX 500,000 in total."),
        Badge("platinum", "💠", "Platinum level", "Contribute UGX 2,000,000 in total."),
        Badge("diamond", "💎", "Diamond level", "Contribute UGX 10,000,000 in total."),
        Badge("weeks4", "🔥", "4 weeks in a row", "Deposit in 4 weeks in a row (Monday to Sunday)."),
        Badge("weeks12", "🚀", "12 weeks in a row", "Deposit in 12 weeks in a row."),
        Badge("days7", "📅", "7 task days", "Have a task approved on 7 days in a row."),
        Badge("tasks30", "✅", "30 tasks done", "Have 30 tasks approved."),
        Badge("tasks100", "🏅", "100 tasks done", "Have 100 tasks approved."),
        Badge("top3", "🏆", "Top 3", "Be in the top 3 contributors (needs at least 3 contributors)."),
        Badge("rising", "📈", "Rising", "Move up in the ranking since your last update."),
        Badge("goal", "🎯", "Goal week", "Have a deposit while the team reaches its weekly goal."),
        Badge("gift", "🎁", "Gift", "Receive a gift from the manager.")
    )

    fun earned(i: BadgeInput): Set<String> {
        val out = HashSet<String>()
        if (i.deposits >= 1) out.add("first")
        if (i.deposits >= 5) out.add("five")
        if (i.allTimeUgx >= 100_000L) out.add("silver")
        if (i.allTimeUgx >= 500_000L) out.add("gold")
        if (i.allTimeUgx >= 2_000_000L) out.add("platinum")
        if (i.allTimeUgx >= 10_000_000L) out.add("diamond")
        if (i.weekStreak >= 4) out.add("weeks4")
        if (i.weekStreak >= 12) out.add("weeks12")
        if (i.dayStreak >= 7) out.add("days7")
        if (i.approvedTasks >= 30) out.add("tasks30")
        if (i.approvedTasks >= 100) out.add("tasks100")
        if (i.rank != null && i.ranked >= 3 && i.rank <= 3) out.add("top3")
        if (i.rankedUp) out.add("rising")
        if (i.goalReachedWithMyDeposit) out.add("goal")
        if (i.hasGift) out.add("gift")
        return out
    }
}

class BoardRow(
    val rank: Int,
    val workerId: String,
    val name: String,
    val shortName: String,
    val level: TeamLevels.Level,
    val share: Double,
    val allTimeUgx: Long,
    val deposits: Int,
    val weekStreak: Int,
    val lastDepositAt: Long?
)

class QuietRow(val workerId: String, val name: String, val reasons: List<String>)

class TeamBoardRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val meta = db.metaDao()

    companion object {
        const val KEY_SHOW_BOARD = "team:showBoard"
        const val BOARD_SIZE = 5
        const val QUIET_TASK_DAYS = 7
        const val QUIET_DEPOSIT_WEEKS = 4
        private const val DAY_MS = 24L * 60 * 60 * 1000

        fun shortName(w: WorkerEntity): String = (w.firstName.trim() + " " + w.lastName.trim().take(1) + ".").trim().take(40)

        private fun ugxText(n: Long): String = "UGX " + String.format(Locale.US, "%,d", n)
    }

    // ---------------------------------------------------------------- consent switch

    suspend fun showBoard(): Boolean = meta.get(KEY_SHOW_BOARD) == "1"

    suspend fun setShowBoard(on: Boolean, actor: String) {
        if (showBoard() == on) return
        meta.put(MetaEntity(KEY_SHOW_BOARD, if (on) "1" else "0"))
        audit.log(actor, "TEAM_SHOW_BOARD_CHANGED", "team", "settings", if (on) "top 5 names and levels may be shown to workers" else "leaderboard hidden from workers")
    }

    private suspend fun halfLife(): Double =
        (meta.get("team:halfLifeDays")?.toIntOrNull()?.coerceIn(TeamRepository.MIN_HALF_LIFE_DAYS, TeamRepository.MAX_HALF_LIFE_DAYS)
            ?: TeamRepository.DEFAULT_HALF_LIFE_DAYS).toDouble()

    // ---------------------------------------------------------------- leaderboard

    suspend fun leaderboard(now: Long = System.currentTimeMillis()): List<BoardRow> {
        val active = db.teamDao().active()
        val shares = TeamMath.shares(active, now, halfLife())
        val workers = db.workerDao().all().associateBy { it.id }
        return shares.mapIndexed { i, s ->
            val w = workers[s.workerId]
            val times = active.filter { it.workerId == s.workerId && (it.valueUgx ?: 0L) > 0L }.map { it.contributedAtUtc }
            BoardRow(
                rank = i + 1, workerId = s.workerId,
                name = w?.fullName() ?: "Worker", shortName = if (w != null) shortName(w) else "Worker",
                level = TeamLevels.forUgx(s.allTimeUgx), share = s.share, allTimeUgx = s.allTimeUgx,
                deposits = s.contributions, weekStreak = TeamStreaks.weekStreak(times, now), lastDepositAt = times.maxOrNull()
            )
        }
    }

    // ---------------------------------------------------------------- quiet workers

    /** Active workers who sent no proof for [QUIET_TASK_DAYS] days or made no deposit for [QUIET_DEPOSIT_WEEKS] weeks. */
    suspend fun quietWorkers(now: Long = System.currentTimeMillis()): List<QuietRow> {
        val active = db.teamDao().active()
        val out = ArrayList<QuietRow>()
        for (w in db.workerDao().all()) {
            if (!w.active) continue
            val reasons = ArrayList<String>()
            val subs = db.submissionDao().observeForWorker(w.id).first()
            val lastSub = subs.maxOfOrNull { it.submittedAt }
            if (w.createdAt < now - QUIET_TASK_DAYS * DAY_MS) {
                if (lastSub == null) reasons.add("Has never sent a proof")
                else if (lastSub < now - QUIET_TASK_DAYS * DAY_MS) reasons.add("No proof for " + ((now - lastSub) / DAY_MS) + " days")
            }
            val lastDep = active.filter { it.workerId == w.id }.maxOfOrNull { it.contributedAtUtc }
            val limit = now - QUIET_DEPOSIT_WEEKS * 7L * DAY_MS
            if (w.createdAt < limit) {
                if (lastDep == null) reasons.add("Has never made a verified deposit")
                else if (lastDep < limit) reasons.add("No deposit for " + ((now - lastDep) / (7L * DAY_MS)) + " weeks")
            }
            if (reasons.isNotEmpty()) out.add(QuietRow(w.id, w.fullName(), reasons))
        }
        return out.sortedByDescending { it.reasons.size }
    }

    // ---------------------------------------------------------------- weekly summary text (to copy or share)

    /** A plain-text summary of LAST Monday-to-Sunday week for one worker. The manager reads it, then sends it by hand. */
    suspend fun weeklySummary(workerId: String, now: Long = System.currentTimeMillis()): String {
        val w = db.workerDao().get(workerId) ?: return "Worker not found."
        val weekKey = LocalDate.parse(TimeUtil.weekKey(now)).minusWeeks(1).toString()
        val start = LocalDate.parse(weekKey)
        val end = start.plusDays(6)
        val f = DateTimeFormatter.ofPattern("d MMM", Locale.US)
        val subs = db.submissionDao().observeForWorker(workerId).first().filter { it.weekKey == weekKey && !it.superseded }
        val approved = subs.filter { it.status == SubStatus.APPROVED }
        val rejected = subs.count { it.status == SubStatus.REJECTED }
        val pending = subs.count { it.status == SubStatus.PENDING }
        val startMs = start.atStartOfDay(TimeUtil.EAT).toInstant().toEpochMilli()
        val endMs = startMs + 7L * DAY_MS
        val active = db.teamDao().active()
        val mineAll = active.filter { it.workerId == workerId && (it.valueUgx ?: 0L) > 0L }
        val deposits = mineAll.filter { it.contributedAtUtc in startMs until endMs }
        val shares = TeamMath.shares(active, now, halfLife())
        val myIdx = shares.indexOfFirst { it.workerId == workerId }
        val allTime = mineAll.sumOf { it.valueUgx ?: 0L }
        val level = TeamLevels.forUgx(allTime)
        val sb = StringBuilder()
        sb.append("CT Team - weekly summary\n")
        sb.append("Name: ").append(w.fullName()).append('\n')
        sb.append("Week: ").append(f.format(start)).append(" - ").append(f.format(end)).append(' ').append(end.year).append("\n\n")
        sb.append("Tasks approved: ").append(approved.size).append(" (").append(ugxText(approved.sumOf { it.payUgx })).append(")\n")
        sb.append("Proofs rejected: ").append(rejected).append(", waiting for review: ").append(pending).append('\n')
        sb.append("Deposits verified: ").append(deposits.size).append(" (").append(ugxText(deposits.sumOf { it.valueUgx ?: 0L })).append(")\n")
        sb.append("Level: ").append(level.name).append(' ').append(level.emoji).append(" (all-time ").append(ugxText(allTime)).append(")\n")
        if (myIdx >= 0) {
            sb.append("Rank: #").append(myIdx + 1).append(" of ").append(shares.size)
                .append(", share about ").append(String.format(Locale.US, "%.2f", shares[myIdx].share * 100.0)).append("% (estimate)\n")
        } else {
            sb.append("Rank: not ranked yet (no verified deposit)\n")
        }
        val streak = TeamStreaks.weekStreak(mineAll.map { it.contributedAtUtc }, now)
        if (streak > 0) sb.append("Deposit streak: ").append(streak).append(if (streak == 1) " week" else " weeks").append(" in a row\n")
        val goal = TeamGoalRepository.goalInfo(db, now)
        if (goal != null) sb.append("Team goal this week: ").append(String.format(Locale.US, "%.0f", goal.progress * 100.0)).append("% reached\n")
        sb.append("\nAll figures are estimates and are not a promise of payment.")
        return sb.toString()
    }
}
