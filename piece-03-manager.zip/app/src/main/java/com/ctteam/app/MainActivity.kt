package com.ctteam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.ui.CTApp
import com.ctteam.app.ui.CTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Open the local database in the background and record the app start.
        // A database problem must never crash the screen.
        val appContext = applicationContext
        Thread {
            try {
                val version = appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName ?: "?"
                kotlinx.coroutines.runBlocking {
                    ServiceLocator.get(appContext).audit.event("APP_START", "v$version")
                }
            } catch (e: Throwable) {
                android.util.Log.e("CTTeam", "Database start failed", e)
            }
        }.start()

        setContent {
            CTTheme {
                CTApp()
            }
        }
    }
}
