package com.ctteam.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Animated logo opening. Calls onDone when finished. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val logoAlpha = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.7f) }
    LaunchedEffect(Unit) {
        launch { logoAlpha.animateTo(1f, tween(900)) }
        launch { logoScale.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        delay(2600)
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        ShimmerLogo(
            modifier = Modifier
                .height(340.dp)
                .graphicsLayer {
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                }
        )
    }
}

/** Choose Manager or Worker mode. */
@Composable
fun RoleScreen(onManager: () -> Unit, onWorker: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(800)) + slideInVertically(tween(800)) { it / 6 }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ShimmerLogo(modifier = Modifier.height(210.dp))
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "CT TEAM",
                    color = CT.Gold,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp,
                    letterSpacing = 6.sp
                )
                Text(
                    text = "WORK • EARN • GROW",
                    color = CT.TextSoft,
                    fontSize = 12.sp,
                    letterSpacing = 4.sp
                )
                Spacer(Modifier.height(32.dp))

                GlassCard(modifier = Modifier.fillMaxWidth(), onClick = onManager) {
                    Text(
                        "Manager",
                        color = CT.GoldLight,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    Text(
                        "Workers, tasks, verification and payouts",
                        color = CT.TextSoft,
                        fontSize = 14.sp
                    )
                }
                Spacer(Modifier.height(16.dp))
                GlassCard(modifier = Modifier.fillMaxWidth(), onClick = onWorker) {
                    Text(
                        "Worker",
                        color = CT.GoldLight,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    Text(
                        "Tasks, proof, earnings and payouts",
                        color = CT.TextSoft,
                        fontSize = 14.sp
                    )
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    "v0.3.0 · Piece 3 · Manager",
                    color = Color(0x80FFFFFF),
                    fontSize = 11.sp
                )
            }
        }
    }
}

/** Temporary screen that later pieces replace with the real Manager / Worker areas. */
@Composable
fun PlaceholderScreen(title: String, subtitle: String, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ShimmerLogo(modifier = Modifier.height(140.dp))
        Spacer(Modifier.height(20.dp))
        Text(
            text = title,
            color = CT.Gold,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = subtitle,
            color = CT.TextSoft,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        GoldButton(text = "BACK", onClick = onBack)
    }
}
