package com.ctteam.app.data

import org.json.JSONArray
import org.json.JSONObject

/*
 * PIECE R3a — REFERRAL REWARDS, WORKER SIDE DATA (no screens yet; the page is R3b).
 * The manager phone puts each worker's referral figures into a signed update (type REFERRAL_VIEW, same envelope, numbering and
 * replay protection as the other updates); the worker phone keeps the newest one. NO database change: the figures live in `meta`.
 *
 * What the message holds (made on the manager phone at time `at`):
 *   rev = counter that rises whenever something in it changed     at = time the figures were made
 *   cd  = the worker's referral code (CT-XXXXX)     bal = points balance     aw = awarded referrals (decides the status)
 *   th  = the four status thresholds [Connector, Builder, Leader, Champion]     nd = approved submissions a new worker needs
 *   up  = UGX per point (only used when the manager approves a points-to-money request, R4)
 *   rf  = the worker's OWN referrals, newest 30: n = first name + last initial, s = P (waiting) / A (awarded) / R (rejected),
 *         ap = approved submissions so far, pt = points (awarded, or what it is worth now while waiting), at = when it was recorded
 * Nothing about anyone else is sent: never the referrer of this worker, never other workers' referrals, never the reason for a refusal.
 */

class RefViewEntry(val name: String, val state: String, val approved: Int, val points: Int, val at: Long)

class ReferralView(
    val rev: Int,
    val asOf: Long,
    val code: String,
    val balance: Int,
    val awarded: Int,
    val thresholds: List<Int>,
    val need: Int,
    val ugxPerPoint: Long,
    val entries: List<RefViewEntry>
) {
    /** Status from the awarded referrals (Member, Connector, Builder, Leader, Champion). */
    fun tier(): ReferralRules.Tier = ReferralRules.tierOf(awarded, thresholds)

    fun nextTier(): ReferralRules.Tier? = ReferralRules.nextTier(awarded, thresholds)

    /** Awarded referrals still missing for the next status, or null when already at the top. */
    fun toNext(): Int? {
        val nt = nextTier() ?: return null
        val idx = ReferralRules.TIERS.indexOf(nt)
        return maxOf(0, ReferralRules.thresholdFor(idx, thresholds) - awarded)
    }

    /** What the balance would be worth at the manager's rate. An estimate: spending needs the manager's approval (R4). */
    fun worthUgx(): Long = if (balance <= 0) 0L else ReferralRules.ugxFor(balance, ugxPerPoint)

    fun waiting(): Int = entries.count { it.state == "P" }
}

class ReferralViewApply(val ok: Boolean, val changed: Boolean, val title: String, val detail: String)

object ReferralViewCodec {
    private const val MAX_LIST = 30
    private val CODE_RULE = Regex("^CT-[A-Z0-9]{5}$")

    private fun kFp(w: String) = "ref:vfp:$w"        // manager phone: what the last message was made from
    private fun kRevOut(w: String) = "ref:vrev:$w"    // manager phone: revision counter
    private fun kAtOut(w: String) = "ref:vat:$w"      // manager phone: time of the last revision
    private fun kJson(w: String) = "ref:vjson:$w"     // worker phone: the newest figures
    private fun kRevIn(w: String) = "ref:vrevin:$w"   // worker phone: revision already kept

    // ------------------------------------------------------------ manager phone

    /**
     * The referral figures of ONE worker. The same data gives the same message (sending it again is harmless);
     * a change in points, status, referrals or rules gives a new `rev`. Makes the worker's code if it did not exist yet.
     */
    suspend fun build(db: CTDatabase, repo: ReferralRepository, workerId: String, now: Long = System.currentTimeMillis()): JSONObject? {
        val worker = db.workerDao().get(workerId) ?: return null
        val dao = db.referralDao()
        val meta = db.metaDao()
        val st = repo.settings()
        val code = repo.codeFor(workerId)
        val bal = dao.balanceOf(workerId)
        val aw = dao.awardedCount(workerId)
        val earned = dao.entriesOf(workerId, 500).filter { it.kind == PointsKind.REFERRAL }.associate { it.refKey to it.points }

        val list = JSONArray()
        val fpSrc = StringBuilder().append(code).append('|').append(bal).append('|').append(aw).append('|')
            .append(st.thresholds.joinToString(",")).append('|').append(st.need).append('|').append(st.ugxPerPoint)
        for (r in dao.referralsBy(worker.id).take(MAX_LIST)) {
            val w = db.workerDao().get(r.referredId)
            val name = if (w == null) "A worker" else (w.firstName.trim() + (if (w.lastName.isNotBlank()) " " + w.lastName.trim().take(1) + "." else ""))
            val state = when (r.status) {
                RefStatus.AWARDED -> "A"
                RefStatus.REJECTED -> "R"
                else -> "P"
            }
            val approved = dao.approvedOf(r.referredId)
            val pts = when (state) {
                "A" -> earned[r.referredId] ?: 0
                "R" -> 0
                else -> repo.pointsForReferral(r, st)
            }
            list.put(JSONObject().put("n", name.take(40)).put("s", state).put("ap", approved).put("pt", pts).put("at", r.createdAt))
            fpSrc.append("|").append(name).append(':').append(state).append(':').append(approved).append(':').append(pts)
        }
        val fp = Hashing.sha256Hex(fpSrc.toString()).take(16)

        var rev = meta.get(kRevOut(workerId))?.toIntOrNull() ?: 0
        var at = meta.get(kAtOut(workerId))?.toLongOrNull() ?: 0L
        if (rev == 0 || meta.get(kFp(workerId)) != fp) {
            rev += 1
            at = maxOf(now, at + 1L)
            meta.put(MetaEntity(kFp(workerId), fp))
            meta.put(MetaEntity(kRevOut(workerId), rev.toString()))
            meta.put(MetaEntity(kAtOut(workerId), at.toString()))
        }
        return JSONObject()
            .put("rev", rev).put("at", at).put("cd", code).put("bal", bal).put("aw", aw)
            .put("th", JSONArray(st.thresholds)).put("nd", st.need).put("up", st.ugxPerPoint)
            .put("rf", list)
    }

    // ------------------------------------------------------------ worker phone

    /** Checks the message and keeps it if it is newer than the one already here. A broken referral line is skipped, never the whole message. */
    suspend fun apply(db: CTDatabase, workerId: String, b: JSONObject): ReferralViewApply {
        val meta = db.metaDao()
        val rev = b.optInt("rev", 0)
        val at = b.optLong("at", 0L)
        val code = b.optString("cd")
        val bal = b.optInt("bal", Int.MIN_VALUE)
        val aw = b.optInt("aw", -1)
        val nd = b.optInt("nd", 0)
        val up = b.optLong("up", -1L)
        val thArr = b.optJSONArray("th")
        val th = ArrayList<Int>()
        if (thArr != null) for (i in 0 until minOf(thArr.length(), 4)) th.add(thArr.optInt(i, 0))
        val ok = rev > 0 && at > 0L && CODE_RULE.matches(code) && bal in -1_000_000_000..1_000_000_000 && aw in 0..100_000 &&
            nd in 1..100 && up in 0L..1_000_000L && th.size == 4 && ReferralRules.thresholdsOk(th)
        if (!ok) return ReferralViewApply(false, false, "Referral figures not used", "The referral figures in this message are not valid. Nothing was used.")

        val known = meta.get(kRevIn(workerId))?.toIntOrNull() ?: 0
        if (rev <= known) return ReferralViewApply(true, false, "Referral figures already up to date", "A newer or equal set was received before.")

        val clean = JSONArray()
        val src = b.optJSONArray("rf")
        if (src != null) {
            for (i in 0 until minOf(src.length(), MAX_LIST)) {
                val o = src.optJSONObject(i) ?: continue
                val name = o.optString("n").filter { it.isLetter() || it == ' ' || it == '.' || it == '-' }.trim().take(40)
                val s = o.optString("s")
                val ap = o.optInt("ap", -1)
                val pt = o.optInt("pt", -1)
                if (name.isEmpty() || (s != "P" && s != "A" && s != "R") || ap !in 0..100_000 || pt !in 0..100_000_000) continue
                clean.put(JSONObject().put("n", name).put("s", s).put("ap", ap).put("pt", pt).put("at", maxOf(0L, o.optLong("at", 0L))))
            }
        }
        val stored = JSONObject()
            .put("rev", rev).put("at", at).put("cd", code).put("bal", bal).put("aw", aw)
            .put("th", JSONArray(th)).put("nd", nd).put("up", up).put("rf", clean)
        meta.put(MetaEntity(kJson(workerId), stored.toString()))
        meta.put(MetaEntity(kRevIn(workerId), rev.toString()))
        return ReferralViewApply(true, true, "Referral figures updated", "Your referral code, points and status were refreshed.")
    }

    /** The newest referral figures kept on this phone for this worker, or null if none arrived yet. */
    suspend fun load(db: CTDatabase, workerId: String): ReferralView? {
        val raw = db.metaDao().get(kJson(workerId)) ?: return null
        return try {
            val o = JSONObject(raw)
            val th = ArrayList<Int>()
            val ta = o.optJSONArray("th")
            if (ta != null) for (i in 0 until ta.length()) th.add(ta.optInt(i, 0))
            if (th.size != 4) return null
            val entries = ArrayList<RefViewEntry>()
            val rf = o.optJSONArray("rf")
            if (rf != null) {
                for (i in 0 until rf.length()) {
                    val e = rf.optJSONObject(i) ?: continue
                    entries.add(RefViewEntry(e.optString("n"), e.optString("s"), e.optInt("ap"), e.optInt("pt"), e.optLong("at")))
                }
            }
            ReferralView(
                rev = o.optInt("rev"), asOf = o.optLong("at"), code = o.optString("cd"), balance = o.optInt("bal"),
                awarded = o.optInt("aw"), thresholds = th, need = o.optInt("nd"), ugxPerPoint = o.optLong("up"), entries = entries
            )
        } catch (e: Exception) {
            null
        }
    }
}
