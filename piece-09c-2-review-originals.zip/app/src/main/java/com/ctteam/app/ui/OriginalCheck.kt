package com.ctteam.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ProofAnalyzer
import com.ctteam.app.data.ProofEntity
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TgOriginal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Piece 9C-2 — under a screenshot in the manager's review screen: did the ORIGINAL arrive on Telegram, is it the very file the
 * report names (SHA-256 was matched when it arrived), and do the picture's look (dHash) and hidden data match what the worker's
 * phone reported? Those two are worked out again HERE from the saved file, so a changed app cannot lie about them.
 * Evidence only: it never decides. A match does not prove the picture is genuine.
 */
private val OC_GOOD = Color(0xFF5FD6A5)
private val OC_BAD = Color(0xFFFF8A8A)
private val OC_WARN = Color(0xFFFFD27A)

private class OriginalFacts(val orig: TgOriginal?, val lines: List<Pair<Boolean, String>>)

@Composable
fun OriginalProofBlock(repos: Repos, proof: ProofEntity, workerId: String, actor: String) {
    val sha = proof.sha256 ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var facts by remember(sha) { mutableStateOf<OriginalFacts?>(null) }
    var tick by remember { mutableStateOf(0) }
    var canAsk by remember { mutableStateOf(false) }
    var asking by remember { mutableStateOf(false) }
    var askNote by remember { mutableStateOf("") }
    var picture by remember(sha) { mutableStateOf<Bitmap?>(null) }
    var pictureError by remember(sha) { mutableStateOf("") }

    LaunchedEffect(sha, tick) {
        canAsk = repos.telegram.canSendTo(workerId)
        val o = repos.telegram.originalOf(sha)
        val out = ArrayList<Pair<Boolean, String>>()
        if (o != null) {
            if (o.workerId != null && o.workerId != workerId) out.add(Pair(false, "This file was sent by a DIFFERENT worker's Telegram chat."))
            if (o.stored) {
                val uri = Uri.fromFile(repos.telegram.originalFile(sha))
                val dh = withContext(Dispatchers.IO) { ProofAnalyzer.dHash(context, uri) }
                val tg = withContext(Dispatchers.IO) { ProofAnalyzer.tags(context, uri) }
                val reportedDh = proof.dhash
                if (dh == null) out.add(Pair(false, "The saved file could not be read as a picture."))
                else if (reportedDh.isNullOrBlank()) out.add(Pair(true, "Picture look: not in the report (older app), nothing to compare."))
                else if (dh == reportedDh) out.add(Pair(true, "Picture look (dHash): same as reported."))
                else out.add(Pair(false, "Picture look (dHash) is DIFFERENT from what the worker's phone reported."))
                val reportedTags = proof.metadataTags
                if (reportedTags.isNullOrBlank()) out.add(Pair(true, "Hidden data of the original: " + tg))
                else if (tg == reportedTags) out.add(Pair(true, "Hidden data (format, editor tags): same as reported."))
                else out.add(Pair(false, "Hidden data of the original is DIFFERENT from what was reported. Original: " + tg + " · Report: " + reportedTags))
            }
        }
        facts = OriginalFacts(o, out)
    }

    val f = facts ?: return
    val o = f.orig
    Spacer(Modifier.height(6.dp))
    if (o == null) {
        Text("Original: not received yet.", color = OC_WARN, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(
            "Ask the worker to send the original file on Telegram. For a doubtful screenshot, wait for it before you decide.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (canAsk) {
            Spacer(Modifier.height(6.dp))
            GhostButton(
                text = if (asking) "SENDING…" else "ASK FOR THE ORIGINAL ON TELEGRAM",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (asking) return@GhostButton
                    asking = true
                    scope.launch {
                        val name = proof.fileName?.takeIf { it.isNotBlank() }
                        val text = "Please send me the ORIGINAL screenshot" + (if (name != null) " (file name: $name)" else "") +
                            " as a FILE in this chat: tap the paperclip, choose File, pick the picture. Do not send it as a photo."
                        val r = repos.telegram.sendCodes(workerId, "request", listOf(text), text, actor)
                        askNote = r.message
                        asking = false
                    }
                }
            )
        }
        if (askNote.isNotEmpty()) Text(askNote, color = CT.TextSoft, fontSize = 12.sp)
    } else {
        Text("Original received on Telegram: the very same file as in the report (SHA-256 matches).", color = OC_GOOD, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(o.fileName + " · " + (o.size / 1024) + " KB · " + fmtTime(o.at), color = CT.TextSoft, fontSize = 12.sp)
        if (!o.stored) Text("The file itself is not saved on this phone (storage limit), so it cannot be shown or re-checked.", color = OC_WARN, fontSize = 12.sp)
        for (l in f.lines) Text((if (l.first) "✔ " else "✖ ") + l.second, color = if (l.first) Color.White else OC_BAD, fontSize = 12.sp)
        if (o.stored) {
            Spacer(Modifier.height(6.dp))
            val bmp = picture
            if (bmp == null) {
                GhostButton(text = "SHOW THE ORIGINAL", modifier = Modifier.fillMaxWidth(), onClick = {
                    scope.launch {
                        val file = repos.telegram.originalFile(sha)
                        val loaded = withContext(Dispatchers.IO) { loadScaled(file.absolutePath, 1400) }
                        if (loaded == null) pictureError = "This phone could not open the picture." else picture = loaded
                    }
                })
                if (pictureError.isNotEmpty()) Text(pictureError, color = OC_BAD, fontSize = 12.sp)
            } else {
                Image(bitmap = bmp.asImageBitmap(), contentDescription = "Original screenshot", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                GhostButton(text = "HIDE", modifier = Modifier.fillMaxWidth(), onClick = { picture = null })
            }
        }
    }
    Text(
        "A matching original shows it is the file the worker reported. It does not prove the picture is genuine: still read it and decide.",
        color = CT.TextSoft, fontSize = 11.sp
    )
}

/** Opens a picture at reduced size (longest side about [maxSide] pixels) so a big screenshot cannot fill the memory. */
private fun loadScaled(path: String, maxSide: Int): Bitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
} catch (ex: Throwable) { null }
