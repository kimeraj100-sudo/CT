package com.ctteam.app.ui

import android.content.ClipData
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.ctteam.app.data.BackupFormat
import com.ctteam.app.data.BackupInfo
import com.ctteam.app.data.BackupRepository
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TelegramRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Piece 11b — Manager > Backup (main manager only). CREATE BACKUP writes one encrypted `.ctb` file through the phone's file picker
 * (phone storage, SD card, Google Drive, any app that offers a save location). CHECK A BACKUP FILE opens a file and verifies it completely
 * without changing anything. Piece 11c adds RESTORE (see RestoreScreens.kt).
 */
private val BK_GOOD = Color(0xFF5FD6A5)
private val BK_BAD = Color(0xFFFF8A8A)

private fun bkStamp(): String = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())

private fun bkInfoText(i: BackupInfo): String {
    val sb = StringBuilder()
    sb.append("Made ").append(fmtTime(i.createdAt)).append(" (East Africa Time)\n")
    sb.append("App build ").append(i.appVersionCode).append(", database version ").append(i.dbVersion).append(", ")
    sb.append(i.dbBytes / 1024).append(" KB\n")
    if (i.counts.isNotEmpty()) sb.append(i.counts.joinToString(", ") { it.first.replace('_', ' ') + " " + it.second })
    return sb.toString().trim()
}

@Composable
fun ManagerBackupScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val backup = remember(repos) { BackupRepository(repos.db, repos.audit) }

    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var checkPass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(true) }
    var last by remember { mutableStateOf<Long?>(null) }

    var tgReady by remember { mutableStateOf(false) }
    var tgLinked by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf<TelegramRepository.BackupLink?>(null) }
    var lateText by remember { mutableStateOf<String?>(null) }
    var remindField by remember { mutableStateOf("") }
    var refresh by remember { mutableStateOf(0) }
    var confirmUnlink by remember { mutableStateOf(false) }

    LaunchedEffect(refresh) {
        last = backup.lastBackupAt()
        tgReady = repos.telegram.token() != null
        tgLinked = repos.telegram.backupChatId() != null
        link = repos.telegram.pendingBackupLink()
        lateText = backup.overdueText()
        if (remindField.isEmpty()) remindField = backup.remindDays().toString()
    }

    // while a link code is waiting, look again every few seconds until the bot has seen it
    LaunchedEffect(link?.code) {
        while (link != null) {
            delay(3000)
            if (repos.telegram.backupChatId() != null) { refresh++; break }
            link = repos.telegram.pendingBackupLink()
        }
    }

    fun say(ok: Boolean, text: String) { good = ok; message = text }

    fun passOk(): Boolean {
        val e = BackupFormat.passError(pass)
        return when {
            e != null -> { say(false, e); false }
            pass != pass2 -> { say(false, "The two passphrases are not the same."); false }
            else -> true
        }
    }

    // Piece 11d: make the backup in the private cache, then hand it to Telegram or to the share window
    fun sendOut(viaTelegram: Boolean) {
        if (busy || !passOk()) return
        message = ""
        scope.launch {
            busy = true
            when (val r = backup.exportToCache(context, pass, actor)) {
                is Outcome.Err -> say(false, r.message)
                is Outcome.Ok -> {
                    val (file, info) = r.value
                    if (viaTelegram) {
                        when (val sent = repos.telegram.sendBackupFile(file, "CT Team backup (encrypted), made " + fmtTime(info.createdAt) + ". Keep your passphrase safe.", actor)) {
                            is Outcome.Ok -> {
                                backup.markLastBackup(info, file.length())
                                say(true, sent.value + "\n" + bkInfoText(info) + "\n\nThe file is encrypted, so Telegram only holds unreadable data. Keep the passphrase safe: without it nobody can open the backup.")
                                pass = ""; pass2 = ""
                            }
                            is Outcome.Err -> say(false, sent.message + " The backup was made but NOT delivered, so it does not count as your latest backup.")
                        }
                        file.delete()
                    } else {
                        val uri = try { FileProvider.getUriForFile(context, context.packageName + ".files", file) } catch (e: Exception) { null }
                        if (uri == null) {
                            say(false, "The phone could not prepare the file for sharing.")
                            file.delete()
                        } else {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "application/octet-stream"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                putExtra(Intent.EXTRA_SUBJECT, "CT Team backup")
                                clipData = ClipData.newRawUri("backup", uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            try {
                                context.startActivity(Intent.createChooser(send, "Send the backup to..."))
                                backup.markLastBackup(info, file.length())
                                say(true, "The share window is open: choose Google Drive, an SD card app, e-mail or another place.\n" + bkInfoText(info) +
                                    "\n\nThe app cannot see whether it arrived, so open it where you sent it (or use CHECK A BACKUP FILE). A temporary encrypted copy stays in the app's private space until the next backup.")
                                pass = ""; pass2 = ""
                            } catch (e: Exception) {
                                say(false, "No app on this phone could take the file.")
                                file.delete()
                            }
                        }
                    }
                }
            }
            refresh++
            busy = false
        }
    }

    val createLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val stream = try { context.contentResolver.openOutputStream(uri, "w") } catch (e: Exception) { null }
                if (stream == null) {
                    say(false, "The phone would not open that place for writing. Choose another place.")
                } else {
                    val r = try {
                        stream.use { backup.export(context, pass, it, actor) }
                    } catch (e: Exception) {
                        Outcome.Err("The file could not be written: " + (e.message ?: ""))
                    }
                    when (r) {
                        is Outcome.Ok -> {
                            say(true, "Backup saved.\n" + bkInfoText(r.value) + "\n\nNow use CHECK A BACKUP FILE on it once, and keep the passphrase safe: without it the file cannot be opened by anyone.")
                            last = backup.lastBackupAt()
                            pass = ""; pass2 = ""
                        }
                        is Outcome.Err -> say(false, r.message)
                    }
                }
                busy = false
            }
        }
    }

    val checkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bytes = try {
                    context.contentResolver.openInputStream(uri)?.use { BackupRepository.readLimited(it, BackupFormat.MAX_DB_BYTES + 1_000_000) }
                } catch (e: Exception) {
                    null
                }
                if (bytes == null) {
                    say(false, "The file could not be read, or it is larger than the backup limit.")
                } else {
                    when (val r = backup.check(context, bytes, checkPass)) {
                        is Outcome.Ok -> say(true, "✓ This backup is complete and can be restored.\n" + bkInfoText(r.value))
                        is Outcome.Err -> say(false, r.message)
                    }
                }
                busy = false
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Backup", onBack)
        lateText?.let {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("⚠ Time for a backup", color = BK_BAD, fontWeight = FontWeight.Bold)
                Text(it, color = Color.White, fontSize = 13.sp)
            }
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Last backup", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            val l = last
            Text(
                if (l == null) "No backup made on this phone yet." else fmtTime(l) + " (East Africa Time)",
                color = if (l == null) BK_BAD else Color.White, fontSize = 14.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "A backup holds everything in the app's database: workers, tasks, submissions, payouts, NC Wallet rows, team mining, lessons, " +
                    "manager accounts and the sync keys. It is encrypted with a passphrase you choose and checked for damage. " +
                    "The original pictures saved from Telegram are not inside it, only their records.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Create a backup", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            CTField(pass, { pass = it }, "Backup passphrase (10+ characters, letters and a digit)", secret = true)
            CTField(pass2, { pass2 = it }, "Repeat the passphrase", secret = true)
            Text(
                "Write the passphrase down somewhere safe. There is NO way to recover a backup if it is lost, and the app never stores it.",
                color = BK_BAD, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            GoldButton(text = if (busy) "WORKING…" else "CREATE BACKUP", modifier = Modifier.fillMaxWidth(), onClick = {
                val e = BackupFormat.passError(pass)
                when {
                    busy -> {}
                    e != null -> say(false, e)
                    pass != pass2 -> say(false, "The two passphrases are not the same.")
                    else -> { message = ""; createLauncher.launch("ctteam-backup-" + bkStamp() + BackupFormat.FILE_EXT) }
                }
            })
            Text("You choose where it is saved: phone storage, SD card or Google Drive.", color = CT.TextSoft, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Text("Or send it straight away:", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "SEND TO MY TELEGRAM", modifier = Modifier.fillMaxWidth(), onClick = {
                when {
                    busy -> {}
                    !tgReady -> say(false, "Connect your bot first (Manager > Telegram).")
                    !tgLinked -> say(false, "Link your own Telegram first (the card below).")
                    else -> sendOut(true)
                }
            })
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "SHARE… (DRIVE, SD CARD, OTHER APPS)", modifier = Modifier.fillMaxWidth(), onClick = { sendOut(false) })
            Text("The file is encrypted before it leaves this app, so only your passphrase opens it.", color = CT.TextSoft, fontSize = 11.sp)
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Telegram for backups", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (!tgReady) {
                Text("Connect your bot first in Manager > Telegram. Then link your own Telegram here, so the bot knows where to send your backups.", color = CT.TextSoft, fontSize = 12.sp)
            } else if (tgLinked) {
                Text("✅ Your own Telegram chat is linked. Backups go to the chat with your bot.", color = BK_GOOD, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                if (!confirmUnlink) {
                    GhostButton(text = "UNLINK MY TELEGRAM", danger = true, modifier = Modifier.fillMaxWidth(), onClick = { confirmUnlink = true })
                } else {
                    GhostButton(text = "YES, UNLINK", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        scope.launch { repos.telegram.unlinkBackupChat(actor); confirmUnlink = false; refresh++ }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { confirmUnlink = false })
                }
            } else {
                val l = link
                if (l == null) {
                    Text("Link your own Telegram once: the app shows a one-time code, you send it to your bot from YOUR Telegram (the phone where you made the bot).", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    GoldButton(text = "LINK MY TELEGRAM", modifier = Modifier.fillMaxWidth(), onClick = {
                        scope.launch {
                            when (val r = repos.telegram.startBackupLink(actor)) {
                                is Outcome.Ok -> link = r.value
                                is Outcome.Err -> say(false, r.message)
                            }
                        }
                    })
                } else {
                    Text("Send this exact text to your bot now:", color = Color.White, fontSize = 13.sp)
                    Text(l.code, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text("It works for 5 minutes. The app is waiting for it and will tell you when it arrives. Keep the manager area open.", color = CT.TextSoft, fontSize = 12.sp)
                }
            }
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Backup reminder", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Remind me when the last backup is older than this many days. The reminder shows here and on the Backup card, and as a phone notification if you turned on notifications for the manager.", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            CTField(remindField, { remindField = it.filter { c -> c.isDigit() }.take(2) }, "Days (1 to 90)")
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "SAVE REMINDER", modifier = Modifier.fillMaxWidth(), onClick = {
                val d = remindField.toIntOrNull()
                if (d == null) say(false, "Enter a number of days.")
                else scope.launch {
                    when (val r = backup.setRemindDays(d, actor)) {
                        is Outcome.Ok -> say(true, "Reminder saved: after " + r.value + " days.")
                        is Outcome.Err -> say(false, r.message)
                    }
                    refresh++
                }
            })
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Check a backup file", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Opens the file, checks the passphrase, the encryption seal, the fingerprint and the database inside. Nothing on this phone is changed.", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            CTField(checkPass, { checkPass = it }, "Passphrase of that backup", secret = true)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "CHECK A BACKUP FILE", modifier = Modifier.fillMaxWidth(), onClick = {
                if (!busy) {
                    if (checkPass.isEmpty()) say(false, "Type the passphrase first.") else { message = ""; checkLauncher.launch(arrayOf("*/*")) }
                }
            })
        }

        // Piece 11c: restore from a backup file (preview first, type RESTORE, safety copy, undo)
        RestoreSection(repos = repos, actor = actor)

        // Piece 11e-2: the steps for moving to a new phone, and RETIRE THIS PHONE
        PhoneMoveSection(repos = repos, actor = actor)

        if (message.isNotEmpty()) Text(message, color = if (good) BK_GOOD else BK_BAD, fontSize = 13.sp)
        GhostButton(text = "BACK", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
