package com.ctteam.app.data

import android.content.Context
import kotlinx.coroutines.flow.first

/**
 * PIECE 11e-2 — moving the manager role to a new phone.
 *
 * Two phones must never act as the manager at the same time: both would number messages for the same workers and read the same
 * Telegram bot. "Retiring" the old phone (after its backup was made and restored on the new one) switches off everything that could
 * clash: Telegram reading, the background notification check, and sign-in to the manager area. Nothing is deleted.
 * The flag is a `meta` value, so it is part of a backup; a backup made AFTER retiring would retire the phone it is restored on
 * (the retired screen has a button to use the phone again).
 */
class MoveStatus(
    val lastBackupAt: Long?,
    val backupOverdue: Boolean,
    val botConnected: Boolean,
    val botPaused: Boolean,
    val notifyOn: Boolean,
    val connectedWorkers: Int,
    val retiredAt: Long?
)

object PhoneMove {
    private const val KEY_RETIRED = "phone:retired"

    suspend fun retiredAt(repos: Repos): Long? = repos.db.metaDao().get(KEY_RETIRED)?.toLongOrNull()

    suspend fun status(repos: Repos): MoveStatus {
        val backups = BackupRepository(repos.db, repos.audit)
        return MoveStatus(
            lastBackupAt = backups.lastBackupAt(),
            backupOverdue = backups.isOverdue(),
            botConnected = repos.telegram.token() != null,
            botPaused = repos.telegram.isPaused(),
            notifyOn = CTNotify.isManagerOn(repos),
            connectedWorkers = repos.db.syncDao().observeKeys().first().size,
            retiredAt = retiredAt(repos)
        )
    }

    /** Switches off Telegram reading and the notification check, then marks the phone retired (the manager area refuses to open). */
    suspend fun retire(ctx: Context, repos: Repos, actor: String) {
        if (CTNotify.isManagerOn(repos)) CTNotify.setManager(ctx, repos, false)
        repos.telegram.setPaused(true, actor)
        repos.db.metaDao().put(MetaEntity(KEY_RETIRED, System.currentTimeMillis().toString()))
        repos.audit.log(actor, "PHONE_RETIRED", "phone", "this", "the manager role moved to another phone")
    }

    /** Lifts the block. Telegram reading and notifications stay OFF: switch them on again by hand if this phone is the manager again. */
    suspend fun useAgain(repos: Repos) {
        repos.db.metaDao().put(MetaEntity(KEY_RETIRED, ""))
        repos.audit.event("PHONE_UNRETIRED", "this phone may be used as the manager phone again")
    }
}
