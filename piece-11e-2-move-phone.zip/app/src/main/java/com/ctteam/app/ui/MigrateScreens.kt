package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.MoveStatus
import com.ctteam.app.data.PhoneMove
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 11e-2 — Manager > Backup > "Move to a new phone": the steps in order, with live checks from this phone,
 * and RETIRE THIS PHONE (type RETIRE). The retired screen blocks the manager area on the old phone.
 */
private val MV_GOOD = Color(0xFF5FD6A5)
private val MV_BAD = Color(0xFFFF8A8A)
private val MV_WARN = Color(0xFFFFD27A)

private fun ageText(ms: Long): String {
    val mins = (System.currentTimeMillis() - ms) / 60_000L
    return when {
        mins < 2L -> "just now"
        mins < 120L -> "$mins minutes ago"
        mins < 48L * 60L -> (mins / 60L).toString() + " hours ago"
        else -> (mins / (24L * 60L)).toString() + " days ago"
    }
}

@Composable
fun PhoneMoveSection(repos: Repos, actor: String) {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var open by remember { mutableStateOf(false) }
    var st by remember { mutableStateOf<MoveStatus?>(null) }
    var tick by remember { mutableStateOf(0) }
    var typed by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }

    LaunchedEffect(open, tick) { if (open) st = PhoneMove.status(repos) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Move to a new phone", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (!open) {
            Text("Changing your manager phone? Follow the steps so that only ONE phone acts as the manager.", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "OPEN THE STEPS", modifier = Modifier.fillMaxWidth(), onClick = { open = true })
            return@GlassCard
        }
        val s = st
        Text("Why: two phones acting as the manager would number messages for the same workers and fight over the same Telegram bot. Do the steps in this order.", color = CT.TextSoft, fontSize = 12.sp)

        Spacer(Modifier.height(10.dp))
        Text("On THIS (old) phone", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("1. Make a fresh backup right now (cards above: SEND TO MY TELEGRAM, or SHARE to Drive / SD card). Anything you do after it is NOT in it.", color = Color.White, fontSize = 13.sp)
        if (s != null) {
            val last = s.lastBackupAt
            if (last == null) Text("✖ No backup was ever made on this phone.", color = MV_BAD, fontSize = 12.sp)
            else Text((if (s.backupOverdue) "! " else "✔ ") + "Last backup delivered: " + ageText(last) + " (" + fmtTime(last) + ").",
                color = if (s.backupOverdue) MV_WARN else MV_GOOD, fontSize = 12.sp)
            Text(
                "Connected workers on this phone: " + s.connectedWorkers + ". Telegram bot: " +
                    (if (!s.botConnected) "not connected" else if (s.botPaused) "paused" else "connected and reading") +
                    ". Notifications: " + (if (s.notifyOn) "on" else "off") + ".",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        Text("2. Check the file with CHECK A BACKUP FILE (it must say the backup is good) and keep the passphrase safe: without it the file cannot be opened.", color = Color.White, fontSize = 13.sp)

        Spacer(Modifier.height(10.dp))
        Text("On the NEW phone", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("3. Install the same app. Do NOT retire this phone yet.", color = Color.White, fontSize = 13.sp)
        Text("4. Manager > Backup > Restore from a backup: choose the file, type the passphrase, type RESTORE. Then sign in with the manager names, passwords and PINs that were on this phone.", color = Color.White, fontSize = 13.sp)
        Text("5. Manager > Notifications: switch it off and on again (the schedule is not copied by a backup). Manager > Telegram: your bot comes back with the backup; check it says it is reading.", color = Color.White, fontSize = 13.sp)

        Spacer(Modifier.height(10.dp))
        Text("Back on THIS phone, when the new one works", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("6. RETIRE THIS PHONE (below). It stops Telegram reading, notifications and the manager sign-in here, so it cannot clash. Nothing is deleted.", color = Color.White, fontSize = 13.sp)

        Spacer(Modifier.height(10.dp))
        Text("The workers", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Workers need to do nothing. Their next report tells the new phone which update number they reached, so numbering is put right by itself. " +
                "Until then an update may be refused as \"already received\": use SEND EVERYTHING AGAIN. Reports you imported after the backup are forgotten; workers can send them again and nothing is counted twice.",
            color = CT.TextSoft, fontSize = 12.sp
        )

        Spacer(Modifier.height(10.dp))
        Text("If the old phone is broken and there is NO backup", color = MV_WARN, fontWeight = FontWeight.Bold)
        Text(
            "Install the app on the new phone and sign in as MAIN. Each worker opens Connect to the manager, makes a connection code and sends it; you approve it (the worker comes back with the same key). " +
                "Then each worker makes a report with EVERYTHING and sends it: submissions, payout requests and claims return. Tasks, payments you recorded, manager accounts and team data are lost, so create the tasks again. Make backups regularly so this never happens.",
            color = CT.TextSoft, fontSize = 12.sp
        )

        Spacer(Modifier.height(10.dp))
        Text("If the old phone was LOST or STOLEN", color = MV_BAD, fontWeight = FontWeight.Bold)
        Text(
            "It holds every worker's secret key and your Telegram bot token. 1) In Telegram open @BotFather, choose your bot, API Token, Revoke, and connect the bot again with the NEW token on the new phone (Manager > Telegram). " +
                "2) On the new phone change every manager password and PIN (My security). This does NOT lock the lost phone's 30-day quick unlock; only the lost phone's own screen lock protects it. " +
                "3) Honest limit: worker keys cannot be changed yet, so whoever opens the phone's data could forge messages for workers. Keep a strong screen lock and report it to the owner.",
            color = CT.TextSoft, fontSize = 12.sp
        )

        Spacer(Modifier.height(12.dp))
        Text("Retire this phone", color = CT.Gold, fontWeight = FontWeight.Bold)
        if (s?.retiredAt != null) {
            Text("This phone was retired " + ageText(s.retiredAt) + ".", color = MV_GOOD, fontSize = 13.sp)
        } else {
            Text("Only after the new phone works. Type RETIRE, then tap the button. You will be signed out and the manager area stays closed on this phone.", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            CTField(typed, { typed = it.trim() }, "Type RETIRE")
            Spacer(Modifier.height(6.dp))
            GoldButton(text = if (busy) "WORKING…" else "RETIRE THIS PHONE", modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy) return@GoldButton
                if (typed != "RETIRE") { note = "Type RETIRE (capital letters) first."; return@GoldButton }
                busy = true
                scope.launch {
                    PhoneMove.retire(context, repos, actor)
                    note = "Done. You will be signed out in a moment."
                    typed = ""
                    tick++
                    busy = false
                }
            })
        }
        if (note.isNotEmpty()) Text(note, color = CT.GoldLight, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        GhostButton(text = "CLOSE THE STEPS", modifier = Modifier.fillMaxWidth(), onClick = { open = false })
    }
}

/** Shown instead of the manager sign-in on a retired phone. */
@Composable
fun RetiredPhoneScreen(repos: Repos, retiredAt: Long, onExit: () -> Unit, onUsedAgain: () -> Unit) {
    val scope = rememberCoroutineScope()
    var typed by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Phone retired", onExit)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("This phone is not the manager phone any more.", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text("It was retired on " + fmtTime(retiredAt) + ". Use your new phone for everything. Telegram reading and notifications are switched off here, and nothing was deleted.", color = Color.White, fontSize = 13.sp)
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Need this phone as the manager again?", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(
                "Only do this if the new phone is NOT being used as the manager. Two manager phones at the same time confuse the workers' updates and fight over the Telegram bot.",
                color = MV_WARN, fontSize = 12.sp
            )
            Spacer(Modifier.height(6.dp))
            CTField(typed, { typed = it.trim() }, "Type USE AGAIN")
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "USE THIS PHONE AGAIN", modifier = Modifier.fillMaxWidth(), onClick = {
                if (typed != "USE AGAIN") { note = "Type USE AGAIN (capital letters) first."; return@GhostButton }
                scope.launch {
                    PhoneMove.useAgain(repos)
                    onUsedAgain()
                }
            })
            if (note.isNotEmpty()) Text(note, color = MV_BAD, fontSize = 12.sp)
            Text("Telegram reading and notifications stay off until you switch them on again.", color = CT.TextSoft, fontSize = 11.sp)
        }
    }
}
