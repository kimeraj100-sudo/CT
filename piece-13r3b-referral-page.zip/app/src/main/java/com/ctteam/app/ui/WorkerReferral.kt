package com.ctteam.app.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ReferralRules
import com.ctteam.app.data.ReferralView
import com.ctteam.app.data.ReferralViewCodec
import com.ctteam.app.data.Repos
import kotlinx.coroutines.delay

/**
 * PIECE R3b — worker page "Referrals & status" (three-bar menu). Reads what the manager sent in R3a (REFERRAL_VIEW):
 * the worker's code (COPY + SHARE), status with progress to the next one, points, and the worker's own referrals.
 * Nothing here is a promise of money: the manager decides what points can be used for. Spending points comes in R4.
 */
private val WR_GOOD = Color(0xFF5FD6A5)
private val WR_WAIT = Color(0xFFFFD166)
private val WR_BAD = Color(0xFFFF8A8A)

private fun wrShareText(code: String, need: Int): String =
    "Join me on CT Team! When you connect in the app, type my referral code " + code + ". " +
        "My referral only counts after you have " + need + " approved task" + (if (need == 1) "" else "s") + "."

@Composable
private fun WrBar(fraction: Float) {
    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x33FFFFFF))) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(10.dp).clip(RoundedCornerShape(5.dp)).background(CT.Gold))
    }
}

@Composable
fun WorkerReferralCard(repos: Repos, workerId: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var view by remember { mutableStateOf<ReferralView?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    // looks again every few seconds, so figures that were just imported appear without any button
    LaunchedEffect(workerId) {
        while (true) {
            view = ReferralViewCodec.load(repos.db, workerId)
            loaded = true
            delay(4000)
        }
    }
    val v = view

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        if (v == null) {
            Text("Referrals & status", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                if (loaded) "No referral figures yet. They arrive with the manager's next update (open Sync and use it)." else "Loading…",
                color = CT.TextSoft, fontSize = 13.sp
            )
            return@GlassCard
        }

        // ---- status
        val tier = v.tier()
        val next = v.nextTier()
        Text("Your status", color = CT.TextSoft, fontSize = 12.sp)
        Text(tier.name, color = CT.Gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp)
        Text(tier.perk, color = CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        if (next != null) {
            val idx = ReferralRules.TIERS.indexOf(next)
            val target = ReferralRules.thresholdFor(idx, v.thresholds)
            val prev = ReferralRules.thresholdFor(idx - 1, v.thresholds)
            val span = maxOf(1, target - prev)
            WrBar((v.awarded - prev).toFloat() / span.toFloat())
            Spacer(Modifier.height(4.dp))
            val more = v.toNext() ?: 0
            Text(
                more.toString() + " more awarded referral" + (if (more == 1) "" else "s") + " to become " + next.name +
                    " (" + v.awarded + " of " + target + ")",
                color = Color.White, fontSize = 13.sp
            )
        } else {
            Text("You are at the top status. Thank you!", color = WR_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }

        // ---- points
        Spacer(Modifier.height(12.dp))
        Text("Your points", color = CT.TextSoft, fontSize = 12.sp)
        Text(v.balance.toString(), color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        if (v.balance > 0 && v.ugxPerPoint > 0L) {
            Text("At the manager's current rate this is about " + ugx(v.worthUgx()) + ". It is an estimate, not a promise.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Text("The manager decides if and when points can be used.", color = CT.TextSoft, fontSize = 12.sp)

        // ---- code
        Spacer(Modifier.height(12.dp))
        Text("Your referral code", color = CT.TextSoft, fontSize = 12.sp)
        Text(v.code, color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton(text = "COPY CODE", modifier = Modifier.weight(1f), onClick = {
                clipboard.setText(AnnotatedString(v.code))
                msg = "Code copied."
            })
            GhostButton(text = "SHARE", modifier = Modifier.weight(1f), onClick = {
                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, wrShareText(v.code, v.need))
                val chooser = Intent.createChooser(send, "Share your code")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(chooser)
                } catch (e: Exception) {
                    msg = "Could not open the share list."
                }
            })
        }
        if (msg.isNotEmpty()) Text(msg, color = CT.GoldLight, fontSize = 12.sp)

        // ---- how it works
        Spacer(Modifier.height(12.dp))
        Text("How it works", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("• A new worker types your code when connecting to the manager.", color = CT.TextSoft, fontSize = 12.sp)
        Text("• It counts after they have " + v.need + " approved task" + (if (v.need == 1) "" else "s") + " and the manager awards it.", color = CT.TextSoft, fontSize = 12.sp)
        Text("• Points come only from the workers you referred yourself, never from their referrals.", color = CT.TextSoft, fontSize = 12.sp)
        Text("• The manager checks every referral, so fake or double accounts are refused.", color = CT.TextSoft, fontSize = 12.sp)

        // ---- my referrals
        Spacer(Modifier.height(12.dp))
        Text("Your referrals (" + v.entries.size + ")", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (v.entries.isEmpty()) Text("Nobody used your code yet.", color = CT.TextSoft, fontSize = 12.sp)
        for (e in v.entries) {
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(e.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(
                    when (e.state) {
                        "A" -> "Awarded"
                        "R" -> "Not counted"
                        else -> "Waiting"
                    },
                    color = when (e.state) {
                        "A" -> WR_GOOD
                        "R" -> WR_BAD
                        else -> WR_WAIT
                    },
                    fontWeight = FontWeight.Bold, fontSize = 12.sp
                )
            }
            when (e.state) {
                "A" -> Text("+" + e.points + " points", color = CT.TextSoft, fontSize = 12.sp)
                "R" -> Text("The manager did not count this one.", color = CT.TextSoft, fontSize = 12.sp)
                else -> {
                    WrBar(if (v.need > 0) e.approved.toFloat() / v.need.toFloat() else 0f)
                    Text(
                        "Approved " + minOf(e.approved, v.need) + " of " + v.need + " · worth about " + e.points + " points once awarded",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                }
            }
            Text("Recorded " + fmtTime(e.at), color = CT.TextSoft, fontSize = 11.sp, modifier = Modifier.padding(top = 1.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("Updated by the manager on " + fmtTime(v.asOf), color = CT.TextSoft, fontSize = 11.sp)
    }
}
