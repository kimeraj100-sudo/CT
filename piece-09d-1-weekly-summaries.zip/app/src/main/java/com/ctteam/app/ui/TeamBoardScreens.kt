package com.ctteam.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.BoardRow
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.TgSendReport
import com.ctteam.app.data.TimeUtil
import com.ctteam.app.data.QuietRow
import com.ctteam.app.data.Repos
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Piece T4 (manager): ranking with levels and streaks, the switch that lets workers see the top 5 (names + levels only),
 * quiet workers, and a weekly summary text per worker that the manager copies or shares by hand.
 * Computed from existing data, nothing new is stored except the consent switch (a `meta` value, audit-logged).
 */
@Composable
fun TeamBoardSection(repos: Repos, actor: String) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var rows by remember { mutableStateOf<List<BoardRow>>(emptyList()) }
    var quiet by remember { mutableStateOf<List<QuietRow>>(emptyList()) }
    var showBoard by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var summaryFor by remember { mutableStateOf<String?>(null) }
    var summaryText by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var linked by remember { mutableStateOf<Set<String>>(emptySet()) }       // workers with a Telegram chat (piece 9D-1)
    var sentWeek by remember { mutableStateOf<Set<String>>(emptySet()) }     // ... who already got a summary this week
    var tgBusy by remember { mutableStateOf(false) }
    var confirmAll by remember { mutableStateOf(false) }
    var tgTick by remember { mutableStateOf(0) }
    val thisWeek = remember { TimeUtil.weekKey(System.currentTimeMillis()) }

    LaunchedEffect(tgTick, rows.size) {
        val ids = if (repos.telegram.token() != null) repos.telegram.observeChats().first().map { it.workerId } else emptyList()
        linked = ids.toSet()
        sentWeek = ids.filter { repos.db.metaDao().get("tg:weekly:$it") == thisWeek }.toSet()
    }

    suspend fun sendWeekly(id: String): TgSendReport {
        val text = repos.teamBoard.weeklySummary(id)
        val r = repos.telegram.sendCodes(id, "weekly summary", listOf(text), text, actor)
        if (r.ok) repos.db.metaDao().put(MetaEntity("tg:weekly:$id", thisWeek))
        return r
    }

    // Look again every few seconds, like the other team cards, so deposits verified a moment ago appear.
    LaunchedEffect(Unit) {
        while (true) {
            rows = repos.teamBoard.leaderboard()
            quiet = repos.teamBoard.quietWorkers()
            if (!loaded) showBoard = repos.teamBoard.showBoard()
            loaded = true
            delay(5000)
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Leaderboard, levels and activity", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Levels follow each worker's ALL-TIME verified deposits (they never go down): Bronze from the first deposit, Silver UGX 100,000, " +
                "Gold 500,000, Platinum 2,000,000, Diamond 10,000,000. The ranking follows the share, so it uses the slow decay. Workers always see their own level, rank, streaks and badges.",
            color = CT.TextSoft, fontSize = 11.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Text("Show the top 5 to workers", color = Color.White, fontSize = 13.sp)
                Text(
                    "Off by default. When ON, every worker sees the first name, last initial and level of the top 5. Never amounts or shares. Only turn it on if the team agreed.",
                    color = CT.TextSoft, fontSize = 11.sp
                )
            }
            Switch(checked = showBoard, onCheckedChange = { on ->
                showBoard = on
                scope.launch {
                    repos.teamBoard.setShowBoard(on, actor)
                    msg = if (on) "Top 5 will be sent with the next update to each worker." else "Top 5 hidden. Workers get the change with their next update."
                }
            })
        }
        if (msg.isNotEmpty()) Text(msg, color = CT.GoldLight, fontSize = 12.sp)
        Text("Every change is written to the audit log.", color = CT.TextSoft, fontSize = 11.sp)

        Spacer(Modifier.height(10.dp))
        Text("Ranking", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (!loaded) {
            Text("Loading…", color = CT.TextSoft, fontSize = 12.sp)
        } else if (rows.isEmpty()) {
            Text("Nobody is ranked yet. Workers appear here after you verify a priced deposit.", color = CT.TextSoft, fontSize = 12.sp)
        }
        for (r in rows) {
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("#" + r.rank + "  " + r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(r.level.emoji + " " + r.level.name, color = CT.Gold, fontSize = 13.sp)
            }
            Text(
                "Share " + String.format(Locale.US, "%.2f", r.share * 100.0) + "%  ·  all-time " + ugx(r.allTimeUgx) + "  ·  " + r.deposits +
                    (if (r.deposits == 1) " deposit" else " deposits") +
                    (if (r.weekStreak > 0) "  ·  🔥 " + r.weekStreak + (if (r.weekStreak == 1) " week" else " weeks") + " in a row" else ""),
                color = CT.TextSoft, fontSize = 11.sp
            )
            if (r.lastDepositAt != null) Text("Last deposit: " + fmtTime(r.lastDepositAt), color = CT.TextSoft, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))
        Text("Quiet workers", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Active workers with no proof for 7 days, or no verified deposit for 4 weeks. A kind message often helps.", color = CT.TextSoft, fontSize = 11.sp)
        if (loaded && quiet.isEmpty()) Text("Nobody is quiet right now. 🎉", color = CT.TextSoft, fontSize = 12.sp)
        for (q in quiet) {
            Spacer(Modifier.height(4.dp))
            Text(q.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            for (reason in q.reasons) Text("• " + reason, color = CT.TextSoft, fontSize = 11.sp)
        }

        Spacer(Modifier.height(12.dp))
        Text("Weekly summary text", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Pick a worker to write last week's summary. Copy or share it by hand (WhatsApp, SMS), or send it on Telegram to workers who have a chat with your bot.", color = CT.TextSoft, fontSize = 11.sp)
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (r in rows) {
                CTChip(text = r.shortName, selected = summaryFor == r.workerId, onClick = {
                    summaryFor = r.workerId
                    summaryText = "Writing…"
                    scope.launch { summaryText = repos.teamBoard.weeklySummary(r.workerId) }
                })
            }
        }
        if (summaryFor != null) {
            Text(summaryText, color = Color.White, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GhostButton(text = "COPY", onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("CT Team weekly summary", summaryText))
                    msg = "Copied."
                })
                GhostButton(text = "SHARE", onClick = {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, summaryText)
                    try {
                        context.startActivity(Intent.createChooser(send, "Share weekly summary"))
                    } catch (ex: Exception) {
                        msg = "No app could be opened to share it. Use COPY."
                    }
                })
            }
            val chosen = summaryFor
            if (chosen != null && chosen in linked) {
                Spacer(Modifier.height(6.dp))
                GoldButton(
                    text = if (tgBusy) "SENDING…" else if (chosen in sentWeek) "SEND AGAIN ON TELEGRAM (sent this week)" else "SEND ON TELEGRAM",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (tgBusy) return@GoldButton
                        tgBusy = true
                        scope.launch {
                            msg = sendWeekly(chosen).message
                            tgTick++
                            tgBusy = false
                        }
                    }
                )
            }
        }
        val toSend = linked.filter { it !in sentWeek }
        if (toSend.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            GoldButton(
                text = if (tgBusy) "SENDING…" else if (confirmAll) "TAP AGAIN TO SEND TO ${toSend.size}" else "SEND LAST WEEK'S SUMMARY TO ALL ON TELEGRAM (${toSend.size} not sent this week)",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (tgBusy) return@GoldButton
                    if (!confirmAll) { confirmAll = true; return@GoldButton }
                    confirmAll = false
                    tgBusy = true
                    val ids = toSend
                    scope.launch {
                        var good = 0
                        val bad = ArrayList<String>()
                        for (id in ids) {
                            val r = sendWeekly(id)
                            if (r.ok) good++ else bad.add(r.message)
                            delay(400)
                        }
                        msg = good.toString() + " of " + ids.size + " sent." + bad.joinToString("") { "\n" + it }
                        tgTick++
                        tgBusy = false
                    }
                }
            )
        }
    }
}
