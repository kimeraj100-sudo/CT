package com.ctteam.app.data

/**
 * Piece C1 — the manager's Telegram bot, built into the release so workers never type or look up its name.
 * Put the bot's username here (the name BotFather gave, with or without the @). NEVER put the bot TOKEN here:
 * anyone can read an APK, and the token would give them the bot and every worker's messages.
 * Leave it empty and the connect card tells the worker to ask the manager for the bot name.
 */
object BotConfig {
    const val BOT_USERNAME = "CtcommBot"

    fun username(): String = BOT_USERNAME.trim().trimStart('@')
}
