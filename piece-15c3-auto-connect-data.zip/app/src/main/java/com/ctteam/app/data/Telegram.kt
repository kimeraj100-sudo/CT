package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/*
 * PIECE 9A — TELEGRAM, manager side: connect a bot, read what workers send it, import it automatically.
 * PIECE 9B — the manager app also SENDS signed updates, reset codes and join codes to a worker's linked chat.
 *
 * HOW IT WORKS (no server, no cost):
 *  - The manager makes a free bot with @BotFather and pastes its token into this app. ONLY the manager phone holds the token.
 *  - A worker shares a CT Team message (the SHARE button already in the worker app) into the bot's chat. The manager app
 *    reads the bot's messages (getUpdates, long polling, only while the manager area is open) and runs every CT1 message
 *    through the SAME checks as copy/paste: HMAC, replay protection, manager approval for enrollments and reset requests.
 *  - A text file (.txt / .ctt) sent to the bot is read the same way.
 *  - After a worker's NEW signed message is accepted, the app remembers that worker's Telegram chat so Piece 9B can send back.
 *
 * HONEST LIMITS: Telegram bot chats are not end-to-end encrypted, so every message stays signed (it cannot be forged or
 * replayed) but is readable by Telegram. The token is stored in this app's private database (not the Android Keystore) and
 * must be treated as a password: anyone holding it controls the bot. Only ONE program may read a bot at a time. The app
 * reads messages only while the manager area is open; Telegram keeps unread messages for about 24 hours.
 */

// ------------------------------------------------------------------ TABLES

/** Which Telegram chat belongs to which worker. Only set after a NEW message signed with that worker's key was accepted. */
@Entity(tableName = "tg_chats")
data class TgChatEntity(
    @PrimaryKey val workerId: String,
    val chatId: Long,
    val username: String?,
    val firstName: String,
    val boundAt: Long,
    val lastSeenAt: Long
)

object TgKind {
    const val OK = "OK"                  // log: a message was used
    const val FAIL = "FAIL"              // log: a message was refused
    const val ENROLL = "ENROLL"          // needs the manager (Sync screen)
    const val RESET_REQ = "RESET_REQ"    // needs the manager (Sync screen)
    const val HELD = "HELD"              // could not be used yet (worker not connected); try again later
    const val FILE = "FILE"              // log: a file that is not a CT message
    const val SENT = "SENT"              // log (9B): something was sent to a worker
    const val SEND_FAIL = "SEND_FAIL"    // log (9B): sending failed
    const val ORIGINAL = "ORIGINAL"          // log (9C): an original picture was received
    const val ORIGINAL_BAD = "ORIGINAL_BAD"  // log (9C): an original picture that does not fit the reports
}

object TgState {
    const val PENDING = "PENDING"
    const val DONE = "DONE"
}

@Entity(tableName = "tg_inbox", indices = [Index("status")])
data class TgInboxEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val receivedAt: Long,
    val chatId: Long,
    val workerId: String?,
    val kind: String,
    val status: String,
    val title: String,
    val detail: String,
    val wire: String?,                // the signed message itself, kept only while it still needs the manager
    val handledAt: Long?
)

@Dao
interface TgDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putChat(c: TgChatEntity)
    @Query("SELECT * FROM tg_chats WHERE workerId = :workerId") suspend fun chat(workerId: String): TgChatEntity?
    @Query("SELECT COUNT(*) FROM tg_chats WHERE chatId = :telegramChatId") suspend fun boundCount(telegramChatId: Long): Int
    @Query("SELECT * FROM tg_chats ORDER BY lastSeenAt DESC") fun observeChats(): Flow<List<TgChatEntity>>
    @Query("SELECT * FROM tg_chats ORDER BY lastSeenAt DESC") suspend fun allChats(): List<TgChatEntity>
    @Query("SELECT workerId FROM tg_chats WHERE chatId = :telegramChatId LIMIT 1") suspend fun workerOfChat(telegramChatId: Long): String?
    @Query("SELECT * FROM proofs WHERE sha256 = :hash") suspend fun proofsWithHash(hash: String): List<ProofEntity>
    @Query("SELECT workerId FROM submissions WHERE id = :submissionKey") suspend fun submissionOwner(submissionKey: String): String?

    @Insert suspend fun addInbox(e: TgInboxEntity): Long
    @Query("SELECT * FROM tg_inbox ORDER BY id DESC LIMIT :limit") fun observeInbox(limit: Int): Flow<List<TgInboxEntity>>
    @Query("SELECT COUNT(*) FROM tg_inbox WHERE status = 'PENDING'") fun observePendingCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM tg_inbox WHERE wire = :wire AND status = 'PENDING'") suspend fun pendingWithWire(wire: String): Int
    @Query("SELECT * FROM tg_inbox WHERE id = :rowId") suspend fun inbox(rowId: Long): TgInboxEntity?
    @Query("UPDATE tg_inbox SET status = :state, handledAt = :at, wire = NULL WHERE id = :rowId") suspend fun setInboxState(rowId: Long, state: String, at: Long)
    @Query("DELETE FROM tg_inbox WHERE status != 'PENDING' AND id NOT IN (SELECT id FROM tg_inbox ORDER BY id DESC LIMIT 300)") suspend fun trimInbox()
}

// ------------------------------------------------------------------ BOT API CLIENT (plain HttpURLConnection, no extra library)

sealed class TgResult<out T> {
    class Ok<T>(val value: T) : TgResult<T>()
    class Err(val code: Int, val message: String, val retryAfterSec: Int = 0) : TgResult<Nothing>()
}

class TelegramClient(token: String) {
    private val base = "https://api.telegram.org/bot$token/"
    private val fileBase = "https://api.telegram.org/file/bot$token/"

    /** Reads the answer of a Bot API call: the result on success, words on failure (including Telegram's "retry after"). */
    private fun readAnswer(conn: HttpURLConnection): TgResult<Any?> {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        val json = try { JSONObject(body) } catch (ex: Exception) { null }
        return if (code in 200..299 && json != null && json.optBoolean("ok")) {
            TgResult.Ok(json.opt("result"))
        } else {
            val desc = json?.optString("description")?.takeIf { it.isNotBlank() } ?: ("HTTP " + code)
            val retry = json?.optJSONObject("parameters")?.optInt("retry_after", 0) ?: 0
            TgResult.Err(json?.optInt("error_code", code) ?: code, desc, retry)
        }
    }

    private fun <T> guarded(block: () -> TgResult<T>): TgResult<T> = try {
        block()
    } catch (ex: UnknownHostException) {
        TgResult.Err(0, "No internet connection.")
    } catch (ex: SocketTimeoutException) {
        TgResult.Err(0, "The connection to Telegram timed out.")
    } catch (ex: IOException) {
        TgResult.Err(0, "Network error while talking to Telegram.")
    } catch (ex: Exception) {
        TgResult.Err(0, "Unexpected error while talking to Telegram.")
    }

    private fun call(method: String, params: JSONObject, readTimeoutMs: Int): TgResult<Any?> {
        var conn: HttpURLConnection? = null
        return try {
            guarded {
                val c = (URL(base + method).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = readTimeoutMs
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                conn = c
                c.outputStream.use { it.write(params.toString().toByteArray(Charsets.UTF_8)) }
                readAnswer(c)
            }
        } finally {
            conn?.disconnect()
        }
    }

    /** Piece 9B: plain text message (no formatting, no link preview). Telegram allows 4096 characters. */
    fun sendMessage(chatId: Long, text: String): TgResult<Unit> {
        val p = JSONObject().put("chat_id", chatId).put("text", text)
            .put("link_preview_options", JSONObject().put("is_disabled", true))
        return when (val r = call("sendMessage", p, 30_000)) {
            is TgResult.Ok -> TgResult.Ok(Unit)
            is TgResult.Err -> r
        }
    }

    /**
     * Piece 9B: sends a file (multipart upload). Used for long updates (text) and, since 11d, for the encrypted backup.
     * The exact length is announced up front, so the phone streams the file instead of keeping a second copy in memory.
     */
    fun sendDocument(chatId: Long, fileName: String, content: ByteArray, caption: String, mime: String = "text/plain"): TgResult<Unit> {
        val boundary = "CTTeamBoundary" + System.currentTimeMillis()
        val nl = "\r\n"
        var conn: HttpURLConnection? = null
        return try {
            guarded {
                val c = (URL(base + "sendDocument").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 120_000
                    doOutput = true
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                }
                conn = c
                val head = StringBuilder()
                fun field(name: String, value: String) {
                    head.append("--$boundary${nl}Content-Disposition: form-data; name=\"$name\"$nl$nl$value$nl")
                }
                field("chat_id", chatId.toString())
                if (caption.isNotBlank()) field("caption", caption.take(1000))
                val safeName = fileName.filter { it.isLetterOrDigit() || it == '.' || it == '-' || it == '_' }.ifBlank { "ct-update.txt" }
                head.append("--$boundary${nl}Content-Disposition: form-data; name=\"document\"; filename=\"$safeName\"${nl}Content-Type: $mime$nl$nl")
                val headBytes = head.toString().toByteArray(Charsets.UTF_8)
                val tailBytes = (nl + "--$boundary--" + nl).toByteArray(Charsets.UTF_8)
                c.setFixedLengthStreamingMode(headBytes.size.toLong() + content.size.toLong() + tailBytes.size.toLong())
                c.outputStream.use { out ->
                    out.write(headBytes)
                    out.write(content)
                    out.write(tailBytes)
                }
                when (val r = readAnswer(c)) {
                    is TgResult.Ok -> TgResult.Ok(Unit)
                    is TgResult.Err -> r
                }
            }
        } finally {
            conn?.disconnect()
        }
    }

    fun getMe(): TgResult<JSONObject> = when (val r = call("getMe", JSONObject(), 20_000)) {
        is TgResult.Ok -> (r.value as? JSONObject)?.let { TgResult.Ok(it) } ?: TgResult.Err(0, "Unexpected answer from Telegram.")
        is TgResult.Err -> r
    }

    /** getUpdates and a webhook cannot both be used, so the webhook is removed (messages already waiting are kept). */
    fun deleteWebhook(): TgResult<Unit> = when (val r = call("deleteWebhook", JSONObject().put("drop_pending_updates", false), 20_000)) {
        is TgResult.Ok -> TgResult.Ok(Unit)
        is TgResult.Err -> r
    }

    fun getUpdates(offset: Long, timeoutSec: Int): TgResult<JSONArray> {
        val p = JSONObject().put("offset", offset).put("timeout", timeoutSec).put("limit", 50)
            .put("allowed_updates", JSONArray().put("message"))
        return when (val r = call("getUpdates", p, (timeoutSec + 20) * 1000)) {
            is TgResult.Ok -> (r.value as? JSONArray)?.let { TgResult.Ok(it) } ?: TgResult.Err(0, "Unexpected answer from Telegram.")
            is TgResult.Err -> r
        }
    }

    /** Downloads a file a user sent to the bot (Telegram allows bots to download up to 20 MB). */
    fun downloadFile(fileId: String, maxBytes: Int): TgResult<ByteArray> {
        val info = call("getFile", JSONObject().put("file_id", fileId), 20_000)
        val path = when (info) {
            is TgResult.Ok -> (info.value as? JSONObject)?.optString("file_path")?.takeIf { it.isNotBlank() }
                ?: return TgResult.Err(0, "Telegram gave no file path.")
            is TgResult.Err -> return info
        }
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(fileBase + path).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 60_000
            }
            if (conn.responseCode !in 200..299) return TgResult.Err(conn.responseCode, "Could not download the file.")
            val buf = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(8192)
            conn.inputStream.use { ins ->
                while (true) {
                    val n = ins.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                    if (buf.size() > maxBytes) return TgResult.Err(0, "The file is too large.")
                }
            }
            TgResult.Ok(buf.toByteArray())
        } catch (ex: Exception) {
            TgResult.Err(0, "Could not download the file.")
        } finally {
            conn?.disconnect()
        }
    }
}

// ------------------------------------------------------------------ REPOSITORY

class TgLive(
    val running: Boolean = false,
    val lastOkAt: Long = 0L,
    val lastError: String? = null,
    val handledTotal: Int = 0
)

class TgPollResult(val handled: Int, val error: String?)

/** Piece 9B: what happened when something was sent to a worker. [sentParts] of [totalParts] Telegram messages were delivered. */
class TgSendReport(val ok: Boolean, val message: String, val sentParts: Int, val totalParts: Int)

/** One line of "send to everyone": which worker, and how it went. */
class TgBulkLine(val workerName: String, val report: TgSendReport)

/** Result of approving a reset request from the Telegram screen. If sending failed, [manualCode] holds the code to hand over some other way. */
class TgResetResult(val sent: Boolean, val message: String, val manualCode: String?)

/** Piece 9C: an original picture a worker sent to the bot as a file. [stored] = the file itself is on this phone. */
class TgOriginal(val sha: String, val workerId: String?, val fileName: String, val size: Long, val at: Long, val stored: Boolean)

class TelegramRepository(
    private val db: CTDatabase,
    private val audit: AuditRepository,
    private val sync: SyncRepository,
    private val originalsDir: File
) {
    private val meta = db.metaDao()
    private val dao = db.tgDao()
    private val loopLock = Mutex()
    private val liveState = MutableStateFlow(TgLive())

    /** Live status for the screen (in memory only). */
    val live: StateFlow<TgLive> get() = liveState

    companion object {
        private const val KEY_TOKEN = "tg:token"
        private const val KEY_BOT = "tg:bot"
        private const val KEY_OFFSET = "tg:offset"
        private const val KEY_PAUSED = "tg:paused"
        private const val KEY_BK_CHAT = "tg:backupChat"      // Piece 11d: the manager's OWN Telegram chat (receives backups)
        private const val KEY_BK_CODE = "tg:backupCode"      // Piece 11d: "CODE|expiresAt|wrongTries" while a link code is pending
        private const val BK_CODE_MINUTES = 5
        private const val MAX_BACKUP_SEND = 49_000_000L      // bots may send files up to 50 MB
        private val TOKEN_RULE = Regex("^[0-9]{6,12}:[A-Za-z0-9_-]{30,60}$")
        private const val MAX_TEXT_FILE = 3_000_000
        private const val MAX_TEXT_PARTS = 3          // more parts than this are sent as one file
        private const val MAX_TEXT_LENGTH = 3900      // a chat message holds 4096 characters
        private const val POLL_SECONDS = 25
        private const val MAX_ORIGINAL = 20_000_000                     // Telegram lets bots download up to 20 MB
        private const val MAX_ORIGINALS_TOTAL = 400L * 1024L * 1024L    // saved originals stop at 400 MB (the match is still recorded)
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- connect / settings

    suspend fun token(): String? = meta.get(KEY_TOKEN)?.takeIf { TOKEN_RULE.matches(it) }
    suspend fun botName(): String? = meta.get(KEY_BOT)?.takeIf { it.isNotBlank() }
    suspend fun isPaused(): Boolean = meta.get(KEY_PAUSED) == "1"

    suspend fun setPaused(paused: Boolean, actor: String) {
        meta.put(MetaEntity(KEY_PAUSED, if (paused) "1" else "0"))
        audit.log(actor, if (paused) "TG_PAUSED" else "TG_RESUMED", "telegram", "bot", "")
    }

    /** Checks the token with Telegram (getMe) and keeps it. The token is never written to the audit log. */
    suspend fun connect(tokenRaw: String, actor: String): Outcome<String> {
        val t = tokenRaw.trim()
        if (!TOKEN_RULE.matches(t)) return Outcome.Err("That does not look like a bot token. It looks like 123456789:ABC... and comes from @BotFather.")
        val me = withContext(Dispatchers.IO) {
            val c = TelegramClient(t)
            when (val r = c.getMe()) {
                is TgResult.Err -> r
                is TgResult.Ok -> {
                    c.deleteWebhook()
                    r
                }
            }
        }
        val name: String = when (me) {
            is TgResult.Err -> return Outcome.Err(friendly(me))
            is TgResult.Ok -> me.value.optString("username")
        }
        if (name.isBlank()) return Outcome.Err("Telegram did not return a bot name. Is this a bot token?")
        meta.put(MetaEntity(KEY_TOKEN, t))
        meta.put(MetaEntity(KEY_BOT, name))
        meta.put(MetaEntity(KEY_PAUSED, "0"))
        audit.log(actor, "TG_CONNECTED", "telegram", "bot", "bot @$name")
        return Outcome.Ok(name)
    }

    suspend fun disconnect(actor: String) {
        val name = botName()
        meta.put(MetaEntity(KEY_TOKEN, ""))
        meta.put(MetaEntity(KEY_BOT, ""))
        audit.log(actor, "TG_DISCONNECTED", "telegram", "bot", "bot @" + (name ?: "?"))
        liveState.value = TgLive()
    }

    private fun friendly(e: TgResult.Err): String = when (e.code) {
        401 -> "Telegram refused the bot token. It is wrong or was revoked. Paste a new token from @BotFather."
        409 -> "Another program is reading this bot (a second phone, or a webhook). Only one phone can read a bot at a time."
        429 -> "Telegram says: too many requests. The app will wait and try again."
        else -> e.message
    }

    // ---------------------------------------------------------------- the reading loop

    /** Runs until cancelled. Started while the manager is signed in; stops when the manager area closes. */
    suspend fun pollLoop(actorOf: () -> String) {
        loopLock.withLock {
            try {
                while (currentCoroutineContext().isActive) {
                    if (token() == null || isPaused()) {
                        liveState.value = TgLive(running = false, lastOkAt = liveState.value.lastOkAt, lastError = null, handledTotal = liveState.value.handledTotal)
                        delay(4000)
                        continue
                    }
                    val before = liveState.value
                    liveState.value = TgLive(true, before.lastOkAt, before.lastError, before.handledTotal)
                    val r = pollOnce(actorOf(), POLL_SECONDS)
                    val s = liveState.value
                    if (r.error != null) {
                        liveState.value = TgLive(true, s.lastOkAt, r.error, s.handledTotal)
                        delay(15_000)
                    } else {
                        liveState.value = TgLive(true, now(), null, s.handledTotal + r.handled)
                    }
                }
            } finally {
                val s = liveState.value
                liveState.value = TgLive(false, s.lastOkAt, s.lastError, s.handledTotal)
            }
        }
    }

    private suspend fun pollOnce(actor: String, timeoutSec: Int): TgPollResult {
        val t = token() ?: return TgPollResult(0, "No bot is connected.")
        val client = TelegramClient(t)
        val offset = meta.get(KEY_OFFSET)?.toLongOrNull() ?: 0L
        val r = withContext(Dispatchers.IO) { client.getUpdates(offset, timeoutSec) }
        val arr: JSONArray = when (r) {
            is TgResult.Err -> return TgPollResult(0, friendly(r))
            is TgResult.Ok -> r.value
        }
        var handled = 0
        for (i in 0 until arr.length()) {
            val u = arr.optJSONObject(i) ?: continue
            val uid = u.optLong("update_id", -1L)
            try {
                if (handleUpdate(client, u, actor)) handled++
            } catch (ex: Exception) {
                audit.event("TG_UPDATE_ERROR", ex.javaClass.simpleName)
            }
            if (uid >= 0L) meta.put(MetaEntity(KEY_OFFSET, (uid + 1L).toString()))
        }
        dao.trimInbox()
        return TgPollResult(handled, null)
    }

    /**
     * Piece 9D-3: looks at how many messages are waiting in the bot WITHOUT taking them (the saved position is not moved), so the
     * background notification can say "N waiting". Returns null when it cannot look: no bot, paused, or the app is already reading
     * the bot right now (two readers at once would clash). At most 50 are reported.
     */
    suspend fun peekWaiting(): Int? {
        val t = token() ?: return null
        if (isPaused()) return null
        if (!loopLock.tryLock()) return null
        try {
            val offset = meta.get(KEY_OFFSET)?.toLongOrNull() ?: 0L
            val r = withContext(Dispatchers.IO) { TelegramClient(t).getUpdates(offset, 0) }
            return when (r) {
                is TgResult.Ok -> r.value.length()
                is TgResult.Err -> null
            }
        } finally {
            loopLock.unlock()
        }
    }

    // ---------------------------------------------------------------- one update

    private suspend fun handleUpdate(client: TelegramClient, u: JSONObject, actor: String): Boolean {
        val m = u.optJSONObject("message") ?: return false
        val chat = m.optJSONObject("chat") ?: return false
        if (chat.optString("type") != "private") return false          // groups and channels are ignored
        val chatId = chat.optLong("id", 0L)
        if (chatId == 0L) return false
        val from = m.optJSONObject("from")
        val username = from?.optString("username")?.takeIf { it.isNotBlank() }
        val firstName = (from?.optString("first_name") ?: "").take(60)

        var text = m.optString("text").ifEmpty { m.optString("caption") }
        val doc = m.optJSONObject("document")
        var docName = ""
        if (doc != null) {
            docName = doc.optString("file_name").take(80)
            val lower = docName.lowercase()
            val mime = doc.optString("mime_type")
            val size = doc.optLong("file_size", 0L)
            val textual = lower.endsWith(".txt") || lower.endsWith(".ctt") || mime.startsWith("text/")
            if (textual && size in 1L..MAX_TEXT_FILE.toLong()) {
                val got = withContext(Dispatchers.IO) { client.downloadFile(doc.optString("file_id"), MAX_TEXT_FILE) }
                when (got) {
                    is TgResult.Ok -> text = text + "\n" + String(got.value, Charsets.UTF_8)
                    is TgResult.Err -> {
                        log(chatId, null, TgKind.FAIL, "File not read: $docName", got.message + " Ask the sender to send it again.")
                        return true
                    }
                }
            }
        }

        // Piece 11d: the manager links their OWN chat by sending the one-time code shown on the Backup screen
        if (doc == null && tryBackupLink(client, chatId, firstName, text, actor)) return true

        if (!text.contains("CT1.")) {
            if (m.has("photo") && isBound(chatId)) {
                log(chatId, null, TgKind.FILE, "Picture received as a photo",
                    "Telegram shrinks photos, so the fingerprint cannot match. Ask the worker to send the ORIGINAL as a file: paperclip, File, choose the picture.")
                return true
            }
            if (doc != null && looksLikePicture(doc, docName) && handleOriginal(client, chatId, doc, docName, actor)) return true
            if (doc != null && isBound(chatId)) {
                log(chatId, null, TgKind.FILE, "File received: " + docName.ifBlank { "(no name)" },
                    "It is not a CT Team message or a picture, so it was not used.")
                return true
            }
            return false          // strangers and chatter: ignored in silence
        }

        // remember what was already accepted, so a replayed copy can never move a worker's chat
        val envelopes = SyncCodec.parseAll(text).filter { it.direction == SyncCodec.W2M && it.type != SyncRepository.TYPE_ENROLL }
        val before = HashMap<String, Long>()
        for (e in envelopes) if (e.workerId !in before) before[e.workerId] = db.syncDao().maxSeen(e.workerId, SyncCodec.W2M)

        val results = sync.receiveAll(text, actor)

        for (e in envelopes) {
            val key = sync.keyOf(e.workerId) ?: continue
            if (SyncCodec.verify(key.keyHex, e) && e.seq > (before[e.workerId] ?: Long.MAX_VALUE)) bind(e.workerId, chatId, username, firstName, actor)
        }
        for (res in results) record(res, chatId, actor, username, firstName)
        return true
    }

    private suspend fun isBound(chatId: Long): Boolean = dao.boundCount(chatId) > 0

    // ---------------------------------------------------------------- Piece 9C: original pictures

    private fun looksLikePicture(doc: JSONObject, name: String): Boolean {
        val n = name.lowercase()
        return doc.optString("mime_type").lowercase().startsWith("image/") ||
            n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".webp") || n.endsWith(".heic")
    }

    fun originalFile(sha: String): File = File(originalsDir, "$sha.img")

    private fun originalsBytes(): Long = originalsDir.listFiles()?.sumOf { it.length() } ?: 0L

    /** What this phone knows about the original with this exact SHA-256 (null = never received). */
    suspend fun originalOf(sha: String): TgOriginal? {
        val raw = meta.get("orig:$sha") ?: return null
        return try {
            val o = JSONObject(raw)
            TgOriginal(sha, o.optString("w").ifBlank { null }, o.optString("n"), o.optLong("s", 0L), o.optLong("at", 0L), o.optBoolean("f", false) && originalFile(sha).exists())
        } catch (ex: Exception) { null }
    }

    /**
     * A worker sent a picture as a FILE (exact bytes). It is downloaded, its SHA-256 worked out here, saved, and compared with the
     * reports: the same file that a report of THIS worker names = a match. Strangers (chats not linked to a worker) are ignored.
     */
    private suspend fun handleOriginal(client: TelegramClient, chatId: Long, doc: JSONObject, docName: String, actor: String): Boolean {
        val workerId = dao.workerOfChat(chatId) ?: return false
        val name = docName.ifBlank { "(no name)" }
        if (doc.optLong("file_size", 0L) > MAX_ORIGINAL) {
            log(chatId, workerId, TgKind.FAIL, "Picture too large: $name", "Telegram bots can only download files up to 20 MB.")
            return true
        }
        val got = withContext(Dispatchers.IO) { client.downloadFile(doc.optString("file_id"), MAX_ORIGINAL) }
        val bytes = when (got) {
            is TgResult.Ok -> got.value
            is TgResult.Err -> {
                log(chatId, workerId, TgKind.FAIL, "Picture not downloaded: $name", got.message + " Ask the worker to send it again.")
                return true
            }
        }
        val sha = Hashing.sha256Hex(bytes)
        val short = sha.take(12)
        if (meta.get("orig:$sha") != null) {
            log(chatId, workerId, TgKind.ORIGINAL, "Original already received: $name", "Fingerprint $short… was saved before.")
            return true
        }
        var stored = false
        try {
            originalsDir.mkdirs()
            if (originalsBytes() + bytes.size <= MAX_ORIGINALS_TOTAL) {
                val tmp = File(originalsDir, "$sha.tmp")
                tmp.writeBytes(bytes)
                stored = tmp.renameTo(originalFile(sha))
                if (!stored) tmp.delete()
            }
        } catch (ex: Exception) {
            stored = false
        }
        meta.put(MetaEntity("orig:$sha", JSONObject().put("w", workerId).put("n", name.take(80)).put("s", bytes.size.toLong()).put("at", now()).put("f", stored).toString()))

        val proofs = dao.proofsWithHash(sha)
        val owners = proofs.map { dao.submissionOwner(it.submissionId) }
        val savedNote = if (stored) " Saved on this phone." else " Not saved (storage limit or error); the result is recorded."
        when {
            owners.any { it == workerId } -> {
                log(chatId, workerId, TgKind.ORIGINAL, "Original matches the report: $name", "Same file as the one in this worker's report (fingerprint $short…)." + savedNote)
                audit.log(actor, "TG_ORIGINAL_MATCH", "worker", workerId, "sha=$short")
            }
            owners.isNotEmpty() -> {
                log(chatId, workerId, TgKind.ORIGINAL_BAD, "File belongs to another worker's report: $name", "Fingerprint $short… is in a report from a DIFFERENT worker than the one who sent it. Look into this." + savedNote)
                audit.log(actor, "TG_ORIGINAL_OTHER_WORKER", "worker", workerId, "sha=$short")
            }
            else -> {
                log(chatId, workerId, TgKind.ORIGINAL, "Original saved, no report has this fingerprint yet: $name",
                    "If the worker's report is not imported yet it will match once you import it. If it IS imported, this is not the file they reported (fingerprint $short…)." + savedNote)
                audit.log(actor, "TG_ORIGINAL_UNMATCHED", "worker", workerId, "sha=$short")
            }
        }
        return true
    }

    private suspend fun bind(workerId: String, chatId: Long, username: String?, firstName: String, actor: String) {
        val old = dao.chat(workerId)
        val at = now()
        if (old == null) {
            dao.putChat(TgChatEntity(workerId, chatId, username, firstName, at, at))
            audit.log(actor, "TG_CHAT_BOUND", "worker", workerId, "Telegram chat linked")
        } else {
            if (old.chatId != chatId) audit.log(actor, "TG_CHAT_CHANGED", "worker", workerId, "the worker now writes from another Telegram account")
            dao.putChat(old.copy(chatId = chatId, username = username ?: old.username, firstName = firstName.ifBlank { old.firstName }, lastSeenAt = at))
        }
    }

    private suspend fun log(chatId: Long, workerId: String?, kind: String, title: String, detail: String) {
        dao.addInbox(TgInboxEntity(receivedAt = now(), chatId = chatId, workerId = workerId, kind = kind, status = TgState.DONE,
            title = title.take(120), detail = detail.take(400), wire = null, handledAt = now()))
    }

    private suspend fun pend(chatId: Long, workerId: String?, kind: String, title: String, detail: String, wire: String) {
        if (dao.pendingWithWire(wire) > 0) return           // the same message sent twice
        dao.addInbox(TgInboxEntity(receivedAt = now(), chatId = chatId, workerId = workerId, kind = kind, status = TgState.PENDING,
            title = title.take(120), detail = detail.take(400), wire = wire, handledAt = null))
    }

    private suspend fun record(res: SyncIncoming, chatId: Long, actor: String, username: String?, firstName: String) {
        when (res) {
            is SyncIncoming.Enroll -> {
                val p = res.preview
                // C2a: auto-connect (main manager's switch). Only a NEW worker with no problem; everything else waits for a manager.
                if (p.problem == null && p.mode == "NEW" && AutoConnect.enabled(db)) {
                    val a = sync.acceptEnrollment(res.wire, actor)
                    if (a is Outcome.Ok) {
                        AutoConnect.markUnverified(db, p.workerId)
                        audit.log(actor, "AUTO_CONNECTED", "worker", p.workerId, "not verified yet; keycheck=" + p.keyCheck)
                        bind(p.workerId, chatId, username, firstName, actor)
                        log(chatId, p.workerId, TgKind.OK, "Connected automatically: " + p.fullName,
                            "Not verified yet. Payouts and referral points wait until a manager verifies this worker.")
                        try { sendUpdate(p.workerId, true, actor) } catch (e: Exception) { /* the worker can still be sent updates later */ }
                        return
                    }
                }
                pend(chatId, p.workerId, TgKind.ENROLL, "Connection request: " + p.fullName,
                    "Key code " + p.keyCheck + (if (p.problem != null) ". Problem: " + p.problem else ""), res.wire)
            }
            is SyncIncoming.ResetRequest ->
                pend(chatId, res.workerId, TgKind.RESET_REQ, "Reset request: " + res.workerName, "Check code " + res.checkCode, res.wire)
            is SyncIncoming.Done ->
                if (res.retryWire != null) pend(chatId, null, TgKind.HELD, res.title, res.detail, res.retryWire)
                else log(chatId, null, if (res.ok) TgKind.OK else TgKind.FAIL, res.title, res.detail)
        }
    }

    // ---------------------------------------------------------------- Piece 9B: sending TO workers

    private fun sendFriendly(e: TgResult.Err): String = when {
        e.code == 403 -> "The worker blocked the bot, or never pressed START in the bot chat. Ask them to open the bot and press START."
        e.code == 400 && e.message.contains("chat not found", ignoreCase = true) ->
            "Telegram cannot find that chat. Ask the worker to open the bot, press START, and send you one message."
        e.code == 401 -> friendly(e)
        e.code == 429 -> "Telegram says: too many messages. Wait a minute and try again."
        else -> e.message
    }

    /** One try, and one more after Telegram's own "retry after" wait if it said slow down. */
    private suspend fun sendWithRetry(call: () -> TgResult<Unit>): TgResult<Unit> {
        var r = withContext(Dispatchers.IO) { call() }
        if (r is TgResult.Err && r.code == 429) {
            delay(r.retryAfterSec.coerceIn(1, 20) * 1000L)
            r = withContext(Dispatchers.IO) { call() }
        }
        return r
    }

    private fun fileSlug(label: String): String = label.lowercase().map { if (it.isLetterOrDigit()) it else '-' }.joinToString("").trim('-').ifBlank { "message" }

    // ---------------------------------------------------------------- the manager's own chat, for backups (Piece 11d)

    class BackupLink(val code: String, val expiresAt: Long)

    suspend fun backupChatId(): Long? = meta.get(KEY_BK_CHAT)?.toLongOrNull()

    /** A one-time code the manager sends to the bot from their OWN Telegram. Valid 5 minutes, 5 wrong tries at most. */
    suspend fun startBackupLink(actor: String): Outcome<BackupLink> {
        if (token() == null) return Outcome.Err("Connect your bot first (Manager > Telegram).")
        val digits = StringBuilder()
        val rnd = java.security.SecureRandom()
        repeat(8) { digits.append(rnd.nextInt(10)) }
        val code = "BK-$digits"
        val exp = now() + BK_CODE_MINUTES * 60_000L
        meta.put(MetaEntity(KEY_BK_CODE, "$code|$exp|0"))
        audit.log(actor, "TG_BACKUP_LINK_STARTED", "telegram", "backup", "")
        return Outcome.Ok(BackupLink(code, exp))
    }

    suspend fun pendingBackupLink(): BackupLink? {
        val st = meta.get(KEY_BK_CODE)?.split("|") ?: return null
        if (st.size < 3) return null
        val exp = st[1].toLongOrNull() ?: return null
        if (now() > exp || st[0].isBlank()) return null
        return BackupLink(st[0], exp)
    }

    suspend fun unlinkBackupChat(actor: String) {
        meta.put(MetaEntity(KEY_BK_CHAT, ""))
        meta.put(MetaEntity(KEY_BK_CODE, ""))
        audit.log(actor, "TG_BACKUP_CHAT_UNLINKED", "telegram", "backup", "")
    }

    /** True when this message was the pending link code (right or wrong), so the normal flow must not look at it. */
    private suspend fun tryBackupLink(client: TelegramClient, chatId: Long, firstName: String, text: String, actor: String): Boolean {
        val raw = text.trim().uppercase()
        if (!raw.startsWith("BK-")) return false
        val st = meta.get(KEY_BK_CODE)?.split("|") ?: return false
        if (st.size < 3 || st[0].isBlank()) return false
        val exp = st[1].toLongOrNull() ?: 0L
        val wrong = st[2].toIntOrNull() ?: 0
        if (now() > exp) {
            meta.put(MetaEntity(KEY_BK_CODE, ""))
            return false
        }
        if (raw == st[0]) {
            meta.put(MetaEntity(KEY_BK_CHAT, chatId.toString()))
            meta.put(MetaEntity(KEY_BK_CODE, ""))
            audit.log(actor, "TG_BACKUP_CHAT_LINKED", "telegram", "backup", "chat linked")
            withContext(Dispatchers.IO) {
                client.sendMessage(chatId, "Linked" + (if (firstName.isNotBlank()) ", $firstName" else "") + ". CT Team backups can now be sent to this chat.")
            }
        } else if (wrong + 1 >= 5) {
            meta.put(MetaEntity(KEY_BK_CODE, ""))          // too many wrong tries: the code dies
            audit.log(actor, "TG_BACKUP_LINK_LOCKED", "telegram", "backup", "5 wrong tries")
        } else {
            meta.put(MetaEntity(KEY_BK_CODE, st[0] + "|" + st[1] + "|" + (wrong + 1)))
        }
        return true
    }

    /** Sends the encrypted backup file to the manager's own chat. The file is encrypted with the manager's passphrase, so Telegram only holds ciphertext. */
    suspend fun sendBackupFile(file: File, caption: String, actor: String): Outcome<String> {
        val t = token() ?: return Outcome.Err("No Telegram bot is connected (Manager > Telegram).")
        val chat = backupChatId() ?: return Outcome.Err("Your own Telegram is not linked yet. Use LINK MY TELEGRAM first.")
        if (!file.exists()) return Outcome.Err("The backup file is missing.")
        if (file.length() > MAX_BACKUP_SEND)
            return Outcome.Err("The backup is bigger than Telegram allows for bots (about 49 MB). Use SHARE or CREATE BACKUP instead.")
        val bytes = withContext(Dispatchers.IO) { file.readBytes() }
        val r = sendWithRetry { TelegramClient(t).sendDocument(chat, file.name, bytes, caption, "application/octet-stream") }
        return when (r) {
            is TgResult.Ok -> {
                audit.log(actor, "TG_BACKUP_SENT", "backup", "db", "size=" + bytes.size)
                Outcome.Ok("Sent to your own Telegram chat (" + (bytes.size / 1024) + " KB).")
            }
            is TgResult.Err -> Outcome.Err(
                when {
                    r.code == 403 -> "Telegram refuses: the bot is blocked. Open the bot in Telegram and press START."
                    r.code == 400 && r.message.contains("chat not found", ignoreCase = true) -> "Telegram cannot find your chat. Link your Telegram again."
                    else -> friendly(r)
                }
            )
        }
    }

    /** True when a bot is connected and this worker has a linked chat: the "send on Telegram" buttons appear only then. */
    suspend fun canSendTo(workerId: String): Boolean = token() != null && dao.chat(workerId) != null

    suspend fun chatOf(workerId: String): TgChatEntity? = dao.chat(workerId)

    /**
     * Sends already-signed CT Team messages to the worker's linked chat. A short update goes as chat messages (one per part);
     * a long one (more than [MAX_TEXT_PARTS] parts, or one part too long for a chat message) goes as ONE small text file.
     * Nothing here is secret-free: Telegram can read what is sent (it stays signed, so it cannot be forged).
     */
    suspend fun sendCodes(workerId: String, label: String, parts: List<String>, fullText: String, actor: String): TgSendReport {
        if (parts.isEmpty()) return TgSendReport(false, "There is nothing to send.", 0, 0)
        val t = token() ?: return TgSendReport(false, "No Telegram bot is connected. Connect one in Manager > Telegram.", 0, parts.size)
        val chat = dao.chat(workerId)
            ?: return TgSendReport(false, "No Telegram chat is linked to this worker yet. A chat is linked after the worker sends you one new signed message through the bot.", 0, parts.size)
        val name = db.workerDao().get(workerId)?.fullName() ?: "the worker"
        val client = TelegramClient(t)
        val asFile = parts.size > MAX_TEXT_PARTS || parts.any { it.length > MAX_TEXT_LENGTH }
        val total = if (asFile) 1 else parts.size
        var sent = 0
        var error: String? = null

        if (asFile) {
            val bytes = fullText.toByteArray(Charsets.UTF_8)
            val r = sendWithRetry { client.sendDocument(chat.chatId, "ct-" + fileSlug(label) + ".txt", bytes, "CT Team: $label. Open the file, tap Share, then choose CT Team.") }
            if (r is TgResult.Err) error = sendFriendly(r) else sent = 1
        } else {
            for ((i, p) in parts.withIndex()) {
                val text = "CT Team: " + label + (if (parts.size > 1) " (" + (i + 1) + " of " + parts.size + ")" else "") + "\n" + p
                val r = sendWithRetry { client.sendMessage(chat.chatId, text) }
                if (r is TgResult.Err) { error = sendFriendly(r); break }
                sent++
                if (i < parts.size - 1) delay(400)
            }
        }

        val ok = error == null
        audit.log(actor, if (ok) "TG_SENT" else "TG_SEND_FAILED", "worker", workerId, label + ": " + sent + "/" + total + (if (asFile) " as a file" else ""))
        log(
            chat.chatId, workerId, if (ok) TgKind.SENT else TgKind.SEND_FAIL,
            (if (ok) "Sent to " else "Not sent to ") + name + ": " + label,
            if (ok) total.toString() + (if (asFile) " file." else " Telegram message(s).") else (error ?: "")
        )
        val message = when {
            ok -> "Sent to $name on Telegram: $label."
            sent > 0 -> "Only $sent of $total parts reached $name: $error"
            else -> "Not sent: $error"
        }
        return TgSendReport(ok, message, sent, total)
    }

    /** Short helper for a single code (reset code, join code). */
    suspend fun sendSingle(workerId: String, label: String, code: String, actor: String): TgSendReport =
        sendCodes(workerId, label, listOf(code), code, actor)

    /**
     * Makes the manager's update for one worker and sends it. The chat and bot are checked BEFORE anything is made, and if nothing
     * at all was delivered the new items are taken back, so "new only" offers them again after the problem is fixed.
     */
    suspend fun sendUpdate(workerId: String, everything: Boolean, actor: String): TgSendReport {
        if (token() == null) return TgSendReport(false, "No Telegram bot is connected. Connect one in Manager > Telegram.", 0, 0)
        if (dao.chat(workerId) == null) return TgSendReport(false, "No Telegram chat is linked to this worker yet.", 0, 0)
        val made = when (val m = sync.makeUpdate(workerId, everything)) {
            is Outcome.Err -> return TgSendReport(false, m.message, 0, 0)
            is Outcome.Ok -> m.value
        }
        val rep = sendCodes(workerId, "update", made.parts.map { it.text }, made.fullText, actor)
        if (rep.ok) return rep
        if (rep.sentParts == 0) {
            sync.rollbackUpdate(workerId, made)
            return rep
        }
        return TgSendReport(
            false,
            rep.message + " Tap SEND EVERYTHING AGAIN to send all of it once more; messages the worker already received are ignored by their app.",
            rep.sentParts, rep.totalParts
        )
    }

    /** One tap for everyone: every worker with a linked chat who has something new gets an update. */
    suspend fun sendAllPending(actor: String): List<TgBulkLine> {
        val out = ArrayList<TgBulkLine>()
        if (token() == null) return out
        for (c in dao.allChats()) {
            val w = db.workerDao().get(c.workerId) ?: continue
            if (sync.pendingUpdateCount(c.workerId) <= 0) continue
            out.add(TgBulkLine(w.fullName(), sendUpdate(c.workerId, false, actor)))
            delay(400)
        }
        return out
    }

    /** Piece 9B-3: the same announcement, signed separately for every worker who has a linked chat. */
    suspend fun sendAnnouncement(text: String, actor: String, uv: Int = 0, un: String = "", ul: String = ""): List<TgBulkLine> {
        val out = ArrayList<TgBulkLine>()
        if (token() == null) return out
        for (c in dao.allChats()) {
            val w = db.workerDao().get(c.workerId) ?: continue
            val made = sync.makeNotice(c.workerId, text, actor, uv, un, ul)
            val rep = when (made) {
                is Outcome.Err -> TgSendReport(false, made.message, 0, 0)
                is Outcome.Ok -> {
                    val r = sendSingle(c.workerId, "announcement", made.value.first, actor)
                    if (!r.ok && r.sentParts == 0) sync.releaseSeq(c.workerId, made.value.second)
                    r
                }
            }
            out.add(TgBulkLine(w.fullName(), rep))
            delay(400)
        }
        return out
    }

    /**
     * Piece 10B: sends the SAVED state of one lesson to every linked chat (published = show it, hidden or draft = take it back).
     * Signed separately per worker; a message number is handed back if nothing at all reached that chat.
     */
    suspend fun sendLesson(lessonId: String, actor: String): List<TgBulkLine> {
        val out = ArrayList<TgBulkLine>()
        if (token() == null) return out
        val title = db.contentDao().learn(lessonId)?.title ?: "lesson"
        for (c in dao.allChats()) {
            val w = db.workerDao().get(c.workerId) ?: continue
            val made = sync.makeLearn(c.workerId, lessonId, actor)
            val rep = when (made) {
                is Outcome.Err -> TgSendReport(false, made.message, 0, 0)
                is Outcome.Ok -> {
                    val r = sendSingle(c.workerId, "lesson: " + title.take(30), made.value.first, actor)
                    if (!r.ok && r.sentParts == 0) sync.releaseSeq(c.workerId, made.value.second)
                    r
                }
            }
            out.add(TgBulkLine(w.fullName(), rep))
            delay(400)
        }
        return out
    }

    /** Piece 9D-2: signs the manager's reply and sends it to the worker's chat. It joins the thread only if it really went out. */
    suspend fun sendSupportReply(workerId: String, text: String, actor: String): TgSendReport {
        if (token() == null) return TgSendReport(false, "No Telegram bot is connected.", 0, 0)
        if (dao.chat(workerId) == null) return TgSendReport(false, "No Telegram chat is linked to this worker yet.", 0, 0)
        val made = when (val m = sync.makeSupportReply(workerId, text, actor)) {
            is Outcome.Err -> return TgSendReport(false, m.message, 0, 0)
            is Outcome.Ok -> m.value
        }
        val rep = sendSingle(workerId, "reply from the manager", made.code, actor)
        if (rep.ok) sync.saveSupportReply(workerId, made, text)
        else if (rep.sentParts == 0) sync.releaseSeq(workerId, made.seq)
        return rep
    }

    /**
     * Approves a worker's reset request kept in the Telegram inbox and sends the one-time code back in the same chat.
     * The request number is used up by the approval, so if Telegram fails the code is handed back for sending another way.
     */
    suspend fun approveResetAndSend(inboxId: Long, actor: String): TgResetResult {
        val row = dao.inbox(inboxId) ?: return TgResetResult(false, "That item is gone.", null)
        val wire = row.wire
        val workerId = row.workerId
        if (row.kind != TgKind.RESET_REQ || wire == null || workerId == null) return TgResetResult(false, "This item is not a reset request any more.", null)
        val code = when (val r = sync.approveReset(wire, actor)) {
            is Outcome.Err -> { dao.setInboxState(row.id, TgState.DONE, now()); return TgResetResult(false, r.message, null) }
            is Outcome.Ok -> r.value
        }
        dao.setInboxState(row.id, TgState.DONE, now())
        val rep = sendSingle(workerId, "reset code", code, actor)
        return if (rep.ok) TgResetResult(true, rep.message + " They copy it, open the app and tap USE IT.", null)
        else TgResetResult(false, rep.message + " The reset code was copied; send it another way.", code)
    }

    // ---------------------------------------------------------------- for the screen

    fun observeChats(): Flow<List<TgChatEntity>> = dao.observeChats()
    fun observeInbox(limit: Int): Flow<List<TgInboxEntity>> = dao.observeInbox(limit)
    fun observePendingCount(): Flow<Int> = dao.observePendingCount()

    /** The manager opened the item in Sync (or dismissed it). The signed text is dropped from the inbox. */
    suspend fun markHandled(rowId: Long): String? {
        val row = dao.inbox(rowId) ?: return null
        dao.setInboxState(rowId, TgState.DONE, now())
        return row.wire
    }
}
