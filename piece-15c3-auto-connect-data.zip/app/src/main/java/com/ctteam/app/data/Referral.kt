package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.security.SecureRandom
import java.util.UUID

/**
 * Piece R1 — referral rewards: data and rules (manager phone is the authority).
 *
 * Rules decided with the owner's idea ("refer workers, get status and points; points can become money or gifts; status = easier access"):
 *  - Every connected worker has ONE referral code (CT-XXXXX). A new worker types it once; each worker has at most ONE referrer.
 *  - A referral only counts when the referred worker has real, APPROVED work (default 3 approved submissions). Signing up alone earns nothing.
 *  - The manager looks at each ready referral and taps AWARD. Points are added to an append-only ledger, once per referred worker.
 *  - Single level only: points come only from workers you referred yourself, never from their referrals (no chains).
 *  - STATUS comes from how many referrals were awarded (Member, Connector, Builder, Leader, Champion). Spending points does not lower it.
 *  - Points become money or gifts only when the manager approves (piece R5). The UGX per point is typed by the manager.
 */
object RefStatus { const val PENDING = "PENDING"; const val AWARDED = "AWARDED"; const val REJECTED = "REJECTED" }
object PointsKind { const val REFERRAL = "REFERRAL"; const val BONUS = "BONUS"; const val ADJUST = "ADJUST"; const val REDEEM = "REDEEM" }

@Entity(tableName = "referral_codes", indices = [Index(value = ["code"], unique = true)])
data class ReferralCodeEntity(
    @PrimaryKey val workerId: String,
    val code: String,
    val createdAt: Long
)

@Entity(tableName = "referrals", indices = [Index("referrerId")])
data class ReferralEntity(
    @PrimaryKey val referredId: String,   // one referrer per worker
    val referrerId: String,
    val code: String,
    val createdAt: Long,
    val status: String,                   // RefStatus
    val decidedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "points_ledger", indices = [Index(value = ["workerId", "kind", "refKey"], unique = true), Index("workerId")])
data class PointsEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val points: Int,                      // signed: + earned, - spent or removed
    val kind: String,                     // PointsKind
    val refKey: String,                   // referred worker id for REFERRAL, a random id for the others (unique per kind)
    val note: String,
    val actor: String,
    val createdAt: Long
)

@Dao
interface ReferralDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putCode(c: ReferralCodeEntity)
    @Query("SELECT * FROM referral_codes WHERE workerId = :w") suspend fun codeOf(w: String): ReferralCodeEntity?
    @Query("SELECT * FROM referral_codes WHERE code = :code LIMIT 1") suspend fun byCode(code: String): ReferralCodeEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putReferral(r: ReferralEntity)
    @Query("SELECT * FROM referrals WHERE referredId = :id") suspend fun referral(id: String): ReferralEntity?
    @Query("SELECT * FROM referrals ORDER BY createdAt DESC") fun observeReferrals(): Flow<List<ReferralEntity>>
    @Query("SELECT * FROM referrals WHERE referrerId = :w ORDER BY createdAt DESC") suspend fun referralsBy(w: String): List<ReferralEntity>
    @Query("UPDATE referrals SET status = :status, decidedAt = :at, note = :note WHERE referredId = :id") suspend fun decide(id: String, status: String, at: Long, note: String)
    @Query("SELECT COUNT(*) FROM referrals WHERE referrerId = :w AND status = 'AWARDED'") suspend fun awardedCount(w: String): Int
    // how many referrals came BEFORE this one (rejected ones do not count; same instant: the smaller worker id counts as earlier)
    @Query("SELECT COUNT(*) FROM referrals WHERE status != 'REJECTED' AND (createdAt < :at OR (createdAt = :at AND referredId < :id))")
    suspend fun earlierInTeam(at: Long, id: String): Int
    @Query("SELECT COUNT(*) FROM referrals WHERE referrerId = :w AND status != 'REJECTED' AND (createdAt < :at OR (createdAt = :at AND referredId < :id))")
    suspend fun earlierOfWorker(w: String, at: Long, id: String): Int

    @Query("SELECT COUNT(*) FROM submissions WHERE workerId = :w AND status = 'APPROVED' AND superseded = 0") suspend fun approvedOf(w: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun addPoints(e: PointsEntryEntity): Long
    @Query("SELECT COALESCE(SUM(points), 0) FROM points_ledger WHERE workerId = :w") suspend fun balanceOf(w: String): Int
    @Query("SELECT COALESCE(SUM(points), 0) FROM points_ledger WHERE workerId = :w") fun observeBalance(w: String): Flow<Int>
    @Query("SELECT * FROM points_ledger WHERE workerId = :w ORDER BY id DESC LIMIT :limit") suspend fun entriesOf(w: String, limit: Int): List<PointsEntryEntity>
    @Query("SELECT * FROM points_ledger ORDER BY id DESC LIMIT :limit") fun observeEntries(limit: Int): Flow<List<PointsEntryEntity>>
    @Query("SELECT workerId, COALESCE(SUM(points), 0) AS total FROM points_ledger GROUP BY workerId") fun observeBalances(): Flow<List<PointsBalance>>
}

class PointsBalance(val workerId: String, val total: Int)

/** Pure rules, kept apart from the database so they are easy to check. */
object ReferralRules {
    class Tier(val name: String, val minAwarded: Int, val perk: String)

    val TIERS: List<Tier> = listOf(
        Tier("Member", 0, "Every task you are allowed to see"),
        Tier("Connector", 1, "A first referral was awarded"),
        Tier("Builder", 3, "Eligible for tasks that need Builder status"),
        Tier("Leader", 7, "Eligible for tasks that need Leader status"),
        Tier("Champion", 15, "Eligible for tasks that need Champion status")
    )

    const val DEFAULT_POINTS = 100        // per awarded referral
    const val DEFAULT_NEED_APPROVED = 3   // approved submissions the referred worker needs
    const val DEFAULT_UGX_PER_POINT = 50L // only used when the manager approves a points-to-money request

    /** Defaults for the four thresholds (Connector, Builder, Leader, Champion). The main manager can change them. */
    val DEFAULT_THRESHOLDS: List<Int> = listOf(1, 3, 7, 15)

    /** [mins] = the four thresholds, strictly increasing and at least 1. Member always starts at 0. */
    fun tierOf(awarded: Int, mins: List<Int> = DEFAULT_THRESHOLDS): Tier {
        var idx = 0
        for (i in mins.indices) if (awarded >= mins[i]) idx = i + 1
        return TIERS[idx]
    }
    fun thresholdFor(index: Int, mins: List<Int> = DEFAULT_THRESHOLDS): Int = if (index <= 0) 0 else mins[index - 1]
    fun nextTier(awarded: Int, mins: List<Int> = DEFAULT_THRESHOLDS): Tier? {
        val cur = TIERS.indexOf(tierOf(awarded, mins))
        return if (cur + 1 < TIERS.size) TIERS[cur + 1] else null
    }
    fun rankOf(name: String): Int = TIERS.indexOfFirst { it.name.equals(name, ignoreCase = true) }.coerceAtLeast(0)
    fun thresholdsOk(mins: List<Int>): Boolean = mins.size == 4 && mins[0] >= 1 && (1 until 4).all { mins[it] > mins[it - 1] } && mins[3] <= 1000

    const val DEFAULT_RATE_PERMILLE = 50   // each earlier referral lowers the next one by 5.0 %
    const val DEFAULT_FLOOR = 10           // a referral never pays less than this many points
    const val SCOPE_TEAM = "TEAM"          // count every referral of the whole team (early referrers of the TEAM earn most)
    const val SCOPE_WORKER = "WORKER"      // count only the referrer's own referrals (each worker's first ones earn most)

    /**
     * Points for the referral that has [earlier] referrals before it: base x (1 - rate)^earlier, rounded, never below [floor]
     * and never above [base]. Whole-number rounding: floor(x + 0.5).
     */
    fun pointsFor(base: Int, ratePermille: Int, floor: Int, earlier: Int): Int {
        val raw = Math.floor(base * Math.pow((1000 - ratePermille) / 1000.0, earlier.toDouble()) + 0.5).toInt()
        return raw.coerceAtMost(base).coerceAtLeast(if (floor < base) floor else base)
    }
    fun isReady(approved: Int, need: Int): Boolean = approved >= need
    fun ugxFor(points: Int, ugxPerPoint: Long): Long = points.toLong() * ugxPerPoint

    /** Code alphabet has no 0/O/1/I/L so a code read out over the phone is not mistaken. */
    const val ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
    const val CODE_LEN = 5

    /** "ct-abcde", "CTABCDE", " CT ABCDE " all become "CT-ABCDE"; anything else is returned as typed (it simply will not match). */
    fun normalizeCode(raw: String): String {
        val s = raw.uppercase().filter { it.isLetterOrDigit() }
        return if (s.length == 2 + CODE_LEN && s.startsWith("CT")) "CT-" + s.substring(2) else s
    }
}

/** One line of the manager's referral list. */
class ReferralLine(
    val referral: ReferralEntity, val referrerName: String, val referredName: String,
    val approved: Int, val need: Int, val points: Int
) {
    val ready: Boolean get() = referral.status == RefStatus.PENDING && ReferralRules.isReady(approved, need)
}

class ReferralRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.referralDao()
    private val meta = db.metaDao()
    private val random = SecureRandom()

    companion object {
        const val KEY_POINTS = "ref:pts"
        const val KEY_NEED = "ref:need"
        const val KEY_UGX = "ref:ugxpp"
        const val KEY_RATE = "ref:rate"       // reduction per earlier referral, in tenths of a percent
        const val KEY_FLOOR = "ref:floor"     // minimum points per referral
        const val KEY_SCOPE = "ref:scope"     // TEAM or WORKER
        const val KEY_TIERS = "ref:tiers"     // "1,3,7,15"
        const val NOTE_MIN = 5
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- settings (manager types them; every change is audited)

    /** Everything the main manager can tune. */
    class RefSettings(
        val points: Int, val need: Int, val ugxPerPoint: Long,
        val ratePermille: Int, val floor: Int, val scope: String, val thresholds: List<Int>
    )

    suspend fun settings(): RefSettings {
        val th = meta.get(KEY_TIERS)?.split(",")?.mapNotNull { it.trim().toIntOrNull() }?.takeIf { ReferralRules.thresholdsOk(it) } ?: ReferralRules.DEFAULT_THRESHOLDS
        val points = meta.get(KEY_POINTS)?.toIntOrNull()?.takeIf { it in 1..100000 } ?: ReferralRules.DEFAULT_POINTS
        return RefSettings(
            points = points,
            need = meta.get(KEY_NEED)?.toIntOrNull()?.takeIf { it in 1..100 } ?: ReferralRules.DEFAULT_NEED_APPROVED,
            ugxPerPoint = meta.get(KEY_UGX)?.toLongOrNull()?.takeIf { it in 0..1_000_000 } ?: ReferralRules.DEFAULT_UGX_PER_POINT,
            ratePermille = meta.get(KEY_RATE)?.toIntOrNull()?.takeIf { it in 0..500 } ?: ReferralRules.DEFAULT_RATE_PERMILLE,
            floor = (meta.get(KEY_FLOOR)?.toIntOrNull()?.takeIf { it in 0..100000 } ?: ReferralRules.DEFAULT_FLOOR).coerceAtMost(points),
            scope = meta.get(KEY_SCOPE)?.takeIf { it == ReferralRules.SCOPE_WORKER } ?: ReferralRules.SCOPE_TEAM,
            thresholds = th
        )
    }

    suspend fun pointsPerAward(): Int = settings().points
    suspend fun needApproved(): Int = settings().need
    suspend fun ugxPerPoint(): Long = settings().ugxPerPoint
    suspend fun thresholds(): List<Int> = settings().thresholds

    /** ONLY the main manager can change the rules ([byMain] must be true; the screen passes the signed-in manager's flag). Every change is audited. */
    suspend fun saveSettings(s: RefSettings, byMain: Boolean, actor: String): Outcome<Unit> {
        if (!byMain) return Outcome.Err("Only the main manager can change the referral rules.")
        if (s.points !in 1..100000) return Outcome.Err("Points for the first referral must be between 1 and 100000.")
        if (s.need !in 1..100) return Outcome.Err("Approved submissions needed must be between 1 and 100.")
        if (s.ugxPerPoint !in 0..1_000_000) return Outcome.Err("UGX per point must be between 0 and 1,000,000.")
        if (s.ratePermille !in 0..500) return Outcome.Err("The reduction must be between 0 % and 50 % per referral.")
        if (s.floor !in 0..s.points) return Outcome.Err("The minimum points per referral must be between 0 and the first-referral points.")
        if (!ReferralRules.thresholdsOk(s.thresholds)) return Outcome.Err("Status thresholds must start at 1 or more and go up each step (for example 1, 3, 7, 15).")
        meta.put(MetaEntity(KEY_POINTS, s.points.toString()))
        meta.put(MetaEntity(KEY_NEED, s.need.toString()))
        meta.put(MetaEntity(KEY_UGX, s.ugxPerPoint.toString()))
        meta.put(MetaEntity(KEY_RATE, s.ratePermille.toString()))
        meta.put(MetaEntity(KEY_FLOOR, s.floor.toString()))
        meta.put(MetaEntity(KEY_SCOPE, s.scope))
        meta.put(MetaEntity(KEY_TIERS, s.thresholds.joinToString(",")))
        audit.log(
            actor, "REFERRAL_SETTINGS", "settings", "referral",
            "points=${s.points} need=${s.need} ugxPerPoint=${s.ugxPerPoint} reductionPermille=${s.ratePermille} floor=${s.floor} scope=${s.scope} tiers=${s.thresholds.joinToString("/")}"
        )
        return Outcome.Ok(Unit)
    }

    /** What the referral would pay if it were awarded now (fixed by its place in line, not by when the manager taps AWARD). */
    suspend fun pointsForReferral(r: ReferralEntity, st: RefSettings? = null): Int {
        val set = st ?: settings()
        val earlier = if (set.scope == ReferralRules.SCOPE_WORKER) dao.earlierOfWorker(r.referrerId, r.createdAt, r.referredId)
        else dao.earlierInTeam(r.createdAt, r.referredId)
        return ReferralRules.pointsFor(set.points, set.ratePermille, set.floor, earlier)
    }

    // ---------------------------------------------------------------- codes

    private fun newCode(): String {
        val sb = StringBuilder("CT-")
        repeat(ReferralRules.CODE_LEN) { sb.append(ReferralRules.ALPHABET[random.nextInt(ReferralRules.ALPHABET.length)]) }
        return sb.toString()
    }

    /** The worker's code; made the first time it is asked for. Never changes afterwards. */
    suspend fun codeFor(workerId: String): String = db.withTransaction {
        dao.codeOf(workerId)?.code ?: run {
            var c = newCode()
            while (dao.byCode(c) != null) c = newCode()
            dao.putCode(ReferralCodeEntity(workerId, c, now()))
            c
        }
    }

    // ---------------------------------------------------------------- linking

    /**
     * Records that [referredId] used someone's code. Refused: unknown code, your own code, a second referrer, or anything that
     * would make a circle (A refers B, B refers C, C refers A). Nothing is paid here; the referral waits for real approved work.
     */
    suspend fun link(referredId: String, rawCode: String, actor: String): Outcome<Unit> {
        val referred = db.workerDao().get(referredId) ?: return Outcome.Err("That worker was not found.")
        val code = ReferralRules.normalizeCode(rawCode)
        val owner = dao.byCode(code) ?: return Outcome.Err("This code is not known. Check it and try again.")
        if (owner.workerId == referredId) return Outcome.Err("A worker cannot use their own code.")
        if (dao.referral(referredId) != null) return Outcome.Err(referred.fullName() + " already has a referrer. It cannot be changed.")
        // walk up from the referrer: if we meet the referred worker, it would be a circle
        var up: String? = owner.workerId
        var steps = 0
        while (up != null && steps < 20) {
            if (up == referredId) return Outcome.Err("This would make a circle of referrals.")
            up = dao.referral(up)?.referrerId
            steps++
        }
        dao.putReferral(ReferralEntity(referredId, owner.workerId, code, now(), RefStatus.PENDING))
        audit.log(actor, "REFERRAL_LINKED", "worker", referredId, "referrer=" + owner.workerId + " code=" + code)
        return Outcome.Ok(Unit)
    }

    suspend fun lines(): List<ReferralLine> {
        val st = settings()
        val names = db.workerDao().all().associate { it.id to it.fullName() }
        return allReferrals().map { r ->
            ReferralLine(r, names[r.referrerId] ?: "Unknown", names[r.referredId] ?: "Unknown", dao.approvedOf(r.referredId), st.need, pointsForReferral(r, st))
        }
    }

    private suspend fun allReferrals(): List<ReferralEntity> {
        val out = ArrayList<ReferralEntity>()
        for (w in db.workerDao().all()) out.addAll(dao.referralsBy(w.id))
        return out.sortedByDescending { it.createdAt }
    }

    // ---------------------------------------------------------------- awarding

    /** The manager's tap. Needs the referred worker to have enough APPROVED work. Once per referred worker (the ledger refuses a second). */
    suspend fun award(referredId: String, actor: String): Outcome<Int> = db.withTransaction {
        val r = dao.referral(referredId) ?: return@withTransaction Outcome.Err("No referral found for this worker.")
        if (r.status != RefStatus.PENDING) return@withTransaction Outcome.Err("This referral was already decided (" + r.status.lowercase() + ").")
        if (AutoConnect.isUnverified(db, referredId) || AutoConnect.isUnverified(db, r.referrerId)) return@withTransaction Outcome.Err(AutoConnect.BLOCK_TEXT)
        val st = settings()
        val approved = dao.approvedOf(referredId)
        if (!ReferralRules.isReady(approved, st.need)) return@withTransaction Outcome.Err("Not ready: $approved of ${st.need} approved submissions.")
        val pts = pointsForReferral(r, st)
        val name = db.workerDao().get(referredId)?.fullName() ?: "a worker"
        val tag = if (st.ratePermille > 0) " (worth $pts of ${st.points} points because of its place in line)" else ""
        dao.addPoints(PointsEntryEntity(workerId = r.referrerId, points = pts, kind = PointsKind.REFERRAL, refKey = referredId, note = "Referral: $name$tag", actor = actor, createdAt = now()))
        dao.decide(referredId, RefStatus.AWARDED, now(), "")
        audit.log(actor, "REFERRAL_AWARDED", "worker", r.referrerId, "referred=$referredId points=$pts base=${st.points} reductionPermille=${st.ratePermille} scope=${st.scope}")
        Outcome.Ok(pts)
    }

    suspend fun reject(referredId: String, note: String, actor: String): Outcome<Unit> {
        val r = dao.referral(referredId) ?: return Outcome.Err("No referral found for this worker.")
        if (r.status != RefStatus.PENDING) return Outcome.Err("This referral was already decided.")
        if (note.trim().length < NOTE_MIN) return Outcome.Err("Write a reason (at least $NOTE_MIN characters).")
        dao.decide(referredId, RefStatus.REJECTED, now(), note.trim())
        audit.log(actor, "REFERRAL_REJECTED", "worker", r.referrerId, "referred=$referredId note=" + note.trim())
        return Outcome.Ok(Unit)
    }

    // ---------------------------------------------------------------- points and status

    suspend fun balance(workerId: String): Int = dao.balanceOf(workerId)
    suspend fun awardedCount(workerId: String): Int = dao.awardedCount(workerId)
    suspend fun statusOf(workerId: String): ReferralRules.Tier = ReferralRules.tierOf(dao.awardedCount(workerId), thresholds())

    /** Manual points: a positive BONUS (for example a campaign) or a negative ADJUST (a correction). A reason is required and audited. */
    suspend fun adjust(workerId: String, points: Int, note: String, actor: String): Outcome<Unit> = db.withTransaction {
        if (points == 0 || points < -100000 || points > 100000) return@withTransaction Outcome.Err("Enter points between -100000 and 100000 (not 0).")
        if (note.trim().length < NOTE_MIN) return@withTransaction Outcome.Err("Write a reason (at least $NOTE_MIN characters).")
        if (db.workerDao().get(workerId) == null) return@withTransaction Outcome.Err("That worker was not found.")
        if (points < 0 && dao.balanceOf(workerId) + points < 0) return@withTransaction Outcome.Err("That would take the balance below zero.")
        val kind = if (points > 0) PointsKind.BONUS else PointsKind.ADJUST
        dao.addPoints(PointsEntryEntity(workerId = workerId, points = points, kind = kind, refKey = UUID.randomUUID().toString(), note = note.trim(), actor = actor, createdAt = now()))
        audit.log(actor, "POINTS_" + kind, "worker", workerId, "points=$points note=" + note.trim())
        Outcome.Ok(Unit)
    }

    fun observeReferrals(): Flow<List<ReferralEntity>> = dao.observeReferrals()
    fun observeBalances(): Flow<List<PointsBalance>> = dao.observeBalances()
    fun observeEntries(limit: Int): Flow<List<PointsEntryEntity>> = dao.observeEntries(limit)
}
