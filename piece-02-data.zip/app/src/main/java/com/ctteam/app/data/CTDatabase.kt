package com.ctteam.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

/**
 * RULES (so app updates never wipe data):
 *  - Never rename the database file (NAME) or use fallbackToDestructiveMigration().
 *  - Any change to an @Entity => raise `version` by 1 AND add a Migration in Migrations.kt.
 */
@Database(
    entities = [
        WorkerEntity::class, PhoneHistoryEntity::class,
        TaskEntity::class, TaskVersionEntity::class,
        SubmissionEntity::class, ProofEntity::class,
        PayoutRequestEntity::class, PaymentEntity::class,
        NcStatementEntity::class, NcRowEntity::class, NcClaimEntity::class,
        SupportMessageEntity::class, AnnouncementEntity::class, LearnContentEntity::class,
        AuditEntity::class, EventEntity::class, MetaEntity::class, ManagerEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class CTDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun taskDao(): TaskDao
    abstract fun submissionDao(): SubmissionDao
    abstract fun payoutDao(): PayoutDao
    abstract fun ncDao(): NcDao
    abstract fun supportDao(): SupportDao
    abstract fun contentDao(): ContentDao
    abstract fun auditDao(): AuditDao
    abstract fun eventDao(): EventDao
    abstract fun metaDao(): MetaDao
    abstract fun managerDao(): ManagerDao

    companion object {
        const val NAME = "ctteam.db"

        fun build(context: Context): CTDatabase =
            Room.databaseBuilder(context.applicationContext, CTDatabase::class.java, NAME)
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

/** Add one Migration per schema version bump, e.g. MIGRATION_1_2. Never delete old ones. */
object Migrations {
    val ALL: Array<Migration> = arrayOf()
}
