package com.ctteam.app.data

import android.content.Context

/** One place to get the database and all repositories: ServiceLocator.get(context). */
class Repos(val db: CTDatabase) {
    val audit = AuditRepository(db)
    val workers = WorkerRepository(db, audit)
    val tasks = TaskRepository(db, audit)
    val submissions = SubmissionRepository(db, audit)
    val payouts = PayoutRepository(db, audit)
    val manager = ManagerRepository(db, audit)
}

object ServiceLocator {
    @Volatile private var instance: Repos? = null

    fun get(context: Context): Repos =
        instance ?: synchronized(this) {
            instance ?: Repos(CTDatabase.build(context)).also { instance = it }
        }
}
