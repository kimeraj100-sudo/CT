package com.ctteam.app.data

import java.security.MessageDigest
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.temporal.TemporalAdjusters

object Hashing {
    fun sha256Hex(text: String): String = sha256Hex(text.toByteArray(Charsets.UTF_8))
    fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}

/** All times are stored as UTC epoch millis. Day/week keys use East Africa Time (UTC+3). */
object TimeUtil {
    val EAT: ZoneId = ZoneOffset.ofHours(3)
    const val WEEK_MS: Long = 7L * 24 * 60 * 60 * 1000

    fun dayKey(millis: Long): String =
        Instant.ofEpochMilli(millis).atZone(EAT).toLocalDate().toString()

    /** Payout weeks run Monday -> Sunday. The key is the Monday's date. */
    fun weekKey(millis: Long): String =
        Instant.ofEpochMilli(millis).atZone(EAT).toLocalDate()
            .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()
}

data class UgPhone(val digits: String, val network: String) {
    /** Local display format, e.g. 0772123456 */
    val national: String get() = "0" + digits.substring(3)
}

object PhoneUtil {
    private val MTN = setOf("77", "78", "76", "39")
    private val AIRTEL = setOf("70", "75", "74", "20")

    /** 0772123456, 256772123456 and +256772123456 all become 256772123456. Null if not a valid shape. */
    fun normalize(raw: String): String? {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00256")) d = d.substring(2)
        d = when {
            d.startsWith("256") && d.length == 12 -> d
            d.startsWith("0") && d.length == 10 -> "256" + d.substring(1)
            d.length == 9 -> "256$d"
            else -> return null
        }
        return d
    }

    fun networkOf(normalized: String): String? {
        val prefix = normalized.substring(3, 5)
        return when {
            prefix in MTN -> "MTN"
            prefix in AIRTEL -> "AIRTEL"
            else -> null
        }
    }

    /** Valid MTN/Airtel Uganda number, or null. */
    fun parse(raw: String): UgPhone? {
        val n = normalize(raw) ?: return null
        val net = networkOf(n) ?: return null
        return UgPhone(n, net)
    }
}

object NameUtil {
    /** Ignores case, spacing, punctuation and word order: "OKELLO john" == "John  Okello". */
    fun key(s: String): String =
        s.lowercase()
            .replace(Regex("[^\\p{L} ]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .sorted()
            .joinToString(" ")
}
