package com.ctteam.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * RULES (so app updates never wipe data):
 *  - Never rename the database file (NAME) or use fallbackToDestructiveMigration().
 *  - Any change to an @Entity => raise `version` by 1 AND add a Migration below.
 *
 * Version history:
 *  1 = piece 2 (all base tables)
 *  2 = piece 4A (manager_accounts: up to 20 managers with code names + PINs)
 *  3 = piece 4B (passwords + activation for managers; pin_ledger, device_trust, worker_credentials)
 *  4 = piece 5A (sync_keys, sync_seen: per-worker HMAC keys and replay protection)
 *  5 = piece 5B (sync_outbox: fixed message numbers for worker reports)
 *  6 = piece 5D (worker_usernames: one username per worker, unique across workers)
 *  7 = piece 5E (manager_rev: last signed manager code used per account)
 */
@Database(
    entities = [
        WorkerEntity::class, PhoneHistoryEntity::class,
        TaskEntity::class, TaskVersionEntity::class,
        SubmissionEntity::class, ProofEntity::class,
        PayoutRequestEntity::class, PaymentEntity::class,
        NcStatementEntity::class, NcRowEntity::class, NcClaimEntity::class,
        SupportMessageEntity::class, AnnouncementEntity::class, LearnContentEntity::class,
        AuditEntity::class, EventEntity::class, MetaEntity::class, ManagerEntity::class,
        ManagerAccountEntity::class,
        PinLedgerEntity::class, DeviceTrustEntity::class, WorkerCredentialEntity::class,
        SyncKeyEntity::class, SyncSeenEntity::class, SyncOutboxEntity::class, WorkerUsernameEntity::class,
        ManagerRevEntity::class
    ],
    version = 8,
    exportSchema = true
)
abstract class CTDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun taskDao(): TaskDao
    abstract fun submissionDao(): SubmissionDao
    abstract fun payoutDao(): PayoutDao
    abstract fun ncDao(): NcDao
    abstract fun supportDao(): SupportDao
    abstract fun contentDao(): ContentDao
    abstract fun auditDao(): AuditDao
    abstract fun eventDao(): EventDao
    abstract fun metaDao(): MetaDao
    abstract fun managerDao(): ManagerDao
    abstract fun managerSyncDao(): ManagerSyncDao
    abstract fun managerAccountDao(): ManagerAccountDao
    abstract fun securityDao(): SecurityDao
    abstract fun syncDao(): SyncDao

    companion object {
        const val NAME = "ctteam.db"

        fun build(context: Context): CTDatabase =
            Room.databaseBuilder(context.applicationContext, CTDatabase::class.java, NAME)
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

/** Add one Migration per schema version bump. Never delete old ones. */
object Migrations {
    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `manager_accounts` (" +
                    "`id` TEXT NOT NULL, `codeName` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, " +
                    "`pinHash` TEXT NOT NULL, `iterations` INTEGER NOT NULL, `isMain` INTEGER NOT NULL, " +
                    "`suspendedUntil` INTEGER, `accessExpiresAt` INTEGER, `note` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_manager_accounts_codeName` " +
                    "ON `manager_accounts` (`codeName`)"
            )
        }
    }

    /** Piece 4B: existing managers keep their PIN and become "not activated" (passHash null) until they create a password. */
    val MIGRATION_2_3: Migration = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passSalt` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passHash` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `credVersion` INTEGER NOT NULL DEFAULT 1")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `pin_ledger` (" +
                    "`fingerprint` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`fingerprint`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `device_trust` (" +
                    "`subjectId` TEXT NOT NULL, `kind` TEXT NOT NULL, `trustedAt` INTEGER NOT NULL, " +
                    "`credVersion` INTEGER NOT NULL, PRIMARY KEY(`subjectId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `worker_credentials` (" +
                    "`workerId` TEXT NOT NULL, `username` TEXT NOT NULL, `passSalt` TEXT NOT NULL, " +
                    "`passHash` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, `pinHash` TEXT NOT NULL, " +
                    "`iterations` INTEGER NOT NULL, `credVersion` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_worker_credentials_username` " +
                    "ON `worker_credentials` (`username`)"
            )
        }
    }

    /** Piece 5A: two new tables only; nothing existing is touched. */
    val MIGRATION_3_4: Migration = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_keys` (" +
                    "`workerId` TEXT NOT NULL, `keyHex` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_seen` (" +
                    "`workerId` TEXT NOT NULL, `direction` TEXT NOT NULL, `seq` INTEGER NOT NULL, " +
                    "`type` TEXT NOT NULL, `receivedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`, `direction`, `seq`))"
            )
        }
    }

    /** Piece 5B: one new table only; nothing existing is touched. */
    val MIGRATION_4_5: Migration = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_outbox` (" +
                    "`itemKey` TEXT NOT NULL, `workerId` TEXT NOT NULL, `type` TEXT NOT NULL, " +
                    "`seq` INTEGER NOT NULL, `madeAt` INTEGER NOT NULL, PRIMARY KEY(`itemKey`))"
            )
        }
    }

    /** Piece 5D: one new table only. */
    val MIGRATION_5_6: Migration = object : Migration(5, 6) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `worker_usernames` (" +
                    "`username` TEXT NOT NULL, `workerId` TEXT NOT NULL, PRIMARY KEY(`username`))"
            )
        }
    }

    /** Piece 5E: one new table only. */
    val MIGRATION_6_7: Migration = object : Migration(6, 7) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `manager_rev` (" +
                    "`accountId` TEXT NOT NULL, `rev` INTEGER NOT NULL, `removed` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`accountId`))"
            )
        }
    }

    /** Piece 8C: two nullable columns + a unique index on the claim id (existing rows keep NULL, which the index allows). */
    val MIGRATION_7_8: Migration = object : Migration(7, 8) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `nc_claims` ADD COLUMN `claimUid` TEXT")
            db.execSQL("ALTER TABLE `nc_claims` ADD COLUMN `taskId` TEXT")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_nc_claims_claimUid` ON `nc_claims` (`claimUid`)")
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
}
