package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkerDao {
    @Insert suspend fun insert(w: WorkerEntity)
    @Update suspend fun update(w: WorkerEntity)
    @Insert suspend fun insertPhone(h: PhoneHistoryEntity)

    @Query("SELECT * FROM workers WHERE id = :id") suspend fun get(id: String): WorkerEntity?
    @Query("SELECT * FROM workers WHERE nationalId = :nin LIMIT 1") suspend fun getByNationalId(nin: String): WorkerEntity?
    @Query("SELECT * FROM workers WHERE phone = :phone LIMIT 1") suspend fun getByPhone(phone: String): WorkerEntity?
    @Query("SELECT * FROM workers ORDER BY createdAt DESC") fun observeAll(): Flow<List<WorkerEntity>>
    @Query("SELECT * FROM workers ORDER BY createdAt DESC") suspend fun all(): List<WorkerEntity>
    @Query("SELECT COUNT(*) FROM workers") suspend fun countAll(): Int
    @Query("SELECT COUNT(*) FROM workers WHERE active = 1") suspend fun countActive(): Int
    @Query("SELECT * FROM phone_history WHERE workerId = :workerId ORDER BY changedAt DESC")
    suspend fun phoneHistory(workerId: String): List<PhoneHistoryEntity>
}

@Dao
interface TaskDao {
    @Insert suspend fun insert(t: TaskEntity)
    @Update suspend fun update(t: TaskEntity)
    @Insert suspend fun insertVersion(v: TaskVersionEntity)

    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun get(id: String): TaskEntity?
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun observeAll(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks WHERE active = 1 ORDER BY createdAt ASC") suspend fun activeTasks(): List<TaskEntity>
    @Query("SELECT * FROM task_versions WHERE taskId = :taskId ORDER BY version DESC")
    suspend fun versions(taskId: String): List<TaskVersionEntity>
}

@Dao
interface SubmissionDao {
    @Insert suspend fun insert(s: SubmissionEntity)
    @Update suspend fun update(s: SubmissionEntity)
    @Insert suspend fun insertProof(p: ProofEntity)

    // ---- Piece 6 (screenshot checks)
    @Update suspend fun updateProof(p: ProofEntity)
    @Query("SELECT * FROM proofs WHERE dhash IS NOT NULL AND submissionId != :sid") suspend fun proofsWithDhash(sid: String): List<ProofEntity>
    @Query("SELECT * FROM submissions WHERE status = 'PENDING' ORDER BY submittedAt ASC") suspend fun pendingNow(): List<SubmissionEntity>
    @Query("SELECT COUNT(DISTINCT p.submissionId) FROM proofs p INNER JOIN submissions s ON s.id = p.submissionId WHERE s.status = 'PENDING' AND p.verdict IN ('CHECK','DONT_TRUST')")
    suspend fun issuesCount(): Int

    @Query("SELECT * FROM submissions WHERE id = :id") suspend fun get(id: String): SubmissionEntity?
    @Query("SELECT * FROM submissions WHERE status = 'PENDING' ORDER BY submittedAt ASC")
    fun observePending(): Flow<List<SubmissionEntity>>
    @Query("SELECT * FROM submissions WHERE workerId = :workerId ORDER BY submittedAt DESC")
    fun observeForWorker(workerId: String): Flow<List<SubmissionEntity>>
    @Query("SELECT * FROM proofs WHERE submissionId = :submissionId ORDER BY id ASC")
    suspend fun proofsFor(submissionId: String): List<ProofEntity>
    @Query("SELECT * FROM proofs WHERE sha256 = :sha AND sha256 IS NOT NULL")
    suspend fun proofsBySha(sha: String): List<ProofEntity>

    @Query("SELECT COUNT(*) FROM submissions WHERE status = :status") suspend fun countByStatus(status: String): Int

    @Query("SELECT COUNT(*) FROM submissions WHERE workerId = :w AND taskId = :t AND dayKey = :day AND superseded = 0 AND status IN ('PENDING','APPROVED')")
    suspend fun countActiveForDay(w: String, t: String, day: String): Int
    @Query("SELECT COUNT(*) FROM submissions WHERE workerId = :w AND taskId = :t AND superseded = 0 AND status IN ('PENDING','APPROVED')")
    suspend fun countActiveEver(w: String, t: String): Int
    @Query("SELECT COALESCE(MAX(seq), 0) FROM submissions WHERE workerId = :w") suspend fun maxSeq(w: String): Long

    @Query("SELECT COALESCE(SUM(payUgx), 0) FROM submissions WHERE workerId = :w AND weekKey = :week AND status = 'APPROVED' AND payoutId IS NULL")
    suspend fun unpaidApprovedTotal(w: String, week: String): Long
    @Query("SELECT COALESCE(SUM(payUgx), 0) FROM submissions WHERE status = 'APPROVED' AND payoutId IS NULL")
    suspend fun allUnpaidApprovedTotal(): Long
    @Query("UPDATE submissions SET payoutId = :payoutId WHERE workerId = :w AND weekKey = :week AND status = 'APPROVED' AND payoutId IS NULL")
    suspend fun attachToPayout(w: String, week: String, payoutId: String)
    @Query("UPDATE submissions SET superseded = 1 WHERE workerId = :w AND taskId = :t AND status = 'APPROVED'")
    suspend fun supersedeApproved(w: String, t: String)
}

@Dao
interface PayoutDao {
    @Insert suspend fun insert(p: PayoutRequestEntity)
    @Update suspend fun update(p: PayoutRequestEntity)
    @Insert suspend fun insertPayment(p: PaymentEntity)

    @Query("SELECT * FROM payout_requests WHERE id = :id") suspend fun get(id: String): PayoutRequestEntity?
    @Query("SELECT * FROM payout_requests WHERE workerId = :w AND status = 'IN_PROGRESS' LIMIT 1")
    suspend fun inProgressFor(w: String): PayoutRequestEntity?
    @Query("SELECT * FROM payout_requests WHERE workerId = :w AND weekKey = :week LIMIT 1")
    suspend fun forWeek(w: String, week: String): PayoutRequestEntity?
    @Query("SELECT * FROM payout_requests WHERE workerId = :w ORDER BY requestedAt DESC")
    fun observeForWorker(w: String): Flow<List<PayoutRequestEntity>>
    @Query("SELECT * FROM payout_requests WHERE status = 'IN_PROGRESS' ORDER BY requestedAt ASC")
    fun observeInProgress(): Flow<List<PayoutRequestEntity>>
    @Query("SELECT COUNT(*) FROM payout_requests WHERE status = :status") suspend fun countByStatus(status: String): Int

    // ---- Piece 7 (payout archive + statement lines already used)
    @Query("SELECT * FROM payout_requests WHERE status = 'PAID' ORDER BY paidAt DESC")
    fun observePaid(): Flow<List<PayoutRequestEntity>>
    @Query("SELECT COUNT(*) FROM payments WHERE statementRef = :ref") suspend fun paymentRefCount(ref: String): Int
}

@Dao
interface NcDao {
    @Insert suspend fun insertStatement(s: NcStatementEntity): Long
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertRow(r: NcRowEntity): Long
    @Update suspend fun updateRow(r: NcRowEntity)
    @Insert suspend fun insertClaim(c: NcClaimEntity): Long
    @Update suspend fun updateClaim(c: NcClaimEntity)

    @Query("SELECT * FROM nc_statements WHERE fileSha256 = :sha LIMIT 1") suspend fun statementBySha(sha: String): NcStatementEntity?
    @Query("SELECT * FROM nc_rows WHERE matchedClaimId IS NULL AND coin = :coin ORDER BY occurredAtUtc ASC")
    suspend fun unmatchedRows(coin: String): List<NcRowEntity>
    @Query("SELECT * FROM nc_claims WHERE status = 'UNMATCHED' ORDER BY claimedAtUtc ASC")
    suspend fun unmatchedClaims(): List<NcClaimEntity>

    // ---- Piece 8B
    @Query("SELECT * FROM nc_statements ORDER BY importedAt DESC") fun observeStatements(): Flow<List<NcStatementEntity>>
    @Query("SELECT * FROM nc_rows ORDER BY occurredAtUtc DESC LIMIT :limit") fun observeRecentRows(limit: Int): Flow<List<NcRowEntity>>
    // ---- Piece 8C
    @Query("SELECT * FROM nc_claims WHERE claimUid = :uid LIMIT 1") suspend fun claimByUid(uid: String): NcClaimEntity?
    @Query("SELECT * FROM nc_claims WHERE workerId = :w ORDER BY claimedAtUtc DESC") fun observeClaimsOf(w: String): Flow<List<NcClaimEntity>>
    @Query("SELECT * FROM nc_claims WHERE workerId = :w ORDER BY createdAt ASC") suspend fun claimsOf(w: String): List<NcClaimEntity>
    @Query("SELECT COUNT(*) FROM nc_claims WHERE workerId = :w") suspend fun claimCountOf(w: String): Int
    @Query("SELECT * FROM nc_claims ORDER BY createdAt DESC LIMIT :limit") fun observeRecentClaims(limit: Int): Flow<List<NcClaimEntity>>
    @Query("SELECT COUNT(*) FROM nc_claims") fun observeClaimCount(): Flow<Int>
    @Query("DELETE FROM nc_claims WHERE id = :id") suspend fun deleteClaim(id: Long)
    @Query("SELECT COUNT(*) FROM nc_claims WHERE workerId = :w AND coin = :coin AND amountText = :amt AND claimedAtUtc = :at AND claimUid != :uid")
    suspend fun sameClaimCount(w: String, coin: String, amt: String, at: Long, uid: String): Int

    @Query("SELECT COUNT(*) FROM nc_rows") fun observeRowCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM nc_rows WHERE matchedClaimId IS NULL") fun observeUnmatchedRowCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM nc_rows WHERE matchedClaimId IS NULL") suspend fun unmatchedRowCount(): Int
    @Query("SELECT statementId AS statementId, COUNT(*) AS n FROM nc_rows GROUP BY statementId") fun observeAddedCounts(): Flow<List<StatementAdded>>
}

@Dao
interface SupportDao {
    @Insert suspend fun insert(m: SupportMessageEntity)
    @Query("SELECT * FROM support_messages WHERE workerId = :w ORDER BY createdAt ASC")
    fun observeThread(w: String): Flow<List<SupportMessageEntity>>
    @Query("SELECT COUNT(*) FROM support_messages WHERE direction = 'TO_MANAGER' AND readAt IS NULL")
    suspend fun unreadForManager(): Int
}

@Dao
interface ContentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAnnouncement(a: AnnouncementEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLearn(l: LearnContentEntity)
    @Query("SELECT * FROM announcements WHERE active = 1 ORDER BY createdAt DESC") fun observeAnnouncements(): Flow<List<AnnouncementEntity>>
    @Query("SELECT * FROM learn_content WHERE published = 1 ORDER BY updatedAt DESC") fun observeLearn(): Flow<List<LearnContentEntity>>
}

@Dao
interface AuditDao {
    @Insert suspend fun insert(a: AuditEntity)
    @Query("SELECT hash FROM audit_log ORDER BY id DESC LIMIT 1") suspend fun lastHash(): String?
    @Query("SELECT * FROM audit_log ORDER BY id ASC") suspend fun all(): List<AuditEntity>
    @Query("SELECT * FROM audit_log ORDER BY id DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<AuditEntity>>
}

@Dao
interface EventDao {
    @Insert suspend fun insert(e: EventEntity)
    @Query("SELECT * FROM events ORDER BY id DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<EventEntity>>
}

@Dao
interface MetaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(m: MetaEntity)
    @Query("SELECT value FROM meta WHERE `key` = :key") suspend fun get(key: String): String?
}

@Dao
interface ManagerDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(m: ManagerEntity)
    @Update suspend fun update(m: ManagerEntity)
    @Query("SELECT * FROM manager_identity WHERE id = 1") suspend fun get(): ManagerEntity?
}
