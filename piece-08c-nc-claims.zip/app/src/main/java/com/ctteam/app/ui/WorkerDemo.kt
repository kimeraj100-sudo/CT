package com.ctteam.app.ui

import com.ctteam.app.data.NcStatus
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TaskType
import com.ctteam.app.data.TimeUtil

/**
 * Demo worker (Piece 4C1).
 *
 * Typing "demo" in every sign-in field opens a pretend worker so the worker side can be seen without a real account.
 * The demo lives ONLY in memory: it never reads or writes the database, never creates a worker, audit entry, trust
 * record or payout, and it is not offered on the Manager side. Everything shown here is made up.
 */
object WorkerDemo {
    const val WORD = "demo"

    fun isDemoWord(text: String): Boolean = text.trim().equals(WORD, ignoreCase = true)

    /** True when username, password and PIN are all the word "demo". */
    fun isDemoLogin(username: String, password: String, pin: String): Boolean =
        isDemoWord(username) && isDemoWord(password) && isDemoWord(pin)

    private const val MIN = 60_000L
    private const val DAY = 24L * 60 * 60 * 1000

    /** Made-up history: four this week (2 approved, 1 pending, 1 rejected) and three paid ones from last week. */
    fun submissions(nowMs: Long): List<WSub> {
        fun sub(id: String, name: String, pay: Long, status: String, at: Long, note: String = "", paid: Boolean = false) = WSub(
            id = id, taskName = name, payUgx = pay, status = status, weekKey = TimeUtil.weekKey(at), submittedAt = at,
            decidedAt = if (status == SubStatus.PENDING) null else at + 20 * MIN, decisionNote = note,
            referenceText = "", explanation = "", inPayout = paid, superseded = false
        )
        return listOf(
            sub("demo-s1", "Daily survey", 1_000L, SubStatus.APPROVED, nowMs - 30 * MIN),
            sub("demo-s2", "Join the Telegram group", 1_000L, SubStatus.APPROVED, nowMs - 50 * MIN),
            sub("demo-s3", "Rate our app", 2_500L, SubStatus.PENDING, nowMs - 20 * MIN),
            sub("demo-s4", "Share promo video", 3_000L, SubStatus.REJECTED, nowMs - 70 * MIN, note = "The screenshot was cropped. Send the full screen."),
            sub("demo-s5", "Daily survey", 1_000L, SubStatus.APPROVED, nowMs - 7 * DAY, paid = true),
            sub("demo-s6", "Daily check-in post", 1_500L, SubStatus.APPROVED, nowMs - 7 * DAY - 60 * MIN, paid = true),
            sub("demo-s7", "Share promo video", 3_000L, SubStatus.APPROVED, nowMs - 7 * DAY - 120 * MIN, paid = true)
        )
    }

    /** Two made-up NC Wallet claims: one verified, one sent and waiting. */
    fun claims(nowMs: Long): List<WClaim> = listOf(
        WClaim("demo-c1", "BNB", "0.0125", nowMs - 2 * DAY, null, "", NcStatus.MATCHED, true),
        WClaim("demo-c2", "BNB", "0.0300", nowMs - 3 * 60 * MIN, null, "", NcStatus.UNMATCHED, true)
    )

    /** Made-up proof files for the demo submission detail screen. */
    fun proofsFor(submissionId: String): List<WProof> = listOf(
        WProof(
            kind = "SCREENSHOT", fileName = "Screenshot_demo.jpg", size = 412L * 1024, width = 1080, height = 2400,
            modifiedAt = System.currentTimeMillis() - 3_600_000L, mime = "image/jpeg",
            fingerprint = submissionId.padEnd(12, '0').take(12), text = ""
        )
    )

    /** Made-up payout history: last week's three approved tasks (1,000 + 1,500 + 3,000) were paid. */
    fun payouts(nowMs: Long): List<WPayout> = listOf(
        WPayout(
            id = "demo-p1", weekKey = TimeUtil.weekKey(nowMs - 7 * DAY), amountUgx = 5_500L, phone = "0772000000",
            network = "MTN", status = com.ctteam.app.data.PayoutStatus.PAID,
            requestedAt = nowMs - 5 * DAY, paidAt = nowMs - 5 * DAY + 3 * 60 * MIN
        )
    )

    fun homeData(nowMs: Long = System.currentTimeMillis()): WorkerHomeData = WorkerHomeData(
        firstName = "Amina",
        fullName = "Amina Demo Nakato",
        username = "demo",
        nationalId = "DEMO-NOT-REAL",
        payoutNumber = "0772000000",
        network = "MTN",
        registeredAt = nowMs - 12L * 24 * 60 * 60 * 1000,
        active = true,
        expectedUgx = 2_000L,
        pending = 1,
        approved = 2,
        rejected = 1,
        tasks = tasks(),
        submissions = submissions(nowMs),
        payouts = payouts(nowMs)
    )

    private fun tasks(): List<WTask> = listOf(
        WTask(
            id = "demo-1",
            name = "Follow our TikTok page",
            description = "Open our TikTok page, follow it, and like our three latest videos.",
            payUgx = 2_000L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "https://example.com/demo-video",
            exampleLinkUrl = "https://example.com/demo-page",
            proofRequirements = "One screenshot showing the Following button and your profile name.",
            state = TaskState.AVAILABLE
        ),
        WTask(
            id = "demo-2",
            name = "Daily check-in post",
            description = "Post today's check-in message on your WhatsApp status and keep it up for 24 hours.",
            payUgx = 1_500L,
            type = TaskType.DAILY,
            exampleVideoUrl = "",
            exampleLinkUrl = "https://example.com/demo-checkin",
            proofRequirements = "A screenshot of the status with the date visible, and the link text we gave you.",
            state = TaskState.AVAILABLE
        ),
        WTask(
            id = "demo-3",
            name = "Share promo video",
            description = "Share the promo video with at least five contacts.",
            payUgx = 3_000L,
            type = TaskType.DAILY,
            exampleVideoUrl = "https://example.com/demo-promo",
            exampleLinkUrl = "",
            proofRequirements = "Two screenshots: the sent message and the list of contacts it went to.",
            state = TaskState.AVAILABLE,
            note = "Your last proof was rejected: the screenshot was cropped. You can submit again."
        ),
        WTask(
            id = "demo-4",
            name = "Rate our app",
            description = "Leave an honest rating and a short review of the app.",
            payUgx = 2_500L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot of your review.",
            state = TaskState.WAITING,
            note = "Your proof was sent. The manager has not reviewed it yet."
        ),
        WTask(
            id = "demo-5",
            name = "Daily survey",
            description = "Answer today's three-question survey.",
            payUgx = 1_000L,
            type = TaskType.DAILY,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot of the thank-you page.",
            state = TaskState.DONE,
            note = "Approved. This task comes back tomorrow."
        ),
        WTask(
            id = "demo-6",
            name = "Join the Telegram group",
            description = "Join the CT Team Telegram group and say hello.",
            payUgx = 1_000L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot showing you inside the group.",
            state = TaskState.DONE,
            note = "Approved. This is a one-time task, so it is finished."
        )
    )
}
