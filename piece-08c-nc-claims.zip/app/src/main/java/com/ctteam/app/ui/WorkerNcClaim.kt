package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.NcRepository
import com.ctteam.app.data.NcStatus
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Piece 8C — the worker tells the manager about a deposit into the team's NC Wallet.
 * The worker types the coin, the EXACT amount and the time shown in NC Wallet, in East Africa Time. The time is changed
 * to UTC before saving (statements are in UTC). A claim can be changed or deleted until it goes into a report.
 * The manager's phone later compares the claim with the imported statement (Piece 8D). A claim is a statement by the
 * worker, not proof.
 */

class WClaim(
    val uid: String,
    val coin: String,
    val amountText: String,
    val claimedAtUtc: Long,
    val taskId: String?,
    val taskName: String,
    val status: String,       // NcStatus
    val reported: Boolean     // already in a report to the manager
)

private val RED = Color(0xFFFF8A8A)
private val GREEN = Color(0xFF7BD88F)
private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US)
private val TIME_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US)

@Composable
fun WorkerNcClaimsScreen(
    claims: List<WClaim>,
    startTaskId: String?,
    startTaskName: String,
    demo: Boolean,
    onSave: suspend (editUid: String?, coin: String, amount: String, claimedAtUtc: Long, taskId: String?) -> Outcome<Unit>,
    onDelete: suspend (uid: String) -> Outcome<Unit>,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var coin by remember { mutableStateOf("BNB") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var editUid by remember { mutableStateOf<String?>(null) }
    var editTaskId by remember { mutableStateOf(startTaskId) }
    var editTaskName by remember { mutableStateOf(startTaskName) }
    var confirmDelete by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    fun resetForm() {
        coin = "BNB"; amount = ""; date = ""; time = ""; editUid = null
        editTaskId = startTaskId; editTaskName = startTaskName
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("BNB deposit claims", onBack)
        Text(
            "Did you send crypto to the team's NC Wallet? Tell the manager exactly what NC Wallet shows. " +
                "The manager compares it with the NC Wallet statement. If the amount or the time is wrong it will not match.",
            color = CT.TextSoft, fontSize = 13.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                if (editUid == null) "New claim" else "Change claim",
                color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            if (!editTaskId.isNullOrBlank() || editTaskName.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("For task: " + editTaskName.ifBlank { "selected task" }, color = CT.TextSoft, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            CTField(coin, { coin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(10) }, "Coin (for example BNB)")
            Spacer(Modifier.height(8.dp))
            CTField(
                amount, { amount = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(34) },
                "Exact amount (for example 0.0125)", keyboard = KeyboardType.Decimal
            )
            Spacer(Modifier.height(8.dp))
            Text("Time you saw in NC Wallet — East Africa Time (EAT, UTC+3)", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            CTField(date, { date = it.filter { c -> c.isDigit() || c == '-' }.take(10) }, "Date (yyyy-MM-dd)")
            Spacer(Modifier.height(8.dp))
            CTField(time, { time = it.filter { c -> c.isDigit() || c == ':' }.take(8) }, "Time (HH:mm or HH:mm:ss)")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CTChip(text = "Today", selected = false, onClick = { date = LocalDate.now(TimeUtil.EAT).format(DATE_FMT) })
                CTChip(text = "Yesterday", selected = false, onClick = { date = LocalDate.now(TimeUtil.EAT).minusDays(1).format(DATE_FMT) })
                CTChip(text = "Now", selected = false, onClick = {
                    date = LocalDate.now(TimeUtil.EAT).format(DATE_FMT)
                    time = LocalTime.now(TimeUtil.EAT).format(TIME_FMT)
                })
            }
            if (message.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = if (good) GREEN else RED, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            GoldButton(
                text = if (busy) "PLEASE WAIT" else if (editUid == null) "SAVE CLAIM" else "SAVE CHANGES",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (busy) return@GoldButton
                    val utc = NcRepository.eatToUtc(date, time)
                    if (utc == null) {
                        good = false
                        message = "Enter the date as yyyy-MM-dd and the time as HH:mm, for example 2026-10-08 and 14:35."
                        return@GoldButton
                    }
                    busy = true
                    message = ""
                    val uid = editUid
                    val c = coin
                    val a = amount
                    val tid = editTaskId
                    scope.launch {
                        val r = onSave(uid, c, a, utc, tid)
                        if (r is Outcome.Err) {
                            good = false
                            message = r.message
                        } else {
                            good = true
                            message = if (uid == null) "Claim saved. Send it to the manager from \"Connect to the manager\" on the home screen." else "Claim changed."
                            resetForm()
                        }
                        busy = false
                    }
                }
            )
            if (editUid != null) {
                Spacer(Modifier.height(8.dp))
                GhostButton(text = "CANCEL CHANGE", onClick = { resetForm(); message = "" }, modifier = Modifier.fillMaxWidth())
            }
        }

        Text("My claims", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (claims.isEmpty()) {
            Text("No claims yet.", color = CT.TextSoft, fontSize = 13.sp)
        }
        for (c in claims) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(c.coin + "  " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("Time you gave: " + fmtTime(c.claimedAtUtc) + " (EAT)", color = CT.TextSoft, fontSize = 12.sp)
                if (c.taskName.isNotBlank()) Text("Task: " + c.taskName, color = CT.TextSoft, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                val verified = c.status == NcStatus.MATCHED || c.status == NcStatus.MANUAL
                Text(
                    when {
                        verified -> "✅ Verified by the manager"
                        c.reported -> "📨 Sent to the manager, waiting for the check"
                        else -> "✏️ Not sent yet. Make a report in \"Connect to the manager\"."
                    },
                    color = if (verified) GREEN else CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
                if (!c.reported && !verified) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostButton(text = "EDIT", onClick = {
                            coin = c.coin
                            amount = c.amountText
                            val z = java.time.Instant.ofEpochMilli(c.claimedAtUtc).atZone(TimeUtil.EAT)
                            date = z.toLocalDate().format(DATE_FMT)
                            time = z.toLocalTime().format(TIME_FMT)
                            editUid = c.uid
                            editTaskId = c.taskId
                            editTaskName = c.taskName
                            message = ""
                        })
                        if (confirmDelete == c.uid) {
                            GhostButton(text = "YES, DELETE", danger = true, onClick = {
                                val uid = c.uid
                                confirmDelete = null
                                scope.launch {
                                    val r = onDelete(uid)
                                    good = r !is Outcome.Err
                                    message = if (r is Outcome.Err) r.message else "Claim deleted."
                                    if (editUid == uid) resetForm()
                                }
                            })
                        } else {
                            GhostButton(text = "DELETE", danger = true, onClick = { confirmDelete = c.uid })
                        }
                    }
                }
            }
        }
        if (demo) Text("Demo: nothing is really saved or sent.", color = CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
    }
}
