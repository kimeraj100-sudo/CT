package com.ctteam.app.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.NcStatus
import com.ctteam.app.data.NcParseResult
import com.ctteam.app.data.NcStatementParser
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PdfText
import com.ctteam.app.data.Repos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Piece 8B — manager screen "NC Wallet": import statements (PDF, text file or pasted text) and see the rows.
 * Statement times are UTC. Every time is shown in UTC and in East Africa Time (UTC+3) side by side.
 * Matching of worker claims to rows comes in Piece 8D.
 */

private const val MODE_LIST = "LIST"
private const val MODE_IMPORT = "IMPORT"
private const val MAX_TEXT_BYTES = 2 * 1024 * 1024
private const val ROWS_SHOWN = 100

private val WARN = Color(0xFFFF8A8A)
private val GOOD = Color(0xFF5FD6A5)

private fun fmtSec(ms: Long, utc: Boolean): String {
    val f = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.US)
    f.timeZone = TimeZone.getTimeZone(if (utc) "UTC" else "GMT+03:00")
    return f.format(Date(ms))
}

private class PickedFile(val name: String, val text: String, val fromPdf: Boolean)

private fun displayName(context: Context, uri: Uri): String {
    return try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Statement file"
    } catch (e: Exception) {
        "Statement file"
    }
}

/** A PDF goes through the shared reader (Piece 8A); anything else must be plain text. */
private suspend fun readPickedFile(context: Context, uri: Uri): Outcome<PickedFile> {
    var headOrNull: ByteArray? = null
    try {
        headOrNull = context.contentResolver.openInputStream(uri)?.use { s ->
            val b = ByteArray(8)
            val n = s.read(b)
            if (n <= 0) ByteArray(0) else b.copyOf(n)
        }
    } catch (e: Exception) {
        headOrNull = null
    }
    val head = headOrNull ?: return Outcome.Err("Could not open that file.")
    val name = withContext(Dispatchers.IO) { displayName(context, uri) }

    if (PdfText.looksLikePdf(head)) {
        val r = PdfText.read(context, uri)
        return if (r is Outcome.Ok) Outcome.Ok(PickedFile(name, r.value, true)) else Outcome.Err((r as Outcome.Err).message)
    }
    return withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext Outcome.Err("Could not open that file.")
            if (bytes.size > MAX_TEXT_BYTES) return@withContext Outcome.Err("That text file is larger than 2 MB.")
            if (bytes.any { it.toInt() == 0 }) return@withContext Outcome.Err("That file is not plain text. Open a PDF, CSV or text file, or paste the rows.")
            Outcome.Ok(PickedFile(name, String(bytes, Charsets.UTF_8), false))
        } catch (e: Exception) {
            Outcome.Err("Could not read that file.")
        }
    }
}

@Composable
fun NcWalletScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val dao = repos.db.ncDao()

    val statementsFlow = remember(repos) { dao.observeStatements() }
    val rowsFlow = remember(repos) { dao.observeRecentRows(ROWS_SHOWN) }
    val rowCountFlow = remember(repos) { dao.observeRowCount() }
    val unmatchedFlow = remember(repos) { dao.observeUnmatchedRowCount() }
    val addedFlow = remember(repos) { dao.observeAddedCounts() }
    val statements by statementsFlow.collectAsState(initial = emptyList())
    val rows by rowsFlow.collectAsState(initial = emptyList())
    val rowCount by rowCountFlow.collectAsState(initial = 0)
    val unmatched by unmatchedFlow.collectAsState(initial = 0)
    val added by addedFlow.collectAsState(initial = emptyList())
    val claimsFlow = remember(repos) { dao.observeRecentClaims(50) }
    val claimCountFlow = remember(repos) { dao.observeClaimCount() }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val claims by claimsFlow.collectAsState(initial = emptyList())
    val claimCount by claimCountFlow.collectAsState(initial = 0)
    val workerList by workersFlow.collectAsState(initial = emptyList())

    var mode by remember { mutableStateOf(MODE_LIST) }
    var text by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("Pasted text") }
    var pdfPreview by remember { mutableStateOf<String?>(null) }
    var parsed by remember { mutableStateOf<NcParseResult?>(null) }
    var message by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var onlyOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    BackHandler(enabled = mode != MODE_LIST) { mode = MODE_LIST; message = "" }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                when (val r = readPickedFile(context, uri)) {
                    is Outcome.Err -> message = r.message
                    is Outcome.Ok -> {
                        fileName = r.value.name
                        parsed = null
                        message = ""
                        if (r.value.fromPdf) pdfPreview = r.value.text else text = r.value.text
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ IMPORT
    if (mode == MODE_IMPORT) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHeader("Import NC Wallet statement", { mode = MODE_LIST; message = "" })
            Text(
                "Open the NC Wallet statement (PDF, CSV or text) or paste its rows. Statement times are UTC; the app shows East Africa Time (UTC+3) next to them. " +
                    "You check what was read before anything is saved.",
                color = CT.TextSoft, fontSize = 13.sp
            )
            CTField(text, { text = it; parsed = null }, "Statement rows", singleLine = false, minLines = 8)
            if (message.isNotEmpty()) Text(message, color = WARN, fontSize = 13.sp)

            val preview = pdfPreview
            if (preview != null) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Text read from the PDF", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        preview.lines().size.toString() + " lines, " + preview.length + " characters. Look at the start to make sure it reads like your statement.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(preview.take(1200), color = Color.White, fontSize = 11.sp)
                    if (preview.length > 1200) Text("…", color = CT.TextSoft, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    GoldButton(text = "USE THIS TEXT", modifier = Modifier.fillMaxWidth(), onClick = {
                        text = preview
                        pdfPreview = null
                        parsed = null
                        message = ""
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "DISCARD", modifier = Modifier.fillMaxWidth(), onClick = { pdfPreview = null })
                }
            }

            GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.fillMaxWidth(), onClick = {
                val t = clipboard.getText()?.text ?: ""
                if (t.isBlank()) {
                    message = "The clipboard is empty."
                } else {
                    text = t
                    fileName = "Pasted text"
                    parsed = null
                    message = ""
                }
            })
            GhostButton(text = "OPEN PDF, CSV OR TEXT FILE", modifier = Modifier.fillMaxWidth(), onClick = {
                picker.launch(arrayOf("application/pdf", "text/*", "application/csv", "application/vnd.ms-excel", "application/octet-stream"))
            })
            GoldButton(text = "CHECK STATEMENT", modifier = Modifier.fillMaxWidth(), onClick = {
                val p = NcStatementParser.parse(text)
                if (p.rows.isEmpty()) {
                    parsed = null
                    message = "No rows were found. Each row needs a date and time, a coin (for example BNB) and an amount."
                } else {
                    parsed = p
                    message = ""
                }
            })

            val p = parsed
            if (p != null) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("What was read", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    InfoRow("Rows found", p.rows.size.toString())
                    InfoRow("Other lines skipped", p.skippedLines.toString())
                    InfoRow("File", fileName)
                    Spacer(Modifier.height(6.dp))
                    Text("First rows (compare them with the statement):", color = CT.TextSoft, fontSize = 12.sp)
                    for (r in p.rows.take(8)) {
                        Spacer(Modifier.height(4.dp))
                        Text(r.coin + "  " + r.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("UTC " + fmtSec(r.occurredAtUtc, true), color = CT.TextSoft, fontSize = 11.sp)
                        Text("EAT " + fmtSec(r.occurredAtUtc, false), color = CT.TextSoft, fontSize = 11.sp)
                    }
                    if (p.rows.size > 8) Text("…and " + (p.rows.size - 8) + " more.", color = CT.TextSoft, fontSize = 11.sp)
                }
                Text(
                    "Rows the app already knows from an earlier statement are not added twice, and rows that were already matched stay matched.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                GoldButton(
                    text = if (busy) "PLEASE WAIT" else "IMPORT " + p.rows.size + " ROWS",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (!busy) {
                            busy = true
                            val t = text
                            val n = fileName
                            scope.launch {
                                val r = withContext(Dispatchers.Default) { repos.nc.importStatement(n, t, actor) }
                                busy = false
                                when (r) {
                                    is Outcome.Err -> message = r.message
                                    is Outcome.Ok -> {
                                        val v = r.value
                                        note = "Imported " + v.rowsRead + " rows: " + v.added + " new, " + v.alreadyKnown + " already known. " +
                                            v.skippedLines + " other lines skipped."
                                        text = ""
                                        parsed = null
                                        fileName = "Pasted text"
                                        message = ""
                                        mode = MODE_LIST
                                    }
                                }
                            }
                        }
                    }
                )
            }
        }
        return
    }

    // ------------------------------------------------------------ LIST
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("NC Wallet", onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Statements imported", statements.size.toString())
            InfoRow("Rows stored", rowCount.toString())
            InfoRow("Rows not matched yet", unmatched.toString())
            Spacer(Modifier.height(6.dp))
            Text(
                "Statement times are UTC. Every time below is also shown in East Africa Time (UTC+3). " +
                    "Worker BNB claims and the matching come in the next pieces.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        GoldButton(text = "IMPORT NC WALLET STATEMENT", modifier = Modifier.fillMaxWidth(), onClick = {
            note = ""
            message = ""
            mode = MODE_IMPORT
        })
        if (note.isNotEmpty()) Text(note, color = GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        if (statements.isNotEmpty()) {
            Text("Statements", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            for (s in statements) {
                val addedHere = added.firstOrNull { it.statementId == s.id }?.n ?: 0
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(s.fileName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Imported " + fmtTime(s.importedAt), color = CT.TextSoft, fontSize = 12.sp)
                    Text(
                        "Rows read " + s.rowCount + " · new " + addedHere + " · already known " + (s.rowCount - addedHere),
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                }
            }
        }

        Text("Worker claims ($claimCount)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Deposits the workers say they made. A claim is only what the worker typed; matching with the statement comes next and you always decide.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (claims.isEmpty()) {
            Text("No claims yet. They arrive in the workers' reports (Sync).", color = CT.TextSoft, fontSize = 13.sp)
        }
        for (c in claims) {
            val who = workerList.firstOrNull { it.id == c.workerId }?.fullName() ?: "Worker"
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.coin + "  " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (c.status == NcStatus.UNMATCHED) Text("⚪ not matched", color = CT.TextSoft, fontSize = 12.sp)
                    else Text("✅ matched", color = GOOD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text(who, color = CT.TextSoft, fontSize = 12.sp)
                Text("UTC " + fmtSec(c.claimedAtUtc, true), color = CT.TextSoft, fontSize = 12.sp)
                Text("EAT " + fmtSec(c.claimedAtUtc, false), color = CT.TextSoft, fontSize = 12.sp)
            }
        }

        Text("Rows", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CTChip(text = "All", selected = !onlyOpen, onClick = { onlyOpen = false })
            CTChip(text = "Not matched", selected = onlyOpen, onClick = { onlyOpen = true })
        }
        val shown = if (onlyOpen) rows.filter { it.matchedClaimId == null } else rows
        if (rows.isEmpty()) {
            Text("No rows yet. Import a statement to see them here.", color = CT.TextSoft, fontSize = 13.sp)
        } else if (shown.isEmpty()) {
            Text("Every row shown here is matched.", color = CT.TextSoft, fontSize = 13.sp)
        }
        for (r in shown) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r.coin + "  " + r.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (r.matchedClaimId == null) Text("⚪ not matched", color = CT.TextSoft, fontSize = 12.sp)
                    else Text("✅ matched", color = GOOD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text("UTC " + fmtSec(r.occurredAtUtc, true), color = CT.TextSoft, fontSize = 12.sp)
                Text("EAT " + fmtSec(r.occurredAtUtc, false), color = CT.TextSoft, fontSize = 12.sp)
                if (r.rowNo.isNotBlank()) Text("Statement row " + r.rowNo, color = CT.TextSoft, fontSize = 11.sp)
            }
        }
        if (rowCount > ROWS_SHOWN) {
            Text("Showing the newest $ROWS_SHOWN of $rowCount rows.", color = CT.TextSoft, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}
