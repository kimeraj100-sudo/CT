package com.ctteam.app.data

import androidx.room.withTransaction
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

/** What an import did. */
class NcImportResult(
    val statementId: Long,
    val rowsRead: Int,
    val added: Int,
    val alreadyKnown: Int,
    val skippedLines: Int
)

/** How many rows a statement added when it was the first to contain them. */
data class StatementAdded(val statementId: Long, val n: Int)

/**
 * Piece 8B — stores NC Wallet statements and their rows.
 *  - The same statement text twice is refused.
 *  - Rows already known (same coin, amount and UTC second, from an earlier overlapping statement) are not stored again.
 *    A row keeps its matched / unmatched state forever, so a later statement can never undo a match.
 */
class NcRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.ncDao()

    /** Hash of the statement text with spacing ignored, so the same statement pasted twice is recognised. */
    fun textHash(text: String): String =
        Hashing.sha256Hex(text.replace("\r", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n"))

    suspend fun importStatement(
        fileName: String, text: String, actor: String, at: Long = System.currentTimeMillis()
    ): Outcome<NcImportResult> {
        val parsed = NcStatementParser.parse(text)
        if (parsed.rows.isEmpty()) {
            return Outcome.Err("No NC Wallet rows were found. Each row needs a date and time, a coin and an amount.")
        }
        val sha = textHash(text)
        return db.withTransaction<Outcome<NcImportResult>> {
            val before = dao.statementBySha(sha)
            if (before != null) {
                return@withTransaction Outcome.Err("This exact statement was already imported (" + before.fileName + ").")
            }
            val sid = dao.insertStatement(
                NcStatementEntity(
                    fileName = fileName.ifBlank { "Pasted text" }.take(120),
                    fileSha256 = sha, importedAt = at, rowCount = parsed.rows.size
                )
            )
            val keys = NcStatementParser.rowKeys(parsed.rows)
            var added = 0
            var known = 0
            for (i in parsed.rows.indices) {
                val r = parsed.rows[i]
                val id = dao.insertRow(
                    NcRowEntity(
                        statementId = sid, rowKey = keys[i], rowNo = r.rowNo, coin = r.coin,
                        amountText = r.amountText, occurredAtUtc = r.occurredAtUtc
                    )
                )
                if (id == -1L) known += 1 else added += 1
            }
            audit.log(
                actor, "NC_STATEMENT_IMPORTED", "nc_statement", sid.toString(),
                "rows=" + parsed.rows.size + " new=" + added + " known=" + known, at
            )
            Outcome.Ok(NcImportResult(sid, parsed.rows.size, added, known, parsed.skippedLines))
        }
    }

    // ------------------------------------------------------------------ Piece 8C: worker BNB claims

    companion object {
        val COIN_RULE = Regex("^[A-Z0-9]{2,10}$")
        private val AMOUNT_RULE = Regex("^[0-9]{1,18}(\\.[0-9]{1,18})?$")
        const val MAX_CLAIMS_PER_WORKER = 500
        const val MAX_AGE_MS = 90L * 24 * 60 * 60 * 1000
        const val FUTURE_TOLERANCE_MS = 10L * 60 * 1000

        /** Date "yyyy-MM-dd" and time "HH:mm" or "HH:mm:ss", both written in East Africa Time, to UTC milliseconds. */
        fun eatToUtc(date: String, time: String): Long? = try {
            val d = LocalDate.parse(date.trim())
            val t = LocalTime.parse(time.trim().let { if (it.length == 5) "$it:00" else it })
            d.atTime(t).atZone(TimeUtil.EAT).toInstant().toEpochMilli()
        } catch (e: Exception) {
            null
        }

        /** Exact amount text as the worker saw it in NC Wallet: spaces and thousands commas removed, digits and one dot only. */
        fun cleanAmount(raw: String): String? {
            val t = raw.replace(" ", "").replace(",", "")
            if (!AMOUNT_RULE.matches(t)) return null
            return try {
                if (BigDecimal(t).signum() <= 0) null else t
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun checkFields(coinRaw: String, amountRaw: String, claimedAtUtc: Long, at: Long): Outcome<Pair<String, String>> {
        val coin = coinRaw.trim().uppercase()
        if (!COIN_RULE.matches(coin)) return Outcome.Err("The coin must be 2 to 10 letters or digits, for example BNB.")
        val amount = cleanAmount(amountRaw)
            ?: return Outcome.Err("Enter the exact amount as NC Wallet shows it: digits and one dot, more than zero, for example 0.0125.")
        if (claimedAtUtc > at + FUTURE_TOLERANCE_MS) return Outcome.Err("That time is in the future. Check the date and time.")
        if (claimedAtUtc < at - MAX_AGE_MS) return Outcome.Err("That time is more than 90 days ago. Ask the manager for help with old deposits.")
        return Outcome.Ok(Pair(coin, amount))
    }

    /** Claim ids that already went into a report (after that a claim can no longer be changed or deleted). */
    suspend fun reportedUids(workerId: String): Set<String> =
        db.syncDao().outboxOf(workerId).map { it.itemKey }.filter { it.startsWith("NC:") }.map { it.removePrefix("NC:") }.toSet()

    suspend fun createClaim(
        workerId: String, coinRaw: String, amountRaw: String, claimedAtUtc: Long, taskId: String?, at: Long = System.currentTimeMillis()
    ): Outcome<NcClaimEntity> = db.withTransaction<Outcome<NcClaimEntity>> {
        val w = db.workerDao().get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
        if (!w.active) return@withTransaction Outcome.Err("Your account is disabled by the manager.")
        val f = checkFields(coinRaw, amountRaw, claimedAtUtc, at)
        val pair = when (f) {
            is Outcome.Err -> return@withTransaction Outcome.Err(f.message)
            is Outcome.Ok -> f.value
        }
        val coin = pair.first
        val amount = pair.second
        if (dao.claimCountOf(workerId) >= MAX_CLAIMS_PER_WORKER) return@withTransaction Outcome.Err("Too many claims on this phone. Ask the manager.")
        val tid = taskId?.takeIf { it.isNotBlank() && db.taskDao().get(it) != null }
        val uid = UUID.randomUUID().toString()
        val c = NcClaimEntity(
            workerId = workerId, coin = coin, amountText = amount, claimedAtUtc = claimedAtUtc,
            timezoneContext = "EAT", status = NcStatus.UNMATCHED, createdAt = at, claimUid = uid, taskId = tid
        )
        val id = dao.insertClaim(c)
        audit.log("worker:$workerId", "NC_CLAIM_MADE", "nc_claim", uid, "$coin $amount", at)
        Outcome.Ok(c.copy(id = id))
    }

    /** Change a claim that was not reported yet. */
    suspend fun updateClaim(
        workerId: String, uid: String, coinRaw: String, amountRaw: String, claimedAtUtc: Long, taskId: String?, at: Long = System.currentTimeMillis()
    ): Outcome<NcClaimEntity> = db.withTransaction<Outcome<NcClaimEntity>> {
        val c = dao.claimByUid(uid)
        if (c == null || c.workerId != workerId) return@withTransaction Outcome.Err("Claim not found.")
        if (uid in reportedUids(workerId)) return@withTransaction Outcome.Err("This claim was already sent to the manager and cannot be changed.")
        if (c.status != NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim was already checked and cannot be changed.")
        val f = checkFields(coinRaw, amountRaw, claimedAtUtc, at)
        val pair = when (f) {
            is Outcome.Err -> return@withTransaction Outcome.Err(f.message)
            is Outcome.Ok -> f.value
        }
        val coin = pair.first
        val amount = pair.second
        val tid = taskId?.takeIf { it.isNotBlank() && db.taskDao().get(it) != null }
        val u = c.copy(coin = coin, amountText = amount, claimedAtUtc = claimedAtUtc, taskId = tid)
        dao.updateClaim(u)
        audit.log("worker:$workerId", "NC_CLAIM_EDITED", "nc_claim", uid, "$coin $amount", at)
        Outcome.Ok(u)
    }

    suspend fun deleteClaim(workerId: String, uid: String, at: Long = System.currentTimeMillis()): Outcome<Unit> =
        db.withTransaction<Outcome<Unit>> {
            val c = dao.claimByUid(uid)
            if (c == null || c.workerId != workerId) return@withTransaction Outcome.Err("Claim not found.")
            if (uid in reportedUids(workerId)) return@withTransaction Outcome.Err("This claim was already sent to the manager and cannot be deleted.")
            if (c.status != NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim was already checked and cannot be deleted.")
            dao.deleteClaim(c.id)
            audit.log("worker:$workerId", "NC_CLAIM_DELETED", "nc_claim", uid, "${c.coin} ${c.amountText}", at)
            Outcome.Ok(Unit)
        }
}
