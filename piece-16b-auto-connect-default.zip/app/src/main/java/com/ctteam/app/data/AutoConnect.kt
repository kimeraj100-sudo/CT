package com.ctteam.app.data

/**
 * Piece C2a — auto-connect (manager phone). When the MAIN manager turns it on, a brand-new worker who sends the connection
 * code to the bot is connected at once, with no key-code call. Such a worker is UNVERIFIED until a manager verifies them:
 * they can work and send reports, but a payout cannot be confirmed and a referral cannot be awarded while either side is unverified.
 * Only workers who are NEW on this phone are auto-connected. A code that matches an existing worker (same National ID) or has
 * any problem still waits for a manager, because that is how someone could take over a real worker's place.
 * Stored in `meta`: `ac:on` = "1", `ac:unv` = comma-separated worker ids that are not verified yet.
 */
object AutoConnect {
    private const val KEY_ON = "ac:on"
    private const val KEY_UNV = "ac:unv"

    const val BLOCK_TEXT = "This worker is not verified yet. Open the menu > Auto-connect, find the worker under \"Not verified\" and press VERIFY first."

    /** Piece 16b: ON unless the main manager switched it OFF ("0"). A phone where it was never set counts as ON. */
    suspend fun enabled(db: CTDatabase): Boolean = db.metaDao().get(KEY_ON) != "0"

    /** Only the main manager may change it. */
    suspend fun setEnabled(db: CTDatabase, audit: AuditRepository, on: Boolean, byMain: Boolean, actor: String): Outcome<Unit> {
        if (!byMain) return Outcome.Err("Only the main manager can change this.")
        db.metaDao().put(MetaEntity(KEY_ON, if (on) "1" else "0"))
        audit.log(actor, if (on) "AUTO_CONNECT_ON" else "AUTO_CONNECT_OFF", "settings", "auto-connect", "")
        return Outcome.Ok(Unit)
    }

    suspend fun unverifiedIds(db: CTDatabase): List<String> =
        (db.metaDao().get(KEY_UNV) ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }

    suspend fun isUnverified(db: CTDatabase, workerId: String): Boolean = workerId in unverifiedIds(db)

    suspend fun markUnverified(db: CTDatabase, workerId: String) {
        val now = unverifiedIds(db)
        if (workerId !in now) db.metaDao().put(MetaEntity(KEY_UNV, (now + workerId).joinToString(",")))
    }

    /** Any manager may verify (they have checked who the person is). */
    suspend fun verify(db: CTDatabase, audit: AuditRepository, workerId: String, actor: String): Outcome<Unit> {
        val now = unverifiedIds(db)
        if (workerId !in now) return Outcome.Ok(Unit)
        db.metaDao().put(MetaEntity(KEY_UNV, (now - workerId).joinToString(",")))
        audit.log(actor, "WORKER_VERIFIED", "worker", workerId, "")
        return Outcome.Ok(Unit)
    }
}
