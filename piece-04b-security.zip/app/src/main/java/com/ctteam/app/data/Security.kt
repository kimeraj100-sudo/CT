package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Piece 4B — shared security building blocks for managers AND workers.
 *
 * Sign-in model (both roles):
 *  - FULL sign-in  = name (code name / username) + password + PIN. Needed the first time on a device
 *    and again once every 30 days on that device.
 *  - QUICK unlock  = just the PIN OR just the password, allowed for 30 days after a full sign-in
 *    on that same device. Any reset or change of password/PIN ends the 30 days (credVersion changes).
 *  - Managers are created by the main manager with a random one-time PIN. The manager activates the
 *    account with code name + that PIN and creates their own password.
 */

// ------------------------------------------------------------------ TABLES

/** Fingerprint of EVERY manager PIN ever issued, so a PIN is never issued twice (even after a reset). */
@Entity(tableName = "pin_ledger")
data class PinLedgerEntity(
    @PrimaryKey val fingerprint: String,   // hex, PBKDF2 with a fixed app salt (the PIN itself is never stored here)
    val createdAt: Long
)

/** "This device did a full sign-in for this account at trustedAt." One row per account/worker. */
@Entity(tableName = "device_trust")
data class DeviceTrustEntity(
    @PrimaryKey val subjectId: String,     // manager account id or worker id
    val kind: String,                      // MANAGER or WORKER
    val trustedAt: Long,                   // UTC millis of the last FULL sign-in on this device
    val credVersion: Int                   // must equal the account's credVersion, else trust is void
)

/** Worker login details (workers register on their own phone and choose these themselves). */
@Entity(tableName = "worker_credentials", indices = [Index(value = ["username"], unique = true)])
data class WorkerCredentialEntity(
    @PrimaryKey val workerId: String,
    val username: String,                  // stored lowercase
    val passSalt: String,                  // hex
    val passHash: String,                  // "<iterations>:<hex>"
    val pinSalt: String,                   // hex
    val pinHash: String,                   // hex
    val iterations: Int,                   // PIN iterations
    val credVersion: Int,
    val updatedAt: Long
)

@Dao
interface SecurityDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addLedger(e: PinLedgerEntity)
    @Query("SELECT COUNT(*) FROM pin_ledger WHERE fingerprint = :fp") suspend fun ledgerCount(fp: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTrust(t: DeviceTrustEntity)
    @Query("SELECT * FROM device_trust WHERE subjectId = :id") suspend fun trust(id: String): DeviceTrustEntity?
    @Query("DELETE FROM device_trust WHERE subjectId = :id") suspend fun clearTrust(id: String)

    @Insert suspend fun insertWorkerCred(c: WorkerCredentialEntity)
    @Update suspend fun updateWorkerCred(c: WorkerCredentialEntity)
    @Query("SELECT * FROM worker_credentials WHERE workerId = :id") suspend fun workerCred(id: String): WorkerCredentialEntity?
    @Query("SELECT * FROM worker_credentials WHERE username = :u LIMIT 1") suspend fun workerCredByUsername(u: String): WorkerCredentialEntity?
}

// ------------------------------------------------------------------ RESULTS

/** Result of a sign-in step. Wrong = counts as a failed try; Denied = refused for another reason (not counted). */
sealed class Auth<out T> {
    data class Ok<T>(val value: T) : Auth<T>()
    data class Wrong(val message: String) : Auth<Nothing>()
    data class Denied(val message: String) : Auth<Nothing>()
}

// ------------------------------------------------------------------ HASHING + RULES

object Secrets {
    const val PASS_ITERATIONS = 100_000
    const val PIN_ITERATIONS = 100_000
    const val TRUST_MS = 30L * 86_400_000L      // "once a month" = 30 days

    const val MANAGER_PIN_MIN = 6
    const val MANAGER_PIN_MAX = 10
    const val WORKER_PIN_MIN = 4
    const val WORKER_PIN_MAX = 10
    const val PASSWORD_MIN = 8
    const val PASSWORD_MAX = 64

    private const val LEDGER_SALT = "5f3c9a1e7b2d4086a1c3e5f7092b4d6e"

    fun newSaltHex(): String = PinHasher.newSaltHex()

    fun hashPin(pin: String, saltHex: String, iterations: Int = PIN_ITERATIONS): String =
        PinHasher.hashHex(pin, saltHex, iterations)

    fun verifyPin(pin: String, saltHex: String, hashHex: String, iterations: Int): Boolean {
        if (pin.isEmpty()) return false
        return MessageDigest.isEqual(
            PinHasher.hashHex(pin, saltHex, iterations).toByteArray(Charsets.UTF_8),
            hashHex.toByteArray(Charsets.UTF_8)
        )
    }

    /** Stored as "<iterations>:<hex>" so the cost can be raised later without breaking old passwords. */
    fun hashPassword(password: String, saltHex: String): String =
        PASS_ITERATIONS.toString() + ":" + PinHasher.hashHex(password, saltHex, PASS_ITERATIONS)

    fun verifyPassword(password: String, saltHex: String, stored: String): Boolean {
        if (password.isEmpty()) return false
        val i = stored.indexOf(':')
        if (i <= 0) return false
        val iter = stored.substring(0, i).toIntOrNull() ?: return false
        if (iter < 1000 || iter > 2_000_000) return false
        return MessageDigest.isEqual(
            PinHasher.hashHex(password, saltHex, iter).toByteArray(Charsets.UTF_8),
            stored.substring(i + 1).toByteArray(Charsets.UTF_8)
        )
    }

    /** Fingerprint used by the "never issued before" ledger. */
    fun fingerprint(pin: String): String = PinHasher.hashHex(pin, LEDGER_SALT, PIN_ITERATIONS)

    /** Random digits, first digit never 0. */
    fun randomPin(length: Int): String {
        val r = SecureRandom()
        val sb = StringBuilder()
        sb.append(1 + r.nextInt(9))
        while (sb.length < length) sb.append(r.nextInt(10))
        return sb.toString()
    }

    fun isDigits(s: String): Boolean = s.isNotEmpty() && s.all { it in '0'..'9' }

    /** Null when fine, otherwise the message to show. */
    fun passwordError(pw: String): String? {
        if (pw.length < PASSWORD_MIN) return "Password must be at least $PASSWORD_MIN characters."
        if (pw.length > PASSWORD_MAX) return "Password can be at most $PASSWORD_MAX characters."
        if (!pw.any { it.isLetter() }) return "Password needs at least one letter."
        if (!pw.any { it.isDigit() }) return "Password needs at least one digit."
        return null
    }

    fun pinError(pin: String, min: Int, max: Int): String? {
        if (!isDigits(pin)) return "PIN can only contain digits."
        if (pin.length < min) return "PIN must be at least $min digits."
        if (pin.length > max) return "PIN can be at most $max digits."
        return null
    }
}

// ------------------------------------------------------------------ WRONG-TRY LOCKOUT (survives closing the app)

/**
 * 5 wrong tries = locked for 30 s; every further 5 wrong tries doubles the lock (up to 1 hour).
 * Kept in the `meta` table so restarting the app does not reset it.
 */
class LockoutStore(private val meta: MetaDao, private val key: String) {
    private data class State(val count: Int, val rounds: Int, val until: Long)

    private suspend fun load(): State {
        val p = (meta.get(key) ?: "").split(",")
        return State(
            p.getOrNull(0)?.toIntOrNull() ?: 0,
            p.getOrNull(1)?.toIntOrNull() ?: 0,
            p.getOrNull(2)?.toLongOrNull() ?: 0L
        )
    }

    private suspend fun save(s: State) = meta.put(MetaEntity(key, s.count.toString() + "," + s.rounds + "," + s.until))

    suspend fun remainingMs(now: Long = System.currentTimeMillis()): Long = maxOf(0L, load().until - now)

    /** Records a wrong try. Returns the lock length in ms if this try started a lock, otherwise 0. */
    suspend fun recordFailure(now: Long = System.currentTimeMillis()): Long {
        val s = load()
        val count = s.count + 1
        if (count < 5) {
            save(s.copy(count = count))
            return 0L
        }
        val rounds = s.rounds + 1
        val lockMs = minOf(30_000L shl minOf(rounds - 1, 7), 3_600_000L)
        save(State(0, rounds, now + lockMs))
        return lockMs
    }

    suspend fun clear() = save(State(0, 0, 0L))
}

// ------------------------------------------------------------------ WORKER SIGN-IN

class WorkerAuthRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val sec = db.securityDao()

    companion object {
        const val BAD_LOGIN = "Username, password or PIN is not correct."
    }

    private fun now() = System.currentTimeMillis()
    private fun actor(workerId: String) = "worker:$workerId"

    fun normalizeUsername(raw: String): String = raw.trim().lowercase()

    private fun usernameError(u: String): String? {
        if (!Regex("^[a-z0-9._]{4,20}$").matches(u))
            return "Username must be 4 to 20 characters: letters, digits, dot or underscore."
        return null
    }

    /** Null when the three values are acceptable for a NEW login, otherwise the message to show. */
    suspend fun checkNew(usernameRaw: String, password: String, pin: String, exceptWorkerId: String? = null): String? {
        val u = normalizeUsername(usernameRaw)
        usernameError(u)?.let { return it }
        Secrets.passwordError(password)?.let { return it }
        Secrets.pinError(pin, Secrets.WORKER_PIN_MIN, Secrets.WORKER_PIN_MAX)?.let { return it }
        val taken = sec.workerCredByUsername(u)
        if (taken != null && taken.workerId != exceptWorkerId) return "That username is already taken. Choose another."
        return null
    }

    suspend fun hasCredentials(workerId: String): Boolean = sec.workerCred(workerId) != null

    suspend fun username(workerId: String): String? = sec.workerCred(workerId)?.username

    private suspend fun isTrusted(c: WorkerCredentialEntity, at: Long): Boolean {
        val t = sec.trust(c.workerId) ?: return false
        val age = at - t.trustedAt
        return t.credVersion == c.credVersion && age in 0 until Secrets.TRUST_MS
    }

    /** True when this phone did a full sign-in less than 30 days ago (PIN-or-password unlock allowed). */
    suspend fun quickAvailable(workerId: String, at: Long = now()): Boolean {
        val c = sec.workerCred(workerId) ?: return false
        return isTrusted(c, at)
    }

    private suspend fun trust(c: WorkerCredentialEntity, at: Long) =
        sec.putTrust(DeviceTrustEntity(c.workerId, "WORKER", at, c.credVersion))

    suspend fun create(
        workerId: String, usernameRaw: String, password: String, pin: String, at: Long = now()
    ): Outcome<Unit> {
        val err = checkNew(usernameRaw, password, pin, exceptWorkerId = workerId)
        if (err != null) return Outcome.Err(err)
        return db.withTransaction<Outcome<Unit>> {
            if (db.workerDao().get(workerId) == null) return@withTransaction Outcome.Err("Worker not found.")
            if (sec.workerCred(workerId) != null) return@withTransaction Outcome.Err("This worker already has a login.")
            val ps = Secrets.newSaltHex()
            val pn = Secrets.newSaltHex()
            val c = WorkerCredentialEntity(
                workerId = workerId, username = normalizeUsername(usernameRaw),
                passSalt = ps, passHash = Secrets.hashPassword(password, ps),
                pinSalt = pn, pinHash = Secrets.hashPin(pin, pn), iterations = Secrets.PIN_ITERATIONS,
                credVersion = 1, updatedAt = at
            )
            sec.insertWorkerCred(c)
            trust(c, at)
            audit.log(actor(workerId), "WORKER_LOGIN_CREATED", "worker", workerId, c.username, at)
            Outcome.Ok(Unit)
        }
    }

    private fun secretMatches(c: WorkerCredentialEntity, secret: String): Boolean {
        if (secret.isEmpty()) return false
        return if (Secrets.isDigits(secret)) Secrets.verifyPin(secret, c.pinSalt, c.pinHash, c.iterations)
        else Secrets.verifyPassword(secret, c.passSalt, c.passHash)
    }

    suspend fun fullLogin(workerId: String, usernameRaw: String, password: String, pin: String, at: Long = now()): Auth<Unit> {
        val c = sec.workerCred(workerId) ?: return Auth.Denied("No login has been created on this phone yet.")
        val userOk = c.username == normalizeUsername(usernameRaw)
        val passOk = Secrets.verifyPassword(password, c.passSalt, c.passHash)
        val pinOk = Secrets.verifyPin(pin, c.pinSalt, c.pinHash, c.iterations)
        if (!(userOk && passOk && pinOk)) {
            audit.event("WORKER_LOGIN_FAILED", workerId, at)
            return Auth.Wrong(BAD_LOGIN)
        }
        trust(c, at)
        audit.log(actor(workerId), "WORKER_LOGIN", "worker", workerId, "full", at)
        return Auth.Ok(Unit)
    }

    suspend fun quick(workerId: String, secret: String, at: Long = now()): Auth<Unit> {
        val c = sec.workerCred(workerId) ?: return Auth.Denied("No login has been created on this phone yet.")
        if (!isTrusted(c, at)) return Auth.Denied("Please sign in again with username, password and PIN.")
        if (!secretMatches(c, secret.trim())) {
            audit.event("WORKER_LOGIN_FAILED", workerId, at)
            return Auth.Wrong("Wrong PIN or password.")
        }
        audit.log(actor(workerId), "WORKER_LOGIN", "worker", workerId, "quick", at)
        return Auth.Ok(Unit)
    }

    /**
     * Forgot password/PIN. Interim rule until Piece 5 (signed manager reset codes): the worker proves it is
     * them with the National ID AND the current payout number saved on this phone, then sets a new password + PIN.
     */
    suspend fun recover(
        workerId: String, ninRaw: String, phoneRaw: String, newPassword: String, newPin: String, at: Long = now()
    ): Auth<Unit> {
        val w = db.workerDao().get(workerId) ?: return Auth.Denied("Worker not found.")
        val c = sec.workerCred(workerId) ?: return Auth.Denied("No login has been created on this phone yet.")
        val phone = PhoneUtil.parse(phoneRaw)
        val ok = w.nationalId == ninRaw.trim().uppercase() && phone != null && phone.digits == w.phone
        if (!ok) {
            audit.event("WORKER_RECOVERY_FAILED", workerId, at)
            return Auth.Wrong("National ID or payout number does not match this account.")
        }
        Secrets.passwordError(newPassword)?.let { return Auth.Denied(it) }
        Secrets.pinError(newPin, Secrets.WORKER_PIN_MIN, Secrets.WORKER_PIN_MAX)?.let { return Auth.Denied(it) }
        val ps = Secrets.newSaltHex()
        val pn = Secrets.newSaltHex()
        val u = c.copy(
            passSalt = ps, passHash = Secrets.hashPassword(newPassword, ps),
            pinSalt = pn, pinHash = Secrets.hashPin(newPin, pn), iterations = Secrets.PIN_ITERATIONS,
            credVersion = c.credVersion + 1, updatedAt = at
        )
        sec.updateWorkerCred(u)
        trust(u, at)
        audit.log(actor(workerId), "WORKER_LOGIN_RECOVERED", "worker", workerId, "", at)
        return Auth.Ok(Unit)
    }

    suspend fun changePassword(workerId: String, current: String, newPassword: String, at: Long = now()): Outcome<Unit> {
        val c = sec.workerCred(workerId) ?: return Outcome.Err("No login found.")
        if (!secretMatches(c, current.trim())) return Outcome.Err("Your current PIN or password is not correct.")
        Secrets.passwordError(newPassword)?.let { return Outcome.Err(it) }
        val ps = Secrets.newSaltHex()
        val u = c.copy(passSalt = ps, passHash = Secrets.hashPassword(newPassword, ps), credVersion = c.credVersion + 1, updatedAt = at)
        sec.updateWorkerCred(u)
        trust(u, at)
        audit.log(actor(workerId), "WORKER_PASSWORD_CHANGED", "worker", workerId, "", at)
        return Outcome.Ok(Unit)
    }

    suspend fun changePin(workerId: String, current: String, newPin: String, at: Long = now()): Outcome<Unit> {
        val c = sec.workerCred(workerId) ?: return Outcome.Err("No login found.")
        if (!secretMatches(c, current.trim())) return Outcome.Err("Your current PIN or password is not correct.")
        Secrets.pinError(newPin, Secrets.WORKER_PIN_MIN, Secrets.WORKER_PIN_MAX)?.let { return Outcome.Err(it) }
        val pn = Secrets.newSaltHex()
        val u = c.copy(pinSalt = pn, pinHash = Secrets.hashPin(newPin, pn), iterations = Secrets.PIN_ITERATIONS, credVersion = c.credVersion + 1, updatedAt = at)
        sec.updateWorkerCred(u)
        trust(u, at)
        audit.log(actor(workerId), "WORKER_PIN_CHANGED", "worker", workerId, "", at)
        return Outcome.Ok(Unit)
    }

    suspend fun forgetDevice(workerId: String) = sec.clearTrust(workerId)
}
