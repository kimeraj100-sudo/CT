package com.ctteam.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * RULES (so app updates never wipe data):
 *  - Never rename the database file (NAME) or use fallbackToDestructiveMigration().
 *  - Any change to an @Entity => raise `version` by 1 AND add a Migration below.
 *
 * Version history:
 *  1 = piece 2 (all base tables)
 *  2 = piece 4A (manager_accounts: up to 20 managers with code names + PINs)
 *  3 = piece 4B (passwords + activation for managers; pin_ledger, device_trust, worker_credentials)
 */
@Database(
    entities = [
        WorkerEntity::class, PhoneHistoryEntity::class,
        TaskEntity::class, TaskVersionEntity::class,
        SubmissionEntity::class, ProofEntity::class,
        PayoutRequestEntity::class, PaymentEntity::class,
        NcStatementEntity::class, NcRowEntity::class, NcClaimEntity::class,
        SupportMessageEntity::class, AnnouncementEntity::class, LearnContentEntity::class,
        AuditEntity::class, EventEntity::class, MetaEntity::class, ManagerEntity::class,
        ManagerAccountEntity::class,
        PinLedgerEntity::class, DeviceTrustEntity::class, WorkerCredentialEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class CTDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun taskDao(): TaskDao
    abstract fun submissionDao(): SubmissionDao
    abstract fun payoutDao(): PayoutDao
    abstract fun ncDao(): NcDao
    abstract fun supportDao(): SupportDao
    abstract fun contentDao(): ContentDao
    abstract fun auditDao(): AuditDao
    abstract fun eventDao(): EventDao
    abstract fun metaDao(): MetaDao
    abstract fun managerDao(): ManagerDao
    abstract fun managerAccountDao(): ManagerAccountDao
    abstract fun securityDao(): SecurityDao

    companion object {
        const val NAME = "ctteam.db"

        fun build(context: Context): CTDatabase =
            Room.databaseBuilder(context.applicationContext, CTDatabase::class.java, NAME)
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

/** Add one Migration per schema version bump. Never delete old ones. */
object Migrations {
    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `manager_accounts` (" +
                    "`id` TEXT NOT NULL, `codeName` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, " +
                    "`pinHash` TEXT NOT NULL, `iterations` INTEGER NOT NULL, `isMain` INTEGER NOT NULL, " +
                    "`suspendedUntil` INTEGER, `accessExpiresAt` INTEGER, `note` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_manager_accounts_codeName` " +
                    "ON `manager_accounts` (`codeName`)"
            )
        }
    }

    /** Piece 4B: existing managers keep their PIN and become "not activated" (passHash null) until they create a password. */
    val MIGRATION_2_3: Migration = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passSalt` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passHash` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `credVersion` INTEGER NOT NULL DEFAULT 1")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `pin_ledger` (" +
                    "`fingerprint` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`fingerprint`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `device_trust` (" +
                    "`subjectId` TEXT NOT NULL, `kind` TEXT NOT NULL, `trustedAt` INTEGER NOT NULL, " +
                    "`credVersion` INTEGER NOT NULL, PRIMARY KEY(`subjectId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `worker_credentials` (" +
                    "`workerId` TEXT NOT NULL, `username` TEXT NOT NULL, `passSalt` TEXT NOT NULL, " +
                    "`passHash` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, `pinHash` TEXT NOT NULL, " +
                    "`iterations` INTEGER NOT NULL, `credVersion` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_worker_credentials_username` " +
                    "ON `worker_credentials` (`username`)"
            )
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3)
}
