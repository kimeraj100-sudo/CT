package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.LockoutStore
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TimeUtil
import com.ctteam.app.data.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Key in the `meta` table that remembers which worker is registered on THIS phone. */
const val WORKER_META_KEY = "this_device_worker_id"

private sealed interface WPhase {
    object Loading : WPhase
    object Register : WPhase
    class Setup(val workerId: String) : WPhase
    class Gate(val workerId: String, val quickName: String?) : WPhase
    class Recover(val workerId: String) : WPhase
    class Home(val workerId: String) : WPhase
}

private suspend fun decidePhase(repos: Repos): WPhase {
    val id = repos.db.metaDao().get(WORKER_META_KEY) ?: return WPhase.Register
    if (!repos.workerAuth.hasCredentials(id)) return WPhase.Setup(id)
    val quick = repos.workerAuth.quickAvailable(id)
    val name = repos.db.workerDao().get(id)?.firstName
    return WPhase.Gate(id, if (quick) (name ?: "") else null)
}

/**
 * Entry point of Worker mode (Piece 4B):
 * register once on this phone (with username, password and PIN) -> every time Worker mode opens the worker
 * unlocks with PIN or password (quick, for 30 days after a full sign-in) or username + password + PIN.
 */
@Composable
fun WorkerArea(onExit: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val repos = remember { ServiceLocator.get(context) }
    var phase by remember { mutableStateOf<WPhase>(WPhase.Loading) }

    LaunchedEffect(Unit) { phase = decidePhase(repos) }

    when (val p = phase) {
        is WPhase.Loading -> {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Opening…", color = CT.TextSoft)
            }
        }
        is WPhase.Register -> RegisterWorkerScreen(
            repos = repos, onExit = onExit,
            onRegistered = { newId -> phase = WPhase.Home(newId) }
        )
        is WPhase.Setup -> {
            var worker by remember(p.workerId) { mutableStateOf<WorkerEntity?>(null) }
            LaunchedEffect(p.workerId) { worker = repos.db.workerDao().get(p.workerId) }
            val w = worker
            if (w != null) {
                SetupWorkerLoginScreen(repos = repos, worker = w, onDone = { phase = WPhase.Home(p.workerId) }, onExit = onExit)
            }
        }
        is WPhase.Gate -> {
            val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:worker") }
            CredentialGate(
                title = "Worker sign-in",
                subtitle = "Sign in with your username, password and PIN.",
                idLabel = "Username",
                notice = "",
                quickName = p.quickName,
                lock = lock,
                onQuick = { secret -> repos.workerAuth.quick(p.workerId, secret).toGate() },
                onFull = { id, password, pin -> repos.workerAuth.fullLogin(p.workerId, id, password, pin).toGate() },
                onActivate = null,
                onForgot = { phase = WPhase.Recover(p.workerId) },
                onDone = { phase = WPhase.Home(p.workerId) },
                onExit = onExit
            )
        }
        is WPhase.Recover -> {
            var worker by remember(p.workerId) { mutableStateOf<WorkerEntity?>(null) }
            LaunchedEffect(p.workerId) { worker = repos.db.workerDao().get(p.workerId) }
            val w = worker
            if (w != null) {
                RecoverWorkerScreen(
                    repos = repos, worker = w,
                    onDone = { phase = WPhase.Home(p.workerId) },
                    onBack = { phase = WPhase.Gate(p.workerId, null) }
                )
            }
        }
        is WPhase.Home -> WorkerHomeScreen(repos = repos, workerId = p.workerId, onExit = onExit)
    }
}

// ------------------------------------------------------------------ REGISTRATION

@Composable
private fun RegisterWorkerScreen(repos: Repos, onExit: () -> Unit, onRegistered: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var nin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var middle by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var ownName by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Register as a worker", onExit)
        Text(
            "Fill in your details exactly as they appear on your National ID. You only do this once on this phone.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(nin, { nin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(14) }, "National ID number")
        CTField(first, { first = it }, "First name")
        CTField(middle, { middle = it }, "Middle name (optional)")
        CTField(last, { last = it }, "Last name")
        CTField(phone, { phone = it }, "MTN or Airtel number (e.g. 0772123456)", keyboard = KeyboardType.Phone)
        Text(
            "Payouts go to this number. It must be registered in your own name. " +
                "You can change it only once a week, and never while a payout is in progress.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("This number is in my own name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(checked = ownName, onCheckedChange = { ownName = it })
        }
        Text("Create your login", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "You sign in with your username, password and PIN. After that, on this phone you can unlock with just your PIN or just your password for 30 days.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        WorkerLoginFields(username, { username = it }, pass, { pass = it }, pass2, { pass2 = it }, pin, { pin = it }, pin2, { pin2 = it })
        if (message.isNotEmpty()) Text(message, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "REGISTER",
            onClick = {
                if (!busy) {
                    message = ""
                    if (!ownName) {
                        message = "Please confirm the number is registered in your own name."
                    } else if (pass != pass2) {
                        message = "The two passwords do not match."
                    } else if (pin != pin2) {
                        message = "The two PINs do not match."
                    } else {
                        busy = true
                        scope.launch {
                            val loginError = withContext(Dispatchers.Default) { repos.workerAuth.checkNew(username, pass, pin) }
                            if (loginError != null) {
                                message = loginError
                                busy = false
                                return@launch
                            }
                            val r = repos.workers.register(nin, first, middle, last, phone)
                            if (r is Outcome.Err) {
                                message = r.message
                            } else if (r is Outcome.Ok) {
                                repos.db.metaDao().put(MetaEntity(WORKER_META_KEY, r.value.id))
                                val c = withContext(Dispatchers.Default) { repos.workerAuth.create(r.value.id, username, pass, pin) }
                                if (c is Outcome.Err) {
                                    message = c.message
                                } else {
                                    onRegistered(r.value.id)
                                }
                            }
                            busy = false
                        }
                    }
                }
            }
        )
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ HOME

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier) {
    GlassCard(modifier = modifier) {
        Text(value, color = CT.GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CT.TextSoft, fontSize = 12.sp)
    }
}

@Composable
private fun WorkerHomeScreen(repos: Repos, workerId: String, onExit: () -> Unit) {
    val scope = rememberCoroutineScope()
    val workerFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workerFlow.collectAsState(initial = emptyList())
    val worker = workers.firstOrNull { it.id == workerId }

    val subFlow = remember(repos, workerId) { repos.db.submissionDao().observeForWorker(workerId) }
    val subs by subFlow.collectAsState(initial = emptyList())

    var expected by remember { mutableStateOf(0L) }
    var username by remember { mutableStateOf("") }
    LaunchedEffect(workerId) { username = repos.workerAuth.username(workerId) ?: "" }
    var newPhone by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val week = TimeUtil.weekKey(System.currentTimeMillis())
    LaunchedEffect(subs, workerId) { expected = repos.submissions.expectedForWeek(workerId, week) }

    if (worker == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            ScreenHeader("Worker", onExit)
            Text("Loading…", color = CT.TextSoft)
        }
        return
    }

    val pending = subs.count { it.status == SubStatus.PENDING }
    val approved = subs.count { it.status == SubStatus.APPROVED }
    val rejected = subs.count { it.status == SubStatus.REJECTED }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Hello, " + worker.firstName, onExit)
        if (!worker.active) {
            Text("Your account is disabled by the manager. Contact support.", color = Color(0xFFFF8A8A), fontSize = 13.sp)
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Name", worker.fullName())
            if (username.isNotBlank()) InfoRow("Username", username)
            InfoRow("National ID", worker.nationalId)
            InfoRow("Payout number", "0" + worker.phone.substring(3) + " (" + worker.network + ")")
            InfoRow("Registered", fmtTime(worker.createdAt))
        }

        Text("This week (Mon–Sun)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryTile("Expected payout", ugx(expected), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryTile("Pending", pending.toString(), Modifier.weight(1f))
            SummaryTile("Approved", approved.toString(), Modifier.weight(1f))
            SummaryTile("Rejected", rejected.toString(), Modifier.weight(1f))
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Coming next (Piece 4C)", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Your task list, submitting proof, full earnings history and requesting your weekly payout.",
                color = CT.TextSoft, fontSize = 13.sp
            )
        }

        Text("Change payout number", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Allowed once per week, and not while a payout is in progress. The number must be in your own name.", color = CT.TextSoft, fontSize = 12.sp)
        CTField(newPhone, { newPhone = it }, "New MTN / Airtel number", keyboard = KeyboardType.Phone)
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)
        GhostButton(text = "CHANGE NUMBER", onClick = {
            scope.launch {
                val r = repos.workers.changePhone(worker.id, newPhone, "worker:" + worker.id)
                if (r is Outcome.Err) {
                    message = r.message
                } else {
                    message = "Phone number changed."
                    newPhone = ""
                }
            }
        })
        Spacer(Modifier.height(8.dp))
        WorkerSecurityCard(repos = repos, workerId = worker.id)
        Spacer(Modifier.height(8.dp))
    }
}
