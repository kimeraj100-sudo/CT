package com.ctteam.app.data

import androidx.room.withTransaction
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

/** What an import did. */
class NcImportResult(
    val statementId: Long,
    val rowsRead: Int,
    val added: Int,
    val alreadyKnown: Int,
    val skippedLines: Int
)

/** How many rows a statement added when it was the first to contain them. */
data class StatementAdded(val statementId: Long, val n: Int)

/**
 * Piece 8B — stores NC Wallet statements and their rows.
 *  - The same statement text twice is refused.
 *  - Rows already known (same coin, amount and UTC second, from an earlier overlapping statement) are not stored again.
 *    A row keeps its matched / unmatched state forever, so a later statement can never undo a match.
 */
class NcRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.ncDao()
    private val team = TeamRepository(db, audit)   // Piece T1: a verified claim becomes a team contribution

    /** Hash of the statement text with spacing ignored, so the same statement pasted twice is recognised. */
    fun textHash(text: String): String =
        Hashing.sha256Hex(text.replace("\r", "").split("\n").map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n"))

    suspend fun importStatement(
        fileName: String, text: String, actor: String, at: Long = System.currentTimeMillis()
    ): Outcome<NcImportResult> {
        val parsed = NcStatementParser.parse(text)
        if (parsed.rows.isEmpty()) {
            return Outcome.Err("No NC Wallet rows were found. Each row needs a date and time, a coin and an amount.")
        }
        val sha = textHash(text)
        return db.withTransaction<Outcome<NcImportResult>> {
            val before = dao.statementBySha(sha)
            if (before != null) {
                return@withTransaction Outcome.Err("This exact statement was already imported (" + before.fileName + ").")
            }
            val sid = dao.insertStatement(
                NcStatementEntity(
                    fileName = fileName.ifBlank { "Pasted text" }.take(120),
                    fileSha256 = sha, importedAt = at, rowCount = parsed.rows.size
                )
            )
            val keys = NcStatementParser.rowKeys(parsed.rows)
            var added = 0
            var known = 0
            for (i in parsed.rows.indices) {
                val r = parsed.rows[i]
                val id = dao.insertRow(
                    NcRowEntity(
                        statementId = sid, rowKey = keys[i], rowNo = r.rowNo, coin = r.coin,
                        amountText = r.amountText, occurredAtUtc = r.occurredAtUtc
                    )
                )
                if (id == -1L) known += 1 else added += 1
            }
            audit.log(
                actor, "NC_STATEMENT_IMPORTED", "nc_statement", sid.toString(),
                "rows=" + parsed.rows.size + " new=" + added + " known=" + known, at
            )
            Outcome.Ok(NcImportResult(sid, parsed.rows.size, added, known, parsed.skippedLines))
        }
    }

    // ------------------------------------------------------------------ Piece 8D: matching

    /** Runs the matcher on everything still unmatched. Nothing is changed. */
    suspend fun runMatch(): NcMatchReport = NcMatcher.match(dao.unmatchedClaims(), dao.allUnmatchedRows())

    private suspend fun link(c: NcClaimEntity, r: NcRowEntity, status: String, actor: String, action: String, details: String) {
        dao.updateClaim(c.copy(status = status, matchedRowId = r.id))
        dao.updateRow(r.copy(matchedClaimId = c.id))
        audit.log(actor, action, "nc_claim", c.claimUid ?: c.id.toString(), details)
        team.onClaimVerified(c, r, actor)
    }

    private fun describe(c: NcClaimEntity, r: NcRowEntity): String =
        "claim " + c.coin + " " + c.amountText + " at " + c.claimedAtUtc + " UTC ms, row " + r.rowNo.ifBlank { "#" + r.id } +
            " " + r.coin + " " + r.amountText + " at " + r.occurredAtUtc + " UTC ms"

    /** Confirms ONE clear pair. The pair is re-checked against fresh data, so an old screen can never confirm something that changed. */
    suspend fun confirmPair(claimId: Long, rowId: Long, actor: String): Outcome<Unit> =
        db.withTransaction<Outcome<Unit>> {
            val report = runMatch()
            val pair = report.clear.firstOrNull { it.claim.id == claimId && it.row.id == rowId }
                ?: return@withTransaction Outcome.Err("This pair is no longer a clear match. Run the matching again.")
            link(pair.claim, pair.row, NcStatus.MATCHED, actor, "NC_MATCH_CONFIRMED", describe(pair.claim, pair.row))
            Outcome.Ok(Unit)
        }

    /** Confirms every clear pair found right now (the screen asks the manager first). Ambiguous groups are never touched. */
    suspend fun confirmAllClear(actor: String): Outcome<Int> =
        db.withTransaction<Outcome<Int>> {
            val report = runMatch()
            if (report.clear.isEmpty()) return@withTransaction Outcome.Err("There is no clear match to confirm.")
            for (p in report.clear) link(p.claim, p.row, NcStatus.MATCHED, actor, "NC_MATCH_CONFIRMED", describe(p.claim, p.row))
            Outcome.Ok(report.clear.size)
        }

    /** Manager links any unmatched claim to any unmatched row. A reason is required and is kept in the audit log. */
    suspend fun manualLink(claimId: Long, rowId: Long, note: String, actor: String): Outcome<Unit> {
        if (note.trim().length < 3) return Outcome.Err("Write a short reason for the manual link.")
        return db.withTransaction<Outcome<Unit>> {
            val c = dao.claimById(claimId) ?: return@withTransaction Outcome.Err("Claim not found.")
            val r = dao.rowById(rowId) ?: return@withTransaction Outcome.Err("Statement row not found.")
            if (c.status != NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim is already linked. Unlink it first.")
            if (r.matchedClaimId != null) return@withTransaction Outcome.Err("This statement row is already matched to another claim.")
            val same = c.coin == r.coin && NcMatcher.amountOf(c.amountText)?.compareTo(NcMatcher.amountOf(r.amountText) ?: java.math.BigDecimal.valueOf(-1)) == 0
            val gap = Math.abs(r.occurredAtUtc - c.claimedAtUtc) / 1000
            link(c, r, NcStatus.MANUAL, actor, "NC_MANUAL_LINK",
                note.trim().take(300) + " | " + describe(c, r) + " | same coin+amount=" + same + " | time gap " + gap + " s")
            Outcome.Ok(Unit)
        }
    }

    /** Undo a match (clear or manual). The claim and the row become free again. A reason is required. */
    suspend fun unlink(claimId: Long, note: String, actor: String): Outcome<Unit> {
        if (note.trim().length < 3) return Outcome.Err("Write a short reason for unlinking.")
        return db.withTransaction<Outcome<Unit>> {
            val c = dao.claimById(claimId) ?: return@withTransaction Outcome.Err("Claim not found.")
            if (c.status == NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim is not linked.")
            val r = dao.rowOfClaim(c.id)
            if (r != null) dao.updateRow(r.copy(matchedClaimId = null))
            dao.updateClaim(c.copy(status = NcStatus.UNMATCHED, matchedRowId = null))
            audit.log(actor, "NC_UNLINKED", "nc_claim", c.claimUid ?: c.id.toString(), note.trim().take(300) + " | was " + c.status)
            team.onClaimUnlinked(c.id, note.trim(), actor)
            Outcome.Ok(Unit)
        }
    }

    /** What the Review screen shows for one submission: the NC claims of that worker for that task, and what the check found. */
    suspend fun reviewLines(sub: SubmissionEntity): List<NcReviewLine> {
        val window = 36L * 60 * 60 * 1000
        val mine = dao.claimsOf(sub.workerId).filter {
            (it.taskId == sub.taskId || it.taskId == null) && Math.abs(it.claimedAtUtc - sub.submittedAt) <= window
        }
        if (mine.isEmpty()) return emptyList()
        val hasRows = dao.rowCountNow() > 0
        val report = runMatch()
        val out = ArrayList<NcReviewLine>()
        for (c in mine) {
            val head = "NC Wallet claim " + c.coin + " " + c.amountText + ": "
            when {
                c.status == NcStatus.MATCHED || c.status == NcStatus.MANUAL -> {
                    val r = dao.rowOfClaim(c.id)
                    val how = if (c.status == NcStatus.MANUAL) "linked by a manager (manual)" else "matched a statement row"
                    out.add(NcReviewLine("GOOD", head + how + (if (r != null) " (row " + r.rowNo.ifBlank { "#" + r.id } + ")" else "") + "."))
                }
                !hasRows -> out.add(NcReviewLine("INFO", head + "no NC Wallet statement has been imported yet."))
                else -> when (report.stateOf(c.id)) {
                    NcClaimState.CLEAR -> out.add(NcReviewLine("GOOD", head + "one statement row fits (same amount, within 2 minutes). Not confirmed yet: confirm it in NC Wallet > Matching."))
                    NcClaimState.AMBIGUOUS -> out.add(NcReviewLine("WARN", head + "more than one row or claim fits, so it needs your decision in NC Wallet > Matching."))
                    else -> out.add(NcReviewLine("WARN", head + "no matching row in the imported statements. The statement may not cover that time yet."))
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ Piece 8C: worker BNB claims

    companion object {
        val COIN_RULE = Regex("^[A-Z0-9]{2,10}$")
        private val AMOUNT_RULE = Regex("^[0-9]{1,18}(\\.[0-9]{1,18})?$")
        const val MAX_CLAIMS_PER_WORKER = 500
        const val MAX_AGE_MS = 90L * 24 * 60 * 60 * 1000
        const val FUTURE_TOLERANCE_MS = 10L * 60 * 1000

        /** Date "yyyy-MM-dd" and time "HH:mm" or "HH:mm:ss", both written in East Africa Time, to UTC milliseconds. */
        fun eatToUtc(date: String, time: String): Long? = try {
            val d = LocalDate.parse(date.trim())
            val t = LocalTime.parse(time.trim().let { if (it.length == 5) "$it:00" else it })
            d.atTime(t).atZone(TimeUtil.EAT).toInstant().toEpochMilli()
        } catch (e: Exception) {
            null
        }

        /** Exact amount text as the worker saw it in NC Wallet: spaces and thousands commas removed, digits and one dot only. */
        fun cleanAmount(raw: String): String? {
            val t = raw.replace(" ", "").replace(",", "")
            if (!AMOUNT_RULE.matches(t)) return null
            return try {
                if (BigDecimal(t).signum() <= 0) null else t
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun checkFields(coinRaw: String, amountRaw: String, claimedAtUtc: Long, at: Long): Outcome<Pair<String, String>> {
        val coin = coinRaw.trim().uppercase()
        if (!COIN_RULE.matches(coin)) return Outcome.Err("The coin must be 2 to 10 letters or digits, for example BNB.")
        val amount = cleanAmount(amountRaw)
            ?: return Outcome.Err("Enter the exact amount as NC Wallet shows it: digits and one dot, more than zero, for example 0.0125.")
        if (claimedAtUtc > at + FUTURE_TOLERANCE_MS) return Outcome.Err("That time is in the future. Check the date and time.")
        if (claimedAtUtc < at - MAX_AGE_MS) return Outcome.Err("That time is more than 90 days ago. Ask the manager for help with old deposits.")
        return Outcome.Ok(Pair(coin, amount))
    }

    /** Claim ids that already went into a report (after that a claim can no longer be changed or deleted). */
    suspend fun reportedUids(workerId: String): Set<String> =
        db.syncDao().outboxOf(workerId).map { it.itemKey }.filter { it.startsWith("NC:") }.map { it.removePrefix("NC:") }.toSet()

    suspend fun createClaim(
        workerId: String, coinRaw: String, amountRaw: String, claimedAtUtc: Long, taskId: String?, at: Long = System.currentTimeMillis()
    ): Outcome<NcClaimEntity> = db.withTransaction<Outcome<NcClaimEntity>> {
        val w = db.workerDao().get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
        if (!w.active) return@withTransaction Outcome.Err("Your account is disabled by the manager.")
        val f = checkFields(coinRaw, amountRaw, claimedAtUtc, at)
        val pair = when (f) {
            is Outcome.Err -> return@withTransaction Outcome.Err(f.message)
            is Outcome.Ok -> f.value
        }
        val coin = pair.first
        val amount = pair.second
        if (dao.claimCountOf(workerId) >= MAX_CLAIMS_PER_WORKER) return@withTransaction Outcome.Err("Too many claims on this phone. Ask the manager.")
        val tid = taskId?.takeIf { it.isNotBlank() && db.taskDao().get(it) != null }
        val uid = UUID.randomUUID().toString()
        val c = NcClaimEntity(
            workerId = workerId, coin = coin, amountText = amount, claimedAtUtc = claimedAtUtc,
            timezoneContext = "EAT", status = NcStatus.UNMATCHED, createdAt = at, claimUid = uid, taskId = tid
        )
        val id = dao.insertClaim(c)
        audit.log("worker:$workerId", "NC_CLAIM_MADE", "nc_claim", uid, "$coin $amount", at)
        Outcome.Ok(c.copy(id = id))
    }

    /** Change a claim that was not reported yet. */
    suspend fun updateClaim(
        workerId: String, uid: String, coinRaw: String, amountRaw: String, claimedAtUtc: Long, taskId: String?, at: Long = System.currentTimeMillis()
    ): Outcome<NcClaimEntity> = db.withTransaction<Outcome<NcClaimEntity>> {
        val c = dao.claimByUid(uid)
        if (c == null || c.workerId != workerId) return@withTransaction Outcome.Err("Claim not found.")
        if (uid in reportedUids(workerId)) return@withTransaction Outcome.Err("This claim was already sent to the manager and cannot be changed.")
        if (c.status != NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim was already checked and cannot be changed.")
        val f = checkFields(coinRaw, amountRaw, claimedAtUtc, at)
        val pair = when (f) {
            is Outcome.Err -> return@withTransaction Outcome.Err(f.message)
            is Outcome.Ok -> f.value
        }
        val coin = pair.first
        val amount = pair.second
        val tid = taskId?.takeIf { it.isNotBlank() && db.taskDao().get(it) != null }
        val u = c.copy(coin = coin, amountText = amount, claimedAtUtc = claimedAtUtc, taskId = tid)
        dao.updateClaim(u)
        audit.log("worker:$workerId", "NC_CLAIM_EDITED", "nc_claim", uid, "$coin $amount", at)
        Outcome.Ok(u)
    }

    suspend fun deleteClaim(workerId: String, uid: String, at: Long = System.currentTimeMillis()): Outcome<Unit> =
        db.withTransaction<Outcome<Unit>> {
            val c = dao.claimByUid(uid)
            if (c == null || c.workerId != workerId) return@withTransaction Outcome.Err("Claim not found.")
            if (uid in reportedUids(workerId)) return@withTransaction Outcome.Err("This claim was already sent to the manager and cannot be deleted.")
            if (c.status != NcStatus.UNMATCHED) return@withTransaction Outcome.Err("This claim was already checked and cannot be deleted.")
            dao.deleteClaim(c.id)
            audit.log("worker:$workerId", "NC_CLAIM_DELETED", "nc_claim", uid, "${c.coin} ${c.amountText}", at)
            Outcome.Ok(Unit)
        }
}
