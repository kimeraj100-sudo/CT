package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import java.util.UUID

/**
 * Piece R4a — spending referral points (data, rules and the two signed messages; the screens come in R4b and R4c).
 *
 * Flow: the worker asks to use [points] either as a CASH-OUT (the manager pays UGX = points x the UGX-per-point rate at the moment of
 * approval) or for a GIFT (the manager says what the gift is). The request travels to the manager phone inside the normal report
 * (type POINTS_REQ). The MANAGER decides: APPROVE writes a negative REDEEM entry into the points ledger (so the balance really drops)
 * and fixes the UGX amount; REJECT needs a reason. The decision travels back as a normal update (type POINTS_DECISION). Later the manager
 * marks it PAID / GIVEN. Spending points never lowers the worker's status (status counts awarded referrals, not points).
 * Nothing is promised: the worker's screen says the manager decides if and when points can be used.
 */
object PointsReqStatus { const val OPEN = "OPEN"; const val APPROVED = "APPROVED"; const val REJECTED = "REJECTED"; const val CANCELLED = "CANCELLED" }
object PointsReqKind { const val CASHOUT = "CASHOUT"; const val GIFT = "GIFT" }

@Entity(tableName = "points_requests", indices = [Index("workerId"), Index("status")])
data class PointsRequestEntity(
    @PrimaryKey val uid: String,              // "PR-" + 32 hex, made on the worker phone
    val workerId: String,
    val points: Int,
    val kind: String,                         // PointsReqKind
    val note: String,                         // the worker's words (for a gift: what they would like)
    val status: String,                       // PointsReqStatus
    val createdAt: Long,
    val decidedAt: Long? = null,
    val decisionNote: String = "",
    val ugxAmount: Long? = null,              // cash-out value, fixed when approved
    val ugxRate: Long = 0L,                   // UGX per point used for it
    val giftText: String = "",                // what the manager gives for a GIFT
    val paidAt: Long? = null,                 // when the manager paid / gave it
    val ver: Int = 0                          // number of manager changes (a late old decision message never undoes a newer one)
)

@Dao
interface PointsRequestDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(r: PointsRequestEntity)
    @Update suspend fun update(r: PointsRequestEntity)
    @Query("SELECT * FROM points_requests WHERE uid = :uid") suspend fun get(uid: String): PointsRequestEntity?
    @Query("SELECT * FROM points_requests WHERE workerId = :w ORDER BY createdAt DESC") suspend fun of(w: String): List<PointsRequestEntity>
    @Query("SELECT * FROM points_requests WHERE workerId = :w ORDER BY createdAt DESC") fun observeOf(w: String): Flow<List<PointsRequestEntity>>
    @Query("SELECT * FROM points_requests ORDER BY createdAt DESC") fun observeAll(): Flow<List<PointsRequestEntity>>
    @Query("SELECT COUNT(*) FROM points_requests WHERE workerId = :w AND status = 'OPEN'") suspend fun openCountOf(w: String): Int
    @Query("SELECT COALESCE(SUM(points), 0) FROM points_requests WHERE workerId = :w AND status = 'OPEN'") suspend fun openPointsOf(w: String): Int
    @Query("SELECT COUNT(*) FROM points_requests WHERE status = 'OPEN'") fun observeOpenCount(): Flow<Int>
}

/** What applying a decision on the worker phone did. */
class PointsDecisionResult(val ok: Boolean, val changed: Boolean, val title: String, val detail: String)

/** The two message bodies (kept apart from the sync file so they are easy to read and check). */
object PointsRequestCodec {
    const val NOTE_MAX = 300
    const val GIFT_MAX = 200
    private val ID_RULE = Regex("^PR-[0-9a-f]{32}$")

    fun idOk(id: String): Boolean = ID_RULE.matches(id)

    /** Worker -> manager (rides in the normal report). */
    fun requestBody(r: PointsRequestEntity): JSONObject =
        JSONObject().put("id", r.uid).put("pt", r.points).put("kd", r.kind).put("nt", r.note.take(NOTE_MAX)).put("at", r.createdAt)

    /** Manager -> worker (rides in the normal update). The same data gives the same message; every manager change raises `ver`. */
    fun decisionBody(r: PointsRequestEntity): JSONObject =
        JSONObject().put("id", r.uid).put("st", r.status).put("ver", r.ver).put("pt", r.points).put("kd", r.kind)
            .put("nt", r.decisionNote.take(NOTE_MAX)).put("at", r.decidedAt ?: 0L)
            .put("ug", r.ugxAmount ?: 0L).put("ur", r.ugxRate).put("gf", r.giftText.take(GIFT_MAX)).put("pd", r.paidAt ?: 0L)

    /** Worker phone: uses a decision if it is valid and newer than what this phone has. */
    suspend fun apply(db: CTDatabase, workerId: String, b: JSONObject): PointsDecisionResult {
        val id = b.optString("id")
        val st = b.optString("st")
        val ver = b.optInt("ver", 0)
        val ug = b.optLong("ug", 0L)
        val ur = b.optLong("ur", 0L)
        val paid = b.optLong("pd", 0L)
        if (!ID_RULE.matches(id) || ver <= 0 || (st != PointsReqStatus.APPROVED && st != PointsReqStatus.REJECTED) ||
            ug < 0L || ug > 100_000_000_000L || ur < 0L || ur > 1_000_000L || paid < 0L
        ) return PointsDecisionResult(false, false, "Points decision not used", "The points decision in this message is not valid.")
        val dao = db.pointsRequestDao()
        val r = dao.get(id) ?: return PointsDecisionResult(false, false, "Not found on this phone", "This points request is not on this phone. Nothing was used.")
        if (r.workerId != workerId) return PointsDecisionResult(false, false, "Points decision not used", "That request belongs to someone else. Nothing was used.")
        if (ver <= r.ver) return PointsDecisionResult(true, false, "Points decision already up to date", "A newer or equal decision for this request was already applied.")
        val u = r.copy(
            status = st, ver = ver, decidedAt = b.optLong("at", 0L).takeIf { it > 0L },
            decisionNote = b.optString("nt").take(NOTE_MAX),
            ugxAmount = if (ug > 0L) ug else null, ugxRate = ur, giftText = b.optString("gf").take(GIFT_MAX),
            paidAt = paid.takeIf { it > 0L }
        )
        dao.update(u)
        val what = if (r.kind == PointsReqKind.CASHOUT) "cash-out of " + r.points + " points" else "gift for " + r.points + " points"
        val title = when {
            st == PointsReqStatus.REJECTED -> "Points request not approved"
            u.paidAt != null -> "Points request paid"
            else -> "Points request approved"
        }
        return PointsDecisionResult(true, true, title, "Your $what: " + title.lowercase() + ".")
    }
}

class PointsRequestRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.pointsRequestDao()
    private val refDao = db.referralDao()

    companion object {
        const val MIN_POINTS = 1
        const val MAX_POINTS = 100_000
        const val NOTE_MIN = 5
        const val GIFT_MIN = 3
    }

    private fun now() = System.currentTimeMillis()

    fun observeOf(workerId: String): Flow<List<PointsRequestEntity>> = dao.observeOf(workerId)
    fun observeAll(): Flow<List<PointsRequestEntity>> = dao.observeAll()
    fun observeOpenCount(): Flow<Int> = dao.observeOpenCount()

    // ---------------------------------------------------------------- worker phone

    /**
     * The worker asks to use points. Checked against the LAST FIGURES THE MANAGER SENT (the worker phone has no ledger of its own), so
     * the manager checks the real balance again when deciding. One open request at a time.
     */
    suspend fun request(workerId: String, points: Int, kind: String, note: String): Outcome<String> = db.withTransaction {
        if (kind != PointsReqKind.CASHOUT && kind != PointsReqKind.GIFT) return@withTransaction Outcome.Err("Choose cash-out or gift.")
        if (points < MIN_POINTS || points > MAX_POINTS) return@withTransaction Outcome.Err("Ask for between $MIN_POINTS and $MAX_POINTS points.")
        val n = note.trim()
        if (n.length > PointsRequestCodec.NOTE_MAX) return@withTransaction Outcome.Err("Keep the note under ${PointsRequestCodec.NOTE_MAX} characters.")
        if (kind == PointsReqKind.GIFT && n.length < GIFT_MIN) return@withTransaction Outcome.Err("Write what gift you would like (at least $GIFT_MIN characters).")
        if (db.workerDao().get(workerId) == null) return@withTransaction Outcome.Err("Your worker record was not found.")
        val view = ReferralViewCodec.load(db, workerId)
            ?: return@withTransaction Outcome.Err("Your points figures have not arrived yet. Ask the manager to send you an update first.")
        if (dao.openCountOf(workerId) > 0) return@withTransaction Outcome.Err("You already have a request waiting for the manager. Wait for the answer first.")
        if (points > view.balance) return@withTransaction Outcome.Err("You have " + view.balance + " points (as of the manager's last update).")
        val uid = "PR-" + UUID.randomUUID().toString().replace("-", "")
        dao.insert(PointsRequestEntity(uid = uid, workerId = workerId, points = points, kind = kind, note = n, status = PointsReqStatus.OPEN, createdAt = now()))
        audit.log("worker:$workerId", "POINTS_REQUEST_MADE", "points_request", uid, "points=$points kind=$kind")
        Outcome.Ok(uid)
    }

    /** A worker can take a request back only while it was never put into a report (the manager phone has not seen it). */
    suspend fun cancel(workerId: String, uid: String): Outcome<Unit> = db.withTransaction {
        val r = dao.get(uid) ?: return@withTransaction Outcome.Err("Request not found.")
        if (r.workerId != workerId) return@withTransaction Outcome.Err("Request not found.")
        if (r.status != PointsReqStatus.OPEN) return@withTransaction Outcome.Err("This request was already answered.")
        if (db.syncDao().outboxOf(workerId).any { it.itemKey == "PTR:" + uid })
            return@withTransaction Outcome.Err("This request was already sent to the manager. Ask the manager to reject it instead.")
        dao.update(r.copy(status = PointsReqStatus.CANCELLED))
        audit.log("worker:$workerId", "POINTS_REQUEST_CANCELLED", "points_request", uid, "")
        Outcome.Ok(Unit)
    }

    // ---------------------------------------------------------------- manager phone

    /** A request arrived in a report. Idempotent by its id. Returns true when it is new. */
    suspend fun accept(workerId: String, uid: String, points: Int, kind: String, note: String, createdAt: Long, actor: String): Outcome<Boolean> = db.withTransaction {
        val old = dao.get(uid)
        if (old != null) {
            return@withTransaction if (old.workerId == workerId) Outcome.Ok(false) else Outcome.Err("This request number already belongs to a different worker.")
        }
        if (!PointsRequestCodec.idOk(uid)) return@withTransaction Outcome.Err("The request number is not valid.")
        if (kind != PointsReqKind.CASHOUT && kind != PointsReqKind.GIFT) return@withTransaction Outcome.Err("The request type is not valid.")
        if (points < MIN_POINTS || points > MAX_POINTS) return@withTransaction Outcome.Err("The number of points is not valid.")
        if (db.workerDao().get(workerId) == null) return@withTransaction Outcome.Err("The worker has no record on this phone.")
        val at = if (createdAt in 1..(now() + 24L * 3_600_000L)) createdAt else now()
        dao.insert(PointsRequestEntity(uid = uid, workerId = workerId, points = points, kind = kind, note = note.trim().take(PointsRequestCodec.NOTE_MAX), status = PointsReqStatus.OPEN, createdAt = at))
        audit.log(actor, "POINTS_REQUEST_RECEIVED", "points_request", uid, "worker=$workerId points=$points kind=$kind")
        Outcome.Ok(true)
    }

    /**
     * The manager's decision. APPROVE: the REAL ledger balance must cover the points; a negative REDEEM entry is written; a cash-out gets
     * UGX = points x the current UGX-per-point (set in Referrals > Rules, must be above 0); a gift needs the text of the gift.
     * REJECT: a reason is required. Once decided, it cannot be decided again.
     */
    suspend fun decide(uid: String, approve: Boolean, giftText: String, note: String, actor: String): Outcome<PointsRequestEntity> = db.withTransaction {
        val r = dao.get(uid) ?: return@withTransaction Outcome.Err("Request not found.")
        if (r.status != PointsReqStatus.OPEN) return@withTransaction Outcome.Err("This request was already decided (" + r.status.lowercase() + ").")
        val at = now()
        val n = note.trim()
        if (!approve) {
            if (n.length < NOTE_MIN) return@withTransaction Outcome.Err("Write a reason (at least $NOTE_MIN characters).")
            val u = r.copy(status = PointsReqStatus.REJECTED, decidedAt = at, decisionNote = n.take(PointsRequestCodec.NOTE_MAX), ver = r.ver + 1)
            dao.update(u)
            audit.log(actor, "POINTS_REQUEST_REJECTED", "points_request", uid, "worker=" + r.workerId + " points=" + r.points + " note=" + n)
            return@withTransaction Outcome.Ok(u)
        }
        val bal = refDao.balanceOf(r.workerId)
        if (bal < r.points) return@withTransaction Outcome.Err("The worker's real balance is $bal points, less than the " + r.points + " asked for. Reject it or ask the worker to ask again.")
        var rate = 0L
        var ugx: Long? = null
        var gift = ""
        if (r.kind == PointsReqKind.CASHOUT) {
            rate = ReferralRepository(db, audit).ugxPerPoint()
            if (rate <= 0L) return@withTransaction Outcome.Err("UGX per point is 0. Set it first in Referrals > Rules (main manager).")
            ugx = ReferralRules.ugxFor(r.points, rate)
        } else {
            gift = giftText.trim()
            if (gift.length < GIFT_MIN) return@withTransaction Outcome.Err("Write what the gift is (at least $GIFT_MIN characters).")
            gift = gift.take(PointsRequestCodec.GIFT_MAX)
        }
        val what = if (ugx != null) "cash-out UGX $ugx ($rate per point)" else "gift: $gift"
        refDao.addPoints(PointsEntryEntity(workerId = r.workerId, points = -r.points, kind = PointsKind.REDEEM, refKey = uid, note = "Points used, $what", actor = actor, createdAt = at))
        val u = r.copy(status = PointsReqStatus.APPROVED, decidedAt = at, decisionNote = n.take(PointsRequestCodec.NOTE_MAX), ugxAmount = ugx, ugxRate = rate, giftText = gift, ver = r.ver + 1)
        dao.update(u)
        audit.log(actor, "POINTS_REQUEST_APPROVED", "points_request", uid, "worker=" + r.workerId + " points=" + r.points + " " + what)
        Outcome.Ok(u)
    }

    /** After the manager really paid the UGX or handed over the gift. Tells the worker with the next update. */
    suspend fun markPaid(uid: String, actor: String): Outcome<PointsRequestEntity> = db.withTransaction {
        val r = dao.get(uid) ?: return@withTransaction Outcome.Err("Request not found.")
        if (r.status != PointsReqStatus.APPROVED) return@withTransaction Outcome.Err("Only an approved request can be marked as paid.")
        if (r.paidAt != null) return@withTransaction Outcome.Err("This request was already marked as paid.")
        val u = r.copy(paidAt = now(), ver = r.ver + 1)
        dao.update(u)
        audit.log(actor, "POINTS_REQUEST_PAID", "points_request", uid, "worker=" + r.workerId + " points=" + r.points)
        Outcome.Ok(u)
    }
}
