package com.ctteam.app.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.EnrollPreview
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.SyncIncoming
import com.ctteam.app.data.SyncStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Piece 5A — screens for the signed-message core.
 *  - Worker phone: [WorkerSyncCard] shows the key code, makes the enrollment message and a test message.
 *  - Manager phone: [ManagerSyncScreen] imports pasted text or a file, asks approval for enrollments,
 *    verifies test messages, lists connected workers.
 * Messages move by copy / share / save-as-file; nothing here needs internet.
 */

private val OK_GREEN = Color(0xFF3DDC97)
private val BAD_RED = Color(0xFFFF8A8A)
private const val MAX_IMPORT_BYTES = 300_000

/** Shows one generated message with COPY / SHARE / SAVE AS FILE. */
@Composable
private fun CodeOutput(label: String, code: String, fileName: String) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var note by remember(code) { mutableStateOf("") }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) } != null
                    } catch (ex: Exception) {
                        false
                    }
                }
                note = if (ok) "File saved." else "Could not save the file."
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            code.take(48) + "…  (" + code.length + " characters)",
            color = CT.TextSoft, fontSize = 11.sp, fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = "COPY",
            modifier = Modifier.fillMaxWidth(),
            onClick = { clipboard.setText(AnnotatedString(code)); note = "Copied. Paste it into a private chat with the manager." }
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "SHARE", modifier = Modifier.weight(1f), onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, code)
                }
                context.startActivity(Intent.createChooser(send, "Send to the manager"))
            })
            GhostButton(text = "SAVE AS FILE", modifier = Modifier.weight(1f), onClick = { saver.launch(fileName) })
        }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(note, color = OK_GREEN, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ WORKER PHONE

/** Card on the worker home screen (real worker only, never in the demo). */
@Composable
fun WorkerSyncCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    var keyCheck by remember { mutableStateOf("") }
    var enrollment by remember { mutableStateOf<String?>(null) }
    var test by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var open by remember { mutableStateOf(false) }

    LaunchedEffect(workerId) {
        val k = repos.sync.ensureKey(workerId)
        keyCheck = repos.sync.keyCheckOf(k.keyHex)
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Connect to the manager", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(
            "Your reports and the manager's replies travel as signed messages that only you and the manager can make. " +
                "Do this once: send your connection code to the manager in a PRIVATE chat, never in a group.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        if (keyCheck.isNotEmpty()) InfoRow("Your key code", keyCheck)
        Text("The manager sees the same code when adding you. Read it to them by phone to be sure nobody swapped the message.", color = CT.TextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        if (!open) {
            GhostButton(text = "SHOW CONNECTION OPTIONS", modifier = Modifier.fillMaxWidth(), onClick = { open = true })
        } else {
            GoldButton(text = "MAKE MY CONNECTION CODE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeEnrollment(workerId)) {
                        is Outcome.Ok -> { enrollment = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            enrollment?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Connection code (send to the manager once)", it, "ct-connect.txt") }
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "MAKE A TEST MESSAGE", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    when (val r = repos.sync.makeTest(workerId, "Test from the worker app")) {
                        is Outcome.Ok -> { test = r.value; message = "" }
                        is Outcome.Err -> message = r.message
                    }
                }
            })
            test?.let { Spacer(Modifier.height(8.dp)); CodeOutput("Test message (each one can be accepted only once)", it, "ct-test.txt") }
            if (message.isNotEmpty()) Text(message, color = BAD_RED, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ MANAGER PHONE

private class SyncRow(val workerId: String, val name: String, val status: SyncStatus?)

@Composable
private fun EnrollCard(preview: EnrollPreview, busy: Boolean, onApprove: () -> Unit, onCancel: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("New connection request", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        InfoRow("Name", preview.fullName)
        InfoRow("National ID", preview.nationalId)
        InfoRow("Payout number", preview.phoneLocal + " (" + preview.network + ")")
        InfoRow("KEY CODE", preview.keyCheck)
        Spacer(Modifier.height(4.dp))
        Text(
            "Ask the worker to read their key code aloud (phone call). Approve only if it is identical to the code above.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (preview.warning != null) {
            Spacer(Modifier.height(6.dp))
            Text(preview.warning, color = CT.GoldLight, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (preview.problem != null) {
            Text("Cannot approve: " + preview.problem, color = BAD_RED, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else if (preview.mode == "ALREADY") {
            GhostButton(text = "CLOSE", onClick = onCancel, modifier = Modifier.fillMaxWidth())
        } else {
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "KEY CODE MATCHES — APPROVE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (!busy) onApprove() }
            )
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "CANCEL", onClick = onCancel, modifier = Modifier.fillMaxWidth(), danger = true)
        }
    }
}

@Composable
fun ManagerSyncScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var pasted by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<SyncIncoming.Enroll?>(null) }
    var pendingText by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<SyncIncoming.Done?>(null) }
    var busy by remember { mutableStateOf(false) }
    var refresh by remember { mutableStateOf(0) }
    var resetAsk by remember { mutableStateOf<String?>(null) }

    val keysFlow = remember(repos) { repos.sync.observeKeys() }
    val keys by keysFlow.collectAsState(initial = emptyList())
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workersFlow.collectAsState(initial = emptyList())
    var rows by remember { mutableStateOf<List<SyncRow>>(emptyList()) }
    LaunchedEffect(keys, workers, refresh) {
        rows = keys.map { k ->
            SyncRow(k.workerId, workers.firstOrNull { it.id == k.workerId }?.fullName() ?: "(unknown)", repos.sync.status(k.workerId))
        }
    }

    fun process(text: String) {
        if (busy) return
        busy = true
        result = null
        pending = null
        scope.launch {
            when (val r = repos.sync.receive(text)) {
                is SyncIncoming.Enroll -> { pending = r; pendingText = text }
                is SyncIncoming.Done -> result = r
            }
            refresh++
            busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { ins ->
                            val buf = ByteArray(MAX_IMPORT_BYTES + 1)
                            var n = 0
                            while (n < buf.size) {
                                val r = ins.read(buf, n, buf.size - n)
                                if (r < 0) break
                                n += r
                            }
                            if (n > MAX_IMPORT_BYTES) null else String(buf, 0, n, Charsets.UTF_8)
                        }
                    } catch (ex: Exception) {
                        null
                    }
                }
                if (text == null) result = SyncIncoming.Done(false, "Could not read the file", "The file is unreadable or too large for a CT Team message.")
                else process(text)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Sync", onBack)
        Text(
            "Messages from workers arrive as text or a small file (copy, Telegram, share). Paste or open them here. " +
                "Every message is checked with the worker's secret key and can only be accepted once.",
            color = CT.TextSoft, fontSize = 13.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Import a message", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            CTField(pasted, { pasted = it }, "Paste the message here", singleLine = false, minLines = 3)
            Spacer(Modifier.height(8.dp))
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "CHECK PASTED MESSAGE",
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (pasted.isNotBlank()) { val t = pasted; pasted = ""; process(t) } }
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.weight(1f), onClick = {
                    val t = clipboard.getText()?.text ?: ""
                    if (t.isNotBlank()) process(t)
                    else result = SyncIncoming.Done(false, "Clipboard is empty", "Copy the worker's message first.")
                })
                GhostButton(text = "OPEN FILE", modifier = Modifier.weight(1f), onClick = { filePicker.launch(arrayOf("*/*")) })
            }
        }

        pending?.let { p ->
            EnrollCard(
                preview = p.preview, busy = busy,
                onCancel = { pending = null; pendingText = "" },
                onApprove = {
                    busy = true
                    val t = pendingText
                    scope.launch {
                        result = when (val r = repos.sync.acceptEnrollment(t, actor)) {
                            is Outcome.Ok -> SyncIncoming.Done(true, "Worker connected", r.value)
                            is Outcome.Err -> SyncIncoming.Done(false, "Not approved", r.message)
                        }
                        pending = null
                        pendingText = ""
                        refresh++
                        busy = false
                    }
                }
            )
        }

        result?.let { r ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) OK_GREEN else BAD_RED, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(r.detail, color = Color.White, fontSize = 13.sp)
            }
        }

        Text("Connected workers (${rows.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (rows.isEmpty()) Text("No worker is connected yet. A worker makes a connection code in their app (Connect to the manager).", color = CT.TextSoft, fontSize = 13.sp)
        for (row in rows) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(row.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                row.status?.let {
                    InfoRow("Key code", it.keyCheck)
                    InfoRow("Messages received", it.received.toString() + (if (it.lastSeq > 0) " (latest #" + it.lastSeq + ")" else ""))
                }
                Spacer(Modifier.height(6.dp))
                if (resetAsk == row.workerId) {
                    Text(
                        "This forgets the worker's key and message history. They must connect again and you must compare the key code. Use it only after a reinstall or a new phone.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "YES, RESET SYNC KEY", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = row.workerId
                        scope.launch { repos.sync.resetKey(id, actor); resetAsk = null; refresh++ }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = null })
                } else {
                    GhostButton(text = "RESET SYNC KEY", modifier = Modifier.fillMaxWidth(), onClick = { resetAsk = row.workerId })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
