package com.ctteam.app.data

import android.util.Base64
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/*
 * PIECE 5A — SYNC CORE (no server: messages travel as text or a small file by copy/paste, share, Telegram, etc.)
 *
 * Wire format of every message ("envelope"), one line of text with no spaces:
 *     CT1.<base64url(JSON header+body)>.<HMAC-SHA256 hex of "CT1.<base64url>">
 * JSON header: v (1), t (type), w (worker id), d (direction W2M worker->manager / M2W manager->worker),
 *              s (sequence number, per worker + direction), ts (sender clock, UTC millis), b (body object).
 * The HMAC key is a 32-byte per-worker secret created on the worker's phone. The manager's phone learns it
 * once, in the ENROLL message, which the manager must approve by hand (compare the key check code by voice).
 *
 * HONEST LIMITS: the enrollment message carries the key, so it must travel on a private channel (a direct
 * message to the manager, not a group). HMAC proves a message came from someone holding the worker's key and was
 * not changed; it cannot prove who holds the phone. Keys are stored inside the app's private database (not in the
 * Android Keystore) and must be covered by the encrypted backup of Piece 11.
 */

// ------------------------------------------------------------------ TABLES

@Entity(tableName = "sync_keys")
data class SyncKeyEntity(
    @PrimaryKey val workerId: String,
    val keyHex: String,           // 64 hex chars = 32 random bytes
    val createdAt: Long
)

/** Every accepted message (worker, direction, seq). The primary key makes a second copy impossible to accept. */
@Entity(tableName = "sync_seen", primaryKeys = ["workerId", "direction", "seq"])
data class SyncSeenEntity(
    val workerId: String,
    val direction: String,
    val seq: Long,
    val type: String,
    val receivedAt: Long
)

@Dao
interface SyncDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putKey(k: SyncKeyEntity): Long
    @Query("SELECT * FROM sync_keys WHERE workerId = :w") suspend fun key(w: String): SyncKeyEntity?
    @Query("SELECT * FROM sync_keys ORDER BY createdAt DESC") fun observeKeys(): Flow<List<SyncKeyEntity>>
    @Query("DELETE FROM sync_keys WHERE workerId = :w") suspend fun deleteKey(w: String)

    /** Returns -1 when this (worker, direction, seq) was already accepted. */
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun markSeen(s: SyncSeenEntity): Long
    @Query("SELECT COALESCE(MAX(seq), 0) FROM sync_seen WHERE workerId = :w AND direction = :d")
    suspend fun maxSeen(w: String, d: String): Long
    @Query("SELECT COUNT(*) FROM sync_seen WHERE workerId = :w AND direction = :d")
    suspend fun seenCount(w: String, d: String): Int
    @Query("DELETE FROM sync_seen WHERE workerId = :w") suspend fun deleteSeen(w: String)

    // Linking a manager-added worker to the worker's own id (same National ID, different id).
    @Query("UPDATE workers SET id = :newId WHERE id = :oldId") suspend fun relinkWorkerRow(oldId: String, newId: String)
    @Query("UPDATE phone_history SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkPhoneHistory(oldId: String, newId: String)
    @Query("UPDATE submissions SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkSubmissions(oldId: String, newId: String)
    @Query("UPDATE payout_requests SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkPayouts(oldId: String, newId: String)
    @Query("UPDATE nc_claims SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkClaims(oldId: String, newId: String)
    @Query("UPDATE support_messages SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkSupport(oldId: String, newId: String)
}

// ------------------------------------------------------------------ CODEC (pure, no database)

class Envelope(
    val signed: String,           // "CT1.<base64url>" — exactly what the HMAC covers
    val mac: String,
    val type: String,
    val workerId: String,
    val direction: String,
    val seq: Long,
    val ts: Long,
    val body: JSONObject
) {
    /** The message exactly as it travels (used to hand a single message back to the repository). */
    val wire: String get() = "$signed.$mac"
}

object SyncCodec {
    const val PREFIX = "CT1"
    const val W2M = "W2M"
    const val M2W = "M2W"

    private val rnd = SecureRandom()
    private val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val WRAPPED = Regex("CT1\\.([A-Za-z0-9_\\-\\s]+)\\.((?:[0-9a-fA-F]\\s*){64})")

    fun newKeyHex(): String {
        val b = ByteArray(32)
        rnd.nextBytes(b)
        return toHex(b)
    }

    fun toHex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) {
            val v = x.toInt() and 0xff
            sb.append("0123456789abcdef"[v shr 4]).append("0123456789abcdef"[v and 0x0f])
        }
        return sb.toString()
    }

    fun fromHex(s: String): ByteArray? {
        if (s.isEmpty() || s.length % 2 != 0) return null
        return try {
            ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        } catch (ex: NumberFormatException) {
            null
        }
    }

    fun isKeyHex(s: String): Boolean = s.length == 64 && s.all { it in '0'..'9' || it in 'a'..'f' }

    fun hmacHex(keyHex: String, message: String): String {
        val key = fromHex(keyHex) ?: throw IllegalArgumentException("bad key")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return toHex(mac.doFinal(message.toByteArray(Charsets.UTF_8)))
    }

    /** Short code both phones can show and read aloud (e.g. 7F3-A92) to check they hold the same key. */
    fun keyCheck(keyHex: String): String {
        val h = Hashing.sha256Hex("CTKEY|$keyHex").take(6).uppercase()
        return h.substring(0, 3) + "-" + h.substring(3)
    }

    fun seal(keyHex: String, type: String, workerId: String, direction: String, seq: Long, ts: Long, body: JSONObject): String {
        val header = JSONObject()
            .put("v", 1).put("t", type).put("w", workerId).put("d", direction)
            .put("s", seq).put("ts", ts).put("b", body)
        val b64 = Base64.encodeToString(header.toString().toByteArray(Charsets.UTF_8), FLAGS)
        val signed = "$PREFIX.$b64"
        return signed + "." + hmacHex(keyHex, signed)
    }

    /**
     * Finds EVERY CT1 message inside pasted text (chat apps add spaces, line breaks and extra words; a manager may
     * paste many messages at once). Does NOT check signatures — call [verify] with the right key afterwards.
     */
    fun parseAll(text: String): List<Envelope> = WRAPPED.findAll(text).mapNotNull { readMatch(it) }.toList()

    fun parse(text: String): Envelope? = parseAll(text).firstOrNull()

    private fun readMatch(m: MatchResult): Envelope? {
        val b64 = m.groupValues[1].filter { !it.isWhitespace() }
        val mac = m.groupValues[2].filter { !it.isWhitespace() }.lowercase()
        if (b64.isEmpty() || mac.length != 64) return null
        return try {
            val json = JSONObject(String(Base64.decode(b64, FLAGS), Charsets.UTF_8))
            if (json.optInt("v", 0) != 1) return null
            val type = json.optString("t")
            val worker = json.optString("w")
            val dir = json.optString("d")
            if (type.isBlank() || worker.isBlank() || (dir != W2M && dir != M2W)) return null
            Envelope(
                signed = "$PREFIX.$b64", mac = mac, type = type, workerId = worker, direction = dir,
                seq = json.getLong("s"), ts = json.optLong("ts", 0L), body = json.optJSONObject("b") ?: JSONObject()
            )
        } catch (ex: Exception) {
            null
        }
    }

    fun verify(keyHex: String, env: Envelope): Boolean = try {
        MessageDigest.isEqual(hmacHex(keyHex, env.signed).toByteArray(Charsets.UTF_8), env.mac.toByteArray(Charsets.UTF_8))
    } catch (ex: Exception) {
        false
    }
}

// ------------------------------------------------------------------ RESULTS

/** What the manager sees before approving a worker's enrollment message. */
class EnrollPreview(
    val workerId: String,
    val fullName: String,
    val nationalId: String,
    val phoneLocal: String,
    val network: String,
    val keyCheck: String,
    val mode: String,             // NEW, LINK (existing manager-added worker, same National ID), ATTACH, ALREADY
    val problem: String?,         // blocks approval
    val warning: String?
)

sealed class SyncIncoming {
    class Enroll(val preview: EnrollPreview, val wire: String) : SyncIncoming()
    class Done(val ok: Boolean, val title: String, val detail: String) : SyncIncoming()
}

class SyncStatus(val keyCheck: String, val lastSeq: Long, val received: Int)

// ------------------------------------------------------------------ REPOSITORY

class SyncRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.syncDao()
    private val meta = db.metaDao()

    companion object {
        const val TYPE_ENROLL = "ENROLL"
        const val TYPE_PING = "PING"
        /** Message types this app version can process on the manager phone. Pieces 5B/5C add more. */
        val MANAGER_TYPES = setOf(TYPE_PING)
        private val ID_RULE = Regex("^[A-Za-z0-9\\-]{8,64}$")
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- keys + counters

    /** The worker phone creates its secret the first time it is needed. */
    suspend fun ensureKey(workerId: String): SyncKeyEntity = db.withTransaction {
        dao.key(workerId) ?: SyncKeyEntity(workerId, SyncCodec.newKeyHex(), now()).also { dao.putKey(it) }
    }

    suspend fun keyOf(workerId: String): SyncKeyEntity? = dao.key(workerId)

    fun observeKeys(): Flow<List<SyncKeyEntity>> = dao.observeKeys()

    suspend fun nextSeq(workerId: String, direction: String): Long = db.withTransaction {
        val k = "sync:out:$direction:$workerId"
        val n = (meta.get(k)?.toLongOrNull() ?: 0L) + 1L
        meta.put(MetaEntity(k, n.toString()))
        n
    }

    suspend fun status(workerId: String): SyncStatus? {
        val k = dao.key(workerId) ?: return null
        return SyncStatus(
            keyCheck = SyncCodec.keyCheck(k.keyHex),
            lastSeq = dao.maxSeen(workerId, SyncCodec.W2M),
            received = dao.seenCount(workerId, SyncCodec.W2M)
        )
    }

    // ---------------------------------------------------------------- worker phone: create messages

    /** The one-time enrollment message: who I am + my secret key. Same text every time (seq 0), safe to send again. */
    suspend fun makeEnrollment(workerId: String): Outcome<String> {
        val w = db.workerDao().get(workerId) ?: return Outcome.Err("Worker not found.")
        val k = ensureKey(workerId)
        val body = JSONObject()
            .put("nin", w.nationalId).put("fn", w.firstName).put("mn", w.middleName).put("ln", w.lastName)
            .put("ph", w.phone).put("nw", w.network).put("ca", w.createdAt).put("k", k.keyHex)
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_ENROLL, workerId, SyncCodec.W2M, 0L, w.createdAt, body))
    }

    /** A small signed test message so worker and manager can check the whole path works. */
    suspend fun makeTest(workerId: String, note: String): Outcome<String> {
        if (db.workerDao().get(workerId) == null) return Outcome.Err("Worker not found.")
        val k = ensureKey(workerId)
        val seq = nextSeq(workerId, SyncCodec.W2M)
        val body = JSONObject().put("note", note.trim().take(200))
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_PING, workerId, SyncCodec.W2M, seq, now(), body))
    }

    fun keyCheckOf(keyHex: String): String = SyncCodec.keyCheck(keyHex)

    // ---------------------------------------------------------------- manager phone: receive

    /** Entry point for pasted text or an imported file on the manager phone: any number of messages at once. */
    suspend fun receiveAll(text: String): List<SyncIncoming> {
        val all = SyncCodec.parseAll(text)
        if (all.isEmpty())
            return listOf(SyncIncoming.Done(false, "Not a CT Team message", "No valid CT1 code was found in what you pasted. Copy the whole code and try again."))
        return all.map { receiveEnvelope(it) }
    }

    private suspend fun receiveEnvelope(env: Envelope): SyncIncoming {
        if (env.direction != SyncCodec.W2M)
            return SyncIncoming.Done(false, "Wrong phone", "This message is meant for a worker's phone, not the manager's.")

        if (env.type == TYPE_ENROLL) return SyncIncoming.Enroll(previewOf(env), env.wire)

        if (env.type !in MANAGER_TYPES)
            return SyncIncoming.Done(false, "Not supported yet", "This message type (${env.type}) needs a newer version of the app. It was NOT used and can be sent again later.")

        val key = dao.key(env.workerId)
            ?: return SyncIncoming.Done(false, "Unknown worker", "This phone has no key for that worker. The worker must send an enrollment message first.")
        if (!SyncCodec.verify(key.keyHex, env)) {
            audit.event("SYNC_REJECTED", "bad signature, worker=${env.workerId}, type=${env.type}, seq=${env.seq}")
            return SyncIncoming.Done(false, "REJECTED: signature does not match", "The message was changed, damaged, or not made with this worker's key. Nothing was used.")
        }
        val name = db.workerDao().get(env.workerId)?.fullName() ?: "worker"
        return db.withTransaction<SyncIncoming> {
            val before = dao.maxSeen(env.workerId, env.direction)
            if (dao.markSeen(SyncSeenEntity(env.workerId, env.direction, env.seq, env.type, now())) == -1L) {
                return@withTransaction SyncIncoming.Done(false, "Already received", "Message #${env.seq} from $name was accepted before. Ignored (replay protection).")
            }
            val gap = if (env.seq > before + 1L)
                "\nMessages #${before + 1L} to #${env.seq - 1L} have not arrived yet. They can still be accepted if they turn up later."
            else ""
            when (env.type) {
                TYPE_PING -> {
                    audit.event("SYNC_PING", "worker=${env.workerId}, seq=${env.seq}")
                    val note = env.body.optString("note")
                    SyncIncoming.Done(true, "Verified: message #${env.seq} from $name",
                        "Signature is valid and this is the first time it was received." + (if (note.isNotBlank()) "\nNote: $note" else "") + gap)
                }
                else -> SyncIncoming.Done(false, "Not supported yet", "Unknown type.")
            }
        }
    }

    private suspend fun previewOf(env: Envelope): EnrollPreview {
        val keyHex = env.body.optString("k")
        val nin = env.body.optString("nin").trim().uppercase()
        val first = env.body.optString("fn").trim()
        val middle = env.body.optString("mn").trim()
        val last = env.body.optString("ln").trim()
        val full = listOf(first, middle, last).filter { it.isNotBlank() }.joinToString(" ")
        val phone = PhoneUtil.parse(env.body.optString("ph"))

        fun bad(msg: String) = EnrollPreview(
            env.workerId, full.ifBlank { "?" }, nin, phone?.national ?: "?", phone?.network ?: "?",
            if (SyncCodec.isKeyHex(keyHex)) SyncCodec.keyCheck(keyHex) else "?", "NONE", msg, null
        )

        if (!ID_RULE.matches(env.workerId)) return bad("The worker id in this message is not valid.")
        if (!SyncCodec.isKeyHex(keyHex)) return bad("The key in this message is not valid.")
        if (!SyncCodec.verify(keyHex, env)) return bad("The code is damaged or was changed after it was made.")
        if (nin.length != WorkerRepository.NIN_LENGTH || !nin.all { it.isLetterOrDigit() }) return bad("The National ID in this message is not valid.")
        if (first.isBlank() || last.isBlank()) return bad("The worker's name is missing.")
        if (phone == null) return bad("The payout number in this message is not a valid MTN/Airtel number.")

        val check = SyncCodec.keyCheck(keyHex)
        fun pv(mode: String, problem: String? = null, warning: String? = null) =
            EnrollPreview(env.workerId, full, nin, phone.national, phone.network, check, mode, problem, warning)

        val existingKey = dao.key(env.workerId)
        if (existingKey != null) {
            return if (existingKey.keyHex == keyHex) pv("ALREADY", warning = "This worker is already connected with this same key. Nothing to do.")
            else pv("NONE", problem = "This worker is already connected with a DIFFERENT key. Do not accept. If the worker reinstalled the app, open the worker in Sync and use RESET SYNC KEY first, then check the key code by voice.")
        }

        val byId = db.workerDao().get(env.workerId)
        val byNin = db.workerDao().getByNationalId(nin)
        val byPhone = db.workerDao().getByPhone(phone.digits)

        if (byNin != null && byNin.id != env.workerId) {
            if (dao.key(byNin.id) != null)
                return pv("NONE", problem = "This National ID already belongs to another connected worker (${byNin.fullName()}).")
            val phoneClash = byPhone != null && byPhone.id != byNin.id
            if (phoneClash) return pv("NONE", problem = "The payout number already belongs to another worker (${byPhone?.fullName()}).")
            val warn = "Worker \"${byNin.fullName()}\" was already added on this phone with this National ID. Approving links the two. The existing record and its history are kept." +
                (if (byNin.phone != phone.digits) "\nPayout numbers differ: this phone has 0" + byNin.phone.substring(3) + ", the worker's phone has " + phone.national + ". The number on this phone stays; payout requests will show the number the worker used." else "")
            return pv("LINK", warning = warn)
        }
        if (byId != null) return pv("ATTACH", warning = "This worker already exists on this phone. Approving only adds the secret key.")
        if (byPhone != null) return pv("NONE", problem = "The payout number already belongs to another worker (${byPhone.fullName()}).")
        return pv("NEW")
    }

    /** Manager approved the enrollment shown by [previewOf]. Everything is checked again inside one transaction. */
    suspend fun acceptEnrollment(text: String, actor: String): Outcome<String> {
        val env = SyncCodec.parse(text) ?: return Outcome.Err("Not a CT Team message.")
        if (env.type != TYPE_ENROLL || env.direction != SyncCodec.W2M) return Outcome.Err("This is not an enrollment message.")
        return db.withTransaction<Outcome<String>> {
            val p = previewOf(env)
            if (p.problem != null) return@withTransaction Outcome.Err(p.problem)
            if (p.mode == "ALREADY") return@withTransaction Outcome.Ok("Already connected. Nothing changed.")
            val keyHex = env.body.optString("k")
            val phone = PhoneUtil.parse(env.body.optString("ph"))
                ?: return@withTransaction Outcome.Err("The payout number is not valid.")
            val at = now()
            when (p.mode) {
                "NEW" -> {
                    val created = env.body.optLong("ca", 0L).let { if (it in 1..at) it else at }
                    db.workerDao().insert(
                        WorkerEntity(
                            id = env.workerId, nationalId = p.nationalId,
                            firstName = env.body.optString("fn").trim(), middleName = env.body.optString("mn").trim(),
                            lastName = env.body.optString("ln").trim(), phone = phone.digits, network = phone.network,
                            createdAt = created
                        )
                    )
                    db.workerDao().insertPhone(PhoneHistoryEntity(workerId = env.workerId, phone = phone.digits, network = phone.network, changedAt = at, reason = "REGISTRATION"))
                }
                "LINK" -> {
                    val old = db.workerDao().getByNationalId(p.nationalId)
                        ?: return@withTransaction Outcome.Err("The existing worker record disappeared. Try again.")
                    dao.relinkWorkerRow(old.id, env.workerId)
                    dao.relinkPhoneHistory(old.id, env.workerId)
                    dao.relinkSubmissions(old.id, env.workerId)
                    dao.relinkPayouts(old.id, env.workerId)
                    dao.relinkClaims(old.id, env.workerId)
                    dao.relinkSupport(old.id, env.workerId)
                }
                "ATTACH" -> Unit
                else -> return@withTransaction Outcome.Err("Cannot approve this message.")
            }
            dao.putKey(SyncKeyEntity(env.workerId, keyHex, at))
            audit.log(actor, "SYNC_ENROLLED", "worker", env.workerId, "mode=${p.mode} keycheck=${p.keyCheck}", at)
            Outcome.Ok(p.fullName + " is now connected (key code " + p.keyCheck + ").")
        }
    }

    /** Main recovery tool: forget a worker's key and message history so they can enroll again (new phone / reinstall). */
    suspend fun resetKey(workerId: String, actor: String): Outcome<Unit> {
        db.withTransaction {
            dao.deleteKey(workerId)
            dao.deleteSeen(workerId)
        }
        audit.log(actor, "SYNC_KEY_RESET", "worker", workerId, "key and message history cleared; worker must enroll again")
        return Outcome.Ok(Unit)
    }
}
