package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.security.SecureRandom
import java.util.UUID

/**
 * Piece R1 — referral rewards: data and rules (manager phone is the authority).
 *
 * Rules decided with the owner's idea ("refer workers, get status and points; points can become money or gifts; status = easier access"):
 *  - Every connected worker has ONE referral code (CT-XXXXX). A new worker types it once; each worker has at most ONE referrer.
 *  - A referral only counts when the referred worker has real, APPROVED work (default 3 approved submissions). Signing up alone earns nothing.
 *  - The manager looks at each ready referral and taps AWARD. Points are added to an append-only ledger, once per referred worker.
 *  - Single level only: points come only from workers you referred yourself, never from their referrals (no chains).
 *  - STATUS comes from how many referrals were awarded (Member, Connector, Builder, Leader, Champion). Spending points does not lower it.
 *  - Points become money or gifts only when the manager approves (piece R5). The UGX per point is typed by the manager.
 */
object RefStatus { const val PENDING = "PENDING"; const val AWARDED = "AWARDED"; const val REJECTED = "REJECTED" }
object PointsKind { const val REFERRAL = "REFERRAL"; const val BONUS = "BONUS"; const val ADJUST = "ADJUST"; const val REDEEM = "REDEEM" }

@Entity(tableName = "referral_codes", indices = [Index(value = ["code"], unique = true)])
data class ReferralCodeEntity(
    @PrimaryKey val workerId: String,
    val code: String,
    val createdAt: Long
)

@Entity(tableName = "referrals", indices = [Index("referrerId")])
data class ReferralEntity(
    @PrimaryKey val referredId: String,   // one referrer per worker
    val referrerId: String,
    val code: String,
    val createdAt: Long,
    val status: String,                   // RefStatus
    val decidedAt: Long? = null,
    val note: String = ""
)

@Entity(tableName = "points_ledger", indices = [Index(value = ["workerId", "kind", "refKey"], unique = true), Index("workerId")])
data class PointsEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val points: Int,                      // signed: + earned, - spent or removed
    val kind: String,                     // PointsKind
    val refKey: String,                   // referred worker id for REFERRAL, a random id for the others (unique per kind)
    val note: String,
    val actor: String,
    val createdAt: Long
)

@Dao
interface ReferralDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putCode(c: ReferralCodeEntity)
    @Query("SELECT * FROM referral_codes WHERE workerId = :w") suspend fun codeOf(w: String): ReferralCodeEntity?
    @Query("SELECT * FROM referral_codes WHERE code = :code LIMIT 1") suspend fun byCode(code: String): ReferralCodeEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun putReferral(r: ReferralEntity)
    @Query("SELECT * FROM referrals WHERE referredId = :id") suspend fun referral(id: String): ReferralEntity?
    @Query("SELECT * FROM referrals ORDER BY createdAt DESC") fun observeReferrals(): Flow<List<ReferralEntity>>
    @Query("SELECT * FROM referrals WHERE referrerId = :w ORDER BY createdAt DESC") suspend fun referralsBy(w: String): List<ReferralEntity>
    @Query("UPDATE referrals SET status = :status, decidedAt = :at, note = :note WHERE referredId = :id") suspend fun decide(id: String, status: String, at: Long, note: String)
    @Query("SELECT COUNT(*) FROM referrals WHERE referrerId = :w AND status = 'AWARDED'") suspend fun awardedCount(w: String): Int

    @Query("SELECT COUNT(*) FROM submissions WHERE workerId = :w AND status = 'APPROVED' AND superseded = 0") suspend fun approvedOf(w: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun addPoints(e: PointsEntryEntity): Long
    @Query("SELECT COALESCE(SUM(points), 0) FROM points_ledger WHERE workerId = :w") suspend fun balanceOf(w: String): Int
    @Query("SELECT COALESCE(SUM(points), 0) FROM points_ledger WHERE workerId = :w") fun observeBalance(w: String): Flow<Int>
    @Query("SELECT * FROM points_ledger WHERE workerId = :w ORDER BY id DESC LIMIT :limit") suspend fun entriesOf(w: String, limit: Int): List<PointsEntryEntity>
    @Query("SELECT * FROM points_ledger ORDER BY id DESC LIMIT :limit") fun observeEntries(limit: Int): Flow<List<PointsEntryEntity>>
    @Query("SELECT workerId, COALESCE(SUM(points), 0) AS total FROM points_ledger GROUP BY workerId") fun observeBalances(): Flow<List<PointsBalance>>
}

class PointsBalance(val workerId: String, val total: Int)

/** Pure rules, kept apart from the database so they are easy to check. */
object ReferralRules {
    class Tier(val name: String, val minAwarded: Int, val perk: String)

    val TIERS: List<Tier> = listOf(
        Tier("Member", 0, "Every task you are allowed to see"),
        Tier("Connector", 1, "A first referral was awarded"),
        Tier("Builder", 3, "Eligible for tasks that need Builder status"),
        Tier("Leader", 7, "Eligible for tasks that need Leader status"),
        Tier("Champion", 15, "Eligible for tasks that need Champion status")
    )

    const val DEFAULT_POINTS = 100        // per awarded referral
    const val DEFAULT_NEED_APPROVED = 3   // approved submissions the referred worker needs
    const val DEFAULT_UGX_PER_POINT = 50L // only used when the manager approves a points-to-money request

    fun tierOf(awarded: Int): Tier = TIERS.last { awarded >= it.minAwarded }
    fun nextTier(awarded: Int): Tier? = TIERS.firstOrNull { it.minAwarded > awarded }
    fun rankOf(name: String): Int = TIERS.indexOfFirst { it.name.equals(name, ignoreCase = true) }.coerceAtLeast(0)
    fun isReady(approved: Int, need: Int): Boolean = approved >= need
    fun ugxFor(points: Int, ugxPerPoint: Long): Long = points.toLong() * ugxPerPoint

    /** Code alphabet has no 0/O/1/I/L so a code read out over the phone is not mistaken. */
    const val ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ"
    const val CODE_LEN = 5

    /** "ct-abcde", "CTABCDE", " CT ABCDE " all become "CT-ABCDE"; anything else is returned as typed (it simply will not match). */
    fun normalizeCode(raw: String): String {
        val s = raw.uppercase().filter { it.isLetterOrDigit() }
        return if (s.length == 2 + CODE_LEN && s.startsWith("CT")) "CT-" + s.substring(2) else s
    }
}

/** One line of the manager's referral list. */
class ReferralLine(
    val referral: ReferralEntity, val referrerName: String, val referredName: String,
    val approved: Int, val need: Int
) {
    val ready: Boolean get() = referral.status == RefStatus.PENDING && ReferralRules.isReady(approved, need)
}

class ReferralRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.referralDao()
    private val meta = db.metaDao()
    private val random = SecureRandom()

    companion object {
        const val KEY_POINTS = "ref:pts"
        const val KEY_NEED = "ref:need"
        const val KEY_UGX = "ref:ugxpp"
        const val NOTE_MIN = 5
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- settings (manager types them; every change is audited)

    suspend fun pointsPerAward(): Int = meta.get(KEY_POINTS)?.toIntOrNull()?.takeIf { it in 1..100000 } ?: ReferralRules.DEFAULT_POINTS
    suspend fun needApproved(): Int = meta.get(KEY_NEED)?.toIntOrNull()?.takeIf { it in 1..100 } ?: ReferralRules.DEFAULT_NEED_APPROVED
    suspend fun ugxPerPoint(): Long = meta.get(KEY_UGX)?.toLongOrNull()?.takeIf { it in 0..1_000_000 } ?: ReferralRules.DEFAULT_UGX_PER_POINT

    suspend fun saveSettings(points: Int, need: Int, ugxPerPoint: Long, actor: String): Outcome<Unit> {
        if (points !in 1..100000) return Outcome.Err("Points per referral must be between 1 and 100000.")
        if (need !in 1..100) return Outcome.Err("Approved submissions needed must be between 1 and 100.")
        if (ugxPerPoint !in 0..1_000_000) return Outcome.Err("UGX per point must be between 0 and 1,000,000.")
        meta.put(MetaEntity(KEY_POINTS, points.toString()))
        meta.put(MetaEntity(KEY_NEED, need.toString()))
        meta.put(MetaEntity(KEY_UGX, ugxPerPoint.toString()))
        audit.log(actor, "REFERRAL_SETTINGS", "settings", "referral", "points=$points need=$need ugxPerPoint=$ugxPerPoint")
        return Outcome.Ok(Unit)
    }

    // ---------------------------------------------------------------- codes

    private fun newCode(): String {
        val sb = StringBuilder("CT-")
        repeat(ReferralRules.CODE_LEN) { sb.append(ReferralRules.ALPHABET[random.nextInt(ReferralRules.ALPHABET.length)]) }
        return sb.toString()
    }

    /** The worker's code; made the first time it is asked for. Never changes afterwards. */
    suspend fun codeFor(workerId: String): String = db.withTransaction {
        dao.codeOf(workerId)?.code ?: run {
            var c = newCode()
            while (dao.byCode(c) != null) c = newCode()
            dao.putCode(ReferralCodeEntity(workerId, c, now()))
            c
        }
    }

    // ---------------------------------------------------------------- linking

    /**
     * Records that [referredId] used someone's code. Refused: unknown code, your own code, a second referrer, or anything that
     * would make a circle (A refers B, B refers C, C refers A). Nothing is paid here; the referral waits for real approved work.
     */
    suspend fun link(referredId: String, rawCode: String, actor: String): Outcome<Unit> {
        val referred = db.workerDao().get(referredId) ?: return Outcome.Err("That worker was not found.")
        val code = ReferralRules.normalizeCode(rawCode)
        val owner = dao.byCode(code) ?: return Outcome.Err("This code is not known. Check it and try again.")
        if (owner.workerId == referredId) return Outcome.Err("A worker cannot use their own code.")
        if (dao.referral(referredId) != null) return Outcome.Err(referred.fullName() + " already has a referrer. It cannot be changed.")
        // walk up from the referrer: if we meet the referred worker, it would be a circle
        var up: String? = owner.workerId
        var steps = 0
        while (up != null && steps < 20) {
            if (up == referredId) return Outcome.Err("This would make a circle of referrals.")
            up = dao.referral(up)?.referrerId
            steps++
        }
        dao.putReferral(ReferralEntity(referredId, owner.workerId, code, now(), RefStatus.PENDING))
        audit.log(actor, "REFERRAL_LINKED", "worker", referredId, "referrer=" + owner.workerId + " code=" + code)
        return Outcome.Ok(Unit)
    }

    suspend fun lines(): List<ReferralLine> {
        val need = needApproved()
        val names = db.workerDao().all().associate { it.id to it.fullName() }
        return allReferrals().map { r ->
            ReferralLine(r, names[r.referrerId] ?: "Unknown", names[r.referredId] ?: "Unknown", dao.approvedOf(r.referredId), need)
        }
    }

    private suspend fun allReferrals(): List<ReferralEntity> {
        val out = ArrayList<ReferralEntity>()
        for (w in db.workerDao().all()) out.addAll(dao.referralsBy(w.id))
        return out.sortedByDescending { it.createdAt }
    }

    // ---------------------------------------------------------------- awarding

    /** The manager's tap. Needs the referred worker to have enough APPROVED work. Once per referred worker (the ledger refuses a second). */
    suspend fun award(referredId: String, actor: String): Outcome<Int> = db.withTransaction {
        val r = dao.referral(referredId) ?: return@withTransaction Outcome.Err("No referral found for this worker.")
        if (r.status != RefStatus.PENDING) return@withTransaction Outcome.Err("This referral was already decided (" + r.status.lowercase() + ").")
        val need = needApproved()
        val approved = dao.approvedOf(referredId)
        if (!ReferralRules.isReady(approved, need)) return@withTransaction Outcome.Err("Not ready: $approved of $need approved submissions.")
        val pts = pointsPerAward()
        val name = db.workerDao().get(referredId)?.fullName() ?: "a worker"
        dao.addPoints(PointsEntryEntity(workerId = r.referrerId, points = pts, kind = PointsKind.REFERRAL, refKey = referredId, note = "Referral: $name", actor = actor, createdAt = now()))
        dao.decide(referredId, RefStatus.AWARDED, now(), "")
        audit.log(actor, "REFERRAL_AWARDED", "worker", r.referrerId, "referred=$referredId points=$pts")
        Outcome.Ok(pts)
    }

    suspend fun reject(referredId: String, note: String, actor: String): Outcome<Unit> {
        val r = dao.referral(referredId) ?: return Outcome.Err("No referral found for this worker.")
        if (r.status != RefStatus.PENDING) return Outcome.Err("This referral was already decided.")
        if (note.trim().length < NOTE_MIN) return Outcome.Err("Write a reason (at least $NOTE_MIN characters).")
        dao.decide(referredId, RefStatus.REJECTED, now(), note.trim())
        audit.log(actor, "REFERRAL_REJECTED", "worker", r.referrerId, "referred=$referredId note=" + note.trim())
        return Outcome.Ok(Unit)
    }

    // ---------------------------------------------------------------- points and status

    suspend fun balance(workerId: String): Int = dao.balanceOf(workerId)
    suspend fun awardedCount(workerId: String): Int = dao.awardedCount(workerId)
    suspend fun statusOf(workerId: String): ReferralRules.Tier = ReferralRules.tierOf(dao.awardedCount(workerId))

    /** Manual points: a positive BONUS (for example a campaign) or a negative ADJUST (a correction). A reason is required and audited. */
    suspend fun adjust(workerId: String, points: Int, note: String, actor: String): Outcome<Unit> = db.withTransaction {
        if (points == 0 || points < -100000 || points > 100000) return@withTransaction Outcome.Err("Enter points between -100000 and 100000 (not 0).")
        if (note.trim().length < NOTE_MIN) return@withTransaction Outcome.Err("Write a reason (at least $NOTE_MIN characters).")
        if (db.workerDao().get(workerId) == null) return@withTransaction Outcome.Err("That worker was not found.")
        if (points < 0 && dao.balanceOf(workerId) + points < 0) return@withTransaction Outcome.Err("That would take the balance below zero.")
        val kind = if (points > 0) PointsKind.BONUS else PointsKind.ADJUST
        dao.addPoints(PointsEntryEntity(workerId = workerId, points = points, kind = kind, refKey = UUID.randomUUID().toString(), note = note.trim(), actor = actor, createdAt = now()))
        audit.log(actor, "POINTS_" + kind, "worker", workerId, "points=$points note=" + note.trim())
        Outcome.Ok(Unit)
    }

    fun observeReferrals(): Flow<List<ReferralEntity>> = dao.observeReferrals()
    fun observeBalances(): Flow<List<PointsBalance>> = dao.observeBalances()
    fun observeEntries(limit: Int): Flow<List<PointsEntryEntity>> = dao.observeEntries(limit)
}
