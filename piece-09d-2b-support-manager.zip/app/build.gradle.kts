plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.ctteam.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ctteam.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 38
        versionName = "0.37.0"
    }

    // One fixed key for every build, so a new APK installs OVER the old one
    // and the app's local data (workers, tasks, history) is kept.
    signingConfigs {
        create("ct") {
            storeFile = file("ct-team.jks")
            storePassword = "ctteam123"
            keyAlias = "ctteam"
            keyPassword = "ctteam123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("ct")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("ct")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
        }
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")

    // Piece 2: local database (Room)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Piece 8A: read text out of PDF statements
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
