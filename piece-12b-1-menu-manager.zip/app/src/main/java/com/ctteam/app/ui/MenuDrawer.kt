package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Piece 12b-1 — the three-bar menu at the top right of a home screen. It holds everything that does not need to be on the home page
 * all day, grouped, with the same numbers (badges) the cards had. A small dot on the three bars means something in the menu needs you.
 */
class HamburgerItem(val title: String, val subtitle: String, val badge: String? = null, val onClick: () -> Unit)

class HamburgerGroup(val title: String, val items: List<HamburgerItem>)

/** The three gold bars (44 dp touch area). [dot] shows a small teal dot when the menu holds something waiting. */
@Composable
fun HamburgerButton(dot: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Open menu" },
        contentAlignment = Alignment.Center
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp), horizontalAlignment = Alignment.End) {
            Box(Modifier.width(24.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(CT.Gold))
            Box(Modifier.width(24.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(CT.Gold))
            Box(Modifier.width(24.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(CT.Gold))
        }
        if (dot) Box(Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp).size(10.dp).clip(CircleShape).background(CT.Teal))
    }
}

/** Same look as [ScreenHeader], with the three bars at the right edge. */
@Composable
fun ScreenHeaderMenu(title: String, onBack: (() -> Unit)?, dot: Boolean, onMenu: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Text(
                text = "←",
                color = CT.Gold,
                fontSize = 26.sp,
                modifier = Modifier
                    .clickable(onClick = onBack)
                    .padding(end = 16.dp, top = 4.dp, bottom = 4.dp)
            )
        }
        Text(
            text = title,
            color = CT.Gold,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            modifier = Modifier.weight(1f)
        )
        HamburgerButton(dot = dot, onClick = onMenu)
    }
}

/** Full-screen menu. Choosing an item closes the menu first, then opens the screen. The back button or CLOSE also close it. */
@Composable
fun HamburgerMenu(title: String, groups: List<HamburgerGroup>, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(CT.Navy)) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title, color = CT.Gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "✕", color = CT.Gold, fontSize = 24.sp,
                        modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                for (g in groups) {
                    if (g.items.isEmpty()) continue
                    Text(g.title.uppercase(), color = CT.TextSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    for (item in g.items) {
                        GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onClose(); item.onClick() }) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(item.title, color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                                if (item.badge != null) Text(item.badge, color = CT.Teal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text(item.subtitle, color = CT.TextSoft, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
