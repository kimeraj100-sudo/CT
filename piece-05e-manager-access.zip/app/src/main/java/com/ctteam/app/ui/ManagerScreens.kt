package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ManagerAccountEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.ProofEntity
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.data.PayoutStatus
import com.ctteam.app.data.PhoneHistoryEntity
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.SubmissionEntity
import com.ctteam.app.data.TaskEntity
import com.ctteam.app.data.TaskType
import com.ctteam.app.data.Verdict
import com.ctteam.app.data.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val ACTOR: String get() = ManagerSession.actor

/** Where the manager currently is inside the Manager area. */
sealed interface MgrRoute {
    object Dashboard : MgrRoute
    object Workers : MgrRoute
    class WorkerDetail(val id: String) : MgrRoute
    object Tasks : MgrRoute
    class TaskEdit(val id: String?) : MgrRoute
    object Review : MgrRoute
    object Managers : MgrRoute
    object MySecurity : MgrRoute
    object Sync : MgrRoute                      // Piece 5A
}

private class DashStats(
    val workers: Int, val activeWorkers: Int,
    val pending: Int, val approved: Int, val rejected: Int,
    val expectedUgx: Long, val inProgress: Int, val paid: Int,
    val auditOk: Boolean
)

private suspend fun loadStats(repos: Repos): DashStats {
    val w = repos.db.workerDao()
    val s = repos.db.submissionDao()
    val p = repos.db.payoutDao()
    return DashStats(
        workers = w.countAll(),
        activeWorkers = w.countActive(),
        pending = s.countByStatus(SubStatus.PENDING),
        approved = s.countByStatus(SubStatus.APPROVED),
        rejected = s.countByStatus(SubStatus.REJECTED),
        expectedUgx = s.allUnpaidApprovedTotal(),
        inProgress = p.countByStatus(PayoutStatus.IN_PROGRESS),
        paid = p.countByStatus(PayoutStatus.PAID),
        auditOk = repos.audit.verifyChain()
    )
}

/** Entry point of Manager mode: code name + password + PIN sign-in first (up to 20 managers), then the dashboard and its sub-screens. */
@Composable
fun ManagerArea(onExit: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val repos = remember { ServiceLocator.get(context) }

    var session by remember { mutableStateOf<ManagerAccountEntity?>(null) }
    var notice by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    var route by remember { mutableStateOf<MgrRoute>(MgrRoute.Dashboard) }
    var stats by remember { mutableStateOf<DashStats?>(null) }

    val me = session

    LaunchedEffect(me?.id, route) {
        if (me != null && route == MgrRoute.Dashboard) stats = loadStats(repos)
    }

    // If the main manager disables this manager (or their allowed period ends) while they are
    // working, they are signed out within a few seconds. The main manager is never signed out.
    LaunchedEffect(me?.id, me?.credVersion) {
        val s = me
        if (s != null && !s.isMain) {
            while (true) {
                delay(5000)
                val fresh = repos.db.managerAccountDao().get(s.id)
                if (fresh != null && fresh.credVersion != s.credVersion) {
                    notice = "Your sign-in details were changed or reset. Please sign in again."
                    ManagerSession.actor = "manager"
                    route = MgrRoute.Dashboard
                    session = null
                    break
                }
                if (fresh == null || repos.managerAccounts.blockReason(fresh) != null) {
                    notice = "Your manager access has been disabled by the main manager."
                    ManagerSession.actor = "manager"
                    route = MgrRoute.Dashboard
                    session = null
                    break
                }
            }
        }
    }

    BackHandler(enabled = me == null && importing) { importing = false }

    BackHandler(enabled = me != null && route != MgrRoute.Dashboard) {
        val r = route
        route = when (r) {
            is MgrRoute.WorkerDetail -> MgrRoute.Workers
            is MgrRoute.TaskEdit -> MgrRoute.Tasks
            else -> MgrRoute.Dashboard
        }
    }

    if (me == null) {
        if (importing) {
            ImportAccessCodeScreen(repos = repos, onBack = { importing = false })
        } else {
            Box(Modifier.fillMaxSize()) {
                ManagerAccessGate(
                    repos = repos,
                    notice = notice,
                    onUnlocked = { acc ->
                        ManagerSession.actor = "manager:" + acc.codeName
                        notice = ""
                        route = MgrRoute.Dashboard
                        session = acc
                    },
                    onExit = onExit
                )
                GhostButton(
                    text = "IMPORT ACCESS CODE",
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                    onClick = { importing = true }
                )
            }
        }
        return
    }

    when (val r = route) {
        is MgrRoute.Dashboard -> DashboardScreen(
            repos = repos, stats = stats, me = me, onExit = onExit,
            onWorkers = { route = MgrRoute.Workers },
            onTasks = { route = MgrRoute.Tasks },
            onReview = { route = MgrRoute.Review },
            onManagers = { route = MgrRoute.Managers },
            onSecurity = { route = MgrRoute.MySecurity },
            onSync = { route = MgrRoute.Sync }
        )
        is MgrRoute.Workers -> WorkersScreen(
            repos = repos,
            onBack = { route = MgrRoute.Dashboard },
            onOpen = { id -> route = MgrRoute.WorkerDetail(id) }
        )
        is MgrRoute.WorkerDetail -> WorkerDetailScreen(
            repos = repos, workerId = r.id, onBack = { route = MgrRoute.Workers }
        )
        is MgrRoute.Tasks -> TasksScreen(
            repos = repos,
            onBack = { route = MgrRoute.Dashboard },
            onOpen = { id -> route = MgrRoute.TaskEdit(id) }
        )
        is MgrRoute.TaskEdit -> TaskEditScreen(
            repos = repos, taskId = r.id, onDone = { route = MgrRoute.Tasks }
        )
        is MgrRoute.Review -> ReviewScreen(repos = repos, onBack = { route = MgrRoute.Dashboard })
        is MgrRoute.Sync -> ManagerSyncScreen(repos = repos, actor = ACTOR, onBack = { route = MgrRoute.Dashboard })
        is MgrRoute.MySecurity -> MySecurityScreen(
            repos = repos, me = me,
            onBack = { route = MgrRoute.Dashboard },
            onUpdated = { fresh -> session = fresh },
            onForgotDevice = { }
        )
        is MgrRoute.Managers -> {
            // Only the main manager can reach this screen (the menu card is hidden for others).
            if (me.isMain) {
                ManagersScreen(repos = repos, me = me, onBack = { route = MgrRoute.Dashboard })
            }
        }
    }
}

// ------------------------------------------------------------------ DASHBOARD

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier) {
    GlassCard(modifier = modifier) {
        Text(value, color = CT.GoldLight, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CT.TextSoft, fontSize = 12.sp)
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String, badge: String?, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (badge != null) Text(badge, color = CT.Teal, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Text(subtitle, color = CT.TextSoft, fontSize = 13.sp)
    }
}

@Composable
private fun DashboardScreen(
    repos: Repos, stats: DashStats?, me: ManagerAccountEntity, onExit: () -> Unit,
    onWorkers: () -> Unit, onTasks: () -> Unit, onReview: () -> Unit, onManagers: () -> Unit,
    onSecurity: () -> Unit, onSync: () -> Unit
) {
    val recentFlow = remember(repos) { repos.db.auditDao().observeRecent(6) }
    val recent by recentFlow.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Manager Dashboard", onExit)
        Text(
            "Signed in as " + me.codeName + (if (me.isMain) " · MAIN MANAGER" else ""),
            color = CT.Teal, fontSize = 13.sp, fontWeight = FontWeight.Bold
        )
        val s = stats
        if (s == null) {
            Text("Loading…", color = CT.TextSoft)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Workers", s.workers.toString(), Modifier.weight(1f))
                StatTile("Active", s.activeWorkers.toString(), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Pending review", s.pending.toString(), Modifier.weight(1f))
                StatTile("Approved", s.approved.toString(), Modifier.weight(1f))
                StatTile("Rejected", s.rejected.toString(), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Expected payouts", ugx(s.expectedUgx), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("Payouts in progress", s.inProgress.toString(), Modifier.weight(1f))
                StatTile("Payouts paid", s.paid.toString(), Modifier.weight(1f))
            }
            MenuCard("Review submissions", "Check proof, approve or reject", if (s.pending > 0) s.pending.toString() else null, onReview)
            MenuCard("Workers", "Add and manage your team", null, onWorkers)
            MenuCard("Tasks", "Create and edit tasks", null, onTasks)
            MenuCard("Sync", "Receive signed messages from workers, connect workers", null, onSync)
            if (me.isMain) MenuCard("Managers", "Add managers, reset to default, disable or enable access", null, onManagers)
            MenuCard("My security", "Change my PIN and password, this phone's quick unlock", null, onSecurity)
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Recent activity", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                if (recent.isEmpty()) Text("Nothing yet.", color = CT.TextSoft, fontSize = 13.sp)
                for (a in recent) {
                    Text(fmtTime(a.createdAt) + "  " + a.action.replace('_', ' ').lowercase(), color = Color.White, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    if (s.auditOk) "Audit log: intact ✔" else "Audit log: TAMPERING DETECTED ✖",
                    color = if (s.auditOk) CT.Teal else Color(0xFFFF6B6B), fontSize = 12.sp
                )
            }
        }
    }
}

// ------------------------------------------------------------------ WORKERS

@Composable
private fun WorkersScreen(repos: Repos, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val flow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by flow.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }

    BackHandler(enabled = adding) { adding = false }

    if (adding) {
        AddWorkerForm(repos = repos, onDone = { adding = false })
        return
    }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Workers", onBack)
        GoldButton(text = "+ ADD WORKER", onClick = { adding = true }, modifier = Modifier.fillMaxWidth())
        if (workers.isEmpty()) Text("No workers yet. Add your first worker.", color = CT.TextSoft)
        for (w in workers) {
            GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpen(w.id) }) {
                Text(w.fullName(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("0" + w.phone.substring(3) + " · " + w.network, color = CT.TextSoft, fontSize = 13.sp)
                Text(if (w.active) "Active" else "Disabled", color = if (w.active) CT.Teal else Color(0xFFFF8A8A), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AddWorkerForm(repos: Repos, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var nin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var middle by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenHeader("Add worker", onDone)
        Text(
            "The phone number must be an MTN or Airtel number registered in the worker's own name.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(nin, { nin = it.uppercase() }, "National ID (NIN)")
        CTField(first, { first = it }, "First name")
        CTField(middle, { middle = it }, "Middle name")
        CTField(last, { last = it }, "Last name")
        CTField(phone, { phone = it }, "MTN / Airtel number", keyboard = KeyboardType.Phone)
        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(text = "SAVE WORKER", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                val r = repos.workers.register(nin, first, middle, last, phone)
                if (r is Outcome.Err) error = r.message else onDone()
            }
        })
    }
}

@Composable
private fun WorkerDetailScreen(repos: Repos, workerId: String, onBack: () -> Unit) {
    val flow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by flow.collectAsState(initial = emptyList())
    val worker = workers.firstOrNull { it.id == workerId }
    if (worker == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            ScreenHeader("Worker", onBack)
            Text("Loading…", color = CT.TextSoft)
        }
        return
    }
    WorkerDetailBody(repos, worker, onBack)
}

@Composable
private fun WorkerDetailBody(repos: Repos, worker: WorkerEntity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var first by remember(worker.id) { mutableStateOf(worker.firstName) }
    var middle by remember(worker.id) { mutableStateOf(worker.middleName) }
    var last by remember(worker.id) { mutableStateOf(worker.lastName) }
    var newPhone by remember(worker.id) { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var history by remember { mutableStateOf<List<PhoneHistoryEntity>>(emptyList()) }

    LaunchedEffect(worker.id, worker.phone) { history = repos.db.workerDao().phoneHistory(worker.id) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(worker.fullName(), onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("National ID", worker.nationalId)
            InfoRow("Phone", "0" + worker.phone.substring(3) + " (" + worker.network + ")")
            InfoRow("Registered", fmtTime(worker.createdAt))
            InfoRow("Status", if (worker.active) "Active" else "Disabled")
        }
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)

        Text("Edit names", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        CTField(first, { first = it }, "First name")
        CTField(middle, { middle = it }, "Middle name")
        CTField(last, { last = it }, "Last name")
        GhostButton(text = "SAVE NAMES", onClick = {
            scope.launch {
                val r = repos.workers.editNames(worker.id, first, middle, last, ACTOR)
                message = if (r is Outcome.Err) r.message else "Names saved."
            }
        })

        Text("Change phone number", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Allowed once per week, and not while a payout is in progress.", color = CT.TextSoft, fontSize = 12.sp)
        CTField(newPhone, { newPhone = it }, "New MTN / Airtel number", keyboard = KeyboardType.Phone)
        GhostButton(text = "CHANGE NUMBER", onClick = {
            scope.launch {
                val r = repos.workers.changePhone(worker.id, newPhone, ACTOR)
                if (r is Outcome.Err) {
                    message = r.message
                } else {
                    message = "Phone number changed."
                    newPhone = ""
                }
            }
        })

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Worker active", color = Color.White)
            Switch(checked = worker.active, onCheckedChange = { on ->
                scope.launch { repos.workers.setActive(worker.id, on, ACTOR) }
            })
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Phone number history", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            for (h in history) {
                Text(fmtTime(h.changedAt) + "  0" + h.phone.substring(3) + "  " + h.reason, color = Color.White, fontSize = 12.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ TASKS

@Composable
private fun TasksScreen(repos: Repos, onBack: () -> Unit, onOpen: (String?) -> Unit) {
    val flow = remember(repos) { repos.db.taskDao().observeAll() }
    val tasks by flow.collectAsState(initial = emptyList())
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Tasks", onBack)
        GoldButton(text = "+ NEW TASK", onClick = { onOpen(null) }, modifier = Modifier.fillMaxWidth())
        if (tasks.isEmpty()) Text("No tasks yet. Create your first task.", color = CT.TextSoft)
        for (t in tasks) {
            GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpen(t.id) }) {
                Text(t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    ugx(t.payUgx) + " · " + (if (t.type == TaskType.DAILY) "Daily" else "One-time") + " · v" + t.version,
                    color = CT.TextSoft, fontSize = 13.sp
                )
                Text(if (t.active) "Active" else "Inactive", color = if (t.active) CT.Teal else Color(0xFFFF8A8A), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TaskEditScreen(repos: Repos, taskId: String?, onDone: () -> Unit) {
    var existing by remember { mutableStateOf<TaskEntity?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(taskId) {
        existing = if (taskId == null) null else repos.db.taskDao().get(taskId)
        loaded = true
    }
    if (!loaded) {
        Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Loading…", color = CT.TextSoft) }
        return
    }
    TaskForm(repos, existing, onDone)
}

@Composable
private fun TaskForm(repos: Repos, existing: TaskEntity?, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var pay by remember { mutableStateOf(existing?.payUgx?.toString() ?: "") }
    var type by remember { mutableStateOf(existing?.type ?: TaskType.DAILY) }
    var video by remember { mutableStateOf(existing?.exampleVideoUrl ?: "") }
    var link by remember { mutableStateOf(existing?.exampleLinkUrl ?: "") }
    var proofReq by remember { mutableStateOf(existing?.proofRequirements ?: "") }
    var verifyReq by remember { mutableStateOf(existing?.verificationRequirements ?: "") }
    var active by remember { mutableStateOf(existing?.active ?: true) }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ScreenHeader(if (existing == null) "New task" else "Edit task", onDone)
        CTField(name, { name = it }, "Task name")
        CTField(description, { description = it }, "Description / instructions", singleLine = false, minLines = 3)
        CTField(pay, { pay = it.filter { c -> c.isDigit() } }, "Payment (UGX)", keyboard = KeyboardType.Number)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CTChip("Daily", type == TaskType.DAILY, { type = TaskType.DAILY })
            CTChip("One-time", type == TaskType.ONE_TIME, { type = TaskType.ONE_TIME })
        }
        Text(
            if (type == TaskType.DAILY) "Daily tasks become available again the next day."
            else "One-time tasks can be done once unless you re-assign them.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        CTField(video, { video = it }, "Example video link (YouTube / TikTok)", keyboard = KeyboardType.Uri)
        CTField(link, { link = it }, "Other example link", keyboard = KeyboardType.Uri)
        CTField(proofReq, { proofReq = it }, "Proof required (screenshots, reference…)", singleLine = false, minLines = 2)
        CTField(verifyReq, { verifyReq = it }, "Extra verification required", singleLine = false, minLines = 2)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Task active", color = Color.White)
            Switch(checked = active, onCheckedChange = { active = it })
        }
        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(text = "SAVE TASK", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                val amount = pay.toLongOrNull() ?: 0L
                val result: Outcome<TaskEntity> = if (existing == null) {
                    repos.tasks.create(
                        name = name, description = description, payUgx = amount, type = type,
                        exampleVideoUrl = video, exampleLinkUrl = link,
                        proofRequirements = proofReq, verificationRequirements = verifyReq,
                        actor = ACTOR
                    )
                } else {
                    repos.tasks.update(
                        existing.copy(
                            name = name.trim(), description = description.trim(), payUgx = amount, type = type,
                            exampleVideoUrl = video.trim(), exampleLinkUrl = link.trim(),
                            proofRequirements = proofReq.trim(), verificationRequirements = verifyReq.trim(),
                            active = active
                        ),
                        ACTOR
                    )
                }
                if (result is Outcome.Err) error = result.message else onDone()
            }
        })
        if (existing != null) {
            Text("Saving creates version ${existing.version + 1}; older versions are kept in history.", color = CT.TextSoft, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ REVIEW

private fun verdictLabel(v: String): String = when (v) {
    Verdict.OK -> "🟢 Looks OK"
    Verdict.CHECK -> "🟡 Check carefully"
    Verdict.DONT_TRUST -> "🔴 Do not trust"
    else -> "⚪ Not checked"
}

@Composable
private fun ReviewScreen(repos: Repos, onBack: () -> Unit) {
    val pendingFlow = remember(repos) { repos.db.submissionDao().observePending() }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val tasksFlow = remember(repos) { repos.db.taskDao().observeAll() }
    val pending by pendingFlow.collectAsState(initial = emptyList())
    val workers by workersFlow.collectAsState(initial = emptyList())
    val tasks by tasksFlow.collectAsState(initial = emptyList())
    var selectedId by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = selectedId != null) { selectedId = null }

    val selected = pending.firstOrNull { it.id == selectedId }
    if (selected != null) {
        val wn = workers.firstOrNull { it.id == selected.workerId }?.fullName() ?: "Unknown worker"
        val tn = tasks.firstOrNull { it.id == selected.taskId }?.name ?: "Unknown task"
        ReviewDetail(repos, selected, wn, tn, onBack = { selectedId = null })
        return
    }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Review submissions", onBack)
        if (pending.isEmpty()) Text("Nothing waiting for review.", color = CT.TextSoft)
        for (s in pending) {
            val wn = workers.firstOrNull { it.id == s.workerId }?.fullName() ?: "Unknown worker"
            val tn = tasks.firstOrNull { it.id == s.taskId }?.name ?: "Unknown task"
            GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { selectedId = s.id }) {
                Text(tn, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(wn + " · " + ugx(s.payUgx), color = CT.TextSoft, fontSize = 13.sp)
                Text(fmtTime(s.submittedAt), color = CT.TextSoft, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ReviewDetail(repos: Repos, sub: SubmissionEntity, workerName: String, taskName: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var proofs by remember { mutableStateOf<List<ProofEntity>>(emptyList()) }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(sub.id) { proofs = repos.db.submissionDao().proofsFor(sub.id) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(taskName, onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Worker", workerName)
            InfoRow("Amount", ugx(sub.payUgx))
            InfoRow("Submitted", fmtTime(sub.submittedAt))
            InfoRow("Task version", "v" + sub.taskVersion)
            if (sub.referenceText.isNotBlank()) InfoRow("Reference", sub.referenceText)
            if (sub.explanation.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(sub.explanation, color = Color.White, fontSize = 13.sp)
            }
        }
        Text("Proof", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (proofs.isEmpty()) Text("No proof attached.", color = CT.TextSoft, fontSize = 13.sp)
        for (p in proofs) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(p.kind, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (!p.fileName.isNullOrBlank()) Text(p.fileName, color = CT.TextSoft, fontSize = 12.sp)
                if (p.width != null && p.height != null) Text(p.width.toString() + " × " + p.height, color = CT.TextSoft, fontSize = 12.sp)
                if (!p.textValue.isNullOrBlank()) Text(p.textValue, color = Color.White, fontSize = 13.sp)
                if (p.kind == "SCREENSHOT") {
                    Text(verdictLabel(p.verdict), color = CT.GoldLight, fontSize = 13.sp)
                    if (p.verdictNotes.isNotBlank()) Text(p.verdictNotes, color = CT.TextSoft, fontSize = 12.sp)
                }
            }
        }
        Text(
            "Automatic checks are only hints. They cannot prove a screenshot is genuine — the decision is yours.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        CTField(note, { note = it }, "Note to worker (required when rejecting)", singleLine = false, minLines = 2)
        if (error.isNotEmpty()) Text(error, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GoldButton(text = "APPROVE", modifier = Modifier.weight(1f), onClick = {
                scope.launch {
                    val r = repos.submissions.decide(sub.id, true, note, ACTOR)
                    if (r is Outcome.Err) error = r.message
                }
            })
            GhostButton(text = "REJECT", danger = true, modifier = Modifier.weight(1f), onClick = {
                if (note.isBlank()) {
                    error = "Please add a reason so the worker can learn from it."
                } else {
                    scope.launch {
                        val r = repos.submissions.decide(sub.id, false, note, ACTOR)
                        if (r is Outcome.Err) error = r.message
                    }
                }
            })
        }
    }
}
