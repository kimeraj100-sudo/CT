package com.ctteam.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ManagerAccountEntity
import com.ctteam.app.data.MgrImportResult
import com.ctteam.app.data.MgrPending
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val OK_GREEN = Color(0xFF3DDC97)
private val BAD_RED = Color(0xFFFF8A8A)
private const val MAX_FILE_BYTES = 300_000

private fun readTextFile(context: Context, uri: Uri): String? {
    return try {
        context.contentResolver.openInputStream(uri)?.use { ins ->
            val buf = ByteArray(MAX_FILE_BYTES + 1)
            var n = 0
            while (n < buf.size) {
                val r = ins.read(buf, n, buf.size - n)
                if (r < 0) break
                n += r
            }
            if (n > MAX_FILE_BYTES) null else String(buf, 0, n, Charsets.UTF_8)
        }
    } catch (ex: Exception) {
        null
    }
}

/** One signed access code with COPY / SHARE / SAVE AS FILE. */
@Composable
fun MgrCodeCard(label: String, code: String, fileName: String, who: String) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var note by remember(code) { mutableStateOf("") }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray(Charsets.UTF_8)) } != null
                    } catch (ex: Exception) {
                        false
                    }
                }
                note = if (ok) "File saved." else "Could not save the file."
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            code.take(40) + "…  (" + code.length + " characters)",
            color = CT.TextSoft, fontSize = 11.sp, fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(
            text = "COPY",
            modifier = Modifier.fillMaxWidth(),
            onClick = { clipboard.setText(AnnotatedString(code)); note = "Copied. Paste it into a private chat with $who." }
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "SHARE", modifier = Modifier.weight(1f), onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, code)
                }
                context.startActivity(Intent.createChooser(send, "Send to $who"))
            })
            GhostButton(text = "SAVE AS FILE", modifier = Modifier.weight(1f), onClick = { saver.launch(fileName) })
        }
        if (note.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(note, color = CT.TextSoft, fontSize = 12.sp)
        }
    }
}

// ------------------------------------------------------------------ MAIN MANAGER SIDE

/** Shows the main manager's signing key code (made on first use) so other managers can check it by voice. */
@Composable
fun MainKeyCard(repos: Repos, me: ManagerAccountEntity) {
    var keyCode by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf("") }
    LaunchedEffect(me.id) {
        val r = repos.managerSync.ensureOwnKeyCode(me)
        if (r is Outcome.Ok) keyCode = r.value else if (r is Outcome.Err) problem = r.message
    }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Your signing key code", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (keyCode.isNotEmpty()) {
            Text(keyCode, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = 3.sp)
            Text(
                "Every access code you make is signed with your key. A manager's phone asks the person to compare this code with you by phone " +
                    "the first time, so nobody can pretend to be the main manager. Read it out loud; never type it into a chat.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else if (problem.isNotEmpty()) {
            Text(problem, color = BAD_RED, fontSize = 12.sp)
        } else {
            Text("Making your key…", color = CT.TextSoft, fontSize = 12.sp)
        }
    }
}

/** In a manager's detail page: make the signed access code for THAT manager's phone. */
@Composable
fun AccessCodeCard(repos: Repos, me: ManagerAccountEntity, target: ManagerAccountEntity) {
    val scope = rememberCoroutineScope()
    var code by remember(target.id, target.pinHash, target.suspendedUntil, target.accessExpiresAt, target.codeName) {
        mutableStateOf<String?>(null)
    }
    var keyCode by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Access code for " + target.codeName, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Their phone only learns about this manager (new, reset, disabled, enabled, renamed) from a signed access code. " +
                "Make a fresh code after every change and send it to them in a private chat. Send the PIN separately (call or another chat). " +
                "On their phone: Manager > IMPORT ACCESS CODE. The code holds only this manager's account, never a password.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(text = "MAKE ACCESS CODE", modifier = Modifier.fillMaxWidth(), onClick = {
            scope.launch {
                val r = repos.managerSync.makeAccountCode(me, target.id)
                if (r is Outcome.Err) {
                    message = r.message
                } else if (r is Outcome.Ok) {
                    message = ""
                    code = r.value
                    val k = repos.managerSync.ensureOwnKeyCode(me)
                    if (k is Outcome.Ok) keyCode = k.value
                }
            }
        })
        if (message.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(message, color = BAD_RED, fontSize = 12.sp)
        }
        val c = code
        if (c != null) {
            Spacer(Modifier.height(8.dp))
            if (keyCode.isNotEmpty()) {
                Text("Key code to read to them by phone: $keyCode", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(6.dp))
            }
            MgrCodeCard(
                label = "Signed access code for " + target.codeName,
                code = c, fileName = "ct-access-" + target.codeName.lowercase().replace(' ', '-') + ".txt",
                who = target.codeName
            )
        }
    }
}

// ------------------------------------------------------------------ OTHER MANAGERS' PHONES

/**
 * Import the signed access codes the main manager sent. Works before signing in (a new manager has no account yet,
 * and a disabled manager must still receive the news).
 */
@Composable
fun ImportAccessCodeScreen(repos: Repos, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var pasted by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MgrImportResult>>(emptyList()) }
    var pending by remember { mutableStateOf<List<MgrPending>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var trustedCode by remember { mutableStateOf<String?>(null) }
    var trustedName by remember { mutableStateOf("") }
    var confirmForget by remember { mutableStateOf(false) }

    suspend fun refreshTrust() {
        trustedCode = repos.managerSync.trustedKeyCode()
        trustedName = repos.managerSync.trustedMainName() ?: ""
    }

    LaunchedEffect(Unit) { refreshTrust() }

    fun process(text: String) {
        if (busy) return
        busy = true
        scope.launch {
            val o = repos.managerSync.importText(text)
            results = o.results
            pending = o.pending
            refreshTrust()
            busy = false
        }
    }

    fun approve(p: MgrPending) {
        if (busy) return
        busy = true
        scope.launch {
            val r = repos.managerSync.approveKey(p.wire)
            val rest = pending.filter { it.wire != p.wire }
            if (r.ok) {
                val all = ArrayList<MgrImportResult>()
                all.add(r)
                if (rest.isNotEmpty()) {
                    val o = repos.managerSync.importText(rest.joinToString("\n") { it.wire })
                    all.addAll(o.results)
                    pending = o.pending
                } else {
                    pending = emptyList()
                }
                results = all
            } else {
                results = listOf(r)
            }
            refreshTrust()
            busy = false
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) { readTextFile(context, uri) }
                if (text == null) results = listOf(MgrImportResult(false, "Could not read the file", "The file is unreadable or too large."))
                else process(text)
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Import access code", onBack)
        Text(
            "The main manager sends you a signed access code (starts with CTM1.). Paste it here. " +
                "The first time, you must read the key code on screen to the main manager by phone and only approve if it is exactly the same.",
            color = CT.TextSoft, fontSize = 13.sp
        )

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            val t = trustedCode
            if (t != null) {
                Text("This phone trusts the main manager key", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(t + (if (trustedName.isNotEmpty()) "  ·  " + trustedName else ""), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.height(6.dp))
                GhostButton(
                    text = if (confirmForget) "TAP AGAIN TO FORGET THE KEY" else "FORGET THIS KEY",
                    danger = true,
                    onClick = {
                        if (!confirmForget) {
                            confirmForget = true
                        } else {
                            confirmForget = false
                            scope.launch {
                                repos.managerSync.forgetTrustedKey()
                                refreshTrust()
                            }
                        }
                    }
                )
            } else {
                Text("No main manager key trusted on this phone yet.", color = CT.TextSoft, fontSize = 13.sp)
            }
        }

        CTField(pasted, { pasted = it }, "Paste the access code here", singleLine = false, minLines = 3)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "USE PASTED CODE",
            modifier = Modifier.fillMaxWidth(),
            onClick = { if (pasted.isNotBlank()) { val t = pasted; pasted = ""; process(t) } }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.weight(1f), onClick = {
                val t = clipboard.getText()?.text ?: ""
                if (t.isNotBlank()) process(t)
                else results = listOf(MgrImportResult(false, "Clipboard is empty", "Copy the access code first."))
            })
            GhostButton(text = "OPEN FILE", modifier = Modifier.weight(1f), onClick = { picker.launch(arrayOf("*/*")) })
        }

        for (p in pending) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    if (p.keyChanged) "WARNING: a DIFFERENT main manager key" else "Check the main manager's key",
                    color = if (p.keyChanged) BAD_RED else CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 15.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(p.keyCode, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = 3.sp)
                Text("Sent by: " + p.mainName + "  ·  code for " + p.what, color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (p.keyChanged)
                        "This phone already trusts another key. Only continue if the main manager told you they changed their phone or reinstalled the app, and read you THIS exact code."
                    else
                        "Call the main manager and read this code to them. Approve only if they say it is the same. If it differs, someone may be pretending to be them: tap DISCARD.",
                    color = CT.TextSoft, fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                GoldButton(text = "IT MATCHES — APPROVE", modifier = Modifier.fillMaxWidth(), onClick = { approve(p) })
                Spacer(Modifier.height(6.dp))
                GhostButton(text = "DISCARD", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                    pending = pending.filter { it.wire != p.wire }
                })
            }
        }

        for (r in results) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) OK_GREEN else BAD_RED, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (r.detail.isNotEmpty()) Text(r.detail, color = CT.TextSoft, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
