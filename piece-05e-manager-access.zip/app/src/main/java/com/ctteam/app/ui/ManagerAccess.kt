package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.AccessUnit
import com.ctteam.app.data.Auth
import com.ctteam.app.data.IssuedAccess
import com.ctteam.app.data.LockoutStore
import com.ctteam.app.data.ManagerAccountEntity
import com.ctteam.app.data.ManagerAccountRepository
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Who is signed in right now. Audit-log actions use this as the actor, e.g. "manager:KINGFISHER". */
object ManagerSession {
    @Volatile var actor: String = "manager"
}

private val RED = Color(0xFFFF8A8A)

/** Remembers which manager last signed in on THIS phone, for the "Welcome back" quick unlock. */
private const val LAST_MANAGER_KEY = "last_manager_account_id"

// ------------------------------------------------------------------ LOGIN

/**
 * Manager sign-in (Piece 4B):
 *  - quick unlock (PIN or password) when this phone did a full sign-in under 30 days ago,
 *  - otherwise full sign-in (code name + password + PIN),
 *  - "First time or after a reset" = activate with code name + the PIN the main manager gave you.
 */
@Composable
fun ManagerAccessGate(
    repos: Repos,
    notice: String,
    onUnlocked: (ManagerAccountEntity) -> Unit,
    onExit: () -> Unit
) {
    var loaded by remember { mutableStateOf(false) }
    var quick by remember { mutableStateOf<ManagerAccountEntity?>(null) }
    var result by remember { mutableStateOf<ManagerAccountEntity?>(null) }
    val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:manager") }

    LaunchedEffect(Unit) {
        repos.managerAccounts.ensureMain()
        val lastId = repos.db.metaDao().get(LAST_MANAGER_KEY)
        quick = if (lastId != null) repos.managerAccounts.quickCandidate(lastId) else null
        loaded = true
    }

    if (!loaded) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Opening…", color = CT.TextSoft)
        }
        return
    }

    suspend fun finish(r: Auth<ManagerAccountEntity>): GateResult {
        if (r is Auth.Ok) {
            result = r.value
            repos.db.metaDao().put(MetaEntity(LAST_MANAGER_KEY, r.value.id))
        }
        return r.toGate()
    }

    val q = quick
    CredentialGate(
        title = "Manager access",
        subtitle = "Sign in with your code name, password and PIN.",
        idLabel = "Code name",
        notice = notice,
        quickName = q?.codeName,
        lock = lock,
        onQuick = { secret ->
            if (q == null) GateResult.Fail("Sign in with your code name instead.", false)
            else finish(repos.managerAccounts.quick(q.id, secret))
        },
        onFull = { id, password, pin -> finish(repos.managerAccounts.fullLogin(id, password, pin)) },
        onActivate = { id, pin, newPassword -> finish(repos.managerAccounts.activate(id, pin, newPassword)) },
        onForgot = null,
        onDone = { result?.let(onUnlocked) },
        onExit = onExit
    )
}

// ------------------------------------------------------------------ MANAGERS (main manager only)

@Composable
private fun LengthPicker(selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (n in listOf(6, 8, 10)) {
            CTChip(text = "$n digits", selected = n == selected, onClick = { onPick(n) })
        }
    }
}

/** Shows a freshly issued PIN ONCE, with a button that copies a ready-to-send message. */
@Composable
private fun IssuedPinCard(issued: IssuedAccess, headline: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember(issued.pin) { mutableStateOf(false) }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(headline, color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        InfoRow("Code name", issued.account.codeName)
        Spacer(Modifier.height(4.dp))
        Text("PIN", color = CT.TextSoft, fontSize = 13.sp)
        Text(
            issued.pin,
            color = CT.Gold, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 30.sp,
            letterSpacing = 3.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Send the code name and this PIN to the manager. This PIN is shown only now and the app does not keep it in readable form. " +
                "They use “First time or after a reset” on the Manager screen and create their own password. " +
                "If you lose the PIN, use Reset to default to make a new one.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        GhostButton(
            text = if (copied) "COPIED ✔" else "COPY MESSAGE TO SEND",
            onClick = {
                clipboard.setText(
                    AnnotatedString(
                        "CT Team manager access\n" +
                            "Code name: " + issued.account.codeName + "\n" +
                            "PIN: " + issued.pin + "\n" +
                            "Open the app > Manager > First time or after a reset. Enter the code name and PIN, then create your own password. Keep the PIN private."
                    )
                )
                copied = true
            }
        )
    }
}

@Composable
fun ManagersScreen(repos: Repos, me: ManagerAccountEntity, onBack: () -> Unit) {
    val flow = remember(repos) { repos.db.managerAccountDao().observeAll() }
    val accounts by flow.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var openId by remember { mutableStateOf<String?>(null) }
    var removalCode by remember { mutableStateOf<String?>(null) }
    var removalName by remember { mutableStateOf("") }

    BackHandler(enabled = adding || openId != null) {
        adding = false
        openId = null
    }

    if (adding) {
        AddManagerForm(repos = repos, me = me, onDone = { adding = false })
        return
    }
    val open = accounts.firstOrNull { it.id == openId }
    if (open != null) {
        ManagerDetail(
            repos = repos, me = me, target = open, onBack = { openId = null },
            onRemoved = { code ->
                removalCode = code
                removalName = open.codeName
                openId = null
            }
        )
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Managers", onBack)
        MainKeyCard(repos = repos, me = me)
        val rc = removalCode
        if (rc != null) {
            Text(
                removalName + " was removed here. Send this signed code to their phone so they are removed there too.",
                color = CT.GoldLight, fontSize = 13.sp
            )
            MgrCodeCard(
                label = "Removal code for " + removalName,
                code = rc, fileName = "ct-remove-" + removalName.lowercase().replace(' ', '-') + ".txt",
                who = removalName
            )
        }
        Text(
            accounts.size.toString() + " of " + ManagerAccountRepository.MAX_MANAGERS + " manager accounts used",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (accounts.size < ManagerAccountRepository.MAX_MANAGERS) {
            GoldButton(text = "ADD MANAGER", onClick = { adding = true })
        }
        for (a in accounts) {
            val blocked = repos.managerAccounts.isBlocked(a)
            GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { openId = a.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(a.codeName, color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    if (a.isMain) Text("MAIN", color = CT.Teal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Text(
                    repos.managerAccounts.statusText(a),
                    color = if (blocked) RED else CT.TextSoft, fontSize = 13.sp
                )
            }
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Good to know", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "New managers get a random PIN that was never used before. They activate with it and create their own password. " +
                    "“Reset to default” removes a manager's password and gives a new PIN. " +
                    "Accounts, resets and disabling take effect on this phone straight away. For a manager's OWN phone, open the manager and MAKE ACCESS CODE: it is signed with your key and carries the change there. " +
                    "The main manager can never be disabled or reset.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AddManagerForm(repos: Repos, me: ManagerAccountEntity, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var length by remember { mutableStateOf(8) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var issued by remember { mutableStateOf<IssuedAccess?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Add manager", onDone)
        val i = issued
        if (i != null) {
            IssuedPinCard(i, "Manager created")
            GoldButton(text = "DONE", onClick = onDone)
        } else {
            Text(
                "Choose a code name. The app creates a random PIN that has never been used before. Send that PIN to the new manager; they create their own password.",
                color = CT.TextSoft, fontSize = 13.sp
            )
            CTField(code, { code = it }, "Code name (e.g. EAGLE)")
            Text("PIN length", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            LengthPicker(selected = length, onPick = { length = it })
            if (message.isNotEmpty()) Text(message, color = RED, fontSize = 13.sp)
            GoldButton(
                text = if (busy) "PLEASE WAIT" else "CREATE MANAGER AND PIN",
                onClick = {
                    if (!busy) {
                        message = ""
                        busy = true
                        val c = code
                        val n = length
                        scope.launch {
                            val r = withContext(Dispatchers.Default) { repos.managerAccounts.issueNew(me, c, n) }
                            busy = false
                            if (r is Outcome.Err) message = r.message else if (r is Outcome.Ok) issued = r.value
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun UnitPicker(selected: AccessUnit, onPick: (AccessUnit) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (u in AccessUnit.values()) {
            CTChip(text = u.label, selected = u == selected, onClick = { onPick(u) })
        }
    }
}

@Composable
private fun ManagerDetail(
    repos: Repos, me: ManagerAccountEntity, target: ManagerAccountEntity,
    onBack: () -> Unit, onRemoved: (String?) -> Unit
) {
    val scope = rememberCoroutineScope()
    var amountText by remember(target.id) { mutableStateOf("1") }
    var unit by remember(target.id) { mutableStateOf(AccessUnit.DAYS) }
    var newName by remember(target.id) { mutableStateOf(target.codeName) }
    var confirmRemove by remember(target.id) { mutableStateOf(false) }
    var confirmReset by remember(target.id) { mutableStateOf(false) }
    var resetLength by remember(target.id) { mutableStateOf(8) }
    var issued by remember(target.id) { mutableStateOf<IssuedAccess?>(null) }
    var message by remember { mutableStateOf("") }

    fun amountOrNull(): Int? {
        val n = amountText.toIntOrNull()
        return if (n != null && n in 1..1000) n else null
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(target.codeName, onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Role", if (target.isMain) "Main manager" else "Manager")
            InfoRow("Status", repos.managerAccounts.statusText(target))
            InfoRow("Account", if (target.activated) "Activated (has a password)" else "Waiting for activation")
            InfoRow("Added", fmtTime(target.createdAt))
        }
        val shown = issued
        if (shown != null) IssuedPinCard(shown, "New PIN for " + shown.account.codeName)
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)

        if (!target.isMain) {
            Text("Period", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text("1 month = 30 days, 1 year = 365 days.", color = CT.TextSoft, fontSize = 12.sp)
            CTField(amountText, { amountText = it.filter { c -> c.isDigit() }.take(4) }, "Amount (1 to 1000)", keyboard = KeyboardType.Number)
            UnitPicker(selected = unit, onPick = { unit = it })

            GoldButton(text = "DISABLE FOR THIS PERIOD", onClick = {
                val n = amountOrNull()
                if (n == null) {
                    message = "Enter an amount from 1 to 1000."
                } else {
                    scope.launch {
                        val r = repos.managerAccounts.disable(me, target.id, unit.toMillis(n))
                        message = if (r is Outcome.Err) r.message else target.codeName + " is disabled for " + n + " " + unit.label.lowercase() + "."
                    }
                }
            })
            GhostButton(text = "DISABLE UNTIL I RE-ENABLE", danger = true, onClick = {
                scope.launch {
                    val r = repos.managerAccounts.disable(me, target.id, null)
                    message = if (r is Outcome.Err) r.message else target.codeName + " is disabled until you enable them again."
                }
            })
            GhostButton(text = "ALLOW ONLY FOR THIS PERIOD", onClick = {
                val n = amountOrNull()
                if (n == null) {
                    message = "Enter an amount from 1 to 1000."
                } else {
                    scope.launch {
                        val r = repos.managerAccounts.allowFor(me, target.id, unit.toMillis(n))
                        message = if (r is Outcome.Err) r.message else target.codeName + " can work for " + n + " " + unit.label.lowercase() + ", then is blocked."
                    }
                }
            })
            GoldButton(text = "ENABLE NOW", onClick = {
                scope.launch {
                    val r = repos.managerAccounts.enableNow(me, target.id)
                    message = if (r is Outcome.Err) r.message else target.codeName + " is enabled with no time limit."
                }
            })
        }

        if (!target.isMain) AccessCodeCard(repos = repos, me = me, target = target)

        Text("Code name", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        CTField(newName, { newName = it }, "Code name")
        GhostButton(text = "SAVE CODE NAME", onClick = {
            scope.launch {
                val r = repos.managerAccounts.rename(me, target.id, newName)
                message = if (r is Outcome.Err) r.message else "Code name saved."
            }
        })

        if (target.isMain) {
            Text(
                "Your own PIN and password are changed in Manager > My security.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else {
            Text("Reset to default", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text(
                "Removes this manager's password, signs them out everywhere, and creates a NEW random PIN that was never used before. " +
                    "They must activate again with the new PIN and make a new password.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            LengthPicker(selected = resetLength, onPick = { resetLength = it })
            GhostButton(
                text = if (confirmReset) "TAP AGAIN TO RESET " + target.codeName else "RESET TO DEFAULT",
                danger = true,
                onClick = {
                    if (!confirmReset) {
                        confirmReset = true
                    } else {
                        confirmReset = false
                        val n = resetLength
                        scope.launch {
                            val r = withContext(Dispatchers.Default) { repos.managerAccounts.resetToDefault(me, target.id, n) }
                            if (r is Outcome.Err) {
                                message = r.message
                            } else if (r is Outcome.Ok) {
                                message = ""
                                issued = r.value
                            }
                        }
                    }
                }
            )

            GhostButton(
                text = if (confirmRemove) "TAP AGAIN TO REMOVE FOR GOOD" else "REMOVE MANAGER",
                danger = true,
                onClick = {
                    if (!confirmRemove) {
                        confirmRemove = true
                    } else {
                        scope.launch {
                            // Signed "take this manager off your phone" code, made BEFORE the account disappears here.
                            val code = repos.managerSync.makeRemoveCode(me, target.id, target.codeName)
                            val r = repos.managerAccounts.remove(me, target.id)
                            if (r is Outcome.Err) message = r.message
                            else onRemoved(if (code is Outcome.Ok) code.value else null)
                        }
                    }
                }
            )
        }
    }
}
