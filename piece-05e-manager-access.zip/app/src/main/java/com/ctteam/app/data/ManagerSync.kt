package com.ctteam.app.data

import android.util.Base64
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

/**
 * Piece 5E — manager accounts travel between PHONES, signed by the main manager.
 *
 * The main manager's phone makes an ECDSA (P-256) key pair the first time it makes an access code.
 * Other managers' phones learn the PUBLIC key once, from the first access code they import, and the
 * person must compare its key code with the main manager by voice before tapping APPROVE. From then on,
 * every code signed by that key is accepted by that phone without asking again, and anything else is refused.
 *
 * Wire format (one line):  CTM1.<base64url(JSON)>.<base64url(64-byte ECDSA signature r||s)>
 * The signature covers the text "CTM1.<base64url(JSON)>".  JSON = {v, t, rev, pk, mn, ts, b:{...}}
 *   t = ACCT   -> one manager account (code name, PIN hash, status). Only that manager's own PIN hash is inside.
 *   t = REMOVE -> take that manager off this phone.
 * `rev` (a time number made on the main phone, always rising) makes older codes harmless: a code is only
 * used when its rev is higher than the last one this phone used for that account.
 */

@Entity(tableName = "manager_rev")
data class ManagerRevEntity(
    @PrimaryKey val accountId: String,
    val rev: Long,                 // highest rev made (main phone) or applied (manager phone)
    val removed: Boolean           // true = a REMOVE code was made / applied (old ACCT codes can not bring it back)
)

@Dao
interface ManagerSyncDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putRev(r: ManagerRevEntity)
    @Query("SELECT * FROM manager_rev WHERE accountId = :id") suspend fun rev(id: String): ManagerRevEntity?
    @Query("DELETE FROM manager_accounts WHERE isMain = 1") suspend fun deleteMainRow()
}

// ------------------------------------------------------------------ CRYPTO

object MgrCrypto {
    private val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, FLAGS)
    fun unb64(s: String): ByteArray? = try { Base64.decode(s, FLAGS) } catch (ex: IllegalArgumentException) { null }

    /** Returns (privateKeyPkcs8Base64Url, publicKeyX509Base64Url). */
    fun newKeyPair(): Pair<String, String> {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"))
        val kp = g.generateKeyPair()
        return Pair(b64(kp.private.encoded), b64(kp.public.encoded))
    }

    fun sign(privB64: String, data: ByteArray): ByteArray {
        val keyBytes = unb64(privB64) ?: throw IllegalArgumentException("bad key")
        val priv = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val s = Signature.getInstance("SHA256withECDSA")
        s.initSign(priv)
        s.update(data)
        return derToRaw(s.sign())
    }

    fun verify(pubB64: String, data: ByteArray, rawSig: ByteArray): Boolean {
        return try {
            if (rawSig.size != 64) return false
            val keyBytes = unb64(pubB64) ?: return false
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(keyBytes))
            val s = Signature.getInstance("SHA256withECDSA")
            s.initVerify(pub)
            s.update(data)
            s.verify(rawToDer(rawSig))
        } catch (ex: Exception) {
            false
        }
    }

    /** "7F3-A92": first 6 hex characters of SHA-256("CTMKEY|" + public key), to compare by voice. */
    fun keyCode(pubB64: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(("CTMKEY|" + pubB64).toByteArray(Charsets.UTF_8))
        val hex = d.joinToString("") { "%02X".format(it) }
        return hex.substring(0, 3) + "-" + hex.substring(3, 6)
    }

    // ---- DER <-> raw (r||s, 32 bytes each)

    private fun derToRaw(der: ByteArray): ByteArray {
        var i = 2
        if ((der[1].toInt() and 0x80) != 0) i = 2 + (der[1].toInt() and 0x7f)
        require(der[i].toInt() == 0x02)
        val rLen = der[i + 1].toInt() and 0xff
        val r = der.copyOfRange(i + 2, i + 2 + rLen)
        val j = i + 2 + rLen
        require(der[j].toInt() == 0x02)
        val sLen = der[j + 1].toInt() and 0xff
        val s = der.copyOfRange(j + 2, j + 2 + sLen)
        val out = ByteArray(64)
        copyFixed(r, out, 0)
        copyFixed(s, out, 32)
        return out
    }

    private fun copyFixed(v: ByteArray, out: ByteArray, offset: Int) {
        var start = 0
        while (start < v.size - 1 && v[start].toInt() == 0) start++
        val len = v.size - start
        require(len <= 32)
        System.arraycopy(v, start, out, offset + 32 - len, len)
    }

    private fun rawToDer(raw: ByteArray): ByteArray {
        val r = BigInteger(1, raw.copyOfRange(0, 32)).toByteArray()
        val s = BigInteger(1, raw.copyOfRange(32, 64)).toByteArray()
        val body = byteArrayOf(0x02, r.size.toByte()) + r + byteArrayOf(0x02, s.size.toByte()) + s
        return byteArrayOf(0x30, body.size.toByte()) + body
    }
}

// ------------------------------------------------------------------ RESULT TYPES

data class MgrImportResult(val ok: Boolean, val title: String, val detail: String)

/** A code from a main manager key this phone does not trust yet: it needs the voice check + APPROVE. */
data class MgrPending(
    val wire: String,
    val keyCode: String,
    val mainName: String,
    val keyChanged: Boolean,       // true = this phone trusts a DIFFERENT key already
    val what: String
)

data class MgrImportOutcome(val results: List<MgrImportResult>, val pending: List<MgrPending>)

private class ParsedMgr(
    val wire: String,              // the whole code, whitespace removed
    val signed: String,            // "CTM1.<b64>"
    val sig: ByteArray,
    val type: String,
    val rev: Long,
    val pk: String,
    val mainName: String,
    val body: JSONObject
)

// ------------------------------------------------------------------ REPOSITORY

class ManagerSyncRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val meta = db.metaDao()
    private val accounts = db.managerAccountDao()
    private val revs = db.managerSyncDao()
    private val sec = db.securityDao()

    companion object {
        const val PREFIX = "CTM1"
        const val K_PRIV = "mgrsync:priv"
        const val K_PUB = "mgrsync:pub"
        const val K_LASTREV = "mgrsync:lastrev"
        const val K_TRUSTED = "mgrsync:trusted_pub"
        const val K_TRUSTED_NAME = "mgrsync:trusted_name"
        const val K_MANAGER_PHONE = "mgrsync:managerphone"

        private val WRAPPED = Regex("CTM1\\.([A-Za-z0-9_\\-\\s]+)\\.((?:[A-Za-z0-9_\\-]\\s*){86})")
        private val ID_RULE = Regex("^[A-Za-z0-9\\-]{8,64}$")
        private val SALT_RULE = Regex("^[0-9a-f]{32}$")
        private val HASH_RULE = Regex("^[0-9a-f]{64}$")
        private const val MAX_FUTURE_REV_MS = 366L * 86_400_000L
    }

    private fun now() = System.currentTimeMillis()

    // ---------------------------------------------------------------- state

    /** True on a phone that accepted another phone's main key: it has no main manager of its own. */
    suspend fun isManagerPhone(): Boolean = meta.get(K_MANAGER_PHONE) == "1"

    suspend fun trustedKeyCode(): String? = meta.get(K_TRUSTED)?.let { MgrCrypto.keyCode(it) }
    suspend fun trustedMainName(): String? = meta.get(K_TRUSTED_NAME)
    suspend fun ownKeyCode(): String? = meta.get(K_PUB)?.let { MgrCrypto.keyCode(it) }

    /** Turn off trust in the main manager key on this phone (accounts stay). Next code needs the voice check again. */
    suspend fun forgetTrustedKey() {
        meta.put(MetaEntity(K_TRUSTED, ""))
        meta.put(MetaEntity(K_TRUSTED_NAME, ""))
        audit.log("system", "MAIN_KEY_FORGOTTEN", "manager_sync", "key", "")
    }

    private suspend fun trustedPub(): String? {
        val t = meta.get(K_TRUSTED)
        return if (t.isNullOrEmpty()) null else t
    }

    private suspend fun ensureKey(): Outcome<String> {
        if (isManagerPhone()) return Outcome.Err("This phone trusts another phone's main manager. Access codes are made on the main manager's phone.")
        val existing = meta.get(K_PUB)
        if (existing != null && meta.get(K_PRIV) != null) return Outcome.Ok(existing)
        val kp = MgrCrypto.newKeyPair()
        meta.put(MetaEntity(K_PRIV, kp.first))
        meta.put(MetaEntity(K_PUB, kp.second))
        audit.log("system", "MAIN_SIGNING_KEY_CREATED", "manager_sync", "key", MgrCrypto.keyCode(kp.second))
        return Outcome.Ok(kp.second)
    }

    /** Key code of the main manager's signing key (made on first use). Read it to the other managers by voice. */
    suspend fun ensureOwnKeyCode(by: ManagerAccountEntity): Outcome<String> {
        if (!by.isMain) return Outcome.Err("Only the main manager can make access codes.")
        return when (val k = ensureKey()) {
            is Outcome.Err -> k
            is Outcome.Ok -> Outcome.Ok(MgrCrypto.keyCode(k.value))
        }
    }

    // ---------------------------------------------------------------- main phone: make codes

    private suspend fun nextRev(at: Long): Long {
        val last = meta.get(K_LASTREV)?.toLongOrNull() ?: 0L
        val rev = maxOf(at, last + 1)
        meta.put(MetaEntity(K_LASTREV, rev.toString()))
        return rev
    }

    private fun seal(priv: String, header: JSONObject): String {
        val json = header.toString().toByteArray(Charsets.UTF_8)
        val signed = PREFIX + "." + MgrCrypto.b64(json)
        val sig = MgrCrypto.sign(priv, signed.toByteArray(Charsets.UTF_8))
        return signed + "." + MgrCrypto.b64(sig)
    }

    /** One manager's account as a signed code for THEIR phone (code name, status, PIN hash). Never contains a password. */
    suspend fun makeAccountCode(by: ManagerAccountEntity, accountId: String, at: Long = now()): Outcome<String> {
        if (!by.isMain) return Outcome.Err("Only the main manager can make access codes.")
        val pub = when (val k = ensureKey()) {
            is Outcome.Err -> return k
            is Outcome.Ok -> k.value
        }
        val priv = meta.get(K_PRIV) ?: return Outcome.Err("Signing key missing.")
        return db.withTransaction<Outcome<String>> {
            val a = accounts.get(accountId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (a.isMain) return@withTransaction Outcome.Err("The main manager does not need a code.")
            val rev = nextRev(at)
            val body = JSONObject()
            body.put("id", a.id)
            body.put("cn", a.codeName)
            body.put("ps", a.pinSalt)
            body.put("ph", a.pinHash)
            body.put("it", a.iterations)
            body.put("su", a.suspendedUntil?.toString() ?: "")
            body.put("ae", a.accessExpiresAt?.toString() ?: "")
            body.put("ca", a.createdAt.toString())
            val head = JSONObject()
            head.put("v", 1)
            head.put("t", "ACCT")
            head.put("rev", rev.toString())
            head.put("pk", pub)
            head.put("mn", by.codeName)
            head.put("ts", at.toString())
            head.put("b", body)
            revs.putRev(ManagerRevEntity(a.id, rev, false))
            audit.log("manager:" + by.codeName, "MANAGER_CODE_MADE", "manager_account", a.id, a.codeName + " rev " + rev, at)
            Outcome.Ok(seal(priv, head))
        }
    }

    /** Signed "take this manager off your phone" code. Make it when you remove a manager. */
    suspend fun makeRemoveCode(by: ManagerAccountEntity, accountId: String, codeName: String, at: Long = now()): Outcome<String> {
        if (!by.isMain) return Outcome.Err("Only the main manager can make access codes.")
        val pub = when (val k = ensureKey()) {
            is Outcome.Err -> return k
            is Outcome.Ok -> k.value
        }
        val priv = meta.get(K_PRIV) ?: return Outcome.Err("Signing key missing.")
        val rev = nextRev(at)
        val body = JSONObject()
        body.put("id", accountId)
        body.put("cn", codeName)
        val head = JSONObject()
        head.put("v", 1)
        head.put("t", "REMOVE")
        head.put("rev", rev.toString())
        head.put("pk", pub)
        head.put("mn", by.codeName)
        head.put("ts", at.toString())
        head.put("b", body)
        revs.putRev(ManagerRevEntity(accountId, rev, true))
        audit.log("manager:" + by.codeName, "MANAGER_REMOVE_CODE_MADE", "manager_account", accountId, codeName + " rev " + rev, at)
        return Outcome.Ok(seal(priv, head))
    }

    // ---------------------------------------------------------------- manager phone: read codes

    private fun parseAll(text: String): List<ParsedMgr> {
        val out = ArrayList<ParsedMgr>()
        val seen = HashSet<String>()
        for (m in WRAPPED.findAll(text)) {
            val b64 = m.groupValues[1].filter { !it.isWhitespace() }
            val sigB64 = m.groupValues[2].filter { !it.isWhitespace() }
            val wire = PREFIX + "." + b64 + "." + sigB64
            if (!seen.add(wire)) continue
            val sig = MgrCrypto.unb64(sigB64) ?: continue
            val jsonBytes = MgrCrypto.unb64(b64) ?: continue
            try {
                val h = JSONObject(String(jsonBytes, Charsets.UTF_8))
                if (h.optInt("v", 0) != 1) continue
                val t = h.optString("t", "")
                val rev = h.optString("rev", "").toLongOrNull() ?: continue
                val pk = h.optString("pk", "")
                val body = h.optJSONObject("b") ?: continue
                if (t != "ACCT" && t != "REMOVE") continue
                if (pk.isEmpty()) continue
                out.add(ParsedMgr(wire, PREFIX + "." + b64, sig, t, rev, pk, h.optString("mn", "MAIN").take(30), body))
            } catch (ex: Exception) {
                continue
            }
        }
        return out
    }

    private fun describe(p: ParsedMgr): String =
        if (p.type == "REMOVE") "remove manager " + p.body.optString("cn", "?").take(20)
        else "manager " + p.body.optString("cn", "?").take(20)

    /** Reads every access code in the text. Codes from the trusted key are applied; others wait for APPROVE. */
    suspend fun importText(text: String, at: Long = now()): MgrImportOutcome {
        val parsed = parseAll(text).sortedBy { it.rev }
        if (parsed.isEmpty()) {
            return MgrImportOutcome(
                listOf(MgrImportResult(false, "No access code found", "Paste the whole message the main manager sent. It starts with CTM1.")),
                emptyList()
            )
        }
        val results = ArrayList<MgrImportResult>()
        val pending = ArrayList<MgrPending>()
        val own = meta.get(K_PUB)
        val trusted = trustedPub()
        for (p in parsed) {
            val label = describe(p)
            if (!MgrCrypto.verify(p.pk, p.signed.toByteArray(Charsets.UTF_8), p.sig)) {
                audit.event("MGR_CODE_REJECTED", "bad signature", at)
                results.add(MgrImportResult(false, "Refused: $label", "The signature is wrong. The code was changed or damaged."))
                continue
            }
            if (own != null && own == p.pk) {
                results.add(MgrImportResult(true, "Already on this phone: $label", "This code was made on this phone."))
                continue
            }
            if (trusted != null && trusted == p.pk) {
                results.add(applyParsed(p, at))
            } else {
                val changed = trusted != null
                pending.add(MgrPending(p.wire, MgrCrypto.keyCode(p.pk), p.mainName, changed, label))
            }
        }
        return MgrImportOutcome(results, pending)
    }

    /**
     * The person compared the key code with the main manager by voice and tapped APPROVE.
     * This phone then trusts that key (and has no main manager of its own), and the code is applied.
     */
    suspend fun approveKey(wire: String, at: Long = now()): MgrImportResult {
        val p = parseAll(wire).firstOrNull() ?: return MgrImportResult(false, "Code not readable", "Ask the main manager to send it again.")
        if (!MgrCrypto.verify(p.pk, p.signed.toByteArray(Charsets.UTF_8), p.sig))
            return MgrImportResult(false, "Refused", "The signature is wrong.")
        if (meta.get(K_PRIV) != null)
            return MgrImportResult(false, "Refused", "This phone is the main manager's own phone (it has the signing key). Use a different phone for this manager.")
        val localMain = accounts.main()
        if (localMain != null && localMain.activated)
            return MgrImportResult(false, "Refused", "The MAIN account on this phone is already in use (a password was created). Reinstall the app on this phone, or use another phone.")
        db.withTransaction<Unit> {
            if (localMain != null) revs.deleteMainRow()
            meta.put(MetaEntity(K_TRUSTED, p.pk))
            meta.put(MetaEntity(K_TRUSTED_NAME, p.mainName))
            meta.put(MetaEntity(K_MANAGER_PHONE, "1"))
            audit.log("system", "MAIN_KEY_TRUSTED", "manager_sync", "key", MgrCrypto.keyCode(p.pk) + " (" + p.mainName + ")", at)
        }
        return applyParsed(p, at)
    }

    private suspend fun applyParsed(p: ParsedMgr, at: Long): MgrImportResult {
        val label = describe(p)
        if (p.rev > at + MAX_FUTURE_REV_MS) { // only absurd values are refused: the main phone clock may differ
            return MgrImportResult(false, "Refused: $label", "The code has an impossible date.")
        }
        return db.withTransaction<MgrImportResult> {
            val id = p.body.optString("id", "")
            if (!ID_RULE.matches(id) || id == "main")
                return@withTransaction MgrImportResult(false, "Refused: $label", "The manager id is not valid.")
            val old = revs.rev(id)
            if (old != null && old.rev >= p.rev)
                return@withTransaction MgrImportResult(true, "Already up to date: $label", "A newer or equal code was already used on this phone.")
            val local = accounts.get(id)
            if (local != null && local.isMain)
                return@withTransaction MgrImportResult(false, "Refused: $label", "That id belongs to a main account.")

            if (p.type == "REMOVE") {
                if (local != null) {
                    accounts.deleteNonMain(id)
                    sec.clearTrust(id)
                }
                revs.putRev(ManagerRevEntity(id, p.rev, true))
                audit.log("sync", "MANAGER_REMOVED_BY_SYNC", "manager_account", id, p.body.optString("cn", ""), at)
                return@withTransaction MgrImportResult(true, "Removed: " + p.body.optString("cn", "manager"), "This manager can no longer sign in on this phone.")
            }

            // ---- ACCT
            val cn = normalizeCode(p.body.optString("cn", ""))
                ?: return@withTransaction MgrImportResult(false, "Refused: $label", "The code name is not valid.")
            val ps = p.body.optString("ps", "")
            val ph = p.body.optString("ph", "")
            val iter = p.body.optInt("it", 0)
            if (!SALT_RULE.matches(ps) || !HASH_RULE.matches(ph) || iter < 10_000 || iter > 1_000_000)
                return@withTransaction MgrImportResult(false, "Refused: $label", "The PIN data in the code is not valid.")
            val su = parseOptLong(p.body.optString("su", "")) ?: return@withTransaction MgrImportResult(false, "Refused: $label", "Bad access date.")
            val ae = parseOptLong(p.body.optString("ae", "")) ?: return@withTransaction MgrImportResult(false, "Refused: $label", "Bad access date.")
            val created = p.body.optString("ca", "").toLongOrNull() ?: at
            val all = accounts.all()
            if (all.any { it.id != id && it.codeName == cn })
                return@withTransaction MgrImportResult(false, "Refused: $label", "Another account on this phone already uses the code name $cn.")
            val suV = su.value
            val aeV = ae.value

            if (local == null) {
                if (all.size >= ManagerAccountRepository.MAX_MANAGERS)
                    return@withTransaction MgrImportResult(false, "Refused: $label", "This phone already has the maximum number of managers.")
                accounts.insert(
                    ManagerAccountEntity(
                        id = id, codeName = cn, pinSalt = ps, pinHash = ph, iterations = iter,
                        isMain = false, suspendedUntil = suV, accessExpiresAt = aeV, note = "", createdAt = created
                    )
                )
                revs.putRev(ManagerRevEntity(id, p.rev, false))
                audit.log("sync", "MANAGER_ADDED_BY_SYNC", "manager_account", id, cn, at)
                return@withTransaction MgrImportResult(
                    true, "Added: $cn",
                    "Now open Manager > FIRST TIME OR AFTER A RESET and use the code name $cn with the PIN the main manager gives you."
                )
            }

            val pinChanged = local.pinHash != ph || local.pinSalt != ps
            val updated = if (pinChanged) {
                local.copy(
                    codeName = cn, pinSalt = ps, pinHash = ph, iterations = iter,
                    suspendedUntil = suV, accessExpiresAt = aeV,
                    passSalt = null, passHash = null, credVersion = local.credVersion + 1
                )
            } else {
                local.copy(codeName = cn, suspendedUntil = suV, accessExpiresAt = aeV)
            }
            accounts.update(updated)
            if (pinChanged) sec.clearTrust(id)
            revs.putRev(ManagerRevEntity(id, p.rev, false))
            audit.log("sync", if (pinChanged) "MANAGER_RESET_BY_SYNC" else "MANAGER_UPDATED_BY_SYNC", "manager_account", id, cn, at)
            MgrImportResult(
                true, (if (pinChanged) "Reset: " else "Updated: ") + cn,
                if (pinChanged) "The password was removed. Activate again with the new PIN." else "Access rules updated on this phone."
            )
        }
    }

    private class OptLong(val value: Long?)

    private fun parseOptLong(s: String): OptLong? {
        if (s.isEmpty()) return OptLong(null)
        val v = s.toLongOrNull() ?: return null
        return OptLong(v)
    }

    private fun normalizeCode(raw: String): String? {
        val c = raw.trim().replace(Regex("\\s+"), " ").uppercase()
        if (c.length < 2 || c.length > 20) return null
        if (!c.all { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_' }) return null
        return c
    }
}
