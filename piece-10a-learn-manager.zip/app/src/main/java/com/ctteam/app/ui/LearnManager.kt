package com.ctteam.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.LearnContentEntity
import com.ctteam.app.data.LearnRepository
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 10A — Manager > Learn & Earn: write lessons (title, category, text, picture link, video link), keep drafts, publish or hide.
 * Sending lessons to the workers' phones comes in piece 10B; until then lessons only live on this phone.
 */
private val LM_BAD = Color(0xFFFF8A8A)
private val LM_GOOD = Color(0xFF5FD6A5)

@Composable
fun ManagerLearnScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val allFlow = remember(repos) { repos.db.contentDao().observeAllLearn() }
    val all by allFlow.collectAsState(initial = emptyList())

    var editing by remember { mutableStateOf(false) }
    var editId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var image by remember { mutableStateOf("") }
    var video by remember { mutableStateOf("") }
    var wasPublished by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    fun openLesson(l: LearnContentEntity?) {
        editId = l?.id
        title = l?.title ?: ""
        category = l?.category ?: ""
        body = l?.body ?: ""
        image = l?.imageUrl ?: ""
        video = l?.videoUrl ?: ""
        wasPublished = l?.published ?: false
        confirmDelete = false
        note = ""
        editing = true
    }

    fun save(publish: Boolean) {
        if (busy) return
        busy = true
        scope.launch {
            when (val r = repos.learn.save(editId, title, body, category, image, video, publish, actor)) {
                is Outcome.Err -> { note = r.message; noteBad = true }
                is Outcome.Ok -> {
                    editId = r.value
                    if (publish) wasPublished = true
                    note = if (publish) "Saved and published." else "Saved."
                    noteBad = false
                }
            }
            busy = false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (!editing) {
            ScreenHeader("Learn & Earn", onBack)
            Text(
                "Lessons for your workers. Pictures and videos are links (https), nothing is uploaded. " +
                    "A lesson is only visible to workers once it is published. Sending lessons to the workers' phones comes next (piece 10B).",
                color = CT.TextSoft, fontSize = 13.sp
            )
            GoldButton(text = "NEW LESSON", modifier = Modifier.fillMaxWidth(), onClick = { openLesson(null) })
            if (all.isEmpty()) Text("No lessons yet.", color = CT.TextSoft, fontSize = 13.sp)
            for (l in all) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { openLesson(l) }) {
                    Text(l.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        (if (l.published) "PUBLISHED" else "DRAFT") + (if (l.category.isNotEmpty()) " · " + l.category else "") + " · v" + l.version,
                        color = if (l.published) LM_GOOD else CT.TextSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text(l.body.take(100), color = CT.TextSoft, fontSize = 12.sp)
                    Text("Changed " + fmtTime(l.updatedAt), color = CT.TextSoft, fontSize = 11.sp)
                }
            }
        } else {
            ScreenHeader(if (editId == null) "New lesson" else "Edit lesson", { editing = false })
            CTField(title, { title = it.take(LearnRepository.TITLE_MAX) }, "Title")
            CTField(category, { category = it.take(LearnRepository.CATEGORY_MAX) }, "Category (optional, e.g. Getting started)")
            CTField(body, { body = it.take(LearnRepository.BODY_MAX) }, "Lesson text", singleLine = false, minLines = 8)
            Text(body.length.toString() + " / " + LearnRepository.BODY_MAX, color = CT.TextSoft, fontSize = 11.sp)
            CTField(image, { image = it.take(LearnRepository.URL_MAX) }, "Picture link (optional, https://…)", keyboard = KeyboardType.Uri)
            CTField(video, { video = it.take(LearnRepository.URL_MAX) }, "Video link (optional, https://…)", keyboard = KeyboardType.Uri)
            if (note.isNotEmpty()) Text(note, color = if (noteBad) LM_BAD else LM_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (editId == null) "Status: not saved yet" else if (wasPublished) "Status: PUBLISHED. Saving changes raises the version so workers get the new text."
                else "Status: DRAFT (workers cannot see it)",
                color = CT.TextSoft, fontSize = 12.sp
            )
            GoldButton(text = if (busy) "SAVING…" else "SAVE AND PUBLISH", modifier = Modifier.fillMaxWidth(), onClick = { save(true) })
            GhostButton(text = "SAVE", modifier = Modifier.fillMaxWidth(), onClick = { save(false) })
            val id = editId
            if (id != null && wasPublished) {
                GhostButton(text = "HIDE FROM WORKERS", modifier = Modifier.fillMaxWidth(), onClick = {
                    if (busy) return@GhostButton
                    busy = true
                    scope.launch {
                        repos.learn.setPublished(id, false, actor)
                        wasPublished = false
                        note = "Hidden. It is a draft again."
                        noteBad = false
                        busy = false
                    }
                })
            }
            if (id != null) {
                GhostButton(text = if (confirmDelete) "TAP AGAIN TO DELETE FOR GOOD" else "DELETE", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                    if (!confirmDelete) { confirmDelete = true; return@GhostButton }
                    if (busy) return@GhostButton
                    busy = true
                    scope.launch {
                        repos.learn.delete(id, actor)
                        busy = false
                        editing = false
                    }
                })
            }
            GhostButton(text = "BACK TO LIST", modifier = Modifier.fillMaxWidth(), onClick = { editing = false })
        }
        Spacer(Modifier.height(8.dp))
    }
}
