package com.ctteam.app.data

import java.util.UUID

/**
 * Piece 10A — Learn & Earn lessons, manager side. Stored in the existing table `learn_content` (no schema change).
 * `version` goes up with every change of the content, so that phones that already have the lesson know to replace it (piece 10B).
 * Pictures and videos are LINKS only (https), nothing is uploaded.
 */
class LearnRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.contentDao()

    companion object {
        const val TITLE_MIN = 3
        const val TITLE_MAX = 80
        const val BODY_MAX = 3000        // fits in a signed message with room to spare
        const val CATEGORY_MAX = 30
        const val URL_MAX = 300
    }

    private fun now() = System.currentTimeMillis()

    private fun goodLink(u: String): Boolean = u.isEmpty() || (u.startsWith("https://") && u.length <= URL_MAX && !u.any { it.isWhitespace() })

    /** Creates a lesson (id = null) or changes one. Content changes raise the version. Returns the lesson id. */
    suspend fun save(
        id: String?, title: String, body: String, category: String, imageUrl: String, videoUrl: String,
        publish: Boolean, actor: String
    ): Outcome<String> {
        val t = title.trim()
        val b = body.trim()
        val c = category.trim()
        val img = imageUrl.trim()
        val vid = videoUrl.trim()
        if (t.length < TITLE_MIN) return Outcome.Err("The title needs at least $TITLE_MIN characters.")
        if (t.length > TITLE_MAX) return Outcome.Err("The title can be at most $TITLE_MAX characters.")
        if (b.isEmpty()) return Outcome.Err("Write the lesson text.")
        if (b.length > BODY_MAX) return Outcome.Err("The text can be at most $BODY_MAX characters (now ${b.length}).")
        if (c.length > CATEGORY_MAX) return Outcome.Err("The category can be at most $CATEGORY_MAX characters.")
        if (!goodLink(img)) return Outcome.Err("The picture link must start with https:// and have no spaces.")
        if (!goodLink(vid)) return Outcome.Err("The video link must start with https:// and have no spaces.")
        val old = if (id == null) null else dao.learn(id)
        val newId = old?.id ?: ("L-" + UUID.randomUUID().toString().replace("-", "").take(16))
        val changed = old == null || old.title != t || old.body != b || old.category != c || old.imageUrl != img || old.videoUrl != vid
        val version = when {
            old == null -> 1
            changed -> old.version + 1
            else -> old.version
        }
        val published = publish || (old?.published ?: false)
        dao.upsertLearn(
            LearnContentEntity(
                id = newId, title = t, body = b, category = c, imageUrl = img, videoUrl = vid,
                published = if (publish) true else (old?.published ?: false), version = version, updatedAt = now()
            )
        )
        audit.event(if (old == null) "LEARN_CREATED" else "LEARN_EDITED", newId + " v" + version + (if (published) " published" else " draft"))
        return Outcome.Ok(newId)
    }

    suspend fun setPublished(id: String, published: Boolean, actor: String): Outcome<Unit> {
        val l = dao.learn(id) ?: return Outcome.Err("Lesson not found.")
        if (l.published == published) return Outcome.Ok(Unit)
        // publishing again after hiding counts as a change, so phones that hid it get it back
        dao.upsertLearn(l.copy(published = published, version = l.version + 1, updatedAt = now()))
        audit.event(if (published) "LEARN_PUBLISHED" else "LEARN_HIDDEN", id)
        return Outcome.Ok(Unit)
    }

    suspend fun delete(id: String, actor: String) {
        dao.deleteLearn(id)
        audit.event("LEARN_DELETED", id)
    }
}
