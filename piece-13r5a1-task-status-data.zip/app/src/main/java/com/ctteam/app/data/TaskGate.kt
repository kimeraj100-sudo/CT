package com.ctteam.app.data

/**
 * Piece R5 — status perks: a task can ask for a lowest referral status.
 * `tasks.minTier` is an index into [ReferralRules.TIERS] (0 Member = everyone, 1 Connector, 2 Builder, 3 Leader, 4 Champion).
 * The owner's list is Builder, Leader and Champion, but the data layer accepts any real level so the rules can change later.
 *
 * Two checks, because two phones know different things:
 *  - the MANAGER phone knows the real number of awarded referrals (the check that counts, used when a submission is imported);
 *  - the WORKER phone knows only what the manager last sent (REFERRAL_VIEW), so it can lock a task on the screen, but a
 *    modified app could not get around the manager's check.
 * Status never goes down (spending points does not lower it), so a locked task opens for good once the status is reached.
 */

/** [allowed] false means locked; [reason] is plain words for the screen or the audit log. */
class TaskGateResult(val allowed: Boolean, val reason: String)

object TaskGate {

    fun valid(tier: Int): Boolean = tier in 0 until ReferralRules.TIERS.size

    fun tierName(tier: Int): String = ReferralRules.TIERS.getOrNull(tier)?.name ?: ReferralRules.TIERS.first().name

    /** Short label for lists and the task editor. */
    fun label(minTier: Int): String = if (minTier <= 0) "Everyone" else tierName(minTier) + " or higher"

    /** Index of a status given awarded referrals and the manager's thresholds. */
    fun tierIndexOf(awarded: Int, thresholds: List<Int>): Int = ReferralRules.TIERS.indexOf(ReferralRules.tierOf(awarded, thresholds))

    fun passes(workerTier: Int, minTier: Int): Boolean = minTier <= 0 || workerTier >= minTier

    /** Awarded referrals the status needs, from the manager's thresholds. */
    fun neededAwarded(minTier: Int, thresholds: List<Int>): Int = ReferralRules.thresholdFor(minTier, thresholds)

    /** What a locked worker is told: what is needed and how far away they are. */
    fun reasonText(minTier: Int, awarded: Int, thresholds: List<Int>): String {
        val need = neededAwarded(minTier, thresholds)
        val missing = maxOf(0, need - awarded)
        return "This task is for workers with the status " + tierName(minTier) + " or higher (" + need + " awarded referral" + (if (need == 1) "" else "s") +
            "). You have " + awarded + ", so " + missing + " more " + (if (missing == 1) "is" else "are") + " needed."
    }

    /** Manager phone: the real answer, from the referral ledger. */
    suspend fun checkOnManager(referrals: ReferralRepository, workerId: String, minTier: Int): TaskGateResult {
        if (minTier <= 0) return TaskGateResult(true, "")
        val awarded = referrals.awardedCount(workerId)
        val thresholds = referrals.thresholds()
        return if (passes(tierIndexOf(awarded, thresholds), minTier)) TaskGateResult(true, "")
        else TaskGateResult(false, reasonText(minTier, awarded, thresholds))
    }

    /**
     * Worker phone: the answer from the manager's last REFERRAL_VIEW. Without one the status is unknown, so a task that
     * asks for a status stays locked and says why (an open task never needs the figures).
     */
    fun checkOnWorker(view: ReferralView?, minTier: Int): TaskGateResult {
        if (minTier <= 0) return TaskGateResult(true, "")
        if (view == null)
            return TaskGateResult(false, "This task is for workers with the status " + tierName(minTier) + " or higher. Your status is not known yet: open Sync and import the manager's latest update.")
        return if (passes(tierIndexOf(view.awarded, view.thresholds), minTier)) TaskGateResult(true, "")
        else TaskGateResult(false, reasonText(minTier, view.awarded, view.thresholds))
    }
}
