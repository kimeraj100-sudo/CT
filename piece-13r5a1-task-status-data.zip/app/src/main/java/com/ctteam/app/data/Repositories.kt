package com.ctteam.app.data

import androidx.room.withTransaction
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Success or a human-readable error that the UI can show. */
sealed class Outcome<out T> {
    data class Ok<T>(val value: T) : Outcome<T>()
    data class Err(val message: String) : Outcome<Nothing>()
}

private fun now() = System.currentTimeMillis()
private fun newId() = UUID.randomUUID().toString()

// ---------------------------------------------------------------- AUDIT / EVENTS

class AuditRepository(private val db: CTDatabase) {
    private val dao = db.auditDao()

    private fun hashOf(prev: String, a: String, act: String, type: String, id: String, details: String, at: Long) =
        Hashing.sha256Hex("$prev|$a|$act|$type|$id|$details|$at")

    /** Append an important action. Rows are chained by hash so edits/deletions are detectable. */
    suspend fun log(
        actor: String, action: String, entityType: String, entityId: String,
        details: String = "", at: Long = now()
    ) {
        db.withTransaction {
            val prev = dao.lastHash() ?: "GENESIS"
            dao.insert(
                AuditEntity(
                    actor = actor, action = action, entityType = entityType, entityId = entityId,
                    details = details, createdAt = at, prevHash = prev,
                    hash = hashOf(prev, actor, action, entityType, entityId, details, at)
                )
            )
        }
    }

    suspend fun event(type: String, details: String = "", at: Long = now()) {
        db.eventDao().insert(EventEntity(type = type, details = details, createdAt = at))
    }

    /** True if no audit row has been altered or removed from the middle of the chain. */
    suspend fun verifyChain(): Boolean {
        var prev = "GENESIS"
        for (r in dao.all()) {
            val expected = hashOf(prev, r.actor, r.action, r.entityType, r.entityId, r.details, r.createdAt)
            if (r.prevHash != prev || r.hash != expected) return false
            prev = r.hash
        }
        return true
    }
}

// ---------------------------------------------------------------- WORKERS

class WorkerRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.workerDao()

    companion object {
        const val NIN_LENGTH = 14 // Uganda National ID Number is 14 characters
    }

    suspend fun register(
        nationalId: String, first: String, middle: String, last: String, phoneRaw: String,
        at: Long = now()
    ): Outcome<WorkerEntity> {
        val nin = nationalId.trim().uppercase()
        if (nin.length != NIN_LENGTH || !nin.all { it.isLetterOrDigit() })
            return Outcome.Err("National ID must be $NIN_LENGTH letters/digits.")
        if (first.isBlank() || last.isBlank()) return Outcome.Err("First and last name are required.")
        val phone = PhoneUtil.parse(phoneRaw)
            ?: return Outcome.Err("Enter a valid MTN or Airtel Uganda number (e.g. 0772123456).")

        return db.withTransaction<Outcome<WorkerEntity>> {
            if (dao.getByNationalId(nin) != null) return@withTransaction Outcome.Err("This National ID is already registered.")
            if (dao.getByPhone(phone.digits) != null) return@withTransaction Outcome.Err("This phone number is already registered.")
            val w = WorkerEntity(
                id = newId(), nationalId = nin,
                firstName = first.trim(), middleName = middle.trim(), lastName = last.trim(),
                phone = phone.digits, network = phone.network, createdAt = at
            )
            dao.insert(w)
            dao.insertPhone(PhoneHistoryEntity(workerId = w.id, phone = phone.digits, network = phone.network, changedAt = at, reason = "REGISTRATION"))
            audit.log("worker:${w.id}", "WORKER_REGISTERED", "worker", w.id, w.fullName(), at)
            Outcome.Ok(w)
        }
    }

    /** Rules: once per 7 days, never while a payout is in progress, old numbers stay in history. */
    suspend fun changePhone(workerId: String, newRaw: String, actor: String, at: Long = now()): Outcome<WorkerEntity> {
        val phone = PhoneUtil.parse(newRaw)
            ?: return Outcome.Err("Enter a valid MTN or Airtel Uganda number.")
        return db.withTransaction<Outcome<WorkerEntity>> {
            val w = dao.get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
            if (db.payoutDao().inProgressFor(workerId) != null)
                return@withTransaction Outcome.Err("A payout is in progress. The number cannot be changed until it is paid.")
            val last = w.phoneChangedAt
            if (last != null && at - last < TimeUtil.WEEK_MS)
                return@withTransaction Outcome.Err("The phone number can only be changed once per week.")
            if (phone.digits == w.phone) return@withTransaction Outcome.Err("That is already your number.")
            if (dao.getByPhone(phone.digits) != null) return@withTransaction Outcome.Err("That number belongs to another worker.")
            val updated = w.copy(phone = phone.digits, network = phone.network, phoneChangedAt = at)
            dao.update(updated)
            dao.insertPhone(PhoneHistoryEntity(workerId = w.id, phone = phone.digits, network = phone.network, changedAt = at, reason = "CHANGE (was ${w.phone})"))
            audit.log(actor, "PHONE_CHANGED", "worker", w.id, "${w.phone} -> ${phone.digits}", at)
            Outcome.Ok(updated)
        }
    }

    suspend fun editNames(workerId: String, first: String, middle: String, last: String, actor: String): Outcome<WorkerEntity> {
        if (first.isBlank() || last.isBlank()) return Outcome.Err("First and last name are required.")
        return db.withTransaction<Outcome<WorkerEntity>> {
            val w = dao.get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
            val u = w.copy(firstName = first.trim(), middleName = middle.trim(), lastName = last.trim())
            dao.update(u)
            audit.log(actor, "WORKER_EDITED", "worker", w.id, "${w.fullName()} -> ${u.fullName()}")
            Outcome.Ok(u)
        }
    }

    suspend fun setActive(workerId: String, active: Boolean, actor: String): Outcome<WorkerEntity> =
        db.withTransaction<Outcome<WorkerEntity>> {
            val w = dao.get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
            val u = w.copy(active = active)
            dao.update(u)
            audit.log(actor, if (active) "WORKER_ENABLED" else "WORKER_DISABLED", "worker", w.id)
            Outcome.Ok(u)
        }
}

// ---------------------------------------------------------------- TASKS

class TaskRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.taskDao()

    private fun snapshot(t: TaskEntity): String = JSONObject().apply {
        put("id", t.id); put("name", t.name); put("description", t.description)
        put("payUgx", t.payUgx); put("type", t.type)
        put("exampleVideoUrl", t.exampleVideoUrl); put("exampleLinkUrl", t.exampleLinkUrl)
        put("proofRequirements", t.proofRequirements); put("verificationRequirements", t.verificationRequirements)
        put("active", t.active); put("version", t.version); put("minTier", t.minTier)
    }.toString()

    suspend fun create(
        name: String, description: String, payUgx: Long, type: String,
        exampleVideoUrl: String = "", exampleLinkUrl: String = "",
        proofRequirements: String = "", verificationRequirements: String = "",
        actor: String, at: Long = now(), minTier: Int = 0
    ): Outcome<TaskEntity> {
        if (name.isBlank()) return Outcome.Err("Task name is required.")
        if (!TaskGate.valid(minTier)) return Outcome.Err("Unknown status level for this task.")
        if (payUgx <= 0) return Outcome.Err("Payment must be more than 0 UGX.")
        if (type != TaskType.DAILY && type != TaskType.ONE_TIME) return Outcome.Err("Unknown task type.")
        return db.withTransaction<Outcome<TaskEntity>> {
            val t = TaskEntity(
                id = newId(), name = name.trim(), description = description.trim(), payUgx = payUgx, type = type,
                exampleVideoUrl = exampleVideoUrl.trim(), exampleLinkUrl = exampleLinkUrl.trim(),
                proofRequirements = proofRequirements.trim(), verificationRequirements = verificationRequirements.trim(),
                createdAt = at, updatedAt = at, minTier = minTier
            )
            dao.insert(t)
            dao.insertVersion(TaskVersionEntity(taskId = t.id, version = 1, snapshotJson = snapshot(t), changedAt = at, changedBy = actor))
            audit.log(actor, "TASK_CREATED", "task", t.id, t.name, at)
            Outcome.Ok(t)
        }
    }

    /** Pass the edited copy. Version goes up by one and the old/new state is kept in task_versions. */
    suspend fun update(edited: TaskEntity, actor: String, at: Long = now()): Outcome<TaskEntity> {
        if (edited.name.isBlank()) return Outcome.Err("Task name is required.")
        if (edited.payUgx <= 0) return Outcome.Err("Payment must be more than 0 UGX.")
        if (!TaskGate.valid(edited.minTier)) return Outcome.Err("Unknown status level for this task.")
        return db.withTransaction<Outcome<TaskEntity>> {
            val old = dao.get(edited.id) ?: return@withTransaction Outcome.Err("Task not found.")
            val u = edited.copy(version = old.version + 1, createdAt = old.createdAt, updatedAt = at)
            dao.update(u)
            dao.insertVersion(TaskVersionEntity(taskId = u.id, version = u.version, snapshotJson = snapshot(u), changedAt = at, changedBy = actor))
            audit.log(actor, "TASK_UPDATED", "task", u.id, "v${old.version} -> v${u.version}", at)
            Outcome.Ok(u)
        }
    }

    suspend fun setActive(taskId: String, active: Boolean, actor: String): Outcome<TaskEntity> {
        val t = dao.get(taskId) ?: return Outcome.Err("Task not found.")
        return update(t.copy(active = active), actor)
    }
}

// ---------------------------------------------------------------- SUBMISSIONS

data class ProofInput(
    val kind: String,                 // SCREENSHOT, REFERENCE or TEXT
    val sha256: String? = null, val dhash: String? = null,
    val fileName: String? = null, val fileSize: Long? = null,
    val width: Int? = null, val height: Int? = null,
    val fileModifiedAt: Long? = null, val mime: String? = null, val metadataTags: String? = null,
    val textValue: String? = null,
    val verdict: String = Verdict.NONE, val verdictNotes: String = ""
)

class SubmissionRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.submissionDao()

    private suspend fun isAvailable(workerId: String, t: TaskEntity, dayKey: String): Boolean {
        val used = if (t.type == TaskType.DAILY) dao.countActiveForDay(workerId, t.id, dayKey)
        else dao.countActiveEver(workerId, t.id)
        return used == 0
    }

    /** Tasks the worker can do right now. Daily tasks reappear on the next East Africa day. */
    suspend fun availableTasks(workerId: String, at: Long = now()): List<TaskEntity> {
        val day = TimeUtil.dayKey(at)
        return db.taskDao().activeTasks().filter { isAvailable(workerId, it, day) }
    }

    /** True if this exact screenshot file hash was already submitted by anyone. */
    suspend fun screenshotSeenBefore(sha256: String): Boolean = dao.proofsBySha(sha256).isNotEmpty()

    suspend fun submit(
        workerId: String, taskId: String, proofs: List<ProofInput>,
        referenceText: String = "", explanation: String = "", at: Long = now()
    ): Outcome<SubmissionEntity> = db.withTransaction<Outcome<SubmissionEntity>> {
        val w = db.workerDao().get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
        if (!w.active) return@withTransaction Outcome.Err("This worker account is disabled.")
        val t = db.taskDao().get(taskId) ?: return@withTransaction Outcome.Err("Task not found.")
        if (!t.active) return@withTransaction Outcome.Err("This task is no longer active.")
        val day = TimeUtil.dayKey(at)
        if (!isAvailable(workerId, t, day)) return@withTransaction Outcome.Err("This task is not available right now.")

        val s = SubmissionEntity(
            id = newId(), taskId = t.id, workerId = workerId, taskVersion = t.version,
            dayKey = day, weekKey = TimeUtil.weekKey(at), seq = dao.maxSeq(workerId) + 1,
            status = SubStatus.PENDING, payUgx = t.payUgx,
            referenceText = referenceText.trim(), explanation = explanation.trim(), submittedAt = at
        )
        dao.insert(s)
        for (p in proofs) {
            dao.insertProof(
                ProofEntity(
                    submissionId = s.id, kind = p.kind, sha256 = p.sha256, dhash = p.dhash,
                    fileName = p.fileName, fileSize = p.fileSize, width = p.width, height = p.height,
                    fileModifiedAt = p.fileModifiedAt, mime = p.mime, metadataTags = p.metadataTags,
                    textValue = p.textValue, verdict = p.verdict, verdictNotes = p.verdictNotes, createdAt = at
                )
            )
        }
        audit.log("worker:$workerId", "SUBMISSION_CREATED", "submission", s.id, "task ${t.name} v${t.version}", at)
        Outcome.Ok(s)
    }

    /** Manager always has the final say, whatever the automatic verdict was. */
    suspend fun decide(submissionId: String, approve: Boolean, note: String, actor: String, at: Long = now()): Outcome<SubmissionEntity> =
        db.withTransaction<Outcome<SubmissionEntity>> {
            val s = dao.get(submissionId) ?: return@withTransaction Outcome.Err("Submission not found.")
            if (s.status != SubStatus.PENDING) return@withTransaction Outcome.Err("This submission was already decided.")
            val u = s.copy(
                status = if (approve) SubStatus.APPROVED else SubStatus.REJECTED,
                decidedAt = at, decidedBy = actor, decisionNote = note.trim()
            )
            dao.update(u)
            audit.log(actor, if (approve) "SUBMISSION_APPROVED" else "SUBMISSION_REJECTED", "submission", s.id, note.trim(), at)
            Outcome.Ok(u)
        }

    /** Let the worker do a one-time task again. */
    suspend fun reassignOneTime(workerId: String, taskId: String, actor: String) {
        db.withTransaction {
            dao.supersedeApproved(workerId, taskId)
            audit.log(actor, "ONE_TIME_REASSIGNED", "task", taskId, "worker $workerId")
        }
    }

    /** Approved money for the week that is not yet part of a payout request. */
    suspend fun expectedForWeek(workerId: String, weekKey: String): Long = dao.unpaidApprovedTotal(workerId, weekKey)
}

// ---------------------------------------------------------------- PAYOUTS

class PayoutRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.payoutDao()

    /** Worker asks for the week's approved earnings. Status becomes IN_PROGRESS. */
    suspend fun request(workerId: String, weekKey: String, at: Long = now()): Outcome<PayoutRequestEntity> =
        db.withTransaction<Outcome<PayoutRequestEntity>> {
            val w = db.workerDao().get(workerId) ?: return@withTransaction Outcome.Err("Worker not found.")
            if (dao.inProgressFor(workerId) != null) return@withTransaction Outcome.Err("You already have a payout in progress.")
            if (dao.forWeek(workerId, weekKey) != null) return@withTransaction Outcome.Err("A payout for that week was already requested.")
            val amount = db.submissionDao().unpaidApprovedTotal(workerId, weekKey)
            if (amount <= 0) return@withTransaction Outcome.Err("Nothing approved to pay for that week yet.")
            val p = PayoutRequestEntity(
                id = newId(), workerId = workerId, weekKey = weekKey, amountUgx = amount,
                phone = w.phone, network = w.network, status = PayoutStatus.IN_PROGRESS, requestedAt = at
            )
            dao.insert(p)
            db.submissionDao().attachToPayout(workerId, weekKey, p.id)
            audit.log("worker:$workerId", "PAYOUT_REQUESTED", "payout", p.id, "UGX $amount to ${w.phone}", at)
            Outcome.Ok(p)
        }

    /**
     * Manager confirms money was really sent. After this the record is permanent (PAID never changes back).
     * mode = "AUTO_MATCH" (statement matched) or "MANUAL".
     */
    suspend fun confirmPaid(
        payoutId: String, mode: String, statementRef: String?, confidence: String?,
        note: String, actor: String, at: Long = now()
    ): Outcome<PayoutRequestEntity> = db.withTransaction<Outcome<PayoutRequestEntity>> {
        val p = dao.get(payoutId) ?: return@withTransaction Outcome.Err("Payout not found.")
        if (p.status != PayoutStatus.IN_PROGRESS) return@withTransaction Outcome.Err("This payout is already completed.")
        val u = p.copy(
            status = PayoutStatus.PAID, paidAt = at, confirmedBy = actor, confirmationMode = mode,
            statementRef = statementRef, matchConfidence = confidence, note = note.trim()
        )
        dao.update(u)
        // R4d: points cash-outs that were added to this weekly payout are paid together with it
        for (pr in db.pointsRequestDao().attachedTo(p.id)) {
            db.pointsRequestDao().update(pr.copy(paidAt = at, ver = pr.ver + 1))
            audit.log(actor, "POINTS_REQUEST_PAID", "points_request", pr.uid, "paid with weekly payout " + p.id, at)
        }
        dao.insertPayment(
            PaymentEntity(
                payoutId = p.id, statementRef = statementRef ?: "", phone = p.phone,
                nameKey = NameUtil.key(db.workerDao().get(p.workerId)?.fullName() ?: ""),
                amountUgx = p.amountUgx, paidAtUtc = at, confidence = confidence ?: "NONE", createdAt = at
            )
        )
        audit.log(actor, "PAYOUT_CONFIRMED", "payout", p.id, "mode=$mode confidence=${confidence ?: "-"}", at)
        Outcome.Ok(u)
    }
}

// ---------------------------------------------------------------- MANAGER IDENTITY

/** Exactly one manager identity can exist. There is no "create manager" feature anywhere else. */
class ManagerRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.managerDao()

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    suspend fun isSetUp(): Boolean = dao.get() != null

    suspend fun setUp(pin: String, at: Long = now()): Outcome<Unit> {
        if (pin.length < 6) return Outcome.Err("PIN must be at least 6 characters.")
        return db.withTransaction<Outcome<Unit>> {
            if (dao.get() != null) return@withTransaction Outcome.Err("A manager already exists on this device.")
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            dao.insert(ManagerEntity(pinSalt = hex(salt), pinHash = hex(hash(pin, salt)), createdAt = at))
            audit.log("manager", "MANAGER_SETUP", "manager", "1", "", at)
            Outcome.Ok(Unit)
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val m = dao.get() ?: return false
        return MessageDigest.isEqual(hash(pin, unhex(m.pinSalt)), unhex(m.pinHash))
    }
}
