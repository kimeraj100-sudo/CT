package com.ctteam.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * RULES (so app updates never wipe data):
 *  - Never rename the database file (NAME) or use fallbackToDestructiveMigration().
 *  - Any change to an @Entity => raise `version` by 1 AND add a Migration below.
 *
 * Version history:
 *  1 = piece 2 (all base tables)
 *  2 = piece 4A (manager_accounts: up to 20 managers with code names + PINs)
 *  3 = piece 4B (passwords + activation for managers; pin_ledger, device_trust, worker_credentials)
 *  4 = piece 5A (sync_keys, sync_seen: per-worker HMAC keys and replay protection)
 *  5 = piece 5B (sync_outbox: fixed message numbers for worker reports)
 *  6 = piece 5D (worker_usernames: one username per worker, unique across workers)
 *  7 = piece 5E (manager_rev: last signed manager code used per account)
 *  8 = piece 8C (nc_claims.claimUid + taskId)
 *  9 = piece T1 (team_contributions, team_rates: team mining ledger and UGX rates)
 * 10 = piece T3a (team_mined_days: real daily mined amounts)
 * 11 = piece T3b (team_goals, team_rigs: weekly hash goal and rig ledger)
 * 12 = piece T3c (team_gifts: gifts from the manager to a worker, with a reason)
 * 13 = piece 9A (tg_chats, tg_inbox: Telegram chat of each worker, items waiting for the manager)
 * 14 = piece R1 (referral_codes, referrals, points_ledger: referral rewards, points and status)
 * 15 = piece R4a (points_requests)
 * 16 = piece R4d (points_requests.payMethod + payRef)
 * 17 = piece R5a-1 (tasks.minTier: lowest status that may do a task)
 */
@Database(
    entities = [
        WorkerEntity::class, PhoneHistoryEntity::class,
        TaskEntity::class, TaskVersionEntity::class,
        SubmissionEntity::class, ProofEntity::class,
        PayoutRequestEntity::class, PaymentEntity::class,
        NcStatementEntity::class, NcRowEntity::class, NcClaimEntity::class,
        SupportMessageEntity::class, AnnouncementEntity::class, LearnContentEntity::class,
        AuditEntity::class, EventEntity::class, MetaEntity::class, ManagerEntity::class,
        ManagerAccountEntity::class,
        PinLedgerEntity::class, DeviceTrustEntity::class, WorkerCredentialEntity::class,
        SyncKeyEntity::class, SyncSeenEntity::class, SyncOutboxEntity::class, WorkerUsernameEntity::class,
        ManagerRevEntity::class,
        TeamContributionEntity::class, TeamRateEntity::class,
        TeamMinedDayEntity::class,
        TeamGoalEntity::class, TeamRigEntity::class,
        TeamGiftEntity::class,
        TgChatEntity::class, TgInboxEntity::class,
        ReferralCodeEntity::class, ReferralEntity::class, PointsEntryEntity::class,
        PointsRequestEntity::class
    ],
    version = 17,
    exportSchema = true
)
abstract class CTDatabase : RoomDatabase() {
    abstract fun workerDao(): WorkerDao
    abstract fun taskDao(): TaskDao
    abstract fun submissionDao(): SubmissionDao
    abstract fun payoutDao(): PayoutDao
    abstract fun ncDao(): NcDao
    abstract fun supportDao(): SupportDao
    abstract fun contentDao(): ContentDao
    abstract fun auditDao(): AuditDao
    abstract fun eventDao(): EventDao
    abstract fun metaDao(): MetaDao
    abstract fun tgDao(): TgDao
    abstract fun managerDao(): ManagerDao
    abstract fun managerSyncDao(): ManagerSyncDao
    abstract fun managerAccountDao(): ManagerAccountDao
    abstract fun securityDao(): SecurityDao
    abstract fun syncDao(): SyncDao
    abstract fun teamDao(): TeamDao
    abstract fun teamGoalDao(): TeamGoalDao
    abstract fun teamGiftDao(): TeamGiftDao
    abstract fun referralDao(): ReferralDao
    abstract fun pointsRequestDao(): PointsRequestDao

    companion object {
        const val NAME = "ctteam.db"

        fun build(context: Context): CTDatabase =
            Room.databaseBuilder(context.applicationContext, CTDatabase::class.java, NAME)
                .addMigrations(*Migrations.ALL)
                .build()
    }
}

/** Add one Migration per schema version bump. Never delete old ones. */
object Migrations {
    val MIGRATION_1_2: Migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `manager_accounts` (" +
                    "`id` TEXT NOT NULL, `codeName` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, " +
                    "`pinHash` TEXT NOT NULL, `iterations` INTEGER NOT NULL, `isMain` INTEGER NOT NULL, " +
                    "`suspendedUntil` INTEGER, `accessExpiresAt` INTEGER, `note` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_manager_accounts_codeName` " +
                    "ON `manager_accounts` (`codeName`)"
            )
        }
    }

    /** Piece 4B: existing managers keep their PIN and become "not activated" (passHash null) until they create a password. */
    val MIGRATION_2_3: Migration = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passSalt` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `passHash` TEXT")
            db.execSQL("ALTER TABLE `manager_accounts` ADD COLUMN `credVersion` INTEGER NOT NULL DEFAULT 1")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `pin_ledger` (" +
                    "`fingerprint` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`fingerprint`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `device_trust` (" +
                    "`subjectId` TEXT NOT NULL, `kind` TEXT NOT NULL, `trustedAt` INTEGER NOT NULL, " +
                    "`credVersion` INTEGER NOT NULL, PRIMARY KEY(`subjectId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `worker_credentials` (" +
                    "`workerId` TEXT NOT NULL, `username` TEXT NOT NULL, `passSalt` TEXT NOT NULL, " +
                    "`passHash` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, `pinHash` TEXT NOT NULL, " +
                    "`iterations` INTEGER NOT NULL, `credVersion` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE UNIQUE INDEX IF NOT EXISTS `index_worker_credentials_username` " +
                    "ON `worker_credentials` (`username`)"
            )
        }
    }

    /** Piece 5A: two new tables only; nothing existing is touched. */
    val MIGRATION_3_4: Migration = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_keys` (" +
                    "`workerId` TEXT NOT NULL, `keyHex` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_seen` (" +
                    "`workerId` TEXT NOT NULL, `direction` TEXT NOT NULL, `seq` INTEGER NOT NULL, " +
                    "`type` TEXT NOT NULL, `receivedAt` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`workerId`, `direction`, `seq`))"
            )
        }
    }

    /** Piece 5B: one new table only; nothing existing is touched. */
    val MIGRATION_4_5: Migration = object : Migration(4, 5) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `sync_outbox` (" +
                    "`itemKey` TEXT NOT NULL, `workerId` TEXT NOT NULL, `type` TEXT NOT NULL, " +
                    "`seq` INTEGER NOT NULL, `madeAt` INTEGER NOT NULL, PRIMARY KEY(`itemKey`))"
            )
        }
    }

    /** Piece 5D: one new table only. */
    val MIGRATION_5_6: Migration = object : Migration(5, 6) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `worker_usernames` (" +
                    "`username` TEXT NOT NULL, `workerId` TEXT NOT NULL, PRIMARY KEY(`username`))"
            )
        }
    }

    /** Piece 5E: one new table only. */
    val MIGRATION_6_7: Migration = object : Migration(6, 7) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `manager_rev` (" +
                    "`accountId` TEXT NOT NULL, `rev` INTEGER NOT NULL, `removed` INTEGER NOT NULL, " +
                    "PRIMARY KEY(`accountId`))"
            )
        }
    }

    /** Piece 8C: two nullable columns + a unique index on the claim id (existing rows keep NULL, which the index allows). */
    val MIGRATION_7_8: Migration = object : Migration(7, 8) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `nc_claims` ADD COLUMN `claimUid` TEXT")
            db.execSQL("ALTER TABLE `nc_claims` ADD COLUMN `taskId` TEXT")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_nc_claims_claimUid` ON `nc_claims` (`claimUid`)")
        }
    }

    /** Piece T1: two new tables only; nothing existing is touched. */
    val MIGRATION_8_9: Migration = object : Migration(8, 9) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_contributions` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `claimId` INTEGER NOT NULL, `claimUid` TEXT, " +
                    "`workerId` TEXT NOT NULL, `coin` TEXT NOT NULL, `amountText` TEXT NOT NULL, " +
                    "`contributedAtUtc` INTEGER NOT NULL, `verifiedAt` INTEGER NOT NULL, `rateText` TEXT, `rateSetAt` INTEGER, " +
                    "`valueUgx` INTEGER, `status` TEXT NOT NULL, `voidKind` TEXT, `voidNote` TEXT NOT NULL, `voidedAt` INTEGER, " +
                    "`createdAt` INTEGER NOT NULL)"
            )
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_team_contributions_claimId` ON `team_contributions` (`claimId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_team_contributions_workerId` ON `team_contributions` (`workerId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_team_contributions_status` ON `team_contributions` (`status`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_rates` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `coin` TEXT NOT NULL, `ugxPerUnitText` TEXT NOT NULL, " +
                    "`setAt` INTEGER NOT NULL, `setBy` TEXT NOT NULL, `note` TEXT NOT NULL)"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_team_rates_coin` ON `team_rates` (`coin`)")
        }
    }

    /** Piece T3a: one new table only; nothing existing is touched. */
    val MIGRATION_9_10: Migration = object : Migration(9, 10) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_mined_days` (" +
                    "`day` TEXT NOT NULL, `minedUgx` INTEGER NOT NULL, `note` TEXT NOT NULL, `setBy` TEXT NOT NULL, " +
                    "`setAt` INTEGER NOT NULL, PRIMARY KEY(`day`))"
            )
        }
    }

    /** Piece T3b: two new tables only; nothing existing is touched. */
    val MIGRATION_10_11: Migration = object : Migration(10, 11) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_goals` (" +
                    "`weekKey` TEXT NOT NULL, `targetText` TEXT NOT NULL, `unit` TEXT NOT NULL, `note` TEXT NOT NULL, " +
                    "`setBy` TEXT NOT NULL, `setAt` INTEGER NOT NULL, PRIMARY KEY(`weekKey`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_rigs` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `hashText` TEXT NOT NULL, `unit` TEXT NOT NULL, " +
                    "`costUgx` INTEGER, `boughtAt` INTEGER NOT NULL, `fundedNote` TEXT NOT NULL, `status` TEXT NOT NULL, " +
                    "`soldAt` INTEGER, `setBy` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_team_rigs_status` ON `team_rigs` (`status`)")
        }
    }

    /** Piece T3c: one new table only; nothing existing is touched. */
    val MIGRATION_11_12: Migration = object : Migration(11, 12) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `team_gifts` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `workerId` TEXT NOT NULL, `kind` TEXT NOT NULL, " +
                    "`multiplierText` TEXT, `fixedUgx` INTEGER, `fromDay` TEXT NOT NULL, `toDay` TEXT NOT NULL, `reason` TEXT NOT NULL, " +
                    "`createdBy` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `voidedAt` INTEGER, `voidedBy` TEXT)"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_team_gifts_workerId` ON `team_gifts` (`workerId`)")
        }
    }

    /** Piece 9A: two new tables only; nothing existing is touched. */
    val MIGRATION_12_13: Migration = object : Migration(12, 13) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `tg_chats` (" +
                    "`workerId` TEXT NOT NULL, `chatId` INTEGER NOT NULL, `username` TEXT, `firstName` TEXT NOT NULL, " +
                    "`boundAt` INTEGER NOT NULL, `lastSeenAt` INTEGER NOT NULL, PRIMARY KEY(`workerId`))"
            )
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `tg_inbox` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `receivedAt` INTEGER NOT NULL, `chatId` INTEGER NOT NULL, " +
                    "`workerId` TEXT, `kind` TEXT NOT NULL, `status` TEXT NOT NULL, `title` TEXT NOT NULL, `detail` TEXT NOT NULL, " +
                    "`wire` TEXT, `handledAt` INTEGER)"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_tg_inbox_status` ON `tg_inbox` (`status`)")
        }
    }

    /** Piece R1: three new tables only; nothing existing is touched. */
    val MIGRATION_13_14: Migration = object : Migration(13, 14) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `referral_codes` (" +
                    "`workerId` TEXT NOT NULL, `code` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`workerId`))"
            )
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_referral_codes_code` ON `referral_codes` (`code`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `referrals` (" +
                    "`referredId` TEXT NOT NULL, `referrerId` TEXT NOT NULL, `code` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                    "`status` TEXT NOT NULL, `decidedAt` INTEGER, `note` TEXT NOT NULL, PRIMARY KEY(`referredId`))"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_referrals_referrerId` ON `referrals` (`referrerId`)")
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `points_ledger` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `workerId` TEXT NOT NULL, `points` INTEGER NOT NULL, " +
                    "`kind` TEXT NOT NULL, `refKey` TEXT NOT NULL, `note` TEXT NOT NULL, `actor` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)"
            )
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_points_ledger_workerId_kind_refKey` ON `points_ledger` (`workerId`, `kind`, `refKey`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_points_ledger_workerId` ON `points_ledger` (`workerId`)")
        }
    }

    /** Piece R4a: one new table (points requests); nothing existing is touched. */
    val MIGRATION_14_15: Migration = object : Migration(14, 15) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `points_requests` (" +
                    "`uid` TEXT NOT NULL, `workerId` TEXT NOT NULL, `points` INTEGER NOT NULL, `kind` TEXT NOT NULL, " +
                    "`note` TEXT NOT NULL, `status` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `decidedAt` INTEGER, " +
                    "`decisionNote` TEXT NOT NULL, `ugxAmount` INTEGER, `ugxRate` INTEGER NOT NULL, `giftText` TEXT NOT NULL, " +
                    "`paidAt` INTEGER, `ver` INTEGER NOT NULL, PRIMARY KEY(`uid`))"
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_points_requests_workerId` ON `points_requests` (`workerId`)")
            db.execSQL("CREATE INDEX IF NOT EXISTS `index_points_requests_status` ON `points_requests` (`status`)")
        }
    }

    /** Piece R4d: two nullable columns on points_requests (how a cash-out is paid, and the gift / payout it is tied to). */
    val MIGRATION_15_16: Migration = object : Migration(15, 16) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `points_requests` ADD COLUMN `payMethod` TEXT")
            db.execSQL("ALTER TABLE `points_requests` ADD COLUMN `payRef` TEXT")
        }
    }

    /** Piece R5a-1: one column on tasks. DEFAULT 0 = every existing task stays open to everyone. */
    val MIGRATION_16_17: Migration = object : Migration(16, 17) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE `tasks` ADD COLUMN `minTier` INTEGER NOT NULL DEFAULT 0")
        }
    }

    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17)
}
