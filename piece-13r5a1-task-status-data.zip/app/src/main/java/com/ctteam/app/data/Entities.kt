package com.ctteam.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** String constants used in status/type columns (stored as text so they survive app updates). */
object TaskType { const val DAILY = "DAILY"; const val ONE_TIME = "ONE_TIME" }
object SubStatus { const val PENDING = "PENDING"; const val APPROVED = "APPROVED"; const val REJECTED = "REJECTED" }
object PayoutStatus { const val IN_PROGRESS = "IN_PROGRESS"; const val PAID = "PAID" }
object Verdict { const val NONE = "NONE"; const val OK = "OK"; const val CHECK = "CHECK"; const val DONT_TRUST = "DONT_TRUST" }
object Dir { const val TO_MANAGER = "TO_MANAGER"; const val TO_WORKER = "TO_WORKER" }
object NcStatus { const val UNMATCHED = "UNMATCHED"; const val MATCHED = "MATCHED"; const val MANUAL = "MANUAL" }

@Entity(tableName = "workers", indices = [Index(value = ["nationalId"], unique = true), Index(value = ["phone"])])
data class WorkerEntity(
    @PrimaryKey val id: String,
    val nationalId: String,
    val firstName: String,
    val middleName: String,
    val lastName: String,
    val phone: String,            // normalized 2567XXXXXXXX
    val network: String,          // MTN or AIRTEL
    val active: Boolean = true,
    val createdAt: Long,
    val phoneChangedAt: Long? = null,
    val telegramChatId: String? = null
) {
    fun fullName(): String = listOf(firstName, middleName, lastName).filter { it.isNotBlank() }.joinToString(" ")
}

@Entity(tableName = "phone_history", indices = [Index("workerId")])
data class PhoneHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val phone: String,
    val network: String,
    val changedAt: Long,
    val reason: String
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val payUgx: Long,
    val type: String,             // TaskType
    val exampleVideoUrl: String = "",
    val exampleLinkUrl: String = "",
    val proofRequirements: String = "",
    val verificationRequirements: String = "",
    val active: Boolean = true,
    val version: Int = 1,
    val createdAt: Long,
    val updatedAt: Long,
    val minTier: Int = 0          // Piece R5: lowest referral status that may do this task (0 = everyone, 2 Builder, 3 Leader, 4 Champion)
)

@Entity(tableName = "task_versions", indices = [Index("taskId")])
data class TaskVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: String,
    val version: Int,
    val snapshotJson: String,
    val changedAt: Long,
    val changedBy: String
)

@Entity(
    tableName = "submissions",
    indices = [Index("workerId"), Index("taskId"), Index("status"), Index("weekKey"), Index("payoutId")]
)
data class SubmissionEntity(
    @PrimaryKey val id: String,
    val taskId: String,
    val workerId: String,
    val taskVersion: Int,
    val dayKey: String,           // yyyy-MM-dd in East Africa Time
    val weekKey: String,          // Monday date of the week (yyyy-MM-dd)
    val seq: Long,                // per-worker sequence number (replay protection, piece 5)
    val status: String,           // SubStatus
    val payUgx: Long,             // amount frozen at submission time
    val referenceText: String = "",
    val explanation: String = "",
    val submittedAt: Long,
    val decidedAt: Long? = null,
    val decidedBy: String? = null,
    val decisionNote: String = "",
    val payoutId: String? = null, // set once this approved amount is included in a payout request
    val superseded: Boolean = false // true when manager re-assigned a one-time task
)

@Entity(tableName = "proofs", indices = [Index("submissionId"), Index("sha256")])
data class ProofEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val submissionId: String,
    val kind: String,             // SCREENSHOT, REFERENCE, TEXT
    val sha256: String? = null,
    val dhash: String? = null,
    val fileName: String? = null,
    val fileSize: Long? = null,
    val width: Int? = null,
    val height: Int? = null,
    val fileModifiedAt: Long? = null,
    val mime: String? = null,
    val metadataTags: String? = null,
    val textValue: String? = null,
    val verdict: String = Verdict.NONE,
    val verdictNotes: String = "",
    val createdAt: Long
)

@Entity(tableName = "payout_requests", indices = [Index("workerId"), Index("status"), Index("weekKey")])
data class PayoutRequestEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val weekKey: String,
    val amountUgx: Long,
    val phone: String,            // number the money is sent to (frozen at request time)
    val network: String,
    val status: String,           // PayoutStatus
    val requestedAt: Long,
    val paidAt: Long? = null,
    val confirmedBy: String? = null,
    val confirmationMode: String? = null,   // AUTO_MATCH or MANUAL
    val statementRef: String? = null,
    val matchConfidence: String? = null,    // STRONG, POSSIBLE, NONE
    val note: String = ""
)

@Entity(tableName = "payments", indices = [Index("payoutId")])
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val payoutId: String? = null,
    val statementRef: String = "",
    val phone: String = "",
    val nameKey: String = "",
    val amountUgx: Long,
    val paidAtUtc: Long,
    val confidence: String = "NONE",
    val createdAt: Long
)

@Entity(tableName = "nc_statements", indices = [Index(value = ["fileSha256"], unique = true)])
data class NcStatementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val fileSha256: String,
    val importedAt: Long,
    val rowCount: Int
)

@Entity(tableName = "nc_rows", indices = [Index(value = ["rowKey"], unique = true), Index("matchedClaimId")])
data class NcRowEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val statementId: Long,
    val rowKey: String,           // coin|amount|utcMillis  (stops overlapping statements counting twice)
    val rowNo: String,
    val coin: String,
    val amountText: String,       // exact decimal text, never a float
    val occurredAtUtc: Long,      // statement time is UTC
    val matchedClaimId: Long? = null
)

@Entity(tableName = "nc_claims", indices = [Index("workerId"), Index("status"), Index(value = ["claimUid"], unique = true)])
data class NcClaimEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val coin: String = "BNB",
    val amountText: String,
    val claimedAtUtc: Long,       // already converted to UTC
    val timezoneContext: String = "EAT",
    val status: String = NcStatus.UNMATCHED,
    val matchedRowId: Long? = null,
    val createdAt: Long,
    val claimUid: String? = null, // Piece 8C: id made on the worker phone; the same on both phones, so a claim is never imported twice
    val taskId: String? = null    // Piece 8C: the task the worker says the deposit is for (optional)
)

@Entity(tableName = "support_messages", indices = [Index("workerId")])
data class SupportMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workerId: String,
    val direction: String,        // Dir
    val body: String,
    val createdAt: Long,
    val telegramMessageId: String? = null,
    val readAt: Long? = null
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val active: Boolean = true
)

@Entity(tableName = "learn_content")
data class LearnContentEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val category: String = "",
    val imageUrl: String = "",
    val videoUrl: String = "",
    val published: Boolean = false,
    val version: Int = 1,
    val updatedAt: Long
)

/** Tamper-evident log: every row stores the hash of the previous row. */
@Entity(tableName = "audit_log")
data class AuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actor: String,
    val action: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val createdAt: Long,
    val prevHash: String,
    val hash: String
)

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val details: String,
    val createdAt: Long
)

@Entity(tableName = "meta")
data class MetaEntity(
    @PrimaryKey val key: String,
    val value: String
)

/** The single manager identity. Only one row (id = 1) can ever exist. */
@Entity(tableName = "manager_identity")
data class ManagerEntity(
    @PrimaryKey val id: Int = 1,
    val pinSalt: String,
    val pinHash: String,
    val keyFingerprint: String? = null, // filled in by piece 5 (security & sync)
    val createdAt: Long
)
