package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos

/**
 * Piece 16c: one line on the manager home that says whether this phone is reading the Telegram bot right now.
 * Good = reading, with the time of the last good check. Bad = no bot, paused, or the last check failed (with the reason).
 */
@Composable
fun TgStatusLine(repos: Repos) {
    val liveFlow = remember(repos) { repos.telegram.live }
    val live by liveFlow.collectAsState()
    var state by remember { mutableStateOf("") } // "", "nobot", "paused"
    LaunchedEffect(repos, live.running) {
        state = when {
            repos.telegram.token() == null -> "nobot"
            repos.telegram.isPaused() -> "paused"
            else -> ""
        }
    }
    val good = Color(0xFF5FD6A5)
    val bad = Color(0xFFFF8A8A)
    val err = live.lastError
    val text: String
    val color: Color
    when {
        state == "nobot" -> { text = "Telegram: no bot connected. Open Menu > Telegram to connect your bot."; color = bad }
        state == "paused" -> { text = "Telegram: reading is paused. Open Menu > Telegram to resume."; color = bad }
        err != null -> { text = "Telegram: problem. " + err; color = bad }
        live.lastOkAt > 0L -> { text = "Telegram: reading. Last check " + fmtTime(live.lastOkAt) + "."; color = good }
        else -> { text = "Telegram: starting to read..."; color = good }
    }
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        androidx.compose.material3.Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(0.dp))
    }
}
