package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PointsReqKind
import com.ctteam.app.data.PointsReqStatus
import com.ctteam.app.data.PointsRequestEntity
import com.ctteam.app.data.ReferralRules
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece R4c — Manager > Referrals > Requests: workers' requests to use points. Approving removes the points from the real ledger and
 * fixes the UGX amount (cash-out) or the gift; it does NOT pay anything by itself: the manager pays or gives, then taps MARK PAID / GIVEN.
 * The worker hears about every change with the next update (Sync or Telegram).
 */
private val RQ_BAD = Color(0xFFFF8A8A)
private val RQ_GOOD = Color(0xFF5FD6A5)
private val RQ_WAIT = Color(0xFFFFD166)

@Composable
fun RfRequestsTab(repos: Repos, actor: String, names: Map<String, String>, say: (String, Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    val reqFlow = remember(repos) { repos.pointsRequests.observeAll() }
    val all by reqFlow.collectAsState(initial = emptyList())
    val balFlow = remember(repos) { repos.referral.observeBalances() }
    val balances by balFlow.collectAsState(initial = emptyList())
    var rate by remember { mutableStateOf(0L) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val texts = remember { mutableStateMapOf<String, String>() }       // per request: reason / note for the worker
    val gifts = remember { mutableStateMapOf<String, String>() }       // per request: what the gift is

    LaunchedEffect(all.size) { rate = repos.referral.ugxPerPoint() }

    val shown = all.filter { it.status != PointsReqStatus.CANCELLED }
        .sortedWith(compareBy<PointsRequestEntity>({ if (it.status == PointsReqStatus.OPEN) 0 else 1 }, { -it.createdAt }))
        .take(30)

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Points requests", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Approving takes the points off the worker's balance and writes down the UGX (cash-out) or the gift. It does not send money: " +
                "you pay or give outside the app, then tap MARK PAID. The worker sees every answer with your next update. " +
                "Rate now: UGX " + rate + " per point (change it in Rules; the rate at the moment of approval counts).",
            color = CT.TextSoft, fontSize = 12.sp
        )
    }
    if (shown.isEmpty()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) { Text("No requests yet. Workers send them with their reports.", color = CT.TextSoft, fontSize = 13.sp) }
        return
    }

    for (r in shown) {
        val name = names[r.workerId] ?: "Unknown"
        val bal = balances.firstOrNull { it.workerId == r.workerId }?.total ?: 0
        val cash = r.kind == PointsReqKind.CASHOUT
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    when (r.status) { PointsReqStatus.OPEN -> "WAITING"; PointsReqStatus.APPROVED -> "APPROVED"; else -> "REJECTED" },
                    color = when (r.status) { PointsReqStatus.OPEN -> RQ_WAIT; PointsReqStatus.APPROVED -> RQ_GOOD; else -> RQ_BAD },
                    fontWeight = FontWeight.Bold, fontSize = 12.sp
                )
            }
            Text((if (cash) "Cash-out" else "Gift") + " · " + r.points + " points · " + fmtTime(r.createdAt), color = CT.TextSoft, fontSize = 12.sp)
            if (r.note.isNotBlank()) Text("Worker wrote: " + r.note, color = Color.White, fontSize = 13.sp)

            when (r.status) {
                PointsReqStatus.OPEN -> {
                    Text(
                        "Real balance now: " + bal + " points" + (if (bal < r.points) " (not enough)" else ""),
                        color = if (bal < r.points) RQ_BAD else CT.TextSoft, fontSize = 12.sp
                    )
                    if (cash) {
                        Text(
                            if (rate > 0L) "If approved: " + ugx(ReferralRules.ugxFor(r.points, rate)) + " (" + rate + " per point)"
                            else "UGX per point is 0: set it in Rules first.",
                            color = CT.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        Spacer(Modifier.height(4.dp))
                        CTField(gifts[r.uid] ?: "", { gifts[r.uid] = it.take(200) }, "What the gift is (the worker sees this)")
                    }
                    Spacer(Modifier.height(4.dp))
                    CTField(texts[r.uid] ?: "", { texts[r.uid] = it.take(300) }, "Note to the worker (needed to reject)")
                    Spacer(Modifier.height(6.dp))
                    val key = "A:" + r.uid
                    GoldButton(
                        text = if (confirm == key) "TAP AGAIN: TAKE " + r.points + " POINTS AND APPROVE" else "APPROVE",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            if (!busy) {
                                if (confirm != key) {
                                    confirm = key
                                } else {
                                    busy = true
                                    scope.launch {
                                        when (val d = repos.pointsRequests.decide(r.uid, true, gifts[r.uid] ?: "", texts[r.uid] ?: "", actor)) {
                                            is Outcome.Err -> say(d.message, true)
                                            is Outcome.Ok -> say("Approved for " + name + ". Send them an update so they see it.", false)
                                        }
                                        confirm = null
                                        busy = false
                                    }
                                }
                            }
                        }
                    )
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "REJECT", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        if (!busy) {
                            busy = true
                            scope.launch {
                                when (val d = repos.pointsRequests.decide(r.uid, false, "", texts[r.uid] ?: "", actor)) {
                                    is Outcome.Err -> say(d.message, true)
                                    is Outcome.Ok -> say("Rejected. The points stay with " + name + ". Send them an update so they see it.", false)
                                }
                                confirm = null
                                busy = false
                            }
                        }
                    })
                }
                PointsReqStatus.APPROVED -> {
                    Text(
                        "✓ " + (if (cash) ugx(r.ugxAmount ?: 0L) + " (" + r.ugxRate + " per point)" else r.giftText),
                        color = RQ_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                    )
                    if (r.decisionNote.isNotBlank()) Text("Your note: " + r.decisionNote, color = CT.TextSoft, fontSize = 12.sp)
                    val p = r.paidAt
                    if (p != null) {
                        Text((if (cash) "Paid " else "Given ") + fmtTime(p), color = CT.TextSoft, fontSize = 12.sp)
                    } else {
                        Text(if (cash) "Not paid yet. Pay the worker, then tap below." else "Not given yet. Hand it over, then tap below.", color = RQ_WAIT, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        val key = "P:" + r.uid
                        GoldButton(
                            text = if (confirm == key) "TAP AGAIN TO CONFIRM" else if (cash) "MARK PAID" else "MARK GIVEN",
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                if (!busy) {
                                    if (confirm != key) {
                                        confirm = key
                                    } else {
                                        busy = true
                                        scope.launch {
                                            when (val d = repos.pointsRequests.markPaid(r.uid, actor)) {
                                                is Outcome.Err -> say(d.message, true)
                                                is Outcome.Ok -> say("Marked. Send " + name + " an update so they see it.", false)
                                            }
                                            confirm = null
                                            busy = false
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
                else -> {
                    Text("Not approved" + (if (r.decisionNote.isNotBlank()) ": " + r.decisionNote else "."), color = RQ_BAD, fontSize = 13.sp)
                }
            }
        }
    }
}
