package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Auth
import com.ctteam.app.data.LockoutStore
import com.ctteam.app.data.ManagerAccountEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.Secrets
import com.ctteam.app.data.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Piece 4B — sign-in screens shared by Manager and Worker mode.
 *
 *  QUICK    : "Welcome back" — type your PIN OR your password. Only offered on a phone where a full
 *             sign-in happened less than 30 days ago.
 *  FULL     : name (code name / username) + password + PIN.
 *  ACTIVATE : managers only — code name + the PIN the main manager gave you, then create your password.
 */

private val RED = Color(0xFFFF8A8A)

sealed class GateResult {
    object Ok : GateResult()
    data class Fail(val message: String, val wrong: Boolean) : GateResult()
}

fun <T> Auth<T>.toGate(): GateResult = when (this) {
    is Auth.Ok -> GateResult.Ok
    is Auth.Wrong -> GateResult.Fail(message, true)
    is Auth.Denied -> GateResult.Fail(message, false)
}

private fun lockText(ms: Long): String {
    val s = (ms + 999) / 1000
    return if (s < 60) "$s seconds" else ((s + 59) / 60).toString() + " minutes"
}

private enum class GateMode { QUICK, FULL, ACTIVATE }

/**
 * PIN fields only accept digits. On the Worker sign-in / register screens (allowDemo) the word "demo" is also let
 * through, one letter at a time, so the demo can be opened. Real PINs are still checked as digits-only on save.
 */
fun demoAwarePin(raw: String, max: Int, allowDemo: Boolean): String {
    val low = raw.lowercase()
    if (allowDemo && low.isNotEmpty() && "demo".startsWith(low)) return low
    return raw.filter { it.isDigit() }.take(max)
}

@Composable
fun CredentialGate(
    title: String,
    subtitle: String,
    idLabel: String,                 // "Code name" or "Username"
    notice: String,
    quickName: String?,              // non-null = quick unlock is available for this person on this phone
    lock: LockoutStore,
    onQuick: suspend (secret: String) -> GateResult,
    onFull: suspend (id: String, password: String, pin: String) -> GateResult,
    onActivate: (suspend (id: String, pin: String, newPassword: String) -> GateResult)?,
    onForgot: (() -> Unit)?,
    onDone: () -> Unit,
    onExit: () -> Unit,
    allowDemo: Boolean = false,          // Worker mode only: typing "demo" opens the in-memory demo worker
    onDemo: (() -> Unit)? = null
) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(if (quickName != null) GateMode.QUICK else GateMode.FULL) }
    var idText by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var newPass2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(notice) }
    var busy by remember { mutableStateOf(false) }

    fun attempt(block: suspend () -> GateResult) {
        if (busy) return
        error = ""
        busy = true
        scope.launch {
            val rem = lock.remainingMs()
            if (rem > 0) {
                error = "Too many wrong tries. Wait " + lockText(rem) + "."
                busy = false
                return@launch
            }
            val r = withContext(Dispatchers.Default) { block() }
            busy = false
            when (r) {
                is GateResult.Ok -> {
                    lock.clear()
                    password = ""; pin = ""; secret = ""; newPass = ""; newPass2 = ""
                    onDone()
                }
                is GateResult.Fail -> {
                    error = r.message
                    if (r.wrong) {
                        val l = lock.recordFailure()
                        if (l > 0) error = "Too many wrong tries. Locked for " + lockText(l) + "."
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ShimmerLogo(modifier = Modifier.height(110.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = CT.Gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Spacer(Modifier.height(6.dp))

        when (mode) {
            GateMode.QUICK -> {
                Text("Welcome back, " + (quickName ?: ""), color = CT.GoldLight, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Type your PIN or your password.",
                    color = CT.TextSoft, fontSize = 14.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(18.dp))
                CTField(secret, { secret = it }, "PIN or password", keyboard = KeyboardType.Password, secret = true)
            }
            GateMode.FULL -> {
                Text(subtitle, color = CT.TextSoft, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(18.dp))
                CTField(idText, { idText = it }, idLabel)
                Spacer(Modifier.height(10.dp))
                CTField(password, { password = it }, "Password", keyboard = KeyboardType.Password, secret = true)
                Spacer(Modifier.height(10.dp))
                CTField(
                    pin, { pin = demoAwarePin(it, Secrets.MANAGER_PIN_MAX, allowDemo) }, "PIN",
                    keyboard = if (allowDemo) KeyboardType.Password else KeyboardType.NumberPassword, secret = true
                )
            }
            GateMode.ACTIVATE -> {
                Text(
                    "First time, or the main manager reset your account. Enter your code name and the PIN you were given, then create your own password.",
                    color = CT.TextSoft, fontSize = 14.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(18.dp))
                CTField(idText, { idText = it }, idLabel)
                Spacer(Modifier.height(10.dp))
                CTField(pin, { pin = it.filter { c -> c.isDigit() }.take(Secrets.MANAGER_PIN_MAX) }, "PIN you were given", keyboard = KeyboardType.NumberPassword, secret = true)
                Spacer(Modifier.height(10.dp))
                CTField(newPass, { newPass = it }, "Create your password", keyboard = KeyboardType.Password, secret = true)
                Spacer(Modifier.height(10.dp))
                CTField(newPass2, { newPass2 = it }, "Repeat password", keyboard = KeyboardType.Password, secret = true)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Password: at least ${Secrets.PASSWORD_MIN} characters with a letter and a digit.",
                    color = CT.TextSoft, fontSize = 12.sp, textAlign = TextAlign.Center
                )
            }
        }

        if (error.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = RED, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(18.dp))

        when (mode) {
            GateMode.QUICK -> GoldButton(
                text = if (busy) "PLEASE WAIT" else "UNLOCK",
                onClick = {
                    val s = secret
                    if (allowDemo && onDemo != null && WorkerDemo.isDemoWord(s)) onDemo()
                    else if (s.isEmpty()) error = "Enter your PIN or password." else attempt { onQuick(s) }
                }
            )
            GateMode.FULL -> GoldButton(
                text = if (busy) "PLEASE WAIT" else "SIGN IN",
                onClick = {
                    val i = idText
                    val p = password
                    val n = pin
                    if (allowDemo && onDemo != null && WorkerDemo.isDemoLogin(i, p, n)) onDemo()
                    else if (i.isBlank() || p.isEmpty() || n.isEmpty()) error = "Fill in $idLabel, password and PIN."
                    else attempt { onFull(i, p, n) }
                }
            )
            GateMode.ACTIVATE -> GoldButton(
                text = if (busy) "PLEASE WAIT" else "ACTIVATE MY ACCOUNT",
                onClick = {
                    val i = idText
                    val n = pin
                    val a = newPass
                    if (i.isBlank() || n.isEmpty()) error = "Fill in $idLabel and the PIN you were given."
                    else if (a != newPass2) error = "The two passwords do not match."
                    else {
                        val act = onActivate
                        if (act != null) attempt { act(i, n, a) }
                    }
                }
            )
        }

        Spacer(Modifier.height(12.dp))
        if (mode == GateMode.QUICK) {
            GhostButton(text = "SIGN IN WITH " + idLabel.uppercase(), onClick = { mode = GateMode.FULL; error = "" })
            Spacer(Modifier.height(8.dp))
        }
        if (mode == GateMode.FULL) {
            if (onActivate != null) {
                GhostButton(text = "FIRST TIME OR AFTER A RESET", onClick = { mode = GateMode.ACTIVATE; error = "" })
                Spacer(Modifier.height(8.dp))
            }
            if (onForgot != null) {
                GhostButton(text = "FORGOT PASSWORD OR PIN", onClick = onForgot)
                Spacer(Modifier.height(8.dp))
            }
        }
        if (mode == GateMode.ACTIVATE) {
            GhostButton(text = "BACK TO SIGN IN", onClick = { mode = GateMode.FULL; error = "" })
            Spacer(Modifier.height(8.dp))
        }
        GhostButton(text = "BACK", onClick = onExit)
    }
}

// ------------------------------------------------------------------ CHANGE PIN / PASSWORD (used by manager + worker)

/**
 * Two small forms: change PIN, change password. Both need the current PIN or password.
 * `pinHint` says what a valid new PIN looks like for that role.
 */
@Composable
fun ChangeSecretsCard(
    pinHint: String,
    onChangePin: suspend (current: String, newPin: String) -> Outcome<Any?>,
    onChangePassword: suspend (current: String, newPassword: String) -> Outcome<Any?>
) {
    val scope = rememberCoroutineScope()
    var curPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var newPin2 by remember { mutableStateOf("") }
    var pinMsg by remember { mutableStateOf("") }

    var curPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var newPass2 by remember { mutableStateOf("") }
    var passMsg by remember { mutableStateOf("") }

    var busy by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Text("Change my PIN", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text(pinHint, color = CT.TextSoft, fontSize = 12.sp)
        CTField(curPin, { curPin = it }, "Current PIN or password", keyboard = KeyboardType.Password, secret = true)
        CTField(newPin, { newPin = it.filter { c -> c.isDigit() }.take(Secrets.MANAGER_PIN_MAX) }, "New PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        CTField(newPin2, { newPin2 = it.filter { c -> c.isDigit() }.take(Secrets.MANAGER_PIN_MAX) }, "Repeat new PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        if (pinMsg.isNotEmpty()) Text(pinMsg, color = CT.GoldLight, fontSize = 13.sp)
        GhostButton(text = "SAVE NEW PIN", onClick = {
            pinMsg = ""
            if (busy) {
                // another save is still running
            } else if (newPin != newPin2) {
                pinMsg = "The two PINs do not match."
            } else {
                busy = true
                val c = curPin
                val n = newPin
                scope.launch {
                    val r = withContext(Dispatchers.Default) { onChangePin(c, n) }
                    busy = false
                    if (r is Outcome.Err) {
                        pinMsg = r.message
                    } else {
                        pinMsg = "PIN changed."
                        curPin = ""; newPin = ""; newPin2 = ""
                    }
                }
            }
        })

        Spacer(Modifier.height(6.dp))
        Text("Change my password", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("At least ${Secrets.PASSWORD_MIN} characters with a letter and a digit. Forgot your password but remember your PIN? Type your PIN as the current secret.", color = CT.TextSoft, fontSize = 12.sp)
        CTField(curPass, { curPass = it }, "Current PIN or password", keyboard = KeyboardType.Password, secret = true)
        CTField(newPass, { newPass = it }, "New password", keyboard = KeyboardType.Password, secret = true)
        CTField(newPass2, { newPass2 = it }, "Repeat new password", keyboard = KeyboardType.Password, secret = true)
        if (passMsg.isNotEmpty()) Text(passMsg, color = CT.GoldLight, fontSize = 13.sp)
        GhostButton(text = "SAVE NEW PASSWORD", onClick = {
            passMsg = ""
            if (busy) {
                // another save is still running
            } else if (newPass != newPass2) {
                passMsg = "The two passwords do not match."
            } else {
                busy = true
                val c = curPass
                val n = newPass
                scope.launch {
                    val r = withContext(Dispatchers.Default) { onChangePassword(c, n) }
                    busy = false
                    if (r is Outcome.Err) {
                        passMsg = r.message
                    } else {
                        passMsg = "Password changed."
                        curPass = ""; newPass = ""; newPass2 = ""
                    }
                }
            }
        })
    }
}

// ------------------------------------------------------------------ MANAGER: MY SECURITY

@Composable
fun MySecurityScreen(
    repos: Repos,
    me: ManagerAccountEntity,
    onBack: () -> Unit,
    onUpdated: (ManagerAccountEntity) -> Unit,
    onForgotDevice: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var trustedUntil by remember { mutableStateOf<Long?>(null) }
    var refresh by remember { mutableStateOf(0) }
    LaunchedEffect(me.credVersion, refresh) { trustedUntil = repos.managerAccounts.trustedUntil(me) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("My security", onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Code name", me.codeName)
            val t = trustedUntil
            InfoRow("This phone", if (t == null) "Full sign-in needed" else "Quick unlock until " + fmtTime(t))
            Spacer(Modifier.height(6.dp))
            Text(
                "After a full sign-in (code name + password + PIN) this phone lets you unlock with just your PIN or just your password for 30 days.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        GhostButton(text = "FORGET THIS PHONE (FULL SIGN-IN NEXT TIME)", onClick = {
            scope.launch {
                repos.managerAccounts.forgetThisDevice(me.id)
                refresh += 1
                onForgotDevice()
            }
        })
        ChangeSecretsCard(
            pinHint = "Managers: ${Secrets.MANAGER_PIN_MIN} to ${Secrets.MANAGER_PIN_MAX} digits. A PIN that was ever used by anyone cannot be used again.",
            onChangePin = { cur, np ->
                val r = repos.managerAccounts.changeOwnPin(me.id, cur, np)
                if (r is Outcome.Ok) onUpdated(r.value)
                r
            },
            onChangePassword = { cur, np ->
                val r = repos.managerAccounts.changeOwnPassword(me.id, cur, np)
                if (r is Outcome.Ok) { onUpdated(r.value); refresh += 1 }
                r
            }
        )
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ WORKER: SETUP, RECOVERY, CARD

/** Shown to a worker who registered before Piece 4B and has no login yet. */
@Composable
fun SetupWorkerLoginScreen(repos: Repos, worker: WorkerEntity, onDone: () -> Unit, onExit: () -> Unit) {
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Secure your account", onExit)
        Text(
            "Hello " + worker.firstName + ". Create your own username, password and PIN. " +
                "From now on you sign in with all three, and then for 30 days on this phone just your PIN or password.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        WorkerLoginFields(username, { username = it }, pass, { pass = it }, pass2, { pass2 = it }, pin, { pin = it }, pin2, { pin2 = it })
        if (message.isNotEmpty()) Text(message, color = RED, fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "SAVE MY LOGIN",
            onClick = {
                if (!busy) {
                    message = ""
                    if (pass != pass2) message = "The two passwords do not match."
                    else if (pin != pin2) message = "The two PINs do not match."
                    else {
                        busy = true
                        val u = username; val p = pass; val n = pin
                        scope.launch {
                            val r = withContext(Dispatchers.Default) { repos.workerAuth.create(worker.id, u, p, n) }
                            busy = false
                            if (r is Outcome.Err) message = r.message else onDone()
                        }
                    }
                }
            }
        )
    }
}

/** The five login fields used when a worker creates a login (registration and setup). */
@Composable
fun WorkerLoginFields(
    username: String, onUsername: (String) -> Unit,
    pass: String, onPass: (String) -> Unit,
    pass2: String, onPass2: (String) -> Unit,
    pin: String, onPin: (String) -> Unit,
    pin2: String, onPin2: (String) -> Unit,
    allowDemo: Boolean = false
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        CTField(username, { onUsername(it.lowercase().filter { c -> c.isLetterOrDigit() || c == '.' || c == '_' }.take(20)) }, "Username (4–20: letters, digits, . or _)")
        CTField(pass, onPass, "Password", keyboard = KeyboardType.Password, secret = true)
        CTField(pass2, onPass2, "Repeat password", keyboard = KeyboardType.Password, secret = true)
        Text("Password: at least ${Secrets.PASSWORD_MIN} characters with a letter and a digit.", color = CT.TextSoft, fontSize = 12.sp)
        val pinKeyboard = if (allowDemo) KeyboardType.Password else KeyboardType.NumberPassword
        CTField(pin, { onPin(demoAwarePin(it, Secrets.WORKER_PIN_MAX, allowDemo)) }, "PIN (${Secrets.WORKER_PIN_MIN}–${Secrets.WORKER_PIN_MAX} digits)", keyboard = pinKeyboard, secret = true)
        CTField(pin2, { onPin2(demoAwarePin(it, Secrets.WORKER_PIN_MAX, allowDemo)) }, "Repeat PIN", keyboard = pinKeyboard, secret = true)
    }
}

/** Forgot password/PIN: prove it is you with National ID + payout number, then set a new password and PIN. */
@Composable
fun RecoverWorkerScreen(repos: Repos, worker: WorkerEntity, onDone: () -> Unit, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var nin by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val lock = remember(repos) { LockoutStore(repos.db.metaDao(), "lock:worker-recover") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Forgot password or PIN", onBack)
        Text(
            "Enter your National ID and the payout number saved in this app, then choose a new password and PIN. Your username stays the same.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(nin, { nin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(14) }, "National ID number")
        CTField(phone, { phone = it }, "Payout number saved in the app", keyboard = KeyboardType.Phone)
        CTField(pass, { pass = it }, "New password", keyboard = KeyboardType.Password, secret = true)
        CTField(pass2, { pass2 = it }, "Repeat new password", keyboard = KeyboardType.Password, secret = true)
        CTField(pin, { pin = it.filter { c -> c.isDigit() }.take(Secrets.WORKER_PIN_MAX) }, "New PIN (${Secrets.WORKER_PIN_MIN}–${Secrets.WORKER_PIN_MAX} digits)", keyboard = KeyboardType.NumberPassword, secret = true)
        CTField(pin2, { pin2 = it.filter { c -> c.isDigit() }.take(Secrets.WORKER_PIN_MAX) }, "Repeat new PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        if (message.isNotEmpty()) Text(message, color = RED, fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "RESET MY LOGIN",
            onClick = {
                if (!busy) {
                    message = ""
                    if (pass != pass2) message = "The two passwords do not match."
                    else if (pin != pin2) message = "The two PINs do not match."
                    else {
                        busy = true
                        val a = nin; val b = phone; val c = pass; val d = pin
                        scope.launch {
                            val rem = lock.remainingMs()
                            if (rem > 0) {
                                message = "Too many wrong tries. Wait " + lockText(rem) + "."
                                busy = false
                                return@launch
                            }
                            val r = withContext(Dispatchers.Default) { repos.workerAuth.recover(worker.id, a, b, c, d) }
                            busy = false
                            when (r) {
                                is Auth.Ok -> { lock.clear(); onDone() }
                                is Auth.Wrong -> {
                                    message = r.message
                                    val l = lock.recordFailure()
                                    if (l > 0) message = "Too many wrong tries. Locked for " + lockText(l) + "."
                                }
                                is Auth.Denied -> message = r.message
                            }
                        }
                    }
                }
            }
        )
    }
}

/** Card on the worker home screen: change PIN / password. */
@Composable
fun WorkerSecurityCard(repos: Repos, workerId: String) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        ChangeSecretsCard(
            pinHint = "Workers: ${Secrets.WORKER_PIN_MIN} to ${Secrets.WORKER_PIN_MAX} digits.",
            onChangePin = { cur, np -> repos.workerAuth.changePin(workerId, cur, np) },
            onChangePassword = { cur, np -> repos.workerAuth.changePassword(workerId, cur, np) }
        )
    }
}
