package com.ctteam.app.ui

import com.ctteam.app.data.TaskType

/**
 * Demo worker (Piece 4C1).
 *
 * Typing "demo" in every sign-in field opens a pretend worker so the worker side can be seen without a real account.
 * The demo lives ONLY in memory: it never reads or writes the database, never creates a worker, audit entry, trust
 * record or payout, and it is not offered on the Manager side. Everything shown here is made up.
 */
object WorkerDemo {
    const val WORD = "demo"

    fun isDemoWord(text: String): Boolean = text.trim().equals(WORD, ignoreCase = true)

    /** True when username, password and PIN are all the word "demo". */
    fun isDemoLogin(username: String, password: String, pin: String): Boolean =
        isDemoWord(username) && isDemoWord(password) && isDemoWord(pin)

    fun homeData(nowMs: Long = System.currentTimeMillis()): WorkerHomeData = WorkerHomeData(
        firstName = "Amina",
        fullName = "Amina Demo Nakato",
        username = "demo",
        nationalId = "DEMO-NOT-REAL",
        payoutNumber = "0772000000",
        network = "MTN",
        registeredAt = nowMs - 12L * 24 * 60 * 60 * 1000,
        active = true,
        expectedUgx = 12_500L,
        pending = 2,
        approved = 5,
        rejected = 1,
        tasks = tasks()
    )

    private fun tasks(): List<WTask> = listOf(
        WTask(
            id = "demo-1",
            name = "Follow our TikTok page",
            description = "Open our TikTok page, follow it, and like our three latest videos.",
            payUgx = 2_000L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "https://example.com/demo-video",
            exampleLinkUrl = "https://example.com/demo-page",
            proofRequirements = "One screenshot showing the Following button and your profile name.",
            state = TaskState.AVAILABLE
        ),
        WTask(
            id = "demo-2",
            name = "Daily check-in post",
            description = "Post today's check-in message on your WhatsApp status and keep it up for 24 hours.",
            payUgx = 1_500L,
            type = TaskType.DAILY,
            exampleVideoUrl = "",
            exampleLinkUrl = "https://example.com/demo-checkin",
            proofRequirements = "A screenshot of the status with the date visible, and the link text we gave you.",
            state = TaskState.AVAILABLE
        ),
        WTask(
            id = "demo-3",
            name = "Share promo video",
            description = "Share the promo video with at least five contacts.",
            payUgx = 3_000L,
            type = TaskType.DAILY,
            exampleVideoUrl = "https://example.com/demo-promo",
            exampleLinkUrl = "",
            proofRequirements = "Two screenshots: the sent message and the list of contacts it went to.",
            state = TaskState.AVAILABLE,
            note = "Your last proof was rejected: the screenshot was cropped. You can submit again."
        ),
        WTask(
            id = "demo-4",
            name = "Rate our app",
            description = "Leave an honest rating and a short review of the app.",
            payUgx = 2_500L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot of your review.",
            state = TaskState.WAITING,
            note = "Your proof was sent. The manager has not reviewed it yet."
        ),
        WTask(
            id = "demo-5",
            name = "Daily survey",
            description = "Answer today's three-question survey.",
            payUgx = 1_000L,
            type = TaskType.DAILY,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot of the thank-you page.",
            state = TaskState.DONE,
            note = "Approved. This task comes back tomorrow."
        ),
        WTask(
            id = "demo-6",
            name = "Join the Telegram group",
            description = "Join the CT Team Telegram group and say hello.",
            payUgx = 1_000L,
            type = TaskType.ONE_TIME,
            exampleVideoUrl = "",
            exampleLinkUrl = "",
            proofRequirements = "A screenshot showing you inside the group.",
            state = TaskState.DONE,
            note = "Approved. This is a one-time task, so it is finished."
        )
    )
}
