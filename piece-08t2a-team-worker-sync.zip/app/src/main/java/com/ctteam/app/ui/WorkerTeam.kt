package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos
import com.ctteam.app.data.TeamView
import kotlinx.coroutines.delay

private val TEAM_RED = Color(0xFFFF8A8A)

/**
 * Team mining on the worker's home screen (T2a): my share, what I contributed, the team totals and my contributions.
 * The figures come from the manager's signed update (Updates from the manager card). Everything is an ESTIMATE.
 * T2b adds the expected daily payout, a "what if I contribute" calculator and the team capacity.
 */
@Composable
fun WorkerTeamCard(repos: Repos, workerId: String) {
    var view by remember { mutableStateOf<TeamView?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var showList by remember { mutableStateOf(false) }

    // The update card sits on the same screen, so look again every few seconds.
    LaunchedEffect(workerId) {
        while (true) {
            view = com.ctteam.app.data.TeamViewCodec.load(repos.db, workerId)
            loaded = true
            delay(4000)
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Team mining", color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(4.dp))
        val v = view
        if (!loaded) {
            Text("Loading…", color = CT.TextSoft, fontSize = 12.sp)
        } else if (v == null) {
            Text(
                "No team figures on this phone yet. They arrive with the manager's next update: paste it in “Updates from the manager” below. " +
                    "Your own deposits count once the manager has verified them.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        } else {
            Text("Your share (estimate)", color = CT.TextSoft, fontSize = 12.sp)
            Text(v.sharePercentText(), color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 34.sp)
            Spacer(Modifier.height(6.dp))
            InfoRow("You contributed (all time)", ugx(v.myAllTimeUgx))
            InfoRow("Counts towards your share", ugx(v.myWeight))
            InfoRow("Team contributed (all time)", ugx(v.teamAllTimeUgx))
            InfoRow("Contributors", v.contributors.toString())
            InfoRow("Figures made", fmtTime(v.asOf))
            Spacer(Modifier.height(6.dp))
            Text(
                "Older contributions count a little less over time: after " + v.halfLifeDays + " days a contribution counts half. " +
                    "The mined amount is split " + v.poolPercent + "% to the workers by share and the rest to the manager. " +
                    "These are estimates. Values use rates set by the manager, they are not a promise of payment, and they refresh only when you import the manager's next update.",
                color = CT.TextSoft, fontSize = 11.sp
            )
            Spacer(Modifier.height(8.dp))
            GhostButton(
                text = if (showList) "HIDE MY CONTRIBUTIONS" else "SHOW MY CONTRIBUTIONS (" + v.contributions.size + (if (v.moreCount > 0) "+" else "") + ")",
                onClick = { showList = !showList },
                modifier = Modifier.fillMaxWidth()
            )
            if (showList) {
                Spacer(Modifier.height(8.dp))
                if (v.contributions.isEmpty()) {
                    Text("You have no verified contributions yet.", color = CT.TextSoft, fontSize = 12.sp)
                }
                for (c in v.contributions) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.coin + " " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                if (c.active) (if (c.valueUgx != null) "≈ " + ugx(c.valueUgx) else "not priced yet") else "not counted",
                                color = if (c.active) CT.GoldLight else TEAM_RED, fontSize = 12.sp
                            )
                        }
                        Text(
                            "Deposited " + fmtTime(c.contributedAtUtc) +
                                (if (c.active && c.rateText.isNotEmpty()) " · rate UGX " + c.rateText + " per " + c.coin else ""),
                            color = CT.TextSoft, fontSize = 11.sp
                        )
                        if (!c.active) {
                            Text(
                                "Not counted" + (if (c.voidNote.isNotBlank()) ": " + c.voidNote else "."),
                                color = TEAM_RED, fontSize = 11.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                if (v.moreCount > 0) {
                    Text(v.moreCount.toString() + " older contribution(s) are not listed here.", color = CT.TextSoft, fontSize = 11.sp)
                }
            }
        }
    }
}
