package com.ctteam.app.data

import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale

/*
 * PIECE T2a — TEAM MINING, WORKER SIDE DATA: the manager phone puts each worker's team figures into a signed
 * update (type TEAM_VIEW, same envelope and replay protection as the other updates of Piece 5C); the worker phone
 * keeps the newest one and shows it. NO database change: the figures are stored in the `meta` table.
 *
 * What the message holds (all numbers are ESTIMATES made on the manager phone at time `at`):
 *   rev  = counter that rises whenever the ledger changed (or a new week started)   at = time the figures were made
 *   hl   = half-life days   pp = workers' percent   n = contributors   ta = team all-time UGX
 *   tw   = team weight after decay (UGX equivalent)   mw / ma = this worker's weight / all-time UGX
 *   ct   = this worker's own contributions (newest 40)   more = how many older ones are not listed
 * Nothing about other workers is sent except the team totals.
 */

class TeamViewContribution(
    val id: String,
    val coin: String,
    val amountText: String,
    val contributedAtUtc: Long,
    val valueUgx: Long?,
    val rateText: String,
    val active: Boolean,
    val voidNote: String
)

class TeamView(
    val rev: Int,
    val asOf: Long,
    val halfLifeDays: Int,
    val poolPercent: Int,
    val contributors: Int,
    val teamAllTimeUgx: Long,
    val teamWeight: Long,
    val myWeight: Long,
    val myAllTimeUgx: Long,
    val contributions: List<TeamViewContribution>,
    val moreCount: Int
) {
    /** 0.0 .. 1.0 */
    val share: Double get() = if (teamWeight > 0L) minOf(1.0, myWeight.toDouble() / teamWeight.toDouble()) else 0.0
    fun sharePercentText(): String = String.format(Locale.US, "%.2f", share * 100.0) + "%"
}

class TeamViewApply(val ok: Boolean, val changed: Boolean, val title: String, val detail: String)

object TeamViewCodec {
    private const val MAX_LIST = 40
    private val ID_RULE = Regex("^[A-Za-z0-9\\-]{1,64}$")
    private val AMOUNT_RULE = Regex("^[0-9]{1,15}(\\.[0-9]{1,18})?$")
    private val COIN_RULE = Regex("^[A-Z0-9]{2,10}$")
    private val RATE_RULE = Regex("^[0-9]{1,15}(\\.[0-9]{1,8})?$")
    private const val MAX_UGX = 1_000_000_000_000_000L

    private fun weekStartMs(now: Long): Long =
        LocalDate.parse(TimeUtil.weekKey(now)).atStartOfDay(TimeUtil.EAT).toInstant().toEpochMilli()

    // ------------------------------------------------------------ manager phone

    /**
     * The team figures for ONE worker, or null when the team has no contributions at all.
     * The same ledger gives the same message (so sending it again is harmless); a changed ledger or a new week gives a new `rev`.
     */
    suspend fun build(db: CTDatabase, workerId: String, now: Long = System.currentTimeMillis()): JSONObject? {
        val meta = db.metaDao()
        val dao = db.teamDao()
        val active = dao.active().sortedBy { it.id }
        val mine = dao.observeOfWorker(workerId).first()
        if (active.isEmpty() && mine.isEmpty()) return null

        val half = meta.get("team:halfLifeDays")?.toIntOrNull()?.coerceIn(TeamRepository.MIN_HALF_LIFE_DAYS, TeamRepository.MAX_HALF_LIFE_DAYS)
            ?: TeamRepository.DEFAULT_HALF_LIFE_DAYS
        val pool = meta.get("team:poolPercent")?.toIntOrNull()?.coerceIn(1, 99) ?: TeamRepository.DEFAULT_POOL_PERCENT

        val src = StringBuilder().append(half).append('|').append(pool).append('|').append(weekStartMs(now))
        for (c in active) src.append('|').append(c.id).append(':').append(c.valueUgx ?: -1L)
        for (c in mine.sortedBy { it.id }) src.append("|m").append(c.id).append(':').append(c.status).append(':').append(c.valueUgx ?: -1L).append(':').append(c.voidNote.hashCode())
        val fp = Hashing.sha256Hex(src.toString()).take(16)

        val kFp = "team:vfp:$workerId"
        val kRev = "team:vrev:$workerId"
        val kAt = "team:vat:$workerId"
        var rev = meta.get(kRev)?.toIntOrNull() ?: 0
        var at = meta.get(kAt)?.toLongOrNull() ?: 0L
        if (rev == 0 || meta.get(kFp) != fp) {
            rev += 1
            at = maxOf(now, at + 1L)
            meta.put(MetaEntity(kFp, fp))
            meta.put(MetaEntity(kRev, rev.toString()))
            meta.put(MetaEntity(kAt, at.toString()))
        }

        val shares = TeamMath.shares(active, at, half.toDouble())
        val my = shares.firstOrNull { it.workerId == workerId }
        val list = JSONArray()
        val sorted = mine.sortedByDescending { it.contributedAtUtc }
        for (c in sorted.take(MAX_LIST)) {
            val o = JSONObject()
                .put("id", c.claimUid ?: ("c" + c.id))
                .put("c", c.coin).put("a", c.amountText).put("t", c.contributedAtUtc)
                .put("r", c.rateText ?: "")
                .put("s", c.status)
            if (c.valueUgx != null) o.put("v", c.valueUgx)
            if (c.status != TeamStatus.ACTIVE) o.put("vn", c.voidNote.take(120))
            list.put(o)
        }
        return JSONObject()
            .put("rev", rev).put("at", at).put("hl", half).put("pp", pool)
            .put("n", shares.size)
            .put("ta", shares.sumOf { it.allTimeUgx })
            .put("tw", Math.round(shares.sumOf { it.weight }))
            .put("mw", Math.round(my?.weight ?: 0.0))
            .put("ma", my?.allTimeUgx ?: 0L)
            .put("ct", list)
            .put("more", maxOf(0, sorted.size - MAX_LIST))
    }

    // ------------------------------------------------------------ worker phone

    private fun kJson(workerId: String) = "teamview:json:$workerId"
    private fun kRev(workerId: String) = "teamview:rev:$workerId"

    /** Checks the message, and keeps it when it is newer than the one this phone has. Everything is re-validated here. */
    suspend fun apply(db: CTDatabase, workerId: String, b: JSONObject): TeamViewApply {
        val meta = db.metaDao()
        val rev = b.optInt("rev", 0)
        val at = b.optLong("at", 0L)
        val hl = b.optInt("hl", 0)
        val pp = b.optInt("pp", 0)
        val n = b.optInt("n", -1)
        val ta = b.optLong("ta", -1L)
        val tw = b.optLong("tw", -1L)
        val mw = b.optLong("mw", -1L)
        val ma = b.optLong("ma", -1L)
        val ok = rev > 0 && at > 0L && hl in TeamRepository.MIN_HALF_LIFE_DAYS..TeamRepository.MAX_HALF_LIFE_DAYS && pp in 1..99 &&
            n in 0..100_000 && ta in 0..MAX_UGX && tw in 0..MAX_UGX && mw in 0..MAX_UGX && ma in 0..MAX_UGX
        if (!ok) return TeamViewApply(false, false, "Team figures not used", "The team figures in this message are not valid. Nothing was used.")

        val known = meta.get(kRev(workerId))?.toIntOrNull() ?: 0
        if (rev <= known) return TeamViewApply(true, false, "Team figures already up to date", "A newer or equal set of team figures is already on this phone.")

        val clean = JSONArray()
        val src = b.optJSONArray("ct") ?: JSONArray()
        for (i in 0 until minOf(src.length(), MAX_LIST)) {
            val o = src.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val coin = o.optString("c")
            val amount = o.optString("a")
            val t = o.optLong("t", 0L)
            val st = o.optString("s")
            val rate = o.optString("r")
            if (!ID_RULE.matches(id) || !COIN_RULE.matches(coin) || !AMOUNT_RULE.matches(amount) || t <= 0L) continue
            if (st != TeamStatus.ACTIVE && st != TeamStatus.VOIDED) continue
            if (rate.isNotEmpty() && !RATE_RULE.matches(rate)) continue
            val c = JSONObject().put("id", id).put("c", coin).put("a", amount).put("t", t).put("r", rate).put("s", st)
            if (o.has("v")) {
                val v = o.optLong("v", -1L)
                if (v in 0..MAX_UGX) c.put("v", v)
            }
            if (st == TeamStatus.VOIDED) c.put("vn", o.optString("vn").replace('\n', ' ').take(120))
            clean.put(c)
        }
        val stored = JSONObject()
            .put("rev", rev).put("at", at).put("hl", hl).put("pp", pp).put("n", n)
            .put("ta", ta).put("tw", tw).put("mw", mw).put("ma", ma)
            .put("ct", clean).put("more", b.optInt("more", 0).coerceIn(0, 1_000_000))
        meta.put(MetaEntity(kJson(workerId), stored.toString()))
        meta.put(MetaEntity(kRev(workerId), rev.toString()))
        return TeamViewApply(true, true, "Team figures updated", "Your team share and contributions were refreshed (estimates, as of the manager's figures).")
    }

    /** The newest team figures on this phone for this worker, or null if none arrived yet. */
    suspend fun load(db: CTDatabase, workerId: String): TeamView? {
        val raw = db.metaDao().get(kJson(workerId)) ?: return null
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("ct") ?: JSONArray()
            val list = ArrayList<TeamViewContribution>()
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                list.add(
                    TeamViewContribution(
                        id = c.optString("id"), coin = c.optString("c"), amountText = c.optString("a"),
                        contributedAtUtc = c.optLong("t"), valueUgx = if (c.has("v")) c.optLong("v") else null,
                        rateText = c.optString("r"), active = c.optString("s") == TeamStatus.ACTIVE, voidNote = c.optString("vn")
                    )
                )
            }
            TeamView(
                rev = o.optInt("rev"), asOf = o.optLong("at"), halfLifeDays = o.optInt("hl"), poolPercent = o.optInt("pp"),
                contributors = o.optInt("n"), teamAllTimeUgx = o.optLong("ta"), teamWeight = o.optLong("tw"),
                myWeight = o.optLong("mw"), myAllTimeUgx = o.optLong("ma"), contributions = list, moreCount = o.optInt("more")
            )
        } catch (ex: Exception) {
            null
        }
    }
}
