package com.ctteam.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ctteam.app.data.BotConfig
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Piece 16a — a window that REQUIRES the worker to connect to the manager through the bot, in taps.
 * It opens by itself on the worker home as soon as the account exists, and again every time the app is opened, until the
 * manager's first message has reached this phone. Before the worker has tapped SEND MY CONNECTION it cannot be closed (the Back
 * button and a tap outside do nothing). After that it can be closed for now with one button and comes back next time.
 * Same calls as the connect card (`makeEnrollment`, the referral code field, `qc:sent:<worker>`).
 */
private const val CP_SENT = "qc:sent:"
private const val CP_OPENED = "qc:opened:"
private val CP_GOOD = Color(0xFF5FD6A5)

@Composable
fun ConnectRequiredPopup(repos: Repos, workerId: String) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val bot = BotConfig.username()

    var needed by remember { mutableStateOf<Boolean?>(null) }
    var opened by remember { mutableStateOf(false) }
    var sent by remember { mutableStateOf(false) }
    var later by remember { mutableStateOf(false) }
    var ref by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(workerId) {
        ref = repos.sync.referralCodeTyped(workerId)
        while (true) {
            needed = repos.sync.managerMessagesReceived(workerId) == 0
            opened = repos.db.metaDao().get(CP_OPENED + workerId) == "1"
            sent = repos.db.metaDao().get(CP_SENT + workerId) == "1"
            delay(3000)
        }
    }
    if (needed != true || later) return

    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CT.NavyDeep).padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🔗 Connect to your manager", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(
                "Your phone is not connected yet. Until it is, your manager cannot see your work and you cannot receive tasks, decisions or payouts. It takes three taps.",
                color = Color.White, fontSize = 13.sp
            )

            CpStep(if (opened) "✓" else "1", "Open the bot and tap START (Telegram's own rule, only the first time).", opened)
            if (bot.isNotEmpty()) {
                GhostButton(text = "OPEN THE BOT", modifier = Modifier.fillMaxWidth(), onClick = {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/$bot")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        message = ""
                        scope.launch { repos.db.metaDao().put(MetaEntity(CP_OPENED + workerId, "1")); opened = true }
                    } catch (e: Exception) {
                        message = "Could not open Telegram. Is it installed?"
                    }
                })
            } else {
                Text("Ask your manager for the bot name, open it in Telegram and tap START.", color = CT.GoldLight, fontSize = 12.sp)
            }

            CpStep(if (sent) "✓" else "2", "Send your connection. Telegram opens with it filled in: pick the bot and tap send.", sent)
            CTField(ref, { ref = it.take(14) }, "Friend's referral code (optional)")
            GoldButton(text = if (sent) "SEND MY CONNECTION AGAIN" else "SEND MY CONNECTION", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    repos.sync.setReferralCodeTyped(workerId, ref)
                    when (val r = repos.sync.makeEnrollment(workerId)) {
                        is Outcome.Ok -> {
                            clipboard.setText(AnnotatedString(r.value))
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, r.value)
                            }
                            try {
                                ctx.startActivity(Intent(send).setPackage("org.telegram.messenger"))
                            } catch (e: ActivityNotFoundException) {
                                ctx.startActivity(Intent.createChooser(send, "Send to the manager's bot"))
                            }
                            repos.db.metaDao().put(MetaEntity(CP_SENT + workerId, "1"))
                            sent = true
                            message = ""
                        }
                        is Outcome.Err -> message = r.message
                    }
                }
            })

            CpStep("3", "Wait for the manager's answer. When the bot replies in Telegram, tap its message and choose Share, then CT Team (or copy it and come back here: the app offers USE IT). This window closes by itself.", false)

            if (message.isNotEmpty()) Text(message, color = CT.Gold, fontSize = 12.sp)
            Text("Never send your connection in a group chat.", color = CT.TextSoft, fontSize = 11.sp)
            if (sent) {
                GhostButton(text = "I SENT IT, CLOSE FOR NOW", modifier = Modifier.fillMaxWidth(), onClick = { later = true })
                Text("This window comes back next time you open the app until the manager's first message arrives.", color = CT.TextSoft, fontSize = 11.sp)
            } else {
                Text("This window can be closed only after you tap SEND MY CONNECTION.", color = CT.TextSoft, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun CpStep(mark: String, text: String, done: Boolean) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(mark, color = if (done) CP_GOOD else CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(text, color = if (done) CT.TextSoft else Color.White, fontSize = 13.sp)
    }
}
