package com.ctteam.app.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Conf
import com.ctteam.app.data.MatchResult
import com.ctteam.app.data.PdfText
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.PayoutInfo
import com.ctteam.app.data.PayoutMatcher
import com.ctteam.app.data.PayoutRequestEntity
import com.ctteam.app.data.Repos
import com.ctteam.app.data.StatementParser
import com.ctteam.app.data.StatementRow
import com.ctteam.app.data.WorkerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * PIECE 7 — manager payouts: waiting payouts, statement import with automatic matching, manual confirmation, and the
 * permanent archive of paid payouts. The manager always confirms; a match is only a suggestion.
 */

private val WARN = Color(0xFFFF8A8A)
private val GOOD = Color(0xFF5FD6A5)
private val MAYBE = Color(0xFFFFD166)

private const val MODE_LIST = "LIST"
private const val MODE_IMPORT = "IMPORT"
private const val MODE_RESULTS = "RESULTS"
private const val MAX_STATEMENT_BYTES = 500 * 1024

private class PickedStatement(val text: String, val fromPdf: Boolean)

/** Reads a chosen file: a PDF goes through the shared PDF reader (Piece 8A), anything else must be plain text. */
private suspend fun readStatementFile(context: Context, uri: Uri): Outcome<PickedStatement> {
    var headOrNull: ByteArray? = null
    try {
        headOrNull = context.contentResolver.openInputStream(uri)?.use { s ->
            val b = ByteArray(8)
            val n = s.read(b)
            if (n <= 0) ByteArray(0) else b.copyOf(n)
        }
    } catch (e: Exception) {
        headOrNull = null
    }
    val head = headOrNull ?: return Outcome.Err("Could not open that file.")

    if (PdfText.looksLikePdf(head)) {
        val r = PdfText.read(context, uri)
        return if (r is Outcome.Ok) Outcome.Ok(PickedStatement(r.value, true)) else Outcome.Err((r as Outcome.Err).message)
    }
    return withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext Outcome.Err("Could not open that file.")
            if (bytes.size > MAX_STATEMENT_BYTES) return@withContext Outcome.Err("That text file is larger than 500 KB.")
            if (bytes.any { it.toInt() == 0 }) return@withContext Outcome.Err("That file is not plain text. Open a CSV, text or PDF file, or paste the lines.")
            Outcome.Ok(PickedStatement(String(bytes, Charsets.UTF_8), false))
        } catch (e: Exception) {
            Outcome.Err("Could not read that file.")
        }
    }
}

private fun nameOf(workers: List<WorkerEntity>, id: String): String =
    workers.firstOrNull { it.id == id }?.fullName() ?: "(unknown worker)"

private fun number(p: PayoutRequestEntity): String = "0" + p.phone.substring(3) + " (" + p.network + ")"

@Composable
fun PayoutsScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val waitingFlow = remember(repos) { repos.db.payoutDao().observeInProgress() }
    val paidFlow = remember(repos) { repos.db.payoutDao().observePaid() }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val waiting by waitingFlow.collectAsState(initial = emptyList())
    val paid by paidFlow.collectAsState(initial = emptyList())
    val workers by workersFlow.collectAsState(initial = emptyList())

    var mode by remember { mutableStateOf(MODE_LIST) }
    var statement by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var pdfPreview by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<MatchResult>>(emptyList()) }
    var leftover by remember { mutableStateOf<List<StatementRow>>(emptyList()) }
    var rowsRead by remember { mutableStateOf(0) }
    var linesSkipped by remember { mutableStateOf(0) }
    var alreadyUsed by remember { mutableStateOf(0) }
    var confirmed by remember { mutableStateOf<Set<String>>(emptySet()) }
    var ask by remember { mutableStateOf<String?>(null) }       // payout id (or "ALL") waiting for the YES tap
    var payNote by remember { mutableStateOf("") }

    BackHandler(enabled = mode != MODE_LIST) { mode = MODE_LIST; message = ""; ask = null }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                when (val r = readStatementFile(context, uri)) {
                    is Outcome.Err -> message = r.message
                    is Outcome.Ok -> {
                        if (r.value.fromPdf) {
                            pdfPreview = r.value.text
                            message = ""
                        } else {
                            statement = r.value.text
                            message = ""
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ IMPORT
    if (mode == MODE_IMPORT) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHeader("Import payment statement", { mode = MODE_LIST; message = ""; ask = null })
            Text(
                "Paste the lines of your MTN or Airtel statement (or open a PDF, CSV or text file). The app looks at each line for the phone number, the name and the amount, and suggests which waiting payout it belongs to. " +
                    "You decide: nothing is marked paid until you confirm it.",
                color = CT.TextSoft, fontSize = 13.sp
            )
            CTField(statement, { statement = it }, "Statement lines", singleLine = false, minLines = 8)
            if (message.isNotEmpty()) Text(message, color = WARN, fontSize = 13.sp)
            val preview = pdfPreview
            if (preview != null) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Text read from the PDF", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        preview.lines().size.toString() + " lines, " + preview.length + " characters. Look at the start to make sure it reads like your statement.",
                        color = CT.TextSoft, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(preview.take(1200), color = Color.White, fontSize = 11.sp)
                    if (preview.length > 1200) Text("…", color = CT.TextSoft, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    GoldButton(text = "USE THIS TEXT", modifier = Modifier.fillMaxWidth(), onClick = {
                        statement = preview
                        pdfPreview = null
                        message = ""
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "DISCARD", modifier = Modifier.fillMaxWidth(), onClick = { pdfPreview = null })
                }
            }
            GhostButton(text = "PASTE FROM CLIPBOARD", modifier = Modifier.fillMaxWidth(), onClick = {
                val t = clipboard.getText()?.text ?: ""
                if (t.isBlank()) message = "The clipboard is empty." else { statement = t; message = "" }
            })
            GhostButton(text = "OPEN PDF, CSV OR TEXT FILE", modifier = Modifier.fillMaxWidth(), onClick = {
                picker.launch(arrayOf("application/pdf", "text/*", "application/csv", "application/vnd.ms-excel", "application/octet-stream"))
            })
            GoldButton(text = "CHECK STATEMENT", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    val parsed = StatementParser.parse(statement)
                    if (parsed.rows.isEmpty()) {
                        message = "No payment lines were found. Each line needs an amount and a phone number or a name."
                    } else if (waiting.isEmpty()) {
                        message = "No payout is waiting, so there is nothing to match."
                    } else {
                        val used = HashSet<String>()
                        for (r in parsed.rows) if (repos.db.payoutDao().paymentRefCount(r.key) > 0) used.add(r.key)
                        val infos = waiting.map { PayoutInfo(it.id, nameOf(workers, it.workerId), it.phone, it.amountUgx) }
                        val res = PayoutMatcher.match(infos, parsed.rows, used)
                        results = res
                        leftover = parsed.rows.filter { r -> r.key !in used && res.none { m -> m.row?.key == r.key } }
                        rowsRead = parsed.rows.size
                        linesSkipped = parsed.skippedLines
                        alreadyUsed = used.size
                        confirmed = emptySet()
                        ask = null
                        message = ""
                        mode = MODE_RESULTS
                    }
                }
            })
        }
        return
    }

    // ------------------------------------------------------------ RESULTS
    if (mode == MODE_RESULTS) {
        val strongOpen = results.filter { it.confidence == Conf.STRONG && it.payoutId !in confirmed && waiting.any { w -> w.id == it.payoutId } }
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHeader("Statement results", { mode = MODE_LIST; message = ""; ask = null })
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                InfoRow("Payment lines read", rowsRead.toString())
                InfoRow("Other lines skipped", linesSkipped.toString())
                if (alreadyUsed > 0) InfoRow("Lines already used before", alreadyUsed.toString())
                InfoRow("Waiting payouts", results.size.toString())
                InfoRow("Strong matches", results.count { it.confidence == Conf.STRONG }.toString())
                InfoRow("Possible matches", results.count { it.confidence == Conf.POSSIBLE }.toString())
            }
            if (message.isNotEmpty()) Text(message, color = WARN, fontSize = 13.sp)

            if (strongOpen.isNotEmpty()) {
                if (ask == "ALL") {
                    Text("Tap YES only if the money for these payouts was really sent. A paid record cannot be changed back.", color = CT.TextSoft, fontSize = 12.sp)
                    GoldButton(text = "YES, CONFIRM " + strongOpen.size + " STRONG MATCH(ES)", modifier = Modifier.fillMaxWidth(), onClick = {
                        val items = strongOpen
                        scope.launch {
                            var failed = ""
                            for (m in items) {
                                val row = m.row ?: continue
                                val r = repos.payouts.confirmPaid(m.payoutId, "AUTO_MATCH", row.key, m.confidence, "Statement line: " + row.raw.take(160), actor)
                                if (r is Outcome.Err) failed = r.message else confirmed = confirmed + m.payoutId
                            }
                            message = failed
                            ask = null
                        }
                    })
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { ask = null })
                } else {
                    GoldButton(text = "CONFIRM ALL STRONG MATCHES (" + strongOpen.size + ")", modifier = Modifier.fillMaxWidth(), onClick = { ask = "ALL" })
                }
            }

            for (m in results) {
                val p = waiting.firstOrNull { it.id == m.payoutId }
                val done = m.payoutId in confirmed || p == null
                val shown = p ?: paid.firstOrNull { it.id == m.payoutId }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    if (shown != null) {
                        Text(nameOf(workers, shown.workerId), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        InfoRow("Amount", ugx(shown.amountUgx))
                        InfoRow("Sent to", number(shown))
                    }
                    Spacer(Modifier.height(4.dp))
                    when {
                        done -> Text("✅ Confirmed as paid", color = GOOD, fontWeight = FontWeight.Bold)
                        m.confidence == Conf.STRONG -> Text("✅ STRONG match", color = GOOD, fontWeight = FontWeight.Bold)
                        m.confidence == Conf.POSSIBLE -> Text("🟡 POSSIBLE match — check it", color = MAYBE, fontWeight = FontWeight.Bold)
                        else -> Text("⚪ No match", color = CT.TextSoft, fontWeight = FontWeight.Bold)
                    }
                    val row = m.row
                    if (row != null) {
                        Spacer(Modifier.height(4.dp))
                        Text("Statement line:", color = CT.TextSoft, fontSize = 11.sp)
                        Text(row.raw.take(200), color = Color.White, fontSize = 12.sp)
                    }
                    if (!done) {
                        Spacer(Modifier.height(4.dp))
                        for (r in m.reasons) Text(r, color = CT.TextSoft, fontSize = 12.sp)
                    }
                    if (!done && row != null && p != null) {
                        Spacer(Modifier.height(8.dp))
                        if (ask == p.id) {
                            Text("Tap YES only after the money was really sent. A paid record cannot be changed back.", color = CT.TextSoft, fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            GoldButton(text = "YES, I SENT IT — MARK PAID", modifier = Modifier.fillMaxWidth(), onClick = {
                                scope.launch {
                                    val r = repos.payouts.confirmPaid(p.id, "AUTO_MATCH", row.key, m.confidence, "Statement line: " + row.raw.take(160), actor)
                                    if (r is Outcome.Err) message = r.message else confirmed = confirmed + p.id
                                    ask = null
                                }
                            })
                            Spacer(Modifier.height(6.dp))
                            GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { ask = null })
                        } else {
                            GhostButton(text = "CONFIRM PAID", modifier = Modifier.fillMaxWidth(), onClick = { ask = p.id })
                        }
                    } else if (!done && row == null) {
                        Spacer(Modifier.height(4.dp))
                        Text("If you did pay this one, mark it paid by hand from the payouts list.", color = CT.TextSoft, fontSize = 12.sp)
                    }
                }
            }

            if (leftover.isNotEmpty()) {
                Text("Statement lines that matched no waiting payout (" + leftover.size + ")", color = CT.GoldLight, fontWeight = FontWeight.Bold)
                for (r in leftover.take(10)) Text(r.raw.take(160), color = CT.TextSoft, fontSize = 11.sp)
                if (leftover.size > 10) Text("…and " + (leftover.size - 10) + " more.", color = CT.TextSoft, fontSize = 11.sp)
            }
        }
        return
    }

    // ------------------------------------------------------------ LIST
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Payouts", onBack)
        Text(
            "A worker asks for a payout in their app (status In progress). You pay the worker's MTN/Airtel number yourself, then confirm here. " +
                "You can match your statement automatically, or mark a payout paid by hand.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        GoldButton(text = "IMPORT PAYMENT STATEMENT", modifier = Modifier.fillMaxWidth(), onClick = { mode = MODE_IMPORT; message = "" })
        if (message.isNotEmpty()) Text(message, color = WARN, fontSize = 13.sp)

        Text("In progress (" + waiting.size + ")", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (waiting.isEmpty()) Text("No payout is waiting. Requests appear here after you import a worker's report.", color = CT.TextSoft, fontSize = 13.sp)
        for (p in waiting) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("🟡 " + nameOf(workers, p.workerId), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                InfoRow("Amount", ugx(p.amountUgx))
                InfoRow("Send to", number(p))
                InfoRow("Week of", p.weekKey)
                InfoRow("Requested", fmtTime(p.requestedAt))
                if (p.note.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ " + p.note, color = CT.GoldLight, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                if (ask == p.id) {
                    CTField(payNote, { payNote = it }, "Note (optional): e.g. transaction ID")
                    Spacer(Modifier.height(6.dp))
                    Text("Tap YES only after the money was really sent. A paid record cannot be changed back.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    GoldButton(text = "YES, I SENT IT — MARK PAID", modifier = Modifier.fillMaxWidth(), onClick = {
                        val id = p.id
                        val note = if (payNote.isBlank()) "Marked paid by hand (Payouts screen)" else "Marked paid by hand: " + payNote.trim()
                        scope.launch {
                            val r = repos.payouts.confirmPaid(id, "MANUAL", null, null, note, actor)
                            message = if (r is Outcome.Err) r.message else ""
                            ask = null
                            payNote = ""
                        }
                    })
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { ask = null; payNote = "" })
                } else {
                    GhostButton(text = "MARK PAID BY HAND", modifier = Modifier.fillMaxWidth(), onClick = { ask = p.id; payNote = "" })
                }
            }
        }

        Text("Paid archive (" + paid.size + ")", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        if (paid.isEmpty()) Text("Paid payouts are kept here permanently.", color = CT.TextSoft, fontSize = 13.sp)
        for (p in paid) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("✅ " + nameOf(workers, p.workerId), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                InfoRow("Amount", ugx(p.amountUgx))
                InfoRow("Sent to", number(p))
                InfoRow("Week of", p.weekKey)
                InfoRow("Requested", fmtTime(p.requestedAt))
                val at = p.paidAt
                if (at != null) InfoRow("Paid", fmtTime(at))
                val how = when (p.confirmationMode) {
                    "AUTO_MATCH" -> "Matched to statement (" + (p.matchConfidence ?: "?") + "), confirmed by manager"
                    "MANUAL" -> "Confirmed by hand by manager"
                    else -> "Confirmed"
                }
                InfoRow("How", how)
                val by = p.confirmedBy
                if (by != null) InfoRow("Manager", by)
                if (p.note.isNotBlank()) Text(p.note, color = CT.TextSoft, fontSize = 11.sp)
            }
        }
    }
}
