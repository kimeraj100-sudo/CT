package com.ctteam.app.data

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Piece 8A — ONE shared PDF text reader.
 * Used by the payout statement import (Piece 7) and by the NC Wallet statement import (Piece 8B).
 *
 * It returns the plain text of a PDF with table rows kept on one line where the PDF allows it.
 * It never guesses: a scanned PDF (a picture of a page, no text) gets a clear message instead of text.
 */
object PdfText {
    const val MAX_BYTES = 10 * 1024 * 1024        // 10 MB
    const val MAX_PAGES = 200
    private const val TIMEOUT_MS = 45_000L

    /** True if the file starts with the PDF marker "%PDF". */
    fun looksLikePdf(head: ByteArray): Boolean =
        head.size >= 4 && String(head, 0, 4, Charsets.ISO_8859_1) == "%PDF"

    suspend fun read(context: Context, uri: Uri): Outcome<String> {
        val app = context.applicationContext
        val result = withTimeoutOrNull(TIMEOUT_MS) {
            withContext(Dispatchers.IO) { readBlocking(app, uri) }
        }
        return result ?: Outcome.Err("Reading the PDF took too long. Try a smaller file, or copy the table text and paste it.")
    }

    private fun readBlocking(context: Context, uri: Uri): Outcome<String> {
        val bytes: ByteArray = try {
            val stream = context.contentResolver.openInputStream(uri) ?: return Outcome.Err("Could not open that file.")
            stream.use { s ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) return Outcome.Err("That PDF is larger than 10 MB.")
                }
                out.toByteArray()
            }
        } catch (e: Exception) {
            return Outcome.Err("Could not open that file.")
        }
        if (!looksLikePdf(bytes)) return Outcome.Err("That file is not a PDF.")

        return try {
            PDFBoxResourceLoader.init(context)
            val doc = PDDocument.load(java.io.ByteArrayInputStream(bytes))
            doc.use { d ->
                if (d.numberOfPages > MAX_PAGES) {
                    return Outcome.Err("That PDF has more than $MAX_PAGES pages. Split it or paste only the part you need.")
                }
                val stripper = PDFTextStripper()
                stripper.setSortByPosition(true)
                stripper.setLineSeparator("\n")
                val text = stripper.getText(d).replace("\r", "")
                val cleaned = text.lines().map { it.trimEnd() }.joinToString("\n").trim()
                if (cleaned.length < 20) {
                    Outcome.Err("This PDF has no readable text (it may be a scan or a picture). Copy the table from the original app and paste it instead.")
                } else {
                    Outcome.Ok(cleaned)
                }
            }
        } catch (e: Exception) {
            val name = e.javaClass.simpleName
            if (name.contains("Password", ignoreCase = true)) {
                Outcome.Err("This PDF is protected with a password. Open it, remove the password, and try again.")
            } else {
                Outcome.Err("Could not read this PDF (" + name + "). Copy the table text and paste it instead.")
            }
        }
    }
}
