package com.ctteam.app.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.ProofAnalyzer
import com.ctteam.app.data.ProofInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.Locale

/**
 * Piece 4C2 — worker proof submission.
 * The worker picks one or more screenshots (any image the phone can open). For each file the app reads the name, size,
 * dimensions, last-modified time and MIME type and computes the SHA-256 of the file. Only this information is stored,
 * not the picture. Piece 6: the picture fingerprint (dHash) and hidden-data tags are read here; the manager phone works out the verdict. The manager always decides.
 */

const val MAX_PROOF_FILES = 5
private const val MAX_FILE_BYTES = 15L * 1024 * 1024
private val RED = Color(0xFFFF8A8A)

/** One picked screenshot with everything we could read from it. */
class PickedProof(
    val uri: Uri,
    val name: String,
    val size: Long,
    val width: Int?,
    val height: Int?,
    val modifiedAt: Long?,
    val mime: String,
    val sha256: String,
    val dhash: String?,   // Piece 6: what the picture looks like (64-bit fingerprint)
    val tags: String      // Piece 6: "fmt=png;sw=...;ed=..." from the file's hidden data
)

private fun humanSize(bytes: Long): String =
    if (bytes >= 1024 * 1024) String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    else String.format(Locale.US, "%d KB", maxOf(1L, bytes / 1024))

/** Reads name/size/dimensions/time/mime and the SHA-256 of a picked image. Throws IllegalStateException(message) on problems. */
private fun readPicked(context: Context, uri: Uri): PickedProof {
    val resolver = context.contentResolver
    val mime = resolver.getType(uri) ?: ""
    if (!mime.lowercase().startsWith("image/")) throw IllegalStateException("Only image files (screenshots) can be added.")

    var name = "screenshot"
    var size = -1L
    try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
    } catch (e: Exception) {
        // name/size are best effort; the real size is counted while hashing below
    }

    var modified: Long? = null
    try {
        resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_LAST_MODIFIED), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                if (i >= 0 && !c.isNull(i)) modified = c.getLong(i)
            }
        }
    } catch (e: Exception) {
        // not every provider reports it
    }

    if (size > MAX_FILE_BYTES) throw IllegalStateException("$name is too big (max ${humanSize(MAX_FILE_BYTES)}).")

    val digest = MessageDigest.getInstance("SHA-256")
    var counted = 0L
    val input = resolver.openInputStream(uri) ?: throw IllegalStateException("Could not open $name.")
    input.use { stream ->
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n < 0) break
            counted += n
            if (counted > MAX_FILE_BYTES) throw IllegalStateException("$name is too big (max ${humanSize(MAX_FILE_BYTES)}).")
            digest.update(buf, 0, n)
        }
    }
    if (counted == 0L) throw IllegalStateException("$name is empty.")
    val hex = digest.digest().joinToString("") { "%02x".format(it) }

    var w: Int? = null
    var h: Int? = null
    try {
        resolver.openInputStream(uri)?.use { stream ->
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeStream(stream, null, o)
            if (o.outWidth > 0 && o.outHeight > 0) {
                w = o.outWidth
                h = o.outHeight
            }
        }
    } catch (e: Exception) {
        // dimensions are best effort
    }

    val dh = ProofAnalyzer.dHash(context, uri)
    val tg = ProofAnalyzer.tags(context, uri)
    return PickedProof(uri, name, counted, w, h, modified, mime, hex, dh, tg)
}

@Composable
fun WorkerSubmitScreen(
    task: WTask?,
    demo: Boolean,
    onSend: suspend (taskId: String, proofs: List<ProofInput>, reference: String, explanation: String) -> Outcome<Unit>,
    onBackToTasks: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<PickedProof>>(emptyList()) }
    var reference by remember { mutableStateOf("") }
    var explanation by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var reading by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var sent by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            reading = true
            message = ""
            val current = files.toMutableList()
            val problems = mutableListOf<String>()
            for (u in uris) {
                if (current.size >= MAX_PROOF_FILES) {
                    problems.add("You can add at most $MAX_PROOF_FILES screenshots.")
                    break
                }
                if (current.any { it.uri == u }) continue
                try {
                    val p = withContext(Dispatchers.IO) { readPicked(context, u) }
                    if (current.any { it.sha256 == p.sha256 }) problems.add(p.name + " is the same picture as one you already added.")
                    else current.add(p)
                } catch (e: IllegalStateException) {
                    problems.add(e.message ?: "Could not read that file.")
                } catch (e: Exception) {
                    problems.add("Could not read that file.")
                }
            }
            files = current
            message = problems.joinToString("\n")
            reading = false
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Submit proof", if (sent) onBackToTasks else onBack)

        if (sent) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Proof sent", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (demo) "Demo only: nothing was really sent. In the real app the manager now reviews your proof and approves or rejects it."
                    else "The manager will review it. You can see the result under Submissions & earnings.",
                    color = CT.TextSoft, fontSize = 14.sp
                )
            }
            GoldButton(text = "BACK TO TASKS", onClick = onBackToTasks, modifier = Modifier.fillMaxWidth())
            return@Column
        }

        if (task == null) {
            Text("This task is no longer available.", color = RED, fontSize = 14.sp)
            return@Column
        }
        if (task.state != TaskState.AVAILABLE) {
            Text("You cannot send proof for this task right now. " + task.note, color = RED, fontSize = 14.sp)
            return@Column
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(task.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            InfoRow("Pay", ugx(task.payUgx))
            Spacer(Modifier.height(4.dp))
            Text("Proof needed", color = CT.GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(
                if (task.proofRequirements.isBlank()) "A clear screenshot showing that you did the task." else task.proofRequirements,
                color = CT.TextSoft, fontSize = 13.sp
            )
        }

        Text("Screenshots (${files.size} of $MAX_PROOF_FILES)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        for (f in files) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(f.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                val dims = if (f.width != null && f.height != null) "${f.width}×${f.height} · " else ""
                Text(dims + humanSize(f.size), color = CT.TextSoft, fontSize = 12.sp)
                if (f.modifiedAt != null) Text("File date: " + fmtTime(f.modifiedAt), color = CT.TextSoft, fontSize = 12.sp)
                Text("Fingerprint: " + f.sha256.take(12) + "…", color = CT.TextSoft, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "REMOVE", color = Color(0xFFFF6B6B), fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.clickable { files = files.filter { it.uri != f.uri } }.padding(vertical = 4.dp)
                )
            }
        }
        GhostButton(
            text = if (reading) "READING…" else if (files.isEmpty()) "ADD SCREENSHOT" else "ADD MORE",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (!reading && !sending && files.size < MAX_PROOF_FILES) picker.launch(arrayOf("image/*"))
            }
        )

        CTField(reference, { reference = it }, "Reference: link, username or ID (optional)")
        CTField(explanation, { explanation = it }, "Explain what you did (optional)", singleLine = false, minLines = 3)

        Text(
            "Send your own original screenshots, uncropped and unedited. The app records each file's size, dimensions, date, a fingerprint and any editing tags hidden in the file. " +
                "These checks can only flag problems — they cannot prove a screenshot is genuine. The manager makes the final decision.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        if (message.isNotEmpty()) Text(message, color = RED, fontSize = 13.sp)

        GoldButton(
            text = if (sending) "SENDING…" else "SEND PROOF",
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (sending || reading) return@GoldButton
                if (files.isEmpty()) {
                    message = "Add at least one screenshot."
                    return@GoldButton
                }
                sending = true
                message = ""
                val proofs = files.map {
                    ProofInput(
                        kind = "SCREENSHOT", sha256 = it.sha256, fileName = it.name, fileSize = it.size,
                        width = it.width, height = it.height, fileModifiedAt = it.modifiedAt, mime = it.mime,
                        dhash = it.dhash, metadataTags = it.tags.ifBlank { null }
                    )
                }
                val ref = reference
                val expl = explanation
                val id = task.id
                scope.launch {
                    val r = onSend(id, proofs, ref, expl)
                    if (r is Outcome.Err) message = r.message else sent = true
                    sending = false
                }
            }
        )
        Spacer(Modifier.height(8.dp))
    }
}
