package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.AutoConnect
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece C2b — Manager menu > Auto-connect. The main manager turns it on or off. Every manager can VERIFY workers who connected by themselves.
 * Until a worker is verified, their payouts cannot be confirmed and referral points involving them cannot be awarded.
 */
@Composable
fun ManagerAutoConnectScreen(repos: Repos, actor: String, isMain: Boolean, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(false) }
    var rows by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var refresh by remember { mutableStateOf(0) }
    var note by remember { mutableStateOf("") }

    LaunchedEffect(refresh) {
        on = AutoConnect.enabled(repos.db)
        val names = repos.db.workerDao().all().associate { it.id to it.fullName() }
        rows = AutoConnect.unverifiedIds(repos.db).map { it to (names[it] ?: "Unknown worker") }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Auto-connect", onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Connect new workers without a call", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(
                "When this is ON, a brand-new worker who sends the connection code to your bot is connected at once. " +
                    "You do not compare key codes. They show below as NOT VERIFIED: they can work and send reports, " +
                    "but their payouts cannot be confirmed and referral points involving them cannot be awarded until you press VERIFY. " +
                    "A code that matches a worker you already added, or has any problem, still waits for you.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Text("Now: " + (if (on) "ON" else "OFF"), color = if (on) CT.Gold else Color.White, fontWeight = FontWeight.SemiBold)
            if (isMain) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CTChip("ON", on, {
                        scope.launch {
                            when (val r = AutoConnect.setEnabled(repos.db, repos.audit, true, isMain, actor)) {
                                is Outcome.Ok -> note = "Auto-connect is ON."
                                is Outcome.Err -> note = r.message
                            }
                            refresh++
                        }
                    })
                    CTChip("OFF", !on, {
                        scope.launch {
                            when (val r = AutoConnect.setEnabled(repos.db, repos.audit, false, isMain, actor)) {
                                is Outcome.Ok -> note = "Auto-connect is OFF."
                                is Outcome.Err -> note = r.message
                            }
                            refresh++
                        }
                    })
                }
            } else {
                Text("Only the main manager can turn it on or off.", color = CT.TextSoft, fontSize = 12.sp)
            }
            if (note.isNotEmpty()) Text(note, color = CT.GoldLight, fontSize = 12.sp)
        }

        Text("Not verified (" + rows.size + ")", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (rows.isEmpty()) {
            EmptyState("✅", "Everyone is verified", "Workers who connect by themselves appear here until you verify them.")
        }
        for ((id, name) in rows) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("Check who this person really is (call them, or ask someone you know) before you verify.", color = CT.TextSoft, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                GoldButton(text = "VERIFY", modifier = Modifier.fillMaxWidth(), onClick = {
                    scope.launch {
                        AutoConnect.verify(repos.db, repos.audit, id, actor)
                        note = "$name is verified."
                        refresh++
                    }
                })
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
