package com.ctteam.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** CT Team jewel-tone palette: navy, emerald/teal, violet, metallic gold. */
object CT {
    val Navy = Color(0xFF070F1F)
    val NavyDeep = Color(0xFF0B1B33)
    val Emerald = Color(0xFF0F9D7A)
    val Teal = Color(0xFF14B8A6)
    val Violet = Color(0xFF7C3AED)
    val Gold = Color(0xFFD4AF37)
    val GoldLight = Color(0xFFF3D98B)
    val GoldDark = Color(0xFF9C7A1E)
    val TextSoft = Color(0xFFB8C4D6)
}

@Composable
fun CTTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = CT.Gold,
            onPrimary = CT.Navy,
            secondary = CT.Teal,
            tertiary = CT.Violet,
            background = CT.Navy,
            onBackground = Color.White,
            surface = CT.NavyDeep,
            onSurface = Color.White
        ),
        content = content
    )
}
