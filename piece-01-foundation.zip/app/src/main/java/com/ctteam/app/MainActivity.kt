package com.ctteam.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ctteam.app.ui.CTApp
import com.ctteam.app.ui.CTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CTTheme {
                CTApp()
            }
        }
    }
}
