package com.ctteam.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ctteam.app.data.LearnContentEntity
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 10C — worker Learn & Earn. The lessons the manager sent (10B) live in `learn_content`; only published ones are shown.
 * A lesson is "read" when the worker taps the tick for the CURRENT version (meta key `learn:read:<worker>:<lessonId>` = version),
 * so an edited lesson shows as new again. Links open in the phone's browser; nothing is downloaded by the app.
 */
private const val WL_GENERAL = "General"
private val WL_GOOD = Color(0xFF5FD6A5)
private val WL_BAD = Color(0xFFFF8A8A)

private fun wlKey(workerId: String, lessonId: String): String = "learn:read:" + workerId + ":" + lessonId

private suspend fun wlLoadTicks(repos: Repos, workerId: String, lessons: List<LearnContentEntity>): Map<String, String> {
    val out = HashMap<String, String>()
    for (l in lessons) out[l.id] = repos.db.metaDao().get(wlKey(workerId, l.id)) ?: ""
    return out
}

private fun wlCategory(l: LearnContentEntity): String = l.category.trim().ifBlank { WL_GENERAL }

private fun wlIsRead(ticks: Map<String, String>, l: LearnContentEntity): Boolean = ticks[l.id] == l.version.toString()

private fun wlHost(url: String): String = url.substringAfter("https://").substringBefore("/").substringBefore("?")

/** Opens an https link only. Returns false when it is not https or the phone has no app to open it. */
private fun wlOpen(handler: UriHandler, url: String): Boolean {
    if (!url.startsWith("https://")) return false
    return try {
        handler.openUri(url)
        true
    } catch (e: Exception) {
        false
    }
}

@Composable
fun WorkerLearnCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val flow = remember(repos) { repos.db.contentDao().observeLearn() }
    val lessons by flow.collectAsState(initial = emptyList())
    var ticks by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var open by remember { mutableStateOf(false) }

    LaunchedEffect(lessons, workerId) { ticks = wlLoadTicks(repos, workerId, lessons) }
    val unread = lessons.count { !wlIsRead(ticks, it) }

    GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { open = true }) {
        Text("📚 Learn & Earn", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        if (lessons.isEmpty()) {
            Text("No lessons yet. Lessons the manager sends you will appear here.", color = CT.TextSoft, fontSize = 12.sp)
        } else {
            val head = if (unread > 0) lessons.size.toString() + " lessons, " + unread + " new or changed" else lessons.size.toString() + " lessons, all read"
            Text(head, color = Color.White, fontSize = 13.sp)
            Text("Tap to open.", color = CT.TextSoft, fontSize = 12.sp)
        }
    }

    if (open) {
        var openId by remember { mutableStateOf<String?>(null) }
        Dialog(
            onDismissRequest = { if (openId != null) openId = null else open = false },
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
        ) {
            CTBackground {
                val picked = lessons.firstOrNull { it.id == openId }
                if (picked == null) {
                    WlList(
                        lessons = lessons,
                        ticks = ticks,
                        onOpen = { openId = it },
                        onClose = { open = false }
                    )
                } else {
                    WlDetail(
                        lesson = picked,
                        read = wlIsRead(ticks, picked),
                        onMarkRead = {
                            scope.launch {
                                repos.db.metaDao().put(MetaEntity(wlKey(workerId, picked.id), picked.version.toString()))
                                ticks = ticks + (picked.id to picked.version.toString())
                            }
                        },
                        onBack = { openId = null }
                    )
                }
            }
        }
    }
}

@Composable
private fun WlList(lessons: List<LearnContentEntity>, ticks: Map<String, String>, onOpen: (String) -> Unit, onClose: () -> Unit) {
    var filter by remember { mutableStateOf<String?>(null) }
    val cats = lessons.map { wlCategory(it) }.distinct().sorted()
    val shown = if (filter == null) lessons else lessons.filter { wlCategory(it) == filter }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Learn & Earn", onClose)
        if (lessons.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("No lessons yet.", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    "When the manager sends a lesson it is added here. If the manager sent one by Telegram or as a code, open it with Share or the \"Use it\" offer on your home screen.",
                    color = CT.TextSoft, fontSize = 13.sp
                )
            }
        } else {
            if (cats.size > 1) {
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CTChip("All (" + lessons.size + ")", filter == null, { filter = null })
                    for (c in cats) {
                        val n = lessons.count { wlCategory(it) == c }
                        CTChip(c + " (" + n + ")", filter == c, { filter = c })
                    }
                }
            }
            for (l in shown) {
                val read = wlIsRead(ticks, l)
                GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { onOpen(l.id) }) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(wlCategory(l), color = CT.TextSoft, fontSize = 11.sp)
                        Text(if (read) "✓ Read" else "NEW", color = if (read) WL_GOOD else CT.Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(l.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    val preview = l.body.trim().replace("\n", " ")
                    Text(if (preview.length > 110) preview.take(110) + "…" else preview, color = CT.TextSoft, fontSize = 12.sp)
                    if (l.videoUrl.isNotBlank() || l.imageUrl.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        val bits = ArrayList<String>()
                        if (l.videoUrl.isNotBlank()) bits.add("🎬 video")
                        if (l.imageUrl.isNotBlank()) bits.add("🖼 picture")
                        Text(bits.joinToString("  "), color = CT.GoldLight, fontSize = 11.sp)
                    }
                }
            }
        }
        GhostButton(text = "CLOSE", onClick = onClose, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun WlDetail(lesson: LearnContentEntity, read: Boolean, onMarkRead: () -> Unit, onBack: () -> Unit) {
    val handler = LocalUriHandler.current
    var note by remember(lesson.id) { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Lesson", onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text(wlCategory(lesson) + "  ·  " + fmtTime(lesson.updatedAt), color = CT.TextSoft, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(lesson.title, color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(8.dp))
            Text(lesson.body, color = Color.White, fontSize = 15.sp, lineHeight = 22.sp)
        }
        if (lesson.videoUrl.isNotBlank()) {
            GoldButton(text = "OPEN VIDEO", modifier = Modifier.fillMaxWidth(), onClick = {
                note = if (wlOpen(handler, lesson.videoUrl)) "" else "This phone could not open the video link."
            })
            Text("Opens in your browser or video app: " + wlHost(lesson.videoUrl), color = CT.TextSoft, fontSize = 11.sp)
        }
        if (lesson.imageUrl.isNotBlank()) {
            GhostButton(text = "OPEN PICTURE", modifier = Modifier.fillMaxWidth(), onClick = {
                note = if (wlOpen(handler, lesson.imageUrl)) "" else "This phone could not open the picture link."
            })
            Text("Opens in your browser: " + wlHost(lesson.imageUrl), color = CT.TextSoft, fontSize = 11.sp)
        }
        if (note.isNotEmpty()) Text(note, color = WL_BAD, fontSize = 13.sp)
        if (read) {
            Text("✓ You marked this lesson as read.", color = WL_GOOD, fontSize = 13.sp)
        } else {
            GoldButton(text = "MARK AS READ", onClick = onMarkRead, modifier = Modifier.fillMaxWidth())
        }
        GhostButton(text = "BACK TO LESSONS", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
