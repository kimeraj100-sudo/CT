package com.ctteam.app.data

import java.math.BigDecimal
import kotlin.math.abs

/**
 * Piece 8D — matches worker BNB claims to NC Wallet statement rows. Pure logic, no database.
 *
 * A claim and a row FIT when:  same coin  +  EXACTLY the same amount (BigDecimal, never a float)  +  times within
 * [TOLERANCE_MS]. Only deposits fit: a row whose amount is zero or negative (a withdrawal) is never a candidate.
 *
 * Strict one-to-one: the claims and rows that fit are put in a graph. A group (connected set) that is exactly one
 * claim + one row is a CLEAR match. Any bigger group (two rows fit one claim, two claims fit one row, ...) is
 * AMBIGUOUS: nothing is chosen automatically, the manager decides.
 */

data class NcMatchPair(val claim: NcClaimEntity, val row: NcRowEntity, val diffMs: Long)

class NcAmbiguous(val claims: List<NcClaimEntity>, val rows: List<NcRowEntity>)

enum class NcClaimState { CLEAR, AMBIGUOUS, NOT_FOUND }

class NcMatchReport(
    val clear: List<NcMatchPair>,
    val ambiguous: List<NcAmbiguous>,
    val noRow: List<NcClaimEntity>,        // claims with no fitting row
    val spareRows: List<NcRowEntity>       // unmatched rows no claim fits
) {
    private val states: Map<Long, NcClaimState> = HashMap<Long, NcClaimState>().also { m ->
        for (p in clear) m[p.claim.id] = NcClaimState.CLEAR
        for (g in ambiguous) for (c in g.claims) m[c.id] = NcClaimState.AMBIGUOUS
        for (c in noRow) m[c.id] = NcClaimState.NOT_FOUND
    }

    /** State of a claim that was still unmatched when the report was made; null for any other claim. */
    fun stateOf(claimId: Long): NcClaimState? = states[claimId]
}

object NcMatcher {
    const val TOLERANCE_MS = 2L * 60 * 1000

    fun amountOf(text: String): BigDecimal? = try {
        BigDecimal(text.trim().removePrefix("+").replace(",", ""))
    } catch (ex: NumberFormatException) {
        null
    }

    fun match(claims: List<NcClaimEntity>, rows: List<NcRowEntity>): NcMatchReport {
        val cl = claims.filter { it.status == NcStatus.UNMATCHED && it.matchedRowId == null }.sortedBy { it.claimedAtUtc }
        val rw = rows.filter { it.matchedClaimId == null }.sortedBy { it.occurredAtUtc }

        val rowsByCoin = rw.groupBy { it.coin }
        val rowAmount = HashMap<Long, BigDecimal>()
        for (r in rw) amountOf(r.amountText)?.let { if (it.signum() > 0) rowAmount[r.id] = it }

        val claimToRows = HashMap<Long, MutableList<NcRowEntity>>()
        val rowToClaims = HashMap<Long, MutableList<NcClaimEntity>>()
        for (c in cl) {
            val ca = amountOf(c.amountText)
            if (ca == null || ca.signum() <= 0) continue
            for (r in rowsByCoin[c.coin].orEmpty()) {
                val ra = rowAmount[r.id] ?: continue
                if (ra.compareTo(ca) != 0) continue
                if (abs(r.occurredAtUtc - c.claimedAtUtc) > TOLERANCE_MS) continue
                claimToRows.getOrPut(c.id) { mutableListOf() }.add(r)
                rowToClaims.getOrPut(r.id) { mutableListOf() }.add(c)
            }
        }

        val clear = ArrayList<NcMatchPair>()
        val ambiguous = ArrayList<NcAmbiguous>()
        val seenClaims = HashSet<Long>()
        val seenRows = HashSet<Long>()

        for (start in cl) {
            if (start.id in seenClaims || claimToRows[start.id] == null) continue
            // walk the whole connected group
            val gClaims = LinkedHashMap<Long, NcClaimEntity>()
            val gRows = LinkedHashMap<Long, NcRowEntity>()
            val todo = ArrayDeque<NcClaimEntity>()
            todo.add(start)
            while (todo.isNotEmpty()) {
                val c = todo.removeFirst()
                if (c.id in gClaims) continue
                gClaims[c.id] = c
                for (r in claimToRows[c.id].orEmpty()) {
                    gRows[r.id] = r
                    for (c2 in rowToClaims[r.id].orEmpty()) if (c2.id !in gClaims) todo.add(c2)
                }
            }
            seenClaims.addAll(gClaims.keys)
            seenRows.addAll(gRows.keys)
            if (gClaims.size == 1 && gRows.size == 1) {
                val c = gClaims.values.first()
                val r = gRows.values.first()
                clear.add(NcMatchPair(c, r, abs(r.occurredAtUtc - c.claimedAtUtc)))
            } else {
                ambiguous.add(
                    NcAmbiguous(
                        gClaims.values.sortedBy { it.claimedAtUtc },
                        gRows.values.sortedBy { it.occurredAtUtc }
                    )
                )
            }
        }

        val noRow = cl.filter { it.id !in seenClaims }
        val spare = rw.filter { it.id !in seenRows }
        return NcMatchReport(clear, ambiguous, noRow, spare)
    }
}

/** One line for the Review screen: kind is GOOD, WARN or INFO (the screen picks the colour). */
class NcReviewLine(val kind: String, val text: String)
