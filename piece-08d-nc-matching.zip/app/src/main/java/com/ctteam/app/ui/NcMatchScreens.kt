package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.NcClaimEntity
import com.ctteam.app.data.NcMatchReport
import com.ctteam.app.data.NcRowEntity
import com.ctteam.app.data.NcStatus
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Piece 8D — Manager > NC Wallet > Matching.
 * The matcher only SUGGESTS. Nothing is matched until the manager taps. A match is evidence that a deposit of that
 * amount existed at about that time; it does not prove who made it, and the manager still decides each submission.
 */

private val MWARN = Color(0xFFFF8A8A)
private val MGOOD = Color(0xFF5FD6A5)

private fun mSec(ms: Long, utc: Boolean): String {
    val f = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.US)
    f.timeZone = TimeZone.getTimeZone(if (utc) "UTC" else "GMT+03:00")
    return f.format(Date(ms))
}

private fun rowLabel(r: NcRowEntity): String = "Row " + r.rowNo.ifBlank { "#" + r.id } + ": " + r.coin + " " + r.amountText

@Composable
private fun ClaimLines(c: NcClaimEntity, who: String) {
    Text(c.coin + "  " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Text(who, color = CT.TextSoft, fontSize = 12.sp)
    Text("Claim time EAT " + mSec(c.claimedAtUtc, false), color = CT.TextSoft, fontSize = 12.sp)
}

@Composable
private fun RowLines(r: NcRowEntity) {
    Text(rowLabel(r), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text("UTC " + mSec(r.occurredAtUtc, true), color = CT.TextSoft, fontSize = 12.sp)
    Text("EAT " + mSec(r.occurredAtUtc, false), color = CT.TextSoft, fontSize = 12.sp)
}

@Composable
fun NcMatchingScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val dao = repos.db.ncDao()

    val claimsFlow = remember(repos) { dao.observeAllClaims() }
    val workersFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val claims by claimsFlow.collectAsState(initial = emptyList())
    val workers by workersFlow.collectAsState(initial = emptyList())

    var report by remember { mutableStateOf<NcMatchReport?>(null) }
    var openRows by remember { mutableStateOf<List<NcRowEntity>>(emptyList()) }
    var linkedRows by remember { mutableStateOf<Map<Long, NcRowEntity>>(emptyMap()) }
    var refresh by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var messageBad by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var confirmAll by remember { mutableStateOf(false) }
    var pickClaimId by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(claims, refresh) {
        report = repos.nc.runMatch()
        openRows = dao.allUnmatchedRows()
        val map = HashMap<Long, NcRowEntity>()
        for (c in claims) if (c.status != NcStatus.UNMATCHED) dao.rowOfClaim(c.id)?.let { map[c.id] = it }
        linkedRows = map
    }

    fun who(c: NcClaimEntity) = workers.firstOrNull { it.id == c.workerId }?.fullName() ?: "Worker"

    fun done(r: Outcome<*>, ok: String) {
        when (r) {
            is Outcome.Ok -> { message = ok; messageBad = false; note = ""; pickClaimId = null }
            is Outcome.Err -> { message = r.message; messageBad = true }
        }
        confirmAll = false
        refresh++
        busy = false
    }

    val rep = report
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Matching", onBack)
        Text(
            "A worker's claim FITS a statement row when the coin is the same, the amount is exactly the same, and the times are within 2 minutes. " +
                "A match is only evidence that such a deposit exists. It does not prove who made it, and you still decide each submission. " +
                "Nothing is matched until you tap.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (message.isNotEmpty()) Text(message, color = if (messageBad) MWARN else MGOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

        if (rep == null) {
            Text("Checking…", color = CT.TextSoft)
        } else {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                InfoRow("Clear matches waiting for you", rep.clear.size.toString())
                InfoRow("Groups that need a decision", rep.ambiguous.size.toString())
                InfoRow("Claims with no fitting row", rep.noRow.size.toString())
                InfoRow("Statement rows no claim fits", rep.spareRows.size.toString())
            }

            // ---------------------------------------------------------------- reason (shared)
            CTField(note, { note = it }, "Reason (needed for a manual link or an unlink)", singleLine = false, minLines = 2)

            // ---------------------------------------------------------------- clear
            Text("Clear matches (${rep.clear.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            if (rep.clear.isEmpty()) Text("None right now.", color = CT.TextSoft, fontSize = 13.sp)
            if (rep.clear.size > 1) {
                if (!confirmAll) {
                    GoldButton(text = "CONFIRM ALL " + rep.clear.size + " CLEAR MATCHES", modifier = Modifier.fillMaxWidth(), onClick = { confirmAll = true })
                } else {
                    Text("Confirm all " + rep.clear.size + " pairs? Each one links a claim to its row.", color = Color.White, fontSize = 13.sp)
                    GoldButton(text = if (busy) "PLEASE WAIT" else "YES, CONFIRM ALL " + rep.clear.size, modifier = Modifier.fillMaxWidth(), onClick = {
                        if (busy) return@GoldButton
                        busy = true
                        scope.launch { done(repos.nc.confirmAllClear(actor), "Confirmed.") }
                    })
                    GhostButton(text = "CANCEL", modifier = Modifier.fillMaxWidth(), onClick = { confirmAll = false })
                }
            }
            for (p in rep.clear) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    ClaimLines(p.claim, who(p.claim))
                    Spacer(Modifier.height(6.dp))
                    Text("fits statement", color = CT.TextSoft, fontSize = 11.sp)
                    RowLines(p.row)
                    Text("Time difference: " + (p.diffMs / 1000) + " s", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    GoldButton(text = if (busy) "PLEASE WAIT" else "CONFIRM THIS MATCH", modifier = Modifier.fillMaxWidth(), onClick = {
                        if (busy) return@GoldButton
                        busy = true
                        val cid = p.claim.id
                        val rid = p.row.id
                        scope.launch { done(repos.nc.confirmPair(cid, rid, actor), "Match confirmed.") }
                    })
                }
            }

            // ---------------------------------------------------------------- ambiguous
            Text("Needs your decision (${rep.ambiguous.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            if (rep.ambiguous.isEmpty()) Text("None.", color = CT.TextSoft, fontSize = 13.sp)
            for (g in rep.ambiguous) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "⚠ " + g.claims.size + " claim(s) and " + g.rows.size + " row(s) fit each other. Nothing was chosen automatically.",
                        color = MWARN, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    for (c in g.claims) {
                        ClaimLines(c, who(c))
                        for (r in g.rows) {
                            Spacer(Modifier.height(4.dp))
                            RowLines(r)
                            GhostButton(text = "LINK THIS CLAIM TO ROW " + r.rowNo.ifBlank { "#" + r.id }, modifier = Modifier.fillMaxWidth(), onClick = {
                                if (busy) return@GhostButton
                                busy = true
                                val cid = c.id
                                val rid = r.id
                                val reason = note
                                scope.launch { done(repos.nc.manualLink(cid, rid, reason, actor), "Linked (manual).") }
                            })
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }

            // ---------------------------------------------------------------- no fitting row
            Text("Claims with no fitting row (${rep.noRow.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            if (rep.noRow.isEmpty()) Text("None.", color = CT.TextSoft, fontSize = 13.sp)
            for (c in rep.noRow) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    ClaimLines(c, who(c))
                    Text("No row with this coin, exact amount and a time within 2 minutes. The statement may not cover that time yet.", color = CT.TextSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    if (pickClaimId == c.id) {
                        Text("Choose the statement row to link (a reason is required):", color = Color.White, fontSize = 13.sp)
                        val candidates = openRows.sortedWith(compareBy<NcRowEntity>({ if (it.coin == c.coin) 0 else 1 }, { Math.abs(it.occurredAtUtc - c.claimedAtUtc) })).take(15)
                        if (candidates.isEmpty()) Text("There are no unmatched statement rows.", color = CT.TextSoft, fontSize = 12.sp)
                        for (r in candidates) {
                            Spacer(Modifier.height(4.dp))
                            RowLines(r)
                            GhostButton(text = "LINK TO THIS ROW", modifier = Modifier.fillMaxWidth(), onClick = {
                                if (busy) return@GhostButton
                                busy = true
                                val cid = c.id
                                val rid = r.id
                                val reason = note
                                scope.launch { done(repos.nc.manualLink(cid, rid, reason, actor), "Linked (manual).") }
                            })
                        }
                        Spacer(Modifier.height(6.dp))
                        GhostButton(text = "CLOSE", modifier = Modifier.fillMaxWidth(), onClick = { pickClaimId = null })
                    } else {
                        GhostButton(text = "LINK TO A ROW MANUALLY…", modifier = Modifier.fillMaxWidth(), onClick = { pickClaimId = c.id })
                    }
                }
            }

            // ---------------------------------------------------------------- already linked
            val linked = claims.filter { it.status != NcStatus.UNMATCHED }
            Text("Linked claims (${linked.size})", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            if (linked.isEmpty()) Text("None yet.", color = CT.TextSoft, fontSize = 13.sp)
            for (c in linked) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.coin + "  " + c.amountText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(if (c.status == NcStatus.MANUAL) "✅ manual" else "✅ matched", color = MGOOD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(who(c), color = CT.TextSoft, fontSize = 12.sp)
                    Text("Claim time EAT " + mSec(c.claimedAtUtc, false), color = CT.TextSoft, fontSize = 12.sp)
                    linkedRows[c.id]?.let { Text(rowLabel(it) + " · EAT " + mSec(it.occurredAtUtc, false), color = CT.TextSoft, fontSize = 12.sp) }
                    Spacer(Modifier.height(6.dp))
                    GhostButton(text = "UNLINK (reason required)", danger = true, modifier = Modifier.fillMaxWidth(), onClick = {
                        if (busy) return@GhostButton
                        busy = true
                        val cid = c.id
                        val reason = note
                        scope.launch { done(repos.nc.unlink(cid, reason, actor), "Unlinked. The claim and the row are free again.") }
                    })
                }
            }

            Text(
                "Workers see \"Verified by the manager\" after you send them an update (Sync > Updates for workers).",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}
