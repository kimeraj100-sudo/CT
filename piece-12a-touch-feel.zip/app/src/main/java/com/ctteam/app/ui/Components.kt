package com.ctteam.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.R

/** Full-screen dark jewel gradient used behind every screen. */
@Composable
fun CTBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(CT.Navy, Color(0xFF0A2A3A), Color(0xFF1B1038))
                )
            ),
        content = content
    )
}

/** The approved CT Team logo with a moving gold light-sweep over it. */
@Composable
fun ShimmerLogo(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerProgress"
    )
    Image(
        painter = painterResource(R.drawable.logo_shield),
        contentDescription = "CT Team logo",
        contentScale = ContentScale.Fit,
        modifier = modifier
            .aspectRatio(494f / 760f)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                val w = size.width
                val x = -w * 0.5f + progress * w * 2f
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.45f),
                            Color.Transparent
                        ),
                        start = Offset(x, 0f),
                        end = Offset(x + w * 0.35f, size.height * 0.35f)
                    ),
                    blendMode = BlendMode.SrcAtop
                )
            }
    )
}

/** Metallic gold button. */
@Composable
fun GoldButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    val press = rememberCTPress(0.96f, onClick)
    Box(
        modifier = modifier
            .ctScale(press)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(CT.GoldLight, CT.Gold, CT.GoldDark)))
            .clickable(interactionSource = press.source, indication = LocalIndication.current, onClick = press.click)
            .padding(horizontal = 32.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = CT.Navy,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            fontSize = 15.sp
        )
    }
}

/** Glass-style card with a gold edge. Pass onClick to make it tappable. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val press = rememberCTPress(0.985f, onClick ?: {})
    val tap = if (onClick != null) Modifier.clickable(interactionSource = press.source, indication = LocalIndication.current, onClick = press.click) else Modifier
    val scaleMod = if (onClick != null) Modifier.ctScale(press) else Modifier
    Column(
        modifier = modifier
            .then(scaleMod)
            .ctEnter()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x10FFFFFF))))
            .border(
                1.dp,
                Brush.linearGradient(listOf(CT.GoldLight, CT.Gold.copy(alpha = 0.3f))),
                shape
            )
            .then(tap)
            .padding(20.dp),
        content = content
    )
}
