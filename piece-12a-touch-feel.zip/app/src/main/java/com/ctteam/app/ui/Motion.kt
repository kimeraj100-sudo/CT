package com.ctteam.app.ui

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback

/**
 * Piece 12a — touch feel, in one place so every button and card in the app gets it.
 *  - Press feedback: a soft spring scale-down while a finger is on a button, chip or tappable card, plus a light haptic tick.
 *  - Entrance: cards fade and rise a few pixels the first time they appear.
 * Both switch themselves off when the phone's "Remove animations" / animator scale is 0 (accessibility), and neither changes
 * what any screen does: a tap still calls the same function.
 */

/** True when the person turned animations off in the phone's settings (animator duration scale 0). */
@Composable
fun ctReduceMotion(): Boolean {
    val context = LocalContext.current
    return remember {
        try {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (ex: Exception) {
            false
        }
    }
}

/** State for one pressable thing: share [source] with `clickable`, read [scale] in `graphicsLayer`, call [click] on tap. */
class CTPress(val source: MutableInteractionSource, val scale: State<Float>, val click: () -> Unit)

@Composable
fun rememberCTPress(pressedScale: Float, onClick: () -> Unit): CTPress {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val still = ctReduceMotion()
    val scale = animateFloatAsState(
        targetValue = if (pressed && !still) pressedScale else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    val haptic = LocalHapticFeedback.current
    return CTPress(source, scale) {
        try { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) } catch (ex: Exception) { /* no vibrator: fine */ }
        onClick()
    }
}

/** Scales the thing by [CTPress.scale]. Put it FIRST in the modifier chain so the whole button (shape, fill, text) moves together. */
fun Modifier.ctScale(press: CTPress): Modifier = this.graphicsLayer {
    val s = press.scale.value
    scaleX = s
    scaleY = s
}

/** Fade in and rise about 12 dp the first time this appears. [delayMs] staggers neighbours if wanted. */
@Composable
fun Modifier.ctEnter(delayMs: Int = 0): Modifier {
    val still = ctReduceMotion()
    val progress = remember { Animatable(if (still) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!still) progress.animateTo(1f, tween(durationMillis = 360, delayMillis = delayMs, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        val p = progress.value
        alpha = p
        translationY = (1f - p) * 12f * density
    }
}
