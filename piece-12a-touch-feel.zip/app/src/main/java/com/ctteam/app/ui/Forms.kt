package com.ctteam.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Shared form/layout pieces used by Manager (piece 3) and Worker (piece 4) screens. */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CTField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    keyboard: KeyboardType = KeyboardType.Text,
    secret: Boolean = false,
    singleLine: Boolean = true,
    minLines: Int = 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = CT.Gold,
            unfocusedBorderColor = CT.TextSoft,
            focusedLabelColor = CT.Gold,
            unfocusedLabelColor = CT.TextSoft,
            cursorColor = CT.Gold
        )
    )
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Text(
                text = "←",
                color = CT.Gold,
                fontSize = 26.sp,
                modifier = Modifier
                    .clickable(onClick = onBack)
                    .padding(end = 16.dp, top = 4.dp, bottom = 4.dp)
            )
        }
        Text(
            text = title,
            color = CT.Gold,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp
        )
    }
}

/** Outlined gold button for secondary actions. Pass danger = true for red (reject, disable). */
@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, danger: Boolean = false) {
    val colour = if (danger) Color(0xFFFF6B6B) else CT.Gold
    val shape = RoundedCornerShape(16.dp)
    val press = rememberCTPress(0.96f, onClick)
    Box(
        modifier = modifier
            .ctScale(press)
            .clip(shape)
            .border(1.dp, colour, shape)
            .clickable(interactionSource = press.source, indication = LocalIndication.current, onClick = press.click)
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = colour, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontSize = 14.sp)
    }
}

@Composable
fun CTChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    val press = rememberCTPress(0.94f, onClick)
    Box(
        modifier = modifier
            .ctScale(press)
            .clip(shape)
            .background(if (selected) CT.Gold else Color(0x20FFFFFF))
            .border(1.dp, if (selected) CT.Gold else CT.TextSoft, shape)
            .clickable(interactionSource = press.source, indication = LocalIndication.current, onClick = press.click)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, color = if (selected) CT.Navy else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = CT.TextSoft, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** Date/time shown in East Africa Time. */
fun fmtTime(ms: Long): String {
    val f = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US)
    f.timeZone = TimeZone.getTimeZone("GMT+03:00")
    return f.format(Date(ms))
}

fun ugx(n: Long): String = "UGX " + String.format(Locale.US, "%,d", n)
