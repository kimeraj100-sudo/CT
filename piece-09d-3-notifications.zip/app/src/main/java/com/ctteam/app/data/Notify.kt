package com.ctteam.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.ctteam.app.MainActivity
import java.util.concurrent.TimeUnit

/**
 * Piece 9D-3 — phone notifications. Nothing leaves the phone and no server is involved:
 *  - Manager phone: every ~15 minutes (when there is internet) the app PEEKS at the bot's waiting messages (it does not take them),
 *    counts submissions to review and unread support messages, and shows ONE notification with counts only (never names or text).
 *  - Worker phone: a quiet reminder, at most once a day, when items were never put into a report for the manager.
 * Both are off until the person turns them on (and allows notifications on Android 13+).
 */
object CTNotify {
    const val CH_MANAGER = "ct_manager"
    const val CH_WORKER = "ct_worker"
    const val ID_MANAGER = 9101
    const val ID_WORKER = 9102
    const val ID_TEST = 9103

    const val KEY_MGR = "notify:mgr"                 // "1" when the manager check is on
    const val KEY_MGR_LAST = "notify:mgr:last"       // "tg,subs,support" counts at the last check
    const val KEY_MGR_CHECKED = "notify:mgr:at"      // time of the last check (millis)
    const val KEY_WRK = "notify:worker"              // id of the worker whose reminders are on, or empty
    const val KEY_WRK_AT = "notify:worker:at"        // time of the last reminder (millis)

    const val PEEK_MAX = 50                          // Telegram gives at most 50 waiting messages per call

    private const val WORK_MGR = "ct-notify-manager"
    private const val WORK_WRK = "ct-notify-worker"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_MANAGER, "Waiting for you (manager)", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_WORKER, "Reminders (worker)", NotificationManager.IMPORTANCE_LOW))
    }

    /** True when the phone lets CT Team show notifications (on Android 13+ this also means the permission was given). */
    fun canPost(ctx: Context): Boolean = NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    fun post(ctx: Context, id: Int, channel: String, title: String, text: String) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
            // permission withdrawn between the check and the call: nothing to do
        }
    }

    fun postTest(ctx: Context) = post(ctx, ID_TEST, CH_MANAGER, "CT Team", "Test: notifications work on this phone.")

    // ---------------------------------------------------------------- manager

    suspend fun isManagerOn(repos: Repos): Boolean = repos.db.metaDao().get(KEY_MGR) == "1"

    suspend fun setManager(ctx: Context, repos: Repos, on: Boolean) {
        val meta = repos.db.metaDao()
        meta.put(MetaEntity(KEY_MGR, if (on) "1" else "0"))
        meta.put(MetaEntity(KEY_MGR_LAST, "0,0,0"))
        val wm = WorkManager.getInstance(ctx)
        if (on) {
            ensureChannels(ctx)
            val req = PeriodicWorkRequestBuilder<ManagerCheckWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(WORK_MGR, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork(WORK_MGR)
        }
        repos.audit.event(if (on) "NOTIFY_MANAGER_ON" else "NOTIFY_MANAGER_OFF", "")
    }

    /** What the manager check found. [telegram] is -1 when it could not look (no bot, paused, or the app is already reading it). */
    class MgrCounts(val telegram: Int, val submissions: Int, val support: Int)

    suspend fun countForManager(repos: Repos): MgrCounts {
        val tg = repos.telegram.peekWaiting() ?: -1
        val subs = repos.db.submissionDao().countByStatus(SubStatus.PENDING)
        val sup = repos.db.supportDao().unreadForManager()
        return MgrCounts(tg, subs, sup)
    }

    fun managerText(c: MgrCounts): String {
        val parts = ArrayList<String>()
        if (c.submissions > 0) parts.add(c.submissions.toString() + (if (c.submissions == 1) " submission to review" else " submissions to review"))
        if (c.support > 0) parts.add(c.support.toString() + (if (c.support == 1) " new support message" else " new support messages"))
        if (c.telegram > 0) {
            val n = if (c.telegram >= PEEK_MAX) "$PEEK_MAX+" else c.telegram.toString()
            parts.add("$n new Telegram " + (if (c.telegram == 1) "message" else "messages") + " waiting")
        }
        return parts.joinToString(" · ")
    }

    /** One check: shows a notification only when something went UP since the last check (so you are not nagged every 15 minutes). */
    suspend fun runManagerCheck(ctx: Context, repos: Repos): MgrCounts? {
        val meta = repos.db.metaDao()
        if (!isManagerOn(repos)) return null
        val c = countForManager(repos)
        val last = (meta.get(KEY_MGR_LAST) ?: "0,0,0").split(",").map { it.toIntOrNull() ?: 0 }
        val lt = last.getOrElse(0) { 0 }
        val ls = last.getOrElse(1) { 0 }
        val lp = last.getOrElse(2) { 0 }
        val tgNow = if (c.telegram < 0) lt else c.telegram     // could not look: keep what we knew
        val higher = tgNow > lt || c.submissions > ls || c.support > lp
        meta.put(MetaEntity(KEY_MGR_LAST, listOf(tgNow, c.submissions, c.support).joinToString(",")))
        meta.put(MetaEntity(KEY_MGR_CHECKED, System.currentTimeMillis().toString()))
        if (higher) {
            val text = managerText(MgrCounts(tgNow, c.submissions, c.support))
            if (text.isNotEmpty()) post(ctx, ID_MANAGER, CH_MANAGER, "CT Team: waiting for you", text)
        }
        return c
    }

    // ---------------------------------------------------------------- worker

    suspend fun workerOn(repos: Repos, workerId: String): Boolean = repos.db.metaDao().get(KEY_WRK) == workerId

    suspend fun setWorker(ctx: Context, repos: Repos, workerId: String, on: Boolean) {
        val meta = repos.db.metaDao()
        meta.put(MetaEntity(KEY_WRK, if (on) workerId else ""))
        val wm = WorkManager.getInstance(ctx)
        if (on) {
            ensureChannels(ctx)
            val req = PeriodicWorkRequestBuilder<WorkerReminderWorker>(6, TimeUnit.HOURS).build()
            wm.enqueueUniquePeriodicWork(WORK_WRK, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork(WORK_WRK)
        }
        repos.audit.event(if (on) "NOTIFY_WORKER_ON" else "NOTIFY_WORKER_OFF", "")
    }

    fun workerText(n: Int): String =
        "You have $n " + (if (n == 1) "item" else "items") + " not yet sent to the manager. Open CT Team and press MAKE REPORT."

    /** At most one reminder per 20 hours, and only while something is unsent. */
    suspend fun runWorkerReminder(ctx: Context, repos: Repos) {
        val meta = repos.db.metaDao()
        val id = meta.get(KEY_WRK)
        if (id.isNullOrBlank()) return
        val n = repos.sync.unsentCount(id)
        if (n <= 0) return
        val lastAt = meta.get(KEY_WRK_AT)?.toLongOrNull() ?: 0L
        val now = System.currentTimeMillis()
        if (now - lastAt < 20L * 3600_000L) return
        meta.put(MetaEntity(KEY_WRK_AT, now.toString()))
        post(ctx, ID_WORKER, CH_WORKER, "CT Team", workerText(n))
    }
}

/** Background job on the manager phone (every ~15 minutes with internet, while the switch is on). */
class ManagerCheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            CTNotify.runManagerCheck(applicationContext, ServiceLocator.get(applicationContext))
        } catch (e: Exception) {
            // a failed check is simply tried again next time
        }
        return Result.success()
    }
}

/** Background job on the worker phone (about every 6 hours, while the switch is on). */
class WorkerReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            CTNotify.runWorkerReminder(applicationContext, ServiceLocator.get(applicationContext))
        } catch (e: Exception) {
            // tried again next time
        }
        return Result.success()
    }
}
