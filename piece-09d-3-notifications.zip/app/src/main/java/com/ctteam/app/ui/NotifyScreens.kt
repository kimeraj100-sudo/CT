package com.ctteam.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.CTNotify
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 9D-3 — screens for the notification switches: Manager > Notifications (full screen) and a small card on the worker home.
 */
private val NT_BAD = Color(0xFFFF8A8A)
private val NT_GOOD = Color(0xFF5FD6A5)

/** Asks for the Android 13+ notification permission when needed, then tells the caller whether notifications can be shown. */
@Composable
private fun rememberAskNotifyPermission(): ((Boolean) -> Unit) -> Unit {
    val ctx = LocalContext.current
    var waiting by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val cb = waiting
        waiting = null
        cb?.invoke(granted && CTNotify.canPost(ctx))
    }
    return { cb ->
        if (CTNotify.canPost(ctx)) {
            cb(true)
        } else if (Build.VERSION.SDK_INT >= 33) {
            waiting = cb
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            cb(false)
        }
    }
}

private fun openNotificationSettings(ctx: Context) {
    try {
        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        // no settings screen to open: the person can find it in the phone's app settings
    }
}

private fun openAppSettings(ctx: Context) {
    try {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        // nothing to open
    }
}

@Composable
fun ManagerNotifyScreen(repos: Repos, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ask = rememberAskNotifyPermission()
    var on by remember { mutableStateOf(false) }
    var checkedAt by remember { mutableStateOf<Long?>(null) }
    var note by remember { mutableStateOf("") }
    var noteBad by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        on = CTNotify.isManagerOn(repos)
        checkedAt = repos.db.metaDao().get(CTNotify.KEY_MGR_CHECKED)?.toLongOrNull()
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Notifications", onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Tell me when something is waiting", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "About every 15 minutes, when this phone has internet, CT Team looks at: submissions waiting for review, new support messages, " +
                    "and new messages sitting in your Telegram bot. You get ONE notification with numbers only (no names, no text). " +
                    "It only shows again when a number goes up.",
                color = CT.TextSoft, fontSize = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(if (on) "Status: ON" else "Status: OFF", color = if (on) NT_GOOD else CT.TextSoft, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            val at = checkedAt
            if (on) Text(if (at == null) "No check has run yet." else "Last check: " + fmtTime(at), color = CT.TextSoft, fontSize = 12.sp)
        }
        if (note.isNotEmpty()) Text(note, color = if (noteBad) NT_BAD else NT_GOOD, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        if (!on) {
            GoldButton(text = "TURN ON", modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy) return@GoldButton
                ask { ok ->
                    if (ok) {
                        busy = true
                        scope.launch {
                            CTNotify.setManager(ctx, repos, true)
                            on = true
                            note = "On. The first check runs within about 15 minutes."
                            noteBad = false
                            busy = false
                        }
                    } else {
                        note = "Notifications are blocked for CT Team on this phone. Use the button below to allow them, then try again."
                        noteBad = true
                    }
                }
            })
        } else {
            GhostButton(text = "TURN OFF", modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy) return@GhostButton
                busy = true
                scope.launch {
                    CTNotify.setManager(ctx, repos, false)
                    on = false
                    note = "Off."
                    noteBad = false
                    busy = false
                }
            })
            GhostButton(text = "CHECK NOW", modifier = Modifier.fillMaxWidth(), onClick = {
                if (busy) return@GhostButton
                busy = true
                scope.launch {
                    val c = CTNotify.countForManager(repos)
                    val text = CTNotify.managerText(c)
                    note = if (text.isEmpty()) "Nothing is waiting right now." else "Right now: $text"
                    noteBad = false
                    busy = false
                }
            })
        }
        GhostButton(text = "SEND A TEST NOTIFICATION", modifier = Modifier.fillMaxWidth(), onClick = {
            ask { ok ->
                if (ok) {
                    CTNotify.postTest(ctx)
                    note = "Test sent. Look at the top of the screen."
                    noteBad = false
                } else {
                    note = "Notifications are blocked for CT Team on this phone."
                    noteBad = true
                }
            }
        })
        GhostButton(text = "PHONE NOTIFICATION SETTINGS", modifier = Modifier.fillMaxWidth(), onClick = { openNotificationSettings(ctx) })
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Please know", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "• Android decides when background checks run. In battery saver, or on phones that close apps aggressively (many Tecno, Infinix, Xiaomi, Samsung), " +
                    "checks can be late or stop. Set CT Team to \"Unrestricted\" under battery, using the button below.\n" +
                    "• The check only LOOKS at your bot. It does not take the messages, so nothing is changed while you are signed out. " +
                    "Open the manager area and the app reads them as usual. Telegram keeps waiting messages for about 24 hours.\n" +
                    "• Tapping the notification opens the app; you still sign in as normal.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
        GhostButton(text = "APP SETTINGS (BATTERY)", modifier = Modifier.fillMaxWidth(), onClick = { openAppSettings(ctx) })
        Spacer(Modifier.height(8.dp))
    }
}

/** Worker home: a small card with one switch for the "you have items not yet sent" reminder. */
@Composable
fun WorkerReminderCard(repos: Repos, workerId: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ask = rememberAskNotifyPermission()
    var on by remember(workerId) { mutableStateOf(false) }
    var note by remember(workerId) { mutableStateOf("") }
    var noteBad by remember(workerId) { mutableStateOf(false) }
    LaunchedEffect(workerId) { on = CTNotify.workerOn(repos, workerId) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Reminder", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "A quiet reminder, at most once a day, when you have work or messages the manager has not received yet. It does not use internet.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(6.dp))
        if (note.isNotEmpty()) Text(note, color = if (noteBad) NT_BAD else NT_GOOD, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        if (!on) {
            GoldButton(text = "TURN ON REMINDER", modifier = Modifier.fillMaxWidth(), onClick = {
                ask { ok ->
                    if (ok) {
                        scope.launch {
                            CTNotify.setWorker(ctx, repos, workerId, true)
                            on = true
                            note = "Reminder is on."
                            noteBad = false
                        }
                    } else {
                        note = "Notifications are blocked for CT Team on this phone. Allow them in the phone's settings and try again."
                        noteBad = true
                    }
                }
            })
        } else {
            GhostButton(text = "TURN OFF REMINDER", modifier = Modifier.fillMaxWidth(), onClick = {
                scope.launch {
                    CTNotify.setWorker(ctx, repos, workerId, false)
                    on = false
                    note = "Reminder is off."
                    noteBad = false
                }
            })
        }
        GhostButton(text = "PHONE NOTIFICATION SETTINGS", modifier = Modifier.fillMaxWidth(), onClick = { openNotificationSettings(ctx) })
    }
}
