package com.ctteam.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Piece 11b — backup export. One file `.ctb` holding a copy of the whole database (`ctteam.db`), encrypted and integrity-checked.
 *
 * FILE LAYOUT (version 1):
 *   bytes 0-3    "CTBK"
 *   byte  4      format version (1)
 *   bytes 5-20   PBKDF2 salt (16)
 *   bytes 21-32  AES-GCM nonce (12)
 *   bytes 33-    AES-256-GCM(ciphertext + 16-byte tag) of:  [4-byte big-endian header length][header JSON UTF-8][database bytes]
 * Key = PBKDF2-HMAC-SHA256(passphrase, salt, 200 000 iterations, 256 bit). The header says: fmt, app (versionCode), db (Room version),
 * created (UTC millis), bytes, sha256 (of the database bytes) and counts (rows per main table). A wrong passphrase or ANY changed byte
 * makes GCM fail, so a damaged or edited file is refused; the SHA-256 is a second check after decrypting.
 * NOT in the backup: the original picture files saved from Telegram (folder `originals`), only their records.
 */
data class BackupInfo(
    val createdAt: Long,
    val appVersionCode: Int,
    val dbVersion: Int,
    val dbBytes: Int,
    val counts: List<Pair<String, Int>>
)

/** What `BackupFormat.open` returns: the readable header and the plain database bytes. */
class BackupOpened(val header: JSONObject, val db: ByteArray)

object BackupFormat {
    private val MAGIC = byteArrayOf(0x43, 0x54, 0x42, 0x4B)   // "CTBK"
    const val VERSION = 1
    const val ITERATIONS = 200_000
    const val MAX_DB_BYTES = 64 * 1024 * 1024
    const val PASS_MIN = 10
    const val PASS_MAX = 64
    private const val SALT_LEN = 16
    private const val NONCE_LEN = 12
    private const val PREFIX_LEN = 4 + 1 + SALT_LEN + NONCE_LEN
    const val FILE_EXT = ".ctb"

    fun passError(p: String): String? {
        if (p.length < PASS_MIN) return "The backup passphrase needs at least $PASS_MIN characters."
        if (p.length > PASS_MAX) return "The backup passphrase can be at most $PASS_MAX characters."
        if (!p.any { it.isLetter() } || !p.any { it.isDigit() }) return "Use letters and at least one digit in the backup passphrase."
        return null
    }

    fun sha256Hex(b: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private fun key(pass: String, salt: ByteArray): SecretKeySpec {
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pass.toCharArray(), salt, ITERATIONS, 256)).encoded
        return SecretKeySpec(raw, "AES")
    }

    fun seal(dbBytes: ByteArray, headerJson: String, pass: String): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { rnd.nextBytes(it) }
        val nonce = ByteArray(NONCE_LEN).also { rnd.nextBytes(it) }
        val h = headerJson.toByteArray(Charsets.UTF_8)
        val plain = ByteArray(4 + h.size + dbBytes.size)
        plain[0] = (h.size ushr 24).toByte(); plain[1] = (h.size ushr 16).toByte()
        plain[2] = (h.size ushr 8).toByte(); plain[3] = h.size.toByte()
        System.arraycopy(h, 0, plain, 4, h.size)
        System.arraycopy(dbBytes, 0, plain, 4 + h.size, dbBytes.size)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pass, salt), GCMParameterSpec(128, nonce))
        c.updateAAD(MAGIC)
        val enc = c.doFinal(plain)
        val out = ByteArray(PREFIX_LEN + enc.size)
        System.arraycopy(MAGIC, 0, out, 0, 4)
        out[4] = VERSION.toByte()
        System.arraycopy(salt, 0, out, 5, SALT_LEN)
        System.arraycopy(nonce, 0, out, 5 + SALT_LEN, NONCE_LEN)
        System.arraycopy(enc, 0, out, PREFIX_LEN, enc.size)
        return out
    }

    fun open(file: ByteArray, pass: String): Outcome<BackupOpened> {
        if (file.size < PREFIX_LEN + 16 + 4) return Outcome.Err("This is not a CT Team backup file (too small).")
        for (i in 0 until 4) if (file[i] != MAGIC[i]) return Outcome.Err("This is not a CT Team backup file.")
        val ver = file[4].toInt()
        if (ver > VERSION) return Outcome.Err("This backup was made by a newer version of the app. Update the app first.")
        if (ver < 1) return Outcome.Err("This is not a CT Team backup file.")
        val salt = file.copyOfRange(5, 5 + SALT_LEN)
        val nonce = file.copyOfRange(5 + SALT_LEN, PREFIX_LEN)
        val plain: ByteArray = try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(pass, salt), GCMParameterSpec(128, nonce))
            c.updateAAD(MAGIC)
            c.doFinal(file, PREFIX_LEN, file.size - PREFIX_LEN)
        } catch (e: Exception) {
            return Outcome.Err("Wrong passphrase, or the file is damaged or was changed. Nothing was read from it.")
        }
        if (plain.size < 4) return Outcome.Err("The backup is damaged.")
        val hl = ((plain[0].toInt() and 0xFF) shl 24) or ((plain[1].toInt() and 0xFF) shl 16) or
            ((plain[2].toInt() and 0xFF) shl 8) or (plain[3].toInt() and 0xFF)
        if (hl <= 0 || hl > 100_000 || 4 + hl > plain.size) return Outcome.Err("The backup is damaged (header).")
        val header = try {
            JSONObject(String(plain, 4, hl, Charsets.UTF_8))
        } catch (e: Exception) {
            return Outcome.Err("The backup is damaged (header).")
        }
        val db = plain.copyOfRange(4 + hl, plain.size)
        if (header.optString("sha256") != sha256Hex(db) || header.optInt("bytes", -1) != db.size) {
            return Outcome.Err("The backup failed its integrity check (SHA-256 does not match).")
        }
        return Outcome.Ok(BackupOpened(header, db))
    }

    fun infoOf(h: JSONObject): BackupInfo {
        val cs = ArrayList<Pair<String, Int>>()
        val arr: JSONArray? = h.optJSONArray("counts")
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            cs.add(o.optString("t") to o.optInt("n"))
        }
        return BackupInfo(h.optLong("created"), h.optInt("app"), h.optInt("db"), h.optInt("bytes"), cs)
    }
}

class BackupRepository(private val db: CTDatabase, private val audit: AuditRepository) {

    companion object {
        const val K_LAST_AT = "backup:lastAt"
        const val K_LAST_BYTES = "backup:lastBytes"
        private val COUNT_TABLES = listOf(
            "workers", "tasks", "submissions", "payout_requests", "payments",
            "nc_rows", "nc_claims", "manager_accounts", "audit_log"
        )

        /** Reads a stream fully, refusing anything above the size limit. */
        fun readLimited(input: InputStream, limit: Int): ByteArray? {
            val buf = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(64 * 1024)
            var total = 0
            while (true) {
                val n = input.read(chunk)
                if (n < 0) break
                total += n
                if (total > limit) return null
                buf.write(chunk, 0, n)
            }
            return buf.toByteArray()
        }
    }

    private fun now() = System.currentTimeMillis()

    private class Inspect(val version: Int, val ok: Boolean, val counts: List<Pair<String, Int>>)

    /** Opens a COPY of a database file, runs SQLite's own integrity check and counts the main tables. The copy is deleted afterwards. */
    private fun inspect(context: Context, bytes: ByteArray): Inspect? {
        val tmp = File(context.cacheDir, "ctb-inspect-" + now() + ".db")
        try {
            tmp.writeBytes(bytes)
            val d = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                var ok = false
                d.rawQuery("PRAGMA integrity_check", null).use { c -> if (c.moveToFirst()) ok = c.getString(0) == "ok" }
                val counts = ArrayList<Pair<String, Int>>()
                for (t in COUNT_TABLES) {
                    try {
                        d.rawQuery("SELECT COUNT(*) FROM $t", null).use { c -> if (c.moveToFirst()) counts.add(t to c.getInt(0)) }
                    } catch (e: Exception) {
                        // table not in this (older) database: leave it out
                    }
                }
                return Inspect(d.version, ok, counts)
            } finally {
                d.close()
            }
        } catch (e: Exception) {
            return null
        } finally {
            tmp.delete(); File(tmp.path + "-wal").delete(); File(tmp.path + "-shm").delete(); File(tmp.path + "-journal").delete()
        }
    }

    suspend fun lastBackupAt(): Long? = db.metaDao().get(K_LAST_AT)?.toLongOrNull()

    /** Makes the backup and writes it to `out`. Only the caller checks that the manager is the main manager. */
    suspend fun export(context: Context, passphrase: String, out: OutputStream, actor: String): Outcome<BackupInfo> =
        withContext(Dispatchers.IO) {
            BackupFormat.passError(passphrase)?.let { return@withContext Outcome.Err(it) }
            try {
                // move everything waiting in the write-ahead log into the main file, then copy that file
                db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").use { it.moveToFirst() }
                val f = context.getDatabasePath(CTDatabase.NAME)
                if (!f.exists()) return@withContext Outcome.Err("The database file was not found.")
                if (f.length() > BackupFormat.MAX_DB_BYTES) return@withContext Outcome.Err("The database is larger than the backup limit of 64 MB.")
                val bytes = f.readBytes()
                val ins = inspect(context, bytes) ?: return@withContext Outcome.Err("The copy of the database could not be opened. Nothing was saved.")
                if (!ins.ok) return@withContext Outcome.Err("The database copy did not pass SQLite's own check. Nothing was saved.")
                val created = now()
                val appCode = try {
                    PackageInfoCompat.getLongVersionCode(context.packageManager.getPackageInfo(context.packageName, 0)).toInt()
                } catch (e: Exception) {
                    0
                }
                val counts = JSONArray()
                for ((t, n) in ins.counts) counts.put(JSONObject().put("t", t).put("n", n))
                val header = JSONObject()
                    .put("fmt", BackupFormat.VERSION).put("app", appCode).put("db", ins.version)
                    .put("created", created).put("bytes", bytes.size).put("sha256", BackupFormat.sha256Hex(bytes))
                    .put("counts", counts)
                val file = BackupFormat.seal(bytes, header.toString(), passphrase)
                out.write(file)
                out.flush()
                db.metaDao().put(MetaEntity(K_LAST_AT, created.toString()))
                db.metaDao().put(MetaEntity(K_LAST_BYTES, file.size.toString()))
                audit.log(actor, "BACKUP_EXPORTED", "backup", "db", "size=" + file.size + " db=" + ins.version, created)
                Outcome.Ok(BackupFormat.infoOf(header))
            } catch (e: Exception) {
                Outcome.Err("The backup could not be made: " + (e.message ?: e.javaClass.simpleName))
            }
        }

    /** Reads a backup file and checks it completely (passphrase, GCM tag, SHA-256, SQLite integrity) WITHOUT changing anything. */
    suspend fun check(context: Context, file: ByteArray, passphrase: String): Outcome<BackupInfo> =
        withContext(Dispatchers.IO) {
            when (val o = BackupFormat.open(file, passphrase)) {
                is Outcome.Err -> Outcome.Err(o.message)
                is Outcome.Ok -> {
                    val ins = inspect(context, o.value.db)
                    if (ins == null || !ins.ok) Outcome.Err("The file decrypts, but the database inside does not pass SQLite's check.")
                    else Outcome.Ok(BackupFormat.infoOf(o.value.header))
                }
            }
        }
}
