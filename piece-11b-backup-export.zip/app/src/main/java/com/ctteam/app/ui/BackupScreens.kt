package com.ctteam.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.BackupFormat
import com.ctteam.app.data.BackupInfo
import com.ctteam.app.data.BackupRepository
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Piece 11b — Manager > Backup (main manager only). CREATE BACKUP writes one encrypted `.ctb` file through the phone's file picker
 * (phone storage, SD card, Google Drive, any app that offers a save location). CHECK A BACKUP FILE opens a file and verifies it completely
 * without changing anything. Restoring comes in Piece 11c.
 */
private val BK_GOOD = Color(0xFF5FD6A5)
private val BK_BAD = Color(0xFFFF8A8A)

private fun bkStamp(): String = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())

private fun bkInfoText(i: BackupInfo): String {
    val sb = StringBuilder()
    sb.append("Made ").append(fmtTime(i.createdAt)).append(" (East Africa Time)\n")
    sb.append("App build ").append(i.appVersionCode).append(", database version ").append(i.dbVersion).append(", ")
    sb.append(i.dbBytes / 1024).append(" KB\n")
    if (i.counts.isNotEmpty()) sb.append(i.counts.joinToString(", ") { it.first.replace('_', ' ') + " " + it.second })
    return sb.toString().trim()
}

@Composable
fun ManagerBackupScreen(repos: Repos, actor: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val backup = remember(repos) { BackupRepository(repos.db, repos.audit) }

    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var checkPass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(true) }
    var last by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(Unit) { last = backup.lastBackupAt() }

    fun say(ok: Boolean, text: String) { good = ok; message = text }

    val createLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val stream = try { context.contentResolver.openOutputStream(uri, "w") } catch (e: Exception) { null }
                if (stream == null) {
                    say(false, "The phone would not open that place for writing. Choose another place.")
                } else {
                    val r = try {
                        stream.use { backup.export(context, pass, it, actor) }
                    } catch (e: Exception) {
                        Outcome.Err("The file could not be written: " + (e.message ?: ""))
                    }
                    when (r) {
                        is Outcome.Ok -> {
                            say(true, "Backup saved.\n" + bkInfoText(r.value) + "\n\nNow use CHECK A BACKUP FILE on it once, and keep the passphrase safe: without it the file cannot be opened by anyone.")
                            last = backup.lastBackupAt()
                            pass = ""; pass2 = ""
                        }
                        is Outcome.Err -> say(false, r.message)
                    }
                }
                busy = false
            }
        }
    }

    val checkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val bytes = try {
                    context.contentResolver.openInputStream(uri)?.use { BackupRepository.readLimited(it, BackupFormat.MAX_DB_BYTES + 1_000_000) }
                } catch (e: Exception) {
                    null
                }
                if (bytes == null) {
                    say(false, "The file could not be read, or it is larger than the backup limit.")
                } else {
                    when (val r = backup.check(context, bytes, checkPass)) {
                        is Outcome.Ok -> say(true, "✓ This backup is complete and can be restored.\n" + bkInfoText(r.value))
                        is Outcome.Err -> say(false, r.message)
                    }
                }
                busy = false
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Backup", onBack)

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Last backup", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            val l = last
            Text(
                if (l == null) "No backup made on this phone yet." else fmtTime(l) + " (East Africa Time)",
                color = if (l == null) BK_BAD else Color.White, fontSize = 14.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "A backup holds everything in the app's database: workers, tasks, submissions, payouts, NC Wallet rows, team mining, lessons, " +
                    "manager accounts and the sync keys. It is encrypted with a passphrase you choose and checked for damage. " +
                    "The original pictures saved from Telegram are not inside it, only their records.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Create a backup", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            CTField(pass, { pass = it }, "Backup passphrase (10+ characters, letters and a digit)", secret = true)
            CTField(pass2, { pass2 = it }, "Repeat the passphrase", secret = true)
            Text(
                "Write the passphrase down somewhere safe. There is NO way to recover a backup if it is lost, and the app never stores it.",
                color = BK_BAD, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            GoldButton(text = if (busy) "WORKING…" else "CREATE BACKUP", modifier = Modifier.fillMaxWidth(), onClick = {
                val e = BackupFormat.passError(pass)
                when {
                    busy -> {}
                    e != null -> say(false, e)
                    pass != pass2 -> say(false, "The two passphrases are not the same.")
                    else -> { message = ""; createLauncher.launch("ctteam-backup-" + bkStamp() + BackupFormat.FILE_EXT) }
                }
            })
            Text("You choose where it is saved: phone storage, SD card or Google Drive.", color = CT.TextSoft, fontSize = 11.sp)
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Check a backup file", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Opens the file, checks the passphrase, the encryption seal, the fingerprint and the database inside. Nothing on this phone is changed.", color = CT.TextSoft, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            CTField(checkPass, { checkPass = it }, "Passphrase of that backup", secret = true)
            Spacer(Modifier.height(6.dp))
            GhostButton(text = if (busy) "WORKING…" else "CHECK A BACKUP FILE", modifier = Modifier.fillMaxWidth(), onClick = {
                if (!busy) {
                    if (checkPass.isEmpty()) say(false, "Type the passphrase first.") else { message = ""; checkLauncher.launch(arrayOf("*/*")) }
                }
            })
        }

        if (message.isNotEmpty()) Text(message, color = if (good) BK_GOOD else BK_BAD, fontSize = 13.sp)
        GhostButton(text = "BACK", onClick = onBack, modifier = Modifier.fillMaxWidth())
    }
}
