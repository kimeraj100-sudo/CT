package com.ctteam.app.data

import android.util.Base64
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/*
 * PIECE 5A — SYNC CORE (5B adds worker reports; 5C adds manager updates; 5D adds usernames, reset codes and JOIN codes) (no server: messages travel as text or a small file by copy/paste, share, Telegram, etc.)
 *
 * Wire format of every message ("envelope"), one line of text with no spaces:
 *     CT1.<base64url(JSON header+body)>.<HMAC-SHA256 hex of "CT1.<base64url>">
 * JSON header: v (1), t (type), w (worker id), d (direction W2M worker->manager / M2W manager->worker),
 *              s (sequence number, per worker + direction), ts (sender clock, UTC millis), b (body object).
 * The HMAC key is a 32-byte per-worker secret created on the worker's phone. The manager's phone learns it
 * once, in the ENROLL message, which the manager must approve by hand (compare the key check code by voice).
 *
 * HONEST LIMITS: the enrollment message carries the key, so it must travel on a private channel (a direct
 * message to the manager, not a group). HMAC proves a message came from someone holding the worker's key and was
 * not changed; it cannot prove who holds the phone. Keys are stored inside the app's private database (not in the
 * Android Keystore) and must be covered by the encrypted backup of Piece 11.
 */

// ------------------------------------------------------------------ TABLES

@Entity(tableName = "sync_keys")
data class SyncKeyEntity(
    @PrimaryKey val workerId: String,
    val keyHex: String,           // 64 hex chars = 32 random bytes
    val createdAt: Long
)

/** Every accepted message (worker, direction, seq). The primary key makes a second copy impossible to accept. */
@Entity(tableName = "sync_seen", primaryKeys = ["workerId", "direction", "seq"])
data class SyncSeenEntity(
    val workerId: String,
    val direction: String,
    val seq: Long,
    val type: String,
    val receivedAt: Long
)

/**
 * Piece 5B (worker phone): every item that went into a report gets a fixed message number the first time.
 * Making the same report again gives the SAME numbers, so a lost or repeated message is harmless.
 */
@Entity(tableName = "sync_outbox")
data class SyncOutboxEntity(
    @PrimaryKey val itemKey: String,   // SUB:<id>, PAY:<id>, PHN:<workerId>:<historyId>
    val workerId: String,
    val type: String,
    val seq: Long,
    val madeAt: Long
)

/** Piece 5D (manager phone): which username each connected worker uses, so two workers can never share one. Stored lowercase. */
@Entity(tableName = "worker_usernames")
data class WorkerUsernameEntity(
    @PrimaryKey val username: String,
    val workerId: String
)

@Dao
interface SyncDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putKey(k: SyncKeyEntity): Long
    @Query("SELECT * FROM sync_keys WHERE workerId = :w") suspend fun key(w: String): SyncKeyEntity?
    @Query("SELECT * FROM sync_keys ORDER BY createdAt DESC") fun observeKeys(): Flow<List<SyncKeyEntity>>
    @Query("DELETE FROM sync_keys WHERE workerId = :w") suspend fun deleteKey(w: String)

    /** Returns -1 when this (worker, direction, seq) was already accepted. */
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun markSeen(s: SyncSeenEntity): Long
    @Query("SELECT COALESCE(MAX(seq), 0) FROM sync_seen WHERE workerId = :w AND direction = :d")
    suspend fun maxSeen(w: String, d: String): Long
    @Query("SELECT COUNT(*) FROM sync_seen WHERE workerId = :w AND direction = :d")
    suspend fun seenCount(w: String, d: String): Int
    @Query("DELETE FROM sync_seen WHERE workerId = :w") suspend fun deleteSeen(w: String)

    // ---- Piece 5B
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putOutbox(o: SyncOutboxEntity): Long
    @Query("SELECT * FROM sync_outbox WHERE workerId = :w") suspend fun outboxOf(w: String): List<SyncOutboxEntity>
    @Query("DELETE FROM sync_outbox WHERE workerId = :w AND itemKey IN (:keys)") suspend fun deleteOutboxKeys(w: String, keys: List<String>)
    @Query("SELECT COUNT(*) FROM sync_seen WHERE workerId = :w AND direction = :d AND seq = :s")
    suspend fun seenCountOf(w: String, d: String, s: Long): Int
    @Query("SELECT * FROM submissions WHERE workerId = :w ORDER BY submittedAt ASC") suspend fun submissionsOf(w: String): List<SubmissionEntity>
    @Query("SELECT * FROM payout_requests WHERE workerId = :w ORDER BY requestedAt ASC") suspend fun payoutsOf(w: String): List<PayoutRequestEntity>
    @Query("SELECT id FROM submissions WHERE payoutId = :p ORDER BY submittedAt ASC") suspend fun subIdsOfPayout(p: String): List<String>
    @Query("SELECT * FROM submissions WHERE id IN (:ids)") suspend fun subsByIds(ids: List<String>): List<SubmissionEntity>
    @Query("UPDATE submissions SET payoutId = :p WHERE id IN (:ids)") suspend fun attachIds(p: String, ids: List<String>)
    @Query("SELECT * FROM task_versions WHERE taskId = :t AND version = :v LIMIT 1") suspend fun taskVersion(t: String, v: Int): TaskVersionEntity?

    // ---- Piece 5D
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putUsername(u: WorkerUsernameEntity)
    @Query("SELECT * FROM worker_usernames WHERE username = :u LIMIT 1") suspend fun usernameOwner(u: String): WorkerUsernameEntity?
    @Query("DELETE FROM worker_usernames WHERE workerId = :w") suspend fun deleteUsernamesOf(w: String)

    // ---- Piece 5C (manager phone builds updates)
    @Query("SELECT * FROM tasks ORDER BY createdAt ASC") suspend fun allTasks(): List<TaskEntity>
    @Query("SELECT * FROM submissions WHERE workerId = :w AND status != 'PENDING' AND decidedAt IS NOT NULL ORDER BY decidedAt ASC")
    suspend fun decidedOf(w: String): List<SubmissionEntity>
    @Query("SELECT * FROM payout_requests WHERE workerId = :w AND status = 'PAID' ORDER BY paidAt ASC")
    suspend fun paidOf(w: String): List<PayoutRequestEntity>
    @Query("SELECT COUNT(*) FROM audit_log WHERE entityType = 'worker' AND entityId = :w AND action IN ('WORKER_ENABLED','WORKER_DISABLED')")
    suspend fun stateChanges(w: String): Int
    // Piece 8D: how many times the manager changed the match of one NC claim (used as a version number)
    @Query("SELECT COUNT(*) FROM audit_log WHERE entityType = 'nc_claim' AND entityId = :uid AND action IN ('NC_MATCH_CONFIRMED','NC_MANUAL_LINK','NC_UNLINKED')")
    suspend fun ncChanges(uid: String): Int

    // Linking a manager-added worker to the worker's own id (same National ID, different id).
    @Query("UPDATE workers SET id = :newId WHERE id = :oldId") suspend fun relinkWorkerRow(oldId: String, newId: String)
    @Query("UPDATE phone_history SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkPhoneHistory(oldId: String, newId: String)
    @Query("UPDATE submissions SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkSubmissions(oldId: String, newId: String)
    @Query("UPDATE payout_requests SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkPayouts(oldId: String, newId: String)
    @Query("UPDATE nc_claims SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkClaims(oldId: String, newId: String)
    @Query("UPDATE support_messages SET workerId = :newId WHERE workerId = :oldId") suspend fun relinkSupport(oldId: String, newId: String)
}

// ------------------------------------------------------------------ CODEC (pure, no database)

class Envelope(
    val signed: String,           // "CT1.<base64url>" — exactly what the HMAC covers
    val mac: String,
    val type: String,
    val workerId: String,
    val direction: String,
    val seq: Long,
    val ts: Long,
    val body: JSONObject
) {
    /** The message exactly as it travels (used to hand a single message back to the repository). */
    val wire: String get() = "$signed.$mac"
}

object SyncCodec {
    const val PREFIX = "CT1"
    const val W2M = "W2M"
    const val M2W = "M2W"

    private val rnd = SecureRandom()
    private val FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    private val WRAPPED = Regex("CT1\\.([A-Za-z0-9_\\-\\s]+)\\.((?:[0-9a-fA-F]\\s*){64})")

    fun newKeyHex(): String {
        val b = ByteArray(32)
        rnd.nextBytes(b)
        return toHex(b)
    }

    fun toHex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) {
            val v = x.toInt() and 0xff
            sb.append("0123456789abcdef"[v shr 4]).append("0123456789abcdef"[v and 0x0f])
        }
        return sb.toString()
    }

    fun fromHex(s: String): ByteArray? {
        if (s.isEmpty() || s.length % 2 != 0) return null
        return try {
            ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        } catch (ex: NumberFormatException) {
            null
        }
    }

    fun isKeyHex(s: String): Boolean = s.length == 64 && s.all { it in '0'..'9' || it in 'a'..'f' }

    fun hmacHex(keyHex: String, message: String): String {
        val key = fromHex(keyHex) ?: throw IllegalArgumentException("bad key")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return toHex(mac.doFinal(message.toByteArray(Charsets.UTF_8)))
    }

    /** Short code both phones can show and read aloud (e.g. 7F3-A92) to check they hold the same key. */
    fun keyCheck(keyHex: String): String {
        val h = Hashing.sha256Hex("CTKEY|$keyHex").take(6).uppercase()
        return h.substring(0, 3) + "-" + h.substring(3)
    }

    fun seal(keyHex: String, type: String, workerId: String, direction: String, seq: Long, ts: Long, body: JSONObject): String {
        val header = JSONObject()
            .put("v", 1).put("t", type).put("w", workerId).put("d", direction)
            .put("s", seq).put("ts", ts).put("b", body)
        val b64 = Base64.encodeToString(header.toString().toByteArray(Charsets.UTF_8), FLAGS)
        val signed = "$PREFIX.$b64"
        return signed + "." + hmacHex(keyHex, signed)
    }

    /**
     * Finds EVERY CT1 message inside pasted text (chat apps add spaces, line breaks and extra words; a manager may
     * paste many messages at once). Does NOT check signatures — call [verify] with the right key afterwards.
     */
    fun parseAll(text: String): List<Envelope> = WRAPPED.findAll(text).mapNotNull { readMatch(it) }.toList()

    fun parse(text: String): Envelope? = parseAll(text).firstOrNull()

    private fun readMatch(m: kotlin.text.MatchResult): Envelope? {
        val b64 = m.groupValues[1].filter { !it.isWhitespace() }
        val mac = m.groupValues[2].filter { !it.isWhitespace() }.lowercase()
        if (b64.isEmpty() || mac.length != 64) return null
        return try {
            val json = JSONObject(String(Base64.decode(b64, FLAGS), Charsets.UTF_8))
            if (json.optInt("v", 0) != 1) return null
            val type = json.optString("t")
            val worker = json.optString("w")
            val dir = json.optString("d")
            if (type.isBlank() || worker.isBlank() || (dir != W2M && dir != M2W)) return null
            Envelope(
                signed = "$PREFIX.$b64", mac = mac, type = type, workerId = worker, direction = dir,
                seq = json.getLong("s"), ts = json.optLong("ts", 0L), body = json.optJSONObject("b") ?: JSONObject()
            )
        } catch (ex: Exception) {
            null
        }
    }

    fun verify(keyHex: String, env: Envelope): Boolean = try {
        MessageDigest.isEqual(hmacHex(keyHex, env.signed).toByteArray(Charsets.UTF_8), env.mac.toByteArray(Charsets.UTF_8))
    } catch (ex: Exception) {
        false
    }
}

// ------------------------------------------------------------------ RESULTS

/** What the manager sees before approving a worker's enrollment message. */
class EnrollPreview(
    val workerId: String,
    val fullName: String,
    val nationalId: String,
    val phoneLocal: String,
    val network: String,
    val keyCheck: String,
    val mode: String,             // NEW, LINK (existing manager-added worker, same National ID), ATTACH, ALREADY
    val problem: String?,         // blocks approval
    val warning: String?
)

sealed class SyncIncoming {
    class Enroll(val preview: EnrollPreview, val wire: String) : SyncIncoming()

    /** A worker asked for a reset code. [checkCode] is shown on both phones; the manager approves with one tap. */
    class ResetRequest(val workerId: String, val workerName: String, val checkCode: String, val wire: String, val madeAt: Long) : SyncIncoming()

    /**
     * [retryWire] is set when the message was NOT used only because the worker is not connected yet; the screen
     * can run it again after the enrollment is approved. [imported] is true when something new landed (Review / payouts / number).
     */
    class Done(
        val ok: Boolean, val title: String, val detail: String,
        val retryWire: String? = null, val imported: Boolean = false
    ) : SyncIncoming()
}

class SyncStatus(val keyCheck: String, val lastSeq: Long, val received: Int)

/** What a worker sees before joining on a new phone with a manager-made JOIN code. */
class JoinPreview(
    val workerId: String, val fullName: String, val phoneLocal: String, val network: String,
    val keyCheck: String, val problem: String?
)

/** One message-sized piece of a worker report (chat apps cut very long texts, so a report is split into parts). */
class ReportPart(val text: String, val messages: Int)

class ReportResult(
    val parts: List<ReportPart>,
    val total: Int,          // messages in this report
    val newCount: Int,       // of those, how many had never been in a report before
    val fullText: String,    // every part in one text (for SAVE AS FILE)
    /** Piece 9B: what a manager update used up, so a send that failed completely can be taken back ([SyncRepository.rollbackUpdate]). */
    val counterBefore: Long = 0L,
    val newKeys: List<String> = emptyList()
)

/** Result of applying one verified message on the manager phone. [consume] = remember its number so it is not accepted again. */
/** 9B-3: one announcement from the manager, as kept on the worker phone. */
class WorkerNotice(val id: String, val text: String, val at: Long)

/** 9D-2: a signed reply made for one worker. [uid] is the shared message id; save it with saveSupportReply once it was really sent. */
class SupportReplyMade(val code: String, val seq: Long, val uid: String)

private class Applied(val ok: Boolean, val title: String, val detail: String, val consume: Boolean = true, val imported: Boolean = false)

private class ReportItem(val key: String, val type: String, val at: Long, val body: JSONObject)

// ------------------------------------------------------------------ REPOSITORY

class SyncRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.syncDao()
    private val meta = db.metaDao()

    companion object {
        const val TYPE_ENROLL = "ENROLL"
        const val TYPE_PING = "PING"
        // Piece 5B: worker -> manager reports
        const val TYPE_SUBMISSION = "SUBMISSION"
        const val TYPE_PAYOUT = "PAYOUT_REQ"
        const val TYPE_PHONE = "PHONE_CHANGE"
        const val TYPE_USERNAME = "USERNAME"      // 5D: worker -> manager
        const val TYPE_SUPPORT = "SUPPORT"        // 9D-2: worker -> manager, a question or message (rides in the normal report)
        const val TYPE_NC_CLAIM = "NC_CLAIM"      // 8C: worker -> manager, "I deposited this amount into NC Wallet at this time"
        const val TYPE_RESET_REQ = "RESET_REQ"    // 5D+: worker -> manager, "please make me a reset code" (one tap)
        const val TYPE_RESET = "RESET"            // 5D: manager -> worker, one-time "forgot password/PIN" code
        const val TYPE_JOIN = "JOIN"              // 5D: manager -> worker, move a worker to a new phone

        /** Message types this app version can process on the manager phone. */
        val MANAGER_TYPES = setOf(TYPE_PING, TYPE_SUBMISSION, TYPE_PAYOUT, TYPE_PHONE, TYPE_USERNAME, TYPE_NC_CLAIM, TYPE_SUPPORT)

        // Piece 5C: manager -> worker updates
        const val TYPE_TASK = "TASK"
        const val TYPE_DECISION = "DECISION"
        const val TYPE_PAID = "PAYOUT_PAID"
        const val TYPE_STATE = "WORKER_STATE"
        const val TYPE_NC_VERIFIED = "NC_VERIFIED"   // 8D: manager -> worker, status of one NC Wallet claim (matched / manual / unlinked)
        const val TYPE_SUPPORT_REPLY = "SUPPORT_REPLY"  // 9D-2: manager -> worker, the answer to the worker's messages
        const val TYPE_NOTICE = "NOTICE"             // 9B-3: manager -> worker, a short announcement
        const val TYPE_LEARN = "LEARN"               // 10B: manager -> worker, one Learn & Earn lesson (or "take it back")
        const val LEARN_TITLE_MAX = 80
        const val LEARN_BODY_MAX = 3000
        const val NOTICE_MAX = 600
        const val TYPE_TEAM_VIEW = "TEAM_VIEW"       // T2a: manager -> worker, the worker's team mining figures (estimates)
        /** Message types the worker phone can process. */
        val WORKER_TYPES = setOf(TYPE_TASK, TYPE_DECISION, TYPE_PAID, TYPE_STATE, TYPE_NC_VERIFIED, TYPE_TEAM_VIEW, TYPE_NOTICE, TYPE_SUPPORT_REPLY, TYPE_LEARN)

        // report choices
        const val SCOPE_NEW = "NEW"
        const val SCOPE_THIS_WEEK = "THIS_WEEK"
        const val SCOPE_LAST_WEEK = "LAST_WEEK"
        const val SCOPE_ALL = "ALL"

        private val ID_RULE = Regex("^[A-Za-z0-9\\-]{8,64}$")
        private val SHA_RULE = Regex("^[0-9a-f]{64}$")
        private val DHASH_RULE = Regex("^[0-9a-fA-F]{8,64}$")
        private val SCREEN_RULE = Regex("^[0-9]{3,5}x[0-9]{3,5}$")
        private val DATE_RULE = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
        private val WAS_RULE = Regex("was ([0-9]{12})")
        private val USERNAME_RULE = Regex("^[a-z0-9._]{4,20}$")
        private const val CODE_VALID_MS = 3L * 24 * 60 * 60 * 1000   // reset / join codes: 3 days (phone clocks differ)
        private const val REQUEST_VALID_MS = 24L * 60 * 60 * 1000   // a reset request is answered within a day
        private const val PART_LIMIT = 3500                 // characters per part (chat apps cut ~4000)
        private const val MAX_PROOFS = 10
        private const val MAX_PAYOUT_SUBS = 500
        private const val FUTURE_TOLERANCE_MS = 10L * 60 * 1000
        private val NOTE_TIME: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm", Locale.US).withZone(TimeUtil.EAT)
    }

    private fun now() = System.currentTimeMillis()
    private fun stamp(ms: Long) = NOTE_TIME.format(java.time.Instant.ofEpochMilli(ms)) + " EAT"

    /** Trims, drops control characters, caps the length. Everything a worker sends is treated as untrusted text. */
    private fun clean(s: String, max: Int): String = s.filter { it == '\n' || !it.isISOControl() }.trim().take(max)

    // ---------------------------------------------------------------- keys + counters

    /** The worker phone creates its secret the first time it is needed. */
    suspend fun ensureKey(workerId: String): SyncKeyEntity = db.withTransaction {
        dao.key(workerId) ?: SyncKeyEntity(workerId, SyncCodec.newKeyHex(), now()).also { dao.putKey(it) }
    }

    suspend fun keyOf(workerId: String): SyncKeyEntity? = dao.key(workerId)

    fun observeKeys(): Flow<List<SyncKeyEntity>> = dao.observeKeys()

    suspend fun nextSeq(workerId: String, direction: String): Long = db.withTransaction {
        val k = "sync:out:$direction:$workerId"
        val n = (meta.get(k)?.toLongOrNull() ?: 0L) + 1L
        meta.put(MetaEntity(k, n.toString()))
        n
    }

    suspend fun status(workerId: String): SyncStatus? {
        val k = dao.key(workerId) ?: return null
        return SyncStatus(
            keyCheck = SyncCodec.keyCheck(k.keyHex),
            lastSeq = dao.maxSeen(workerId, SyncCodec.W2M),
            received = dao.seenCount(workerId, SyncCodec.W2M)
        )
    }

    // ---------------------------------------------------------------- worker phone: create messages

    /** The one-time enrollment message: who I am + my secret key. Same text every time (seq 0), safe to send again. */
    suspend fun makeEnrollment(workerId: String): Outcome<String> {
        val w = db.workerDao().get(workerId) ?: return Outcome.Err("Worker not found.")
        val k = ensureKey(workerId)
        val body = JSONObject()
            .put("nin", w.nationalId).put("fn", w.firstName).put("mn", w.middleName).put("ln", w.lastName)
            .put("ph", w.phone).put("nw", w.network).put("ca", w.createdAt).put("k", k.keyHex)
            .putOpt("un", db.securityDao().workerCred(workerId)?.username)
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_ENROLL, workerId, SyncCodec.W2M, 0L, w.createdAt, body))
    }

    /** A small signed test message so worker and manager can check the whole path works. */
    suspend fun makeTest(workerId: String, note: String): Outcome<String> {
        if (db.workerDao().get(workerId) == null) return Outcome.Err("Worker not found.")
        val k = ensureKey(workerId)
        val seq = nextSeq(workerId, SyncCodec.W2M)
        val body = JSONObject().put("note", note.trim().take(200))
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_PING, workerId, SyncCodec.W2M, seq, now(), body))
    }

    fun keyCheckOf(keyHex: String): String = SyncCodec.keyCheck(keyHex)

    // ---------------------------------------------------------------- worker phone: reports (Piece 5B)

    private suspend fun collectItems(workerId: String, device: String): List<ReportItem> {
        val out = ArrayList<ReportItem>()
        val screen = if (SCREEN_RULE.matches(device)) device else null

        for (s in dao.submissionsOf(workerId)) {
            val proofs = db.submissionDao().proofsFor(s.id)
            val arr = JSONArray()
            for (p in proofs) {
                arr.put(
                    JSONObject().put("k", p.kind)
                        .putOpt("h", p.sha256).putOpt("dh", p.dhash)
                        .putOpt("fn", p.fileName).putOpt("sz", p.fileSize)
                        .putOpt("w", p.width).putOpt("ht", p.height)
                        .putOpt("fm", p.fileModifiedAt).putOpt("mt", p.mime)
                        .putOpt("tg", p.metadataTags).putOpt("tx", p.textValue)
                )
            }
            val body = JSONObject()
                .put("id", s.id).put("tid", s.taskId).put("tv", s.taskVersion)
                .put("tn", db.taskDao().get(s.taskId)?.name ?: "")
                .put("at", s.submittedAt).put("pay", s.payUgx).put("ws", s.seq)
                .put("ref", s.referenceText.take(500)).put("ex", s.explanation.take(2000))
                .putOpt("ds", screen).put("pr", arr)
            out.add(ReportItem("SUB:" + s.id, TYPE_SUBMISSION, s.submittedAt, body))
        }

        for (p in dao.payoutsOf(workerId)) {
            val ids = JSONArray()
            for (id in dao.subIdsOfPayout(p.id)) ids.put(id)
            val body = JSONObject()
                .put("id", p.id).put("wk", p.weekKey).put("amt", p.amountUgx)
                .put("ph", p.phone).put("nw", p.network).put("at", p.requestedAt).put("subs", ids)
            out.add(ReportItem("PAY:" + p.id, TYPE_PAYOUT, p.requestedAt, body))
        }

        for (h in db.workerDao().phoneHistory(workerId)) {
            if (!h.reason.startsWith("CHANGE")) continue   // the registration number travels in the enrollment message
            val prev = WAS_RULE.find(h.reason)?.groupValues?.get(1)
            val body = JSONObject().put("ph", h.phone).put("nw", h.network).put("at", h.changedAt).putOpt("prev", prev)
            out.add(ReportItem("PHN:" + workerId + ":" + h.id, TYPE_PHONE, h.changedAt, body))
        }
        for (c in db.ncDao().claimsOf(workerId)) {
            val uid = c.claimUid ?: continue
            val body = JSONObject()
                .put("id", uid).put("coin", c.coin).put("amt", c.amountText).put("at", c.claimedAtUtc)
                .put("tz", c.timezoneContext).put("ca", c.createdAt)
                .putOpt("tid", c.taskId).put("tn", c.taskId?.let { db.taskDao().get(it)?.name } ?: "")
            out.add(ReportItem("NC:" + uid, TYPE_NC_CLAIM, c.createdAt, body))
        }
        for (m in db.supportDao().withUid(workerId, Dir.TO_MANAGER)) {
            val uid = m.telegramMessageId ?: continue
            out.add(ReportItem("SUP:" + uid, TYPE_SUPPORT, m.createdAt, JSONObject().put("id", uid).put("tx", m.body).put("at", m.createdAt)))
        }
        val cred = db.securityDao().workerCred(workerId)
        if (cred != null) {
            out.add(ReportItem("USR:" + workerId + ":" + cred.username, TYPE_USERNAME, cred.updatedAt, JSONObject().put("un", cred.username)))
        }
        return out.sortedBy { it.at }
    }

    /** How many submissions / payout requests / number changes were never put into a report. */
    suspend fun unsentCount(workerId: String): Int {
        val known = dao.outboxOf(workerId).map { it.itemKey }.toSet()
        var n = 0
        for (s in dao.submissionsOf(workerId)) if (("SUB:" + s.id) !in known) n++
        for (p in dao.payoutsOf(workerId)) if (("PAY:" + p.id) !in known) n++
        for (h in db.workerDao().phoneHistory(workerId)) {
            if (h.reason.startsWith("CHANGE") && ("PHN:" + workerId + ":" + h.id) !in known) n++
        }
        for (c in db.ncDao().claimsOf(workerId)) {
            val uid = c.claimUid ?: continue
            if (("NC:" + uid) !in known) n++
        }
        for (m in db.supportDao().withUid(workerId, Dir.TO_MANAGER)) if (("SUP:" + m.telegramMessageId) !in known) n++
        val cred = db.securityDao().workerCred(workerId)
        if (cred != null && ("USR:" + workerId + ":" + cred.username) !in known) n++
        return n
    }

    /**
     * Builds signed messages for the worker's submissions (with screenshot fingerprints and details, never the pictures),
     * payout requests and payout-number changes. [scope]: NEW = only what was never reported, THIS_WEEK / LAST_WEEK /
     * ALL = everything in that range again (same numbers as before, so repeats are harmless). [device] = "WxH" screen size.
     */
    suspend fun makeReport(workerId: String, scope: String, device: String): Outcome<ReportResult> {
        val w = db.workerDao().get(workerId) ?: return Outcome.Err("Worker not found.")
        val k = ensureKey(workerId)
        return db.withTransaction<Outcome<ReportResult>> {
            val items = collectItems(workerId, device)
            val known = dao.outboxOf(workerId).associateBy { it.itemKey }
            val thisWeek = TimeUtil.weekKey(now())
            val lastWeek = TimeUtil.weekKey(now() - TimeUtil.WEEK_MS)
            val chosen = when (scope) {
                SCOPE_NEW -> items.filter { it.key !in known }
                SCOPE_THIS_WEEK -> items.filter { TimeUtil.weekKey(it.at) == thisWeek }
                SCOPE_LAST_WEEK -> items.filter { TimeUtil.weekKey(it.at) == lastWeek }
                else -> items
            }
            if (chosen.isEmpty())
                return@withTransaction Outcome.Err(if (scope == SCOPE_NEW) "Nothing new to report. Everything was already put into a report." else "There is nothing to report for that choice.")

            val codes = ArrayList<String>()
            var fresh = 0
            for (item in chosen) {
                val row = known[item.key] ?: SyncOutboxEntity(
                    itemKey = item.key, workerId = workerId, type = item.type,
                    seq = nextSeq(workerId, SyncCodec.W2M), madeAt = now()
                ).also { dao.putOutbox(it); fresh++ }
                codes.add(SyncCodec.seal(k.keyHex, item.type, workerId, SyncCodec.W2M, row.seq, row.madeAt, item.body))
            }
            audit.log("worker:$workerId", "SYNC_REPORT_MADE", "worker", workerId, "scope=$scope messages=${codes.size} new=$fresh")

            val parts = buildParts(codes)
            val header = "CT Team report from " + w.fullName() + " - " + stamp(now()) + " - " + codes.size + " messages\n"
            Outcome.Ok(ReportResult(parts, codes.size, fresh, header + codes.joinToString("\n")))
        }
    }

    /** Splits whole codes into parts of at most PART_LIMIT characters (a single longer code stays alone in its part). */
    private fun buildParts(codes: List<String>): List<ReportPart> {
        val parts = ArrayList<ReportPart>()
        val cur = StringBuilder()
        var n = 0
        for (c in codes) {
            if (n > 0 && cur.length + c.length + 1 > PART_LIMIT) {
                parts.add(ReportPart(cur.toString(), n)); cur.setLength(0); n = 0
            }
            if (n > 0) cur.append('\n')
            cur.append(c); n++
        }
        if (n > 0) parts.add(ReportPart(cur.toString(), n))
        return parts
    }

    // ---------------------------------------------------------------- manager phone: updates for ONE worker (Piece 5C)

    private fun updatePriority(type: String) = when (type) {
        TYPE_TASK -> 0
        TYPE_DECISION -> 1
        TYPE_PAID -> 2
        else -> 3
    }

    private suspend fun collectUpdateItems(workerId: String): List<ReportItem> {
        val out = ArrayList<ReportItem>()

        for (t in dao.allTasks()) {
            val body = JSONObject()
                .put("id", t.id).put("nm", t.name).put("ds", t.description.take(2000))
                .put("pay", t.payUgx).put("ty", t.type)
                .put("vu", t.exampleVideoUrl.take(500)).put("lu", t.exampleLinkUrl.take(500))
                .put("pr", t.proofRequirements.take(1000)).put("vr", t.verificationRequirements.take(1000))
                .put("ac", t.active).put("vs", t.version).put("ca", t.createdAt).put("ua", t.updatedAt)
            out.add(ReportItem("TASK:" + t.id + ":" + t.version + ":" + workerId, TYPE_TASK, t.updatedAt, body))
        }

        for (s in dao.decidedOf(workerId)) {
            val body = JSONObject()
                .put("id", s.id).put("st", s.status).put("nt", s.decisionNote.take(500))
                .put("at", s.decidedAt ?: 0L).put("pay", s.payUgx)
            out.add(ReportItem("DEC:" + s.id, TYPE_DECISION, s.decidedAt ?: 0L, body))
        }

        for (p in dao.paidOf(workerId)) {
            val ids = JSONArray()
            for (id in dao.subIdsOfPayout(p.id)) ids.put(id)
            val body = JSONObject()
                .put("id", p.id).put("at", p.paidAt ?: 0L).put("amt", p.amountUgx)
                .put("md", p.confirmationMode ?: "MANUAL").put("subs", ids)
            out.add(ReportItem("PAID:" + p.id, TYPE_PAID, p.paidAt ?: 0L, body))
        }

        // account on/off: the number of switches is the version, so a late old message can never undo a newer one
        val ver = dao.stateChanges(workerId)
        if (ver > 0) {
            val active = db.workerDao().get(workerId)?.active ?: true
            val body = JSONObject().put("ver", ver).put("ac", active)
            out.add(ReportItem("WST:" + workerId + ":" + ver, TYPE_STATE, now(), body))
        }

        // NC Wallet claims: the number of manager changes is the version, so a late old message can never undo a newer one
        for (c in db.ncDao().claimsOf(workerId)) {
            val uid = c.claimUid ?: continue
            val ver = dao.ncChanges(uid)
            if (ver <= 0) continue
            val body = JSONObject().put("id", uid).put("st", c.status).put("ver", ver).put("cn", c.coin).put("am", c.amountText)
            out.add(ReportItem("NCV:" + uid + ":" + ver, TYPE_NC_VERIFIED, now(), body))
        }

        // Team mining (T2a): this worker's own team figures. A new message exists only when the ledger changed or a new week began.
        val tv = TeamViewCodec.build(db, workerId)
        if (tv != null) out.add(ReportItem("TV:" + workerId + ":" + tv.optInt("rev"), TYPE_TEAM_VIEW, tv.optLong("at"), tv))
        return out.sortedWith(compareBy<ReportItem>({ updatePriority(it.type) }, { it.at }))
    }

    /** Number of things this worker has not been sent yet (new/changed tasks, decisions, payments, account switch). */
    suspend fun pendingUpdateCount(workerId: String): Int {
        if (dao.key(workerId) == null) return 0
        val known = dao.outboxOf(workerId).map { it.itemKey }.toSet()
        return collectUpdateItems(workerId).count { it.key !in known }
    }

    /**
     * Manager phone: signed update messages for one connected worker. [everything] = false sends only what was never
     * sent to this worker; true makes all of it again (same message numbers, so repeats are harmless; use after a reinstall).
     */
    suspend fun makeUpdate(workerId: String, everything: Boolean): Outcome<ReportResult> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val name = db.workerDao().get(workerId)?.fullName() ?: "worker"
        return db.withTransaction<Outcome<ReportResult>> {
            val items = collectUpdateItems(workerId)
            val known = dao.outboxOf(workerId).associateBy { it.itemKey }
            val chosen = if (everything) items else items.filter { it.key !in known }
            if (chosen.isEmpty())
                return@withTransaction Outcome.Err(if (everything) "There is nothing to send yet. Create tasks first." else "Nothing new for $name. Everything was already put into an update.")
            val counterBefore = meta.get("sync:out:" + SyncCodec.M2W + ":" + workerId)?.toLongOrNull() ?: 0L
            val codes = ArrayList<String>()
            val madeKeys = ArrayList<String>()
            var fresh = 0
            for (item in chosen) {
                val row = known[item.key] ?: SyncOutboxEntity(
                    itemKey = item.key, workerId = workerId, type = item.type,
                    seq = nextSeq(workerId, SyncCodec.M2W), madeAt = now()
                ).also { dao.putOutbox(it); fresh++; madeKeys.add(item.key) }
                codes.add(SyncCodec.seal(k.keyHex, item.type, workerId, SyncCodec.M2W, row.seq, row.madeAt, item.body))
            }
            audit.log("manager", "SYNC_UPDATE_MADE", "worker", workerId, "everything=$everything messages=${codes.size} new=$fresh")
            val header = "CT Team update for " + name + " - " + stamp(now()) + " - " + codes.size + " messages\n"
            Outcome.Ok(ReportResult(buildParts(codes), codes.size, fresh, header + codes.joinToString("\n"), counterBefore, madeKeys))
        }
    }

    /**
     * Piece 9B: an update was made but NOTHING reached the worker (for example no internet). Takes the new items back out of
     * the outbox, so "new only" offers them again. Only the message counter is wound back, and only when nothing else used a
     * number in between. Never call this after any part was delivered: the worker may already hold those numbers.
     */
    suspend fun rollbackUpdate(workerId: String, made: ReportResult) {
        if (made.newKeys.isEmpty()) return
        db.withTransaction {
            for (chunk in made.newKeys.chunked(400)) dao.deleteOutboxKeys(workerId, chunk)
            val counterKey = "sync:out:" + SyncCodec.M2W + ":" + workerId
            val current = meta.get(counterKey)?.toLongOrNull() ?: 0L
            if (current == made.counterBefore + made.newKeys.size) meta.put(MetaEntity(counterKey, made.counterBefore.toString()))
            audit.log("manager", "SYNC_UPDATE_ROLLED_BACK", "worker", workerId, "nothing was delivered; " + made.newKeys.size + " items released")
        }
    }

    // ---------------------------------------------------------------- worker phone: receive updates (Piece 5C)

    private fun workerOrder(type: String) = when (type) {
        TYPE_TASK -> 0
        TYPE_DECISION -> 1
        TYPE_PAID -> 2
        else -> 3
    }

    /** Worker phone: pasted text or file with any number of manager updates. Only messages made for THIS worker are used. */
    suspend fun receiveFromManager(workerId: String, text: String): List<SyncIncoming.Done> {
        val all = SyncCodec.parseAll(text).sortedWith(compareBy<Envelope>({ workerOrder(it.type) }, { it.seq }))
        if (all.isEmpty())
            return listOf(SyncIncoming.Done(false, "Not a CT Team message", "No valid CT1 code was found in what you pasted. Copy the whole code and try again."))
        val key = ensureKey(workerId)
        return all.map { receiveUpdate(workerId, key.keyHex, it) }
    }

    private suspend fun receiveUpdate(workerId: String, keyHex: String, env: Envelope): SyncIncoming.Done {
        if (env.direction != SyncCodec.M2W)
            return SyncIncoming.Done(false, "Wrong phone", "This message was made by a worker's phone for the manager. It is not an update.")
        if (env.workerId != workerId)
            return SyncIncoming.Done(false, "Not for this phone", "This update was made for a different worker. Nothing was used.")
        if (env.type == TYPE_RESET)
            return SyncIncoming.Done(false, "This is a reset code", "Reset codes are used on the sign-in screen: tap Forgot password or PIN, then paste the code there. It was NOT used here.")
        if (env.type !in WORKER_TYPES)
            return SyncIncoming.Done(false, "Not supported yet", "This message type (${env.type}) needs a newer version of the app. It was NOT used and can be sent again later.")
        if (!SyncCodec.verify(keyHex, env)) {
            audit.event("SYNC_REJECTED", "bad signature on worker phone, type=${env.type}, seq=${env.seq}")
            return SyncIncoming.Done(false, "REJECTED: signature does not match", "The update was changed, damaged, or not made with your key. Nothing was used.")
        }
        return try {
            db.withTransaction<SyncIncoming.Done> {
                if (dao.seenCountOf(workerId, env.direction, env.seq) > 0)
                    return@withTransaction SyncIncoming.Done(false, "Already received", "Update #${env.seq} was accepted before. Ignored (replay protection).")
                val before = dao.maxSeen(workerId, env.direction)
                val r = when (env.type) {
                    TYPE_TASK -> applyTask(env)
                    TYPE_DECISION -> applyDecision(env, workerId)
                    TYPE_PAID -> applyPaid(env, workerId)
                    TYPE_STATE -> applyState(env, workerId)
                    TYPE_NC_VERIFIED -> applyNcVerified(env, workerId)
                    TYPE_TEAM_VIEW -> applyTeamView(env, workerId)
                    TYPE_NOTICE -> applyNotice(env, workerId)
                    TYPE_SUPPORT_REPLY -> applySupportReply(env, workerId)
                    TYPE_LEARN -> applyLearn(env)
                    else -> Applied(false, "Not supported yet", "Unknown type.", consume = false)
                }
                var gap = ""
                if (r.consume) {
                    dao.markSeen(SyncSeenEntity(workerId, env.direction, env.seq, env.type, now()))
                    if (env.seq > before + 1L)
                        gap = "\nUpdates #${before + 1L} to #${env.seq - 1L} have not arrived yet. They can still be accepted if they turn up later."
                }
                SyncIncoming.Done(r.ok, r.title, r.detail + gap, imported = r.imported)
            }
        } catch (ex: Exception) {
            SyncIncoming.Done(false, "Could not use this update", "Nothing was changed. (" + (ex.message ?: ex.javaClass.simpleName) + ")")
        }
    }

    // ---------------------------------------------------------------- Piece 9D-2: support chat

    /** Worker phone: writes a message to the manager. It is sent inside the next report (MAKE REPORT), like a submission. */
    suspend fun askSupport(workerId: String, text: String): Outcome<Unit> {
        if (db.workerDao().get(workerId) == null) return Outcome.Err("Worker not found.")
        val t = clean(text, NOTICE_MAX)
        if (t.isBlank()) return Outcome.Err("Write your message first.")
        val waiting = unsentSupportCount(workerId)
        if (waiting >= 20) return Outcome.Err("You already have $waiting messages waiting to be sent. Send a report first.")
        val uid = SyncCodec.newKeyHex().take(16)
        db.supportDao().insert(SupportMessageEntity(workerId = workerId, direction = Dir.TO_MANAGER, body = t, createdAt = now(), telegramMessageId = uid, readAt = now()))
        audit.log("worker:$workerId", "SUPPORT_ASKED", "worker", workerId, "id=$uid")
        return Outcome.Ok(Unit)
    }

    /** Worker phone: messages written but not yet put into a report. */
    suspend fun unsentSupportCount(workerId: String): Int {
        val known = dao.outboxOf(workerId).map { it.itemKey }.toSet()
        return db.supportDao().withUid(workerId, Dir.TO_MANAGER).count { ("SUP:" + it.telegramMessageId) !in known }
    }

    /** Manager phone: signs a reply for one worker. Nothing is saved until [saveSupportReply] (after it was really sent or copied). */
    suspend fun makeSupportReply(workerId: String, text: String, actor: String): Outcome<SupportReplyMade> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val t = clean(text, NOTICE_MAX)
        if (t.isBlank()) return Outcome.Err("Write the reply first.")
        val seq = nextSeq(workerId, SyncCodec.M2W)
        val at = now()
        val uid = SyncCodec.newKeyHex().take(16)
        audit.log(actor, "SYNC_SUPPORT_REPLY_MADE", "worker", workerId, "seq=$seq")
        val body = JSONObject().put("id", uid).put("tx", t).put("at", at)
        return Outcome.Ok(SupportReplyMade(SyncCodec.seal(k.keyHex, TYPE_SUPPORT_REPLY, workerId, SyncCodec.M2W, seq, at, body), seq, uid))
    }

    /** Manager phone: the reply left the phone (Telegram sent it, or the manager copied it). Keeps it in the thread and marks the worker's messages read. */
    suspend fun saveSupportReply(workerId: String, made: SupportReplyMade, text: String) {
        val t = clean(text, NOTICE_MAX)
        db.supportDao().insert(SupportMessageEntity(workerId = workerId, direction = Dir.TO_WORKER, body = t, createdAt = now(), telegramMessageId = made.uid, readAt = now()))
        db.supportDao().markManagerRead(workerId, now())
    }

    private suspend fun applySupport(env: Envelope, name: String): Applied {
        val b = env.body
        val uid = b.optString("id")
        val text = clean(b.optString("tx"), NOTICE_MAX)
        if (!ID_RULE.matches(uid) || text.isBlank()) return Applied(false, "Message not used", "The support message in this report is not valid.")
        val old = db.supportDao().byUid(uid)
        if (old != null) {
            return if (old.workerId == env.workerId) Applied(true, "Support message already here", "This message is already in $name's chat.")
            else Applied(false, "Message not used", "This message number already belongs to a different worker.")
        }
        val at = now()
        val sentAt = b.optLong("at", 0L).let { if (it in 1..at) it else at }
        db.supportDao().insert(SupportMessageEntity(workerId = env.workerId, direction = Dir.TO_MANAGER, body = text, createdAt = sentAt, telegramMessageId = uid, readAt = null))
        audit.log("sync", "SUPPORT_RECEIVED", "worker", env.workerId, "id=$uid", at)
        return Applied(true, "Support message from $name", text.take(200), imported = true)
    }

    private suspend fun applySupportReply(env: Envelope, workerId: String): Applied {
        val b = env.body
        val uid = b.optString("id")
        val text = clean(b.optString("tx"), NOTICE_MAX)
        if (!ID_RULE.matches(uid) || text.isBlank()) return Applied(false, "Reply not used", "The reply in this message is not valid.")
        if (db.supportDao().byUid(uid) != null) return Applied(true, "Reply already received", "This reply is already in your chat.")
        val at = now()
        val sentAt = b.optLong("at", 0L).let { if (it in 1..at) it else at }
        db.supportDao().insert(SupportMessageEntity(workerId = workerId, direction = Dir.TO_WORKER, body = text, createdAt = sentAt, telegramMessageId = uid, readAt = null))
        audit.log("sync", "SUPPORT_REPLY_RECEIVED", "worker", workerId, "id=$uid", at)
        return Applied(true, "Reply from the manager", text.take(300), imported = true)
    }

    // ---------------------------------------------------------------- Piece 9B-3: announcements

    /** Manager phone: a signed announcement for ONE worker. Returns (code, message number). Not part of "update"; sent once. */
    suspend fun makeNotice(workerId: String, text: String, actor: String): Outcome<Pair<String, Long>> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val t = clean(text, NOTICE_MAX)
        if (t.isBlank()) return Outcome.Err("Write the message first.")
        val seq = nextSeq(workerId, SyncCodec.M2W)
        val at = now()
        audit.log(actor, "SYNC_NOTICE_MADE", "worker", workerId, "seq=$seq")
        val body = JSONObject().put("id", SyncCodec.newKeyHex().take(16)).put("tx", t).put("at", at)
        return Outcome.Ok(Pair(SyncCodec.seal(k.keyHex, TYPE_NOTICE, workerId, SyncCodec.M2W, seq, at, body), seq))
    }

    /** Nothing was delivered: gives the message number back (only if nothing else used a later one), so the worker sees no gap. */
    suspend fun releaseSeq(workerId: String, seq: Long) {
        db.withTransaction {
            val key = "sync:out:" + SyncCodec.M2W + ":" + workerId
            if ((meta.get(key)?.toLongOrNull() ?: 0L) == seq) meta.put(MetaEntity(key, (seq - 1L).toString()))
            Unit
        }
    }

    // ---------------------------------------------------------------- Piece 10B: lessons (Learn & Earn)

    private fun goodLearnLink(u: String): Boolean =
        u.isEmpty() || (u.startsWith("https://") && u.length <= 300 && !u.any { it.isWhitespace() })

    /**
     * Manager phone: a signed copy of one lesson for ONE worker. Returns (code, message number).
     * A published lesson is sent in full; a hidden or draft lesson is sent as "take it back" (pb = 0, no text).
     * The message carries the lesson's version, so the worker phone keeps only the newest one.
     */
    suspend fun makeLearn(workerId: String, lessonId: String, actor: String): Outcome<Pair<String, Long>> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val l = db.contentDao().learn(lessonId) ?: return Outcome.Err("Lesson not found. Save it first.")
        val seq = nextSeq(workerId, SyncCodec.M2W)
        val at = now()
        val body = JSONObject()
            .put("id", l.id).put("vs", l.version).put("pb", if (l.published) 1 else 0)
            .put("tt", l.title).put("ct", l.category).put("tx", if (l.published) l.body else "")
            .put("im", l.imageUrl).put("vd", l.videoUrl).put("at", at)
        audit.log(actor, "SYNC_LEARN_MADE", "worker", workerId, l.id + " v" + l.version + (if (l.published) "" else " (take back)") + " seq=" + seq)
        return Outcome.Ok(Pair(SyncCodec.seal(k.keyHex, TYPE_LEARN, workerId, SyncCodec.M2W, seq, at, body), seq))
    }

    /**
     * Worker phone: keeps the lesson if it is newer than the one already here. A "take back" keeps a hidden record (published = false,
     * no text) so an older message that turns up late cannot bring the lesson back.
     */
    private suspend fun applyLearn(env: Envelope): Applied {
        val b = env.body
        val id = b.optString("id")
        val version = b.optInt("vs", 0)
        val published = b.optInt("pb", 0) == 1
        val title = clean(b.optString("tt"), LEARN_TITLE_MAX)
        val category = clean(b.optString("ct"), 30)
        val text = if (published) clean(b.optString("tx"), LEARN_BODY_MAX) else ""
        val image = b.optString("im").trim()
        val video = b.optString("vd").trim()
        if (!ID_RULE.matches(id) || version < 1 || title.length < 3 || (published && text.isBlank()) || !goodLearnLink(image) || !goodLearnLink(video))
            return Applied(false, "Lesson not used", "The lesson in this message is not valid. Nothing was used.")
        val old = db.contentDao().learn(id)
        if (old != null && old.version >= version)
            return Applied(true, "Lesson already up to date", "\"" + title + "\": this phone already has version " + old.version + " or newer.")
        val at = now()
        db.contentDao().upsertLearn(
            LearnContentEntity(
                id = id, title = title, body = text, category = category, imageUrl = image, videoUrl = video,
                published = published, version = version, updatedAt = at
            )
        )
        audit.log("sync", if (published) "LEARN_RECEIVED" else "LEARN_TAKEN_BACK", "learn", id, "v" + version, at)
        return if (published) Applied(true, "New lesson: " + title, "It is now in Learn & Earn.", imported = true)
        else Applied(true, "A lesson was taken back", "\"" + title + "\" is no longer shown.", imported = true)
    }

    private fun parseNotices(raw: String?): List<WorkerNotice> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                WorkerNotice(o.optString("id"), o.optString("tx"), o.optLong("at", 0L))
            }
        } catch (ex: Exception) { emptyList() }
    }

    /** Worker phone: announcements received so far, newest first (the last 20 are kept). */
    suspend fun notices(workerId: String): List<WorkerNotice> = parseNotices(meta.get("notices:$workerId"))

    suspend fun clearNotices(workerId: String) { meta.put(MetaEntity("notices:$workerId", "[]")) }

    private suspend fun applyNotice(env: Envelope, workerId: String): Applied {
        val b = env.body
        val id = b.optString("id")
        val text = clean(b.optString("tx"), NOTICE_MAX)
        if (!ID_RULE.matches(id) || text.isBlank()) return Applied(false, "Message not used", "The announcement in this message is not valid.")
        val at = now()
        val key = "notices:$workerId"
        val old = parseNotices(meta.get(key))
        if (old.any { it.id == id }) return Applied(true, "Announcement already received", "This message is already in your list.")
        val sentAt = b.optLong("at", 0L).let { if (it in 1..at) it else at }
        val list = (listOf(WorkerNotice(id, text, sentAt)) + old).take(20)
        val arr = JSONArray()
        for (n in list) arr.put(JSONObject().put("id", n.id).put("tx", n.text).put("at", n.at))
        meta.put(MetaEntity(key, arr.toString()))
        audit.log("sync", "NOTICE_RECEIVED", "worker", workerId, "id=$id", at)
        return Applied(true, "Message from the manager", text.take(300), imported = true)
    }

    private suspend fun applyTask(env: Envelope): Applied {
        val b = env.body
        val id = b.optString("id")
        val name = clean(b.optString("nm"), 120)
        val pay = b.optLong("pay", 0L)
        val type = b.optString("ty")
        val version = b.optInt("vs", 0)
        if (!ID_RULE.matches(id) || name.isBlank() || pay <= 0L || version < 1 || (type != TaskType.DAILY && type != TaskType.ONE_TIME))
            return Applied(false, "Task not used", "The task in this message is not valid. Nothing was used.")
        val old = db.taskDao().get(id)
        if (old != null && old.version >= version)
            return Applied(true, "Task already up to date", "\"" + name + "\": this phone already has version " + old.version + " or newer.")
        val at = now()
        val t = TaskEntity(
            id = id, name = name, description = clean(b.optString("ds"), 2000), payUgx = pay, type = type,
            exampleVideoUrl = clean(b.optString("vu"), 500), exampleLinkUrl = clean(b.optString("lu"), 500),
            proofRequirements = clean(b.optString("pr"), 1000), verificationRequirements = clean(b.optString("vr"), 1000),
            active = b.optBoolean("ac", true), version = version,
            createdAt = old?.createdAt ?: b.optLong("ca", at).let { if (it in 1..at) it else at },
            updatedAt = b.optLong("ua", at).let { if (it in 1..at) it else at }
        )
        if (old == null) db.taskDao().insert(t) else db.taskDao().update(t)
        audit.log("sync", "TASK_RECEIVED", "task", id, "v$version ${t.name}", at)
        return Applied(true, (if (old == null) "New task: " else "Task updated: ") + name, "Version " + version + ", " + ugxText(pay) + (if (!t.active) " (switched off by the manager)" else "") + ".", imported = true)
    }

    private suspend fun applyDecision(env: Envelope, workerId: String): Applied {
        val b = env.body
        val sid = b.optString("id")
        val st = b.optString("st")
        if (!ID_RULE.matches(sid) || (st != SubStatus.APPROVED && st != SubStatus.REJECTED))
            return Applied(false, "Decision not used", "The decision in this message is not valid.")
        val s = db.submissionDao().get(sid)
            ?: return Applied(false, "Not found on this phone", "This decision is for a submission that is not on this phone. Nothing was used.")
        if (s.workerId != workerId) return Applied(false, "Decision not used", "That submission belongs to someone else. Nothing was used.")
        if (s.status != SubStatus.PENDING) {
            return if (s.status == st) Applied(true, "Decision already up to date", "This submission is already " + st + ".")
            else Applied(false, "Decision not used", "This submission is already " + s.status + " here but the message says " + st + ". Nothing was changed; tell the manager.")
        }
        val at = now()
        val pay = b.optLong("pay", 0L).let { if (it > 0L) it else s.payUgx }
        val decidedAt = b.optLong("at", 0L).let { if (it in 1..at) it else at }
        db.submissionDao().update(s.copy(status = st, decidedAt = decidedAt, decidedBy = "manager", decisionNote = clean(b.optString("nt"), 500), payUgx = pay))
        audit.log("worker:$workerId", "DECISION_RECEIVED", "submission", sid, st, at)
        return Applied(
            true, (if (st == SubStatus.APPROVED) "Approved: " else "Rejected: ") + (db.taskDao().get(s.taskId)?.name ?: "task"),
            ugxText(pay) + (if (st == SubStatus.REJECTED && b.optString("nt").isNotBlank()) "\nManager's note: " + clean(b.optString("nt"), 500) else ""),
            imported = true
        )
    }

    private suspend fun applyPaid(env: Envelope, workerId: String): Applied {
        val b = env.body
        val pid = b.optString("id")
        if (!ID_RULE.matches(pid)) return Applied(false, "Payment not used", "The payout number in this message is not valid.")
        val p = db.payoutDao().get(pid)
            ?: return Applied(false, "Not found on this phone", "This payment is for a payout request that is not on this phone. Nothing was used.")
        if (p.workerId != workerId) return Applied(false, "Payment not used", "That payout belongs to someone else. Nothing was used.")
        if (p.status == PayoutStatus.PAID) return Applied(true, "Payment already up to date", "This payout is already marked Paid.")
        val at = now()
        val amount = b.optLong("amt", 0L).let { if (it > 0L) it else p.amountUgx }
        val paidAt = b.optLong("at", 0L).let { if (it in 1..at) it else at }
        db.payoutDao().update(
            p.copy(
                status = PayoutStatus.PAID, paidAt = paidAt, confirmedBy = "manager",
                confirmationMode = clean(b.optString("md"), 20).ifBlank { "MANUAL" }, amountUgx = amount
            )
        )
        // submissions the manager did not count stay with the worker as unpaid, not as "paid"
        val listed = HashSet<String>()
        val arr = b.optJSONArray("subs")
        if (arr != null) for (i in 0 until minOf(arr.length(), MAX_PAYOUT_SUBS)) listed.add(arr.optString(i))
        var released = 0
        if (listed.isNotEmpty()) {
            for (sid in dao.subIdsOfPayout(p.id)) {
                if (sid !in listed) {
                    val s = db.submissionDao().get(sid)
                    if (s != null) { db.submissionDao().update(s.copy(payoutId = null)); released++ }
                }
            }
        }
        audit.log("worker:$workerId", "PAYOUT_PAID_RECEIVED", "payout", pid, "UGX $amount released=$released", at)
        return Applied(
            true, "Paid: " + ugxText(amount), "Your payout for the week of " + p.weekKey + " was paid to 0" + p.phone.substring(3) + "." +
                (if (amount != p.amountUgx) "\nThe manager's amount (" + ugxText(amount) + ") differs from your request (" + ugxText(p.amountUgx) + ")." else "") +
                (if (released > 0) "\n" + released + " approved submission(s) were not part of this payment. Ask the manager." else ""),
            imported = true
        )
    }

    private suspend fun applyNcVerified(env: Envelope, workerId: String): Applied {
        val b = env.body
        val uid = b.optString("id")
        val st = b.optString("st")
        val ver = b.optInt("ver", 0)
        if (!ID_RULE.matches(uid) || ver <= 0 || (st != NcStatus.MATCHED && st != NcStatus.MANUAL && st != NcStatus.UNMATCHED))
            return Applied(false, "NC check not used", "The NC Wallet status in this message is not valid.")
        val c = db.ncDao().claimByUid(uid)
            ?: return Applied(false, "Not found on this phone", "This NC claim is not on this phone. Nothing was used.")
        if (c.workerId != workerId) return Applied(false, "NC check not used", "That claim belongs to someone else. Nothing was used.")
        val key = "ncv:" + uid
        val known = meta.get(key)?.toIntOrNull() ?: 0
        if (ver <= known)
            return Applied(true, "NC check already up to date", "A newer or equal status for this claim was already applied.")
        meta.put(MetaEntity(key, ver.toString()))
        if (c.status != st) db.ncDao().updateClaim(c.copy(status = st))
        audit.log("worker:$workerId", "NC_STATUS_RECEIVED", "nc_claim", uid, st, now())
        val label = c.coin + " " + c.amountText
        return if (st == NcStatus.UNMATCHED)
            Applied(true, "NC claim check removed: $label", "The manager removed the match for this claim. It is waiting for a new check.", imported = true)
        else
            Applied(true, "NC claim verified: $label", "The manager matched this deposit with the NC Wallet statement.", imported = true)
    }

    private suspend fun applyTeamView(env: Envelope, workerId: String): Applied {
        val r = TeamViewCodec.apply(db, workerId, env.body)
        if (r.changed) audit.log("worker:$workerId", "TEAM_VIEW_RECEIVED", "worker", workerId, "rev " + env.body.optInt("rev"), now())
        return Applied(r.ok, r.title, r.detail, imported = r.changed)
    }

    private suspend fun applyState(env: Envelope, workerId: String): Applied {
        val ver = env.body.optLong("ver", 0L)
        val active = env.body.optBoolean("ac", true)
        val key = "sync:wver:$workerId"
        val current = meta.get(key)?.toLongOrNull() ?: 0L
        if (ver <= current) return Applied(true, "Account status already up to date", "A newer or equal status was received before.")
        val w = db.workerDao().get(workerId)
            ?: return Applied(false, "Worker record missing", "No worker record on this phone. Nothing was used.", consume = false)
        db.workerDao().update(w.copy(active = active))
        meta.put(MetaEntity(key, ver.toString()))
        audit.log("worker:$workerId", "STATE_RECEIVED", "worker", workerId, if (active) "enabled" else "disabled")
        return Applied(true, if (active) "Your account was enabled" else "Your account was disabled by the manager", if (active) "You can work on tasks again." else "You cannot submit tasks until the manager enables it again.", imported = true)
    }

    // ---------------------------------------------------------------- manager phone: receive

    private fun order(type: String) = when (type) {
        TYPE_PHONE, TYPE_USERNAME -> 0       // number changes first, so a payout that follows can be checked against the right number
        TYPE_SUBMISSION -> 1
        TYPE_PAYOUT -> 2
        else -> 3
    }

    /** Entry point for pasted text or an imported file on the manager phone: any number of messages at once. */
    suspend fun receiveAll(text: String, actor: String = "manager"): List<SyncIncoming> {
        val all = SyncCodec.parseAll(text).sortedWith(compareBy<Envelope>({ order(it.type) }, { it.workerId }, { it.seq }))
        if (all.isEmpty())
            return listOf(SyncIncoming.Done(false, "Not a CT Team message", "No valid CT1 code was found in what you pasted. Copy the whole code and try again."))
        return all.map { receiveEnvelope(it, actor) }
    }

    private suspend fun receiveEnvelope(env: Envelope, actor: String): SyncIncoming {
        if (env.direction != SyncCodec.W2M)
            return SyncIncoming.Done(false, "Wrong phone", "This message is meant for a worker's phone, not the manager's.")

        if (env.type == TYPE_ENROLL) return SyncIncoming.Enroll(previewOf(env), env.wire)

        if (env.type == TYPE_RESET_REQ) {
            val k = dao.key(env.workerId)
                ?: return SyncIncoming.Done(false, "Unknown worker", "This phone has no key for that worker, so the reset request cannot be checked. Connect the worker first.")
            if (!SyncCodec.verify(k.keyHex, env)) {
                audit.event("SYNC_REJECTED", "bad signature, worker=${env.workerId}, type=${env.type}, seq=${env.seq}")
                return SyncIncoming.Done(false, "REJECTED: signature does not match", "The reset request was changed or not made with this worker's key. Nothing was used.")
            }
            if (dao.seenCountOf(env.workerId, env.direction, env.seq) > 0)
                return SyncIncoming.Done(false, "Reset request already answered", "This request was already approved once. Ask the worker to make a new one.")
            if (kotlin.math.abs(now() - env.ts) > REQUEST_VALID_MS)
                return SyncIncoming.Done(false, "Reset request too old", "Ask the worker to make a new request (or their phone date and time are wrong).")
            val who = db.workerDao().get(env.workerId)?.fullName() ?: "worker"
            return SyncIncoming.ResetRequest(env.workerId, who, resetCheckCode(env.body.optString("n")), env.wire, env.ts)
        }

        if (env.type !in MANAGER_TYPES)
            return SyncIncoming.Done(false, "Not supported yet", "This message type (${env.type}) needs a newer version of the app. It was NOT used and can be sent again later.")

        val key = dao.key(env.workerId)
            ?: return SyncIncoming.Done(
                false, "Unknown worker",
                "This phone has no key for that worker. The worker must send a connection code first. It was NOT used; if you approve the connection from the same paste it is tried again automatically.",
                retryWire = env.wire
            )
        if (!SyncCodec.verify(key.keyHex, env)) {
            audit.event("SYNC_REJECTED", "bad signature, worker=${env.workerId}, type=${env.type}, seq=${env.seq}")
            return SyncIncoming.Done(false, "REJECTED: signature does not match", "The message was changed, damaged, or not made with this worker's key. Nothing was used.")
        }
        val name = db.workerDao().get(env.workerId)?.fullName() ?: "worker"
        return try {
            db.withTransaction<SyncIncoming> {
                if (dao.seenCountOf(env.workerId, env.direction, env.seq) > 0)
                    return@withTransaction SyncIncoming.Done(false, "Already received", "Message #${env.seq} from $name was accepted before. Ignored (replay protection).")
                val before = dao.maxSeen(env.workerId, env.direction)
                val r = when (env.type) {
                    TYPE_PING -> applyPing(env, name)
                    TYPE_SUBMISSION -> applySubmission(env, name, actor)
                    TYPE_PAYOUT -> applyPayout(env, name, actor)
                    TYPE_PHONE -> applyPhone(env, name, actor)
                    TYPE_USERNAME -> applyUsername(env, name, actor)
                    TYPE_NC_CLAIM -> applyNcClaim(env, name, actor)
                    TYPE_SUPPORT -> applySupport(env, name)
                    else -> Applied(false, "Not supported yet", "Unknown type.", consume = false)
                }
                var gap = ""
                if (r.consume) {
                    dao.markSeen(SyncSeenEntity(env.workerId, env.direction, env.seq, env.type, now()))
                    if (env.seq > before + 1L)
                        gap = "\nMessages #${before + 1L} to #${env.seq - 1L} have not arrived yet. They can still be accepted if they turn up later."
                }
                SyncIncoming.Done(r.ok, r.title, r.detail + gap, imported = r.imported)
            }
        } catch (ex: Exception) {
            SyncIncoming.Done(false, "Could not import this message", "Nothing was changed. (" + (ex.message ?: ex.javaClass.simpleName) + ")")
        }
    }

    private suspend fun applyPing(env: Envelope, name: String): Applied {
        audit.event("SYNC_PING", "worker=${env.workerId}, seq=${env.seq}")
        val note = env.body.optString("note")
        return Applied(
            true, "Verified: message #${env.seq} from $name",
            "Signature is valid and this is the first time it was received." + (if (note.isNotBlank()) "\nNote: $note" else "")
        )
    }

    // ---- submissions -> Review

    private suspend fun applySubmission(env: Envelope, name: String, actor: String): Applied {
        val b = env.body
        val id = b.optString("id")
        if (!ID_RULE.matches(id)) return Applied(false, "Submission not used", "The submission number in this message is not valid.")
        val w = db.workerDao().get(env.workerId)
            ?: return Applied(false, "Worker record missing", "The worker is connected but has no record on this phone. Nothing was used.", consume = false)

        val existing = db.submissionDao().get(id)
        if (existing != null) {
            return if (existing.workerId == env.workerId)
                Applied(true, "Already on this phone", "This submission is already here (status " + existing.status + "). Nothing changed.")
            else Applied(false, "Submission not used", "This submission number already belongs to a different worker. Nothing was used.")
        }

        val taskId = b.optString("tid")
        val task = db.taskDao().get(taskId)
            ?: return Applied(
                false, "Task not found on this phone",
                "The task \"" + clean(b.optString("tn"), 80) + "\" does not exist on this phone, so the submission was NOT used. " +
                    "Tasks must reach the worker from this phone first (Piece 5C). The worker can send the report again later.",
                consume = false
            )

        val received = now()
        val notes = ArrayList<String>()
        val claimed = b.optLong("at", 0L)
        var at = claimed
        if (claimed <= 0L) {
            at = received
            notes.add("The worker's phone gave no valid time, so the arrival time was used.")
        } else if (claimed > received + FUTURE_TOLERANCE_MS) {
            at = received
            notes.add("The worker's phone clock is ahead (it said " + stamp(claimed) + "). The arrival time was used instead.")
        } else if (claimed < task.createdAt) {
            notes.add("Time on the worker's phone (" + stamp(claimed) + ") is BEFORE this task was created. Phone clock wrong, or the proof is old.")
        }

        val day = TimeUtil.dayKey(at)
        val already = if (task.type == TaskType.DAILY) db.submissionDao().countActiveForDay(env.workerId, task.id, day)
        else db.submissionDao().countActiveEver(env.workerId, task.id)
        if (already > 0)
            return Applied(
                false, "Not used: task already done",
                name + " already has a pending or approved submission for \"" + task.name + "\"" +
                    (if (task.type == TaskType.DAILY) " on " + day else "") + ". This one was NOT added (a task is paid once).",
                consume = true
            )

        // the manager's own task decides the pay, never the number in the worker's message
        val claimedPay = b.optLong("pay", -1L)
        val tv = b.optInt("tv", 0)
        var versionPay = -1L
        val snap = dao.taskVersion(task.id, tv)
        if (snap != null) {
            versionPay = try { JSONObject(snap.snapshotJson).optLong("payUgx", -1L) } catch (ex: Exception) { -1L }
        }
        val pay = if (versionPay > 0L) versionPay else task.payUgx
        val version = if (versionPay > 0L) tv else task.version
        if (claimedPay != pay)
            notes.add("The worker's app said UGX " + claimedPay + " but this phone's task pays UGX " + pay + " (version " + version + "). This phone's amount is used.")
        if (!task.active) notes.add("This task is switched off on this phone now.")
        if (!w.active) notes.add("This worker is disabled on this phone.")

        val sub = SubmissionEntity(
            id = id, taskId = task.id, workerId = env.workerId, taskVersion = version,
            dayKey = day, weekKey = TimeUtil.weekKey(at), seq = b.optLong("ws", 0L).coerceAtLeast(0L),
            status = SubStatus.PENDING, payUgx = pay,
            referenceText = clean(b.optString("ref"), 500), explanation = clean(b.optString("ex"), 2000),
            submittedAt = at
        )
        db.submissionDao().insert(sub)

        val arr = b.optJSONArray("pr")
        var kept = 0
        var skipped = 0
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i)
                if (o == null || kept >= MAX_PROOFS) { skipped++; continue }
                val kind = o.optString("k")
                if (kind != "SCREENSHOT" && kind != "REFERENCE" && kind != "TEXT") { skipped++; continue }
                val sha = o.optString("h").lowercase().takeIf { SHA_RULE.matches(it) }
                val dh = o.optString("dh").takeIf { DHASH_RULE.matches(it) }
                db.submissionDao().insertProof(
                    ProofEntity(
                        submissionId = id, kind = kind, sha256 = sha, dhash = dh,
                        fileName = clean(o.optString("fn"), 200).ifBlank { null },
                        fileSize = o.optLong("sz", -1L).takeIf { it >= 0L },
                        width = o.optInt("w", -1).takeIf { it > 0 },
                        height = o.optInt("ht", -1).takeIf { it > 0 },
                        fileModifiedAt = o.optLong("fm", 0L).takeIf { it > 0L },
                        mime = clean(o.optString("mt"), 60).ifBlank { null },
                        metadataTags = clean(o.optString("tg"), 300).ifBlank { null },
                        textValue = clean(o.optString("tx"), 1000).ifBlank { null },
                        createdAt = received
                    )
                )
                kept++
            }
        }
        if (skipped > 0) notes.add(skipped.toString() + " proof item(s) in the message were not valid and were left out.")

        // information for the manager, shown in Review as extra proof lines (Piece 6 will read the screen size from here)
        val ds = b.optString("ds")
        val info = StringBuilder("Arrived by sync on " + stamp(received) + ". Pictures are NOT inside the report: ask for the original files if needed.")
        if (SCREEN_RULE.matches(ds)) info.append(" Worker phone screen: ").append(ds).append(".")
        db.submissionDao().insertProof(ProofEntity(submissionId = id, kind = "TEXT", textValue = info.toString(), createdAt = received))
        for (n in notes) {
            db.submissionDao().insertProof(
                ProofEntity(submissionId = id, kind = "TEXT", textValue = "⚠ $n", verdict = Verdict.CHECK, createdAt = received)
            )
        }

        audit.log(actor, "SUBMISSION_IMPORTED", "submission", id, "worker=${env.workerId} task=${task.name} v$version seq=${env.seq} warnings=${notes.size}", received)
        return Applied(
            true, "Imported: " + task.name + " from " + name,
            "Waiting in Review (" + kept + " proof item(s), UGX " + pay + ")." + (if (notes.isEmpty()) "" else "\n⚠ " + notes.joinToString("\n⚠ ")),
            imported = true
        )
    }

    // ---- payout requests

    private suspend fun applyPayout(env: Envelope, name: String, actor: String): Applied {
        val b = env.body
        val id = b.optString("id")
        if (!ID_RULE.matches(id)) return Applied(false, "Payout request not used", "The payout number in this message is not valid.")
        val w = db.workerDao().get(env.workerId)
            ?: return Applied(false, "Worker record missing", "The worker is connected but has no record on this phone. Nothing was used.", consume = false)

        val existing = db.payoutDao().get(id)
        if (existing != null) {
            return if (existing.workerId == env.workerId)
                Applied(true, "Payout already on this phone", "This payout request is already here (status " + existing.status + "). Nothing changed.")
            else Applied(false, "Payout request not used", "This payout number already belongs to a different worker. Nothing was used.")
        }

        val week = b.optString("wk")
        val weekOk = DATE_RULE.matches(week) && try { LocalDate.parse(week).dayOfWeek == DayOfWeek.MONDAY } catch (ex: Exception) { false }
        if (!weekOk) return Applied(false, "Payout request not used", "The week in this message is not a valid Monday-to-Sunday week.")

        val phone = PhoneUtil.parse(b.optString("ph"))
            ?: return Applied(false, "Payout request not used", "The payout number in this message is not a valid MTN/Airtel number.")

        if (db.payoutDao().inProgressFor(env.workerId) != null)
            return Applied(
                false, "Not used: another payout is in progress",
                name + " already has a payout waiting to be paid. Mark it as paid first, then ask the worker to send the report again. Nothing was used.",
                consume = false
            )
        if (db.payoutDao().forWeek(env.workerId, week) != null)
            return Applied(false, "Not used: that week already has a payout", name + " already has a payout request for the week of " + week + ". Nothing was used.")

        val notes = ArrayList<String>()
        if (phone.digits != w.phone) {
            val known = db.workerDao().phoneHistory(env.workerId).any { it.phone == phone.digits }
            if (!known)
                return Applied(
                    false, "Not used: payout number not known",
                    "The payout number " + phone.national + " is not a number this phone knows for " + name + ". Import the worker's number-change message first, then this one again. Nothing was used.",
                    consume = false
                )
            notes.add("The payout number " + phone.national + " is an OLD number. The worker's current number on this phone is 0" + w.phone.substring(3) + ".")
        }
        if (!w.active) notes.add("This worker is disabled on this phone.")

        val idsArr = b.optJSONArray("subs")
        val ids = ArrayList<String>()
        if (idsArr != null) {
            for (i in 0 until minOf(idsArr.length(), MAX_PAYOUT_SUBS)) {
                val s = idsArr.optString(i)
                if (ID_RULE.matches(s)) ids.add(s)
            }
        }
        if (ids.isEmpty()) return Applied(false, "Payout request not used", "The message lists no submissions, so there is nothing to pay.")

        // only money the MANAGER phone itself approved counts; the worker's amount is just a claim
        val valid = dao.subsByIds(ids).filter {
            it.workerId == env.workerId && it.status == SubStatus.APPROVED && it.payoutId == null && !it.superseded
        }
        if (valid.isEmpty())
            return Applied(
                false, "Not used: nothing approved yet",
                "None of the submissions in this request is approved on this phone (or they are already in a payout). Import and approve them in Review first, then ask the worker to send the report again. Nothing was used.",
                consume = false
            )
        val amount = valid.sumOf { it.payUgx }
        val left = ids.size - valid.size
        if (left > 0) notes.add(left.toString() + " listed submission(s) are not approved here (or unknown) and were left out.")
        val claimedAmt = b.optLong("amt", -1L)
        if (claimedAmt != amount) notes.add("The worker's app said UGX " + claimedAmt + "; this phone adds up UGX " + amount + " from what you approved. UGX " + amount + " is used.")

        val received = now()
        val asked = b.optLong("at", 0L).let { if (it in 1..received) it else received }
        val p = PayoutRequestEntity(
            id = id, workerId = env.workerId, weekKey = week, amountUgx = amount,
            phone = phone.digits, network = phone.network, status = PayoutStatus.IN_PROGRESS,
            requestedAt = asked, note = notes.joinToString(" ")
        )
        db.payoutDao().insert(p)
        dao.attachIds(id, valid.map { it.id })
        audit.log(actor, "PAYOUT_IMPORTED", "payout", id, "worker=${env.workerId} week=$week UGX $amount to ${phone.digits} warnings=${notes.size}", received)
        return Applied(
            true, "Payout request: " + name + " " + ugxText(amount),
            "Week of " + week + ", to " + phone.national + " (" + phone.network + "). It is listed under \"Payout requests waiting\" below." +
                (if (notes.isEmpty()) "" else "\n⚠ " + notes.joinToString("\n⚠ ")),
            imported = true
        )
    }

    private fun ugxText(n: Long) = "UGX " + String.format(Locale.US, "%,d", n)

    // ---- usernames (5D)

    private suspend fun applyUsername(env: Envelope, name: String, actor: String): Applied {
        val un = env.body.optString("un").trim().lowercase()
        if (!USERNAME_RULE.matches(un)) return Applied(false, "Username not used", "The username in this message is not valid.")
        val owner = dao.usernameOwner(un)
        if (owner != null && owner.workerId != env.workerId) {
            val other = db.workerDao().get(owner.workerId)?.fullName() ?: "another worker"
            return Applied(
                false, "Username already taken",
                name + " uses the username \"" + un + "\" but " + other + " already has it. Ask " + name + " to choose a new one (Connect to the manager > Change my username).",
                imported = false
            )
        }
        if (owner != null) return Applied(true, "Username already recorded", "\"" + un + "\" is already recorded for " + name + ".")
        dao.deleteUsernamesOf(env.workerId)
        dao.putUsername(WorkerUsernameEntity(un, env.workerId))
        audit.log(actor, "WORKER_USERNAME_RECORDED", "worker", env.workerId, un)
        return Applied(true, "Username recorded: " + name, "\"" + un + "\" is unique across your workers.", imported = true)
    }

    // ---- Piece 8C: BNB / NC Wallet deposit claims

    private suspend fun applyNcClaim(env: Envelope, name: String, actor: String): Applied {
        val b = env.body
        val uid = b.optString("id")
        if (!ID_RULE.matches(uid)) return Applied(false, "Claim not used", "The claim number in this message is not valid.")
        val w = db.workerDao().get(env.workerId)
            ?: return Applied(false, "Worker record missing", "The worker is connected but has no record on this phone. Nothing was used.", consume = false)

        val existing = db.ncDao().claimByUid(uid)
        if (existing != null) {
            return if (existing.workerId == env.workerId)
                Applied(true, "Already on this phone", "This claim is already here (status " + existing.status + "). Nothing changed.")
            else Applied(false, "Claim not used", "This claim number already belongs to a different worker. Nothing was used.")
        }

        val coin = b.optString("coin").trim().uppercase()
        if (!NcRepository.COIN_RULE.matches(coin)) return Applied(false, "Claim not used", "The coin in this message is not valid.")
        val amount = NcRepository.cleanAmount(b.optString("amt"))
            ?: return Applied(false, "Claim not used", "The amount in this message is not a valid number.")
        val claimedAt = b.optLong("at", 0L)
        if (claimedAt <= 0L) return Applied(false, "Claim not used", "The claim has no valid time.")

        val received = now()
        val notes = ArrayList<String>()
        if (claimedAt > received + FUTURE_TOLERANCE_MS) notes.add("The claimed time is in the future compared with this phone. Check both phone clocks.")
        if (claimedAt < received - 90L * 24 * 60 * 60 * 1000) notes.add("The claimed time is more than 90 days old.")
        val taskId = b.optString("tid").takeIf { it.isNotBlank() && db.taskDao().get(it) != null }
        if (b.optString("tid").isNotBlank() && taskId == null) notes.add("The task named in the claim is not on this phone.")
        if (db.ncDao().sameClaimCount(env.workerId, coin, amount, claimedAt, uid) > 0)
            notes.add("This worker already has a claim with the same coin, amount and time. Only one of them can match a statement row.")

        db.ncDao().insertClaim(
            NcClaimEntity(
                workerId = w.id, coin = coin, amountText = amount, claimedAtUtc = claimedAt,
                timezoneContext = "EAT", status = NcStatus.UNMATCHED, createdAt = received, claimUid = uid, taskId = taskId
            )
        )
        audit.log(actor, "NC_CLAIM_RECEIVED", "nc_claim", uid, "worker=" + w.id + " " + coin + " " + amount, received)
        return Applied(
            true, "NC claim received: " + name,
            coin + " " + amount + " at " + stamp(claimedAt) + ". Waiting for the matching check (it compares with the NC Wallet statement; you decide)." +
                (if (notes.isEmpty()) "" else "\n⚠ " + notes.joinToString("\n⚠ ")),
            imported = true
        )
    }

    // ---- payout number changes

    private suspend fun applyPhone(env: Envelope, name: String, actor: String): Applied {
        val b = env.body
        val phone = PhoneUtil.parse(b.optString("ph"))
            ?: return Applied(false, "Number change not used", "The new number in this message is not a valid MTN/Airtel number.")
        val w = db.workerDao().get(env.workerId)
            ?: return Applied(false, "Worker record missing", "The worker is connected but has no record on this phone. Nothing was used.", consume = false)
        if (w.phone == phone.digits)
            return Applied(true, "Number already up to date", name + " already has " + phone.national + " on this phone. Nothing changed.")

        val other = db.workerDao().getByPhone(phone.digits)
        if (other != null && other.id != env.workerId)
            return Applied(false, "Number change not used", "The number " + phone.national + " already belongs to another worker (" + other.fullName() + "). Nothing was changed.")

        val received = now()
        val at = b.optLong("at", 0L).let { if (it in 1..received) it else received }
        val last = w.phoneChangedAt
        if (last != null && at < last) {
            // an older change that arrived late must not undo a newer number
            db.workerDao().insertPhone(PhoneHistoryEntity(workerId = w.id, phone = phone.digits, network = phone.network, changedAt = at, reason = "OLDER CHANGE (late report, not applied)"))
            audit.log(actor, "PHONE_CHANGE_OLD", "worker", w.id, "late report for ${phone.digits}, current number kept", received)
            return Applied(true, "Older number change recorded", "This change is older than the number on this phone, so the current number was kept. The old number is kept in the history.", imported = true)
        }

        val notes = ArrayList<String>()
        if (last != null && at - last < TimeUtil.WEEK_MS) notes.add("This is a second change within a week.")
        if (db.payoutDao().inProgressFor(w.id) != null) notes.add("A payout is in progress. It keeps the number it was requested with.")
        val prev = b.optString("prev")
        if (prev.isNotBlank() && prev != w.phone) notes.add("The worker says the old number was " + prev + "; this phone had " + w.phone + ".")

        db.workerDao().update(w.copy(phone = phone.digits, network = phone.network, phoneChangedAt = at))
        db.workerDao().insertPhone(PhoneHistoryEntity(workerId = w.id, phone = phone.digits, network = phone.network, changedAt = at, reason = "CHANGE (was ${w.phone}) via worker report"))
        audit.log(actor, "PHONE_CHANGED", "worker", w.id, "${w.phone} -> ${phone.digits} (worker report)", received)
        return Applied(
            true, "Payout number changed: " + name,
            "New number " + phone.national + " (" + phone.network + ")." + (if (notes.isEmpty()) "" else "\n⚠ " + notes.joinToString("\n⚠ ")),
            imported = true
        )
    }

    // ---------------------------------------------------------------- Piece 5D: username, reset code, join code

    /** Worker phone: change the username (needs the current PIN or password). The new name reaches the manager in the next report. */
    suspend fun changeUsername(workerId: String, newRaw: String, currentSecret: String): Outcome<String> {
        val sec = db.securityDao()
        val c = sec.workerCred(workerId) ?: return Outcome.Err("No login found.")
        val given = currentSecret.trim()
        val ok = Secrets.verifyPassword(given, c.passSalt, c.passHash) || Secrets.verifyPin(given, c.pinSalt, c.pinHash, c.iterations)
        if (!ok) return Outcome.Err("Your current PIN or password is not correct.")
        val u = newRaw.trim().lowercase()
        if (!USERNAME_RULE.matches(u)) return Outcome.Err("Username must be 4 to 20 characters: letters, digits, dot or underscore.")
        if (u == c.username) return Outcome.Err("That is already your username.")
        val taken = sec.workerCredByUsername(u)
        if (taken != null && taken.workerId != workerId) return Outcome.Err("That username is already taken.")
        sec.updateWorkerCred(c.copy(username = u, updatedAt = now()))
        audit.log("worker:$workerId", "WORKER_USERNAME_CHANGED", "worker", workerId, "${c.username} -> $u")
        return Outcome.Ok(u)
    }

    /** 4-digit code derived from the request; the worker's screen and the manager's card show the same one. */
    fun resetCheckCode(nonce: String): String {
        val h = Hashing.sha256Hex("CTRQ|$nonce").take(8)
        val n = java.lang.Long.parseLong(h, 16) % 10000L
        return String.format(Locale.US, "%04d", n)
    }

    /** Worker phone, one tap: a signed "please reset my login" request. Returns (message, check code). */
    suspend fun makeResetRequest(workerId: String): Outcome<Pair<String, String>> {
        val k = dao.key(workerId) ?: return Outcome.Err("This phone is not connected to the manager.")
        if (!hasHeardFromManager(workerId)) return Outcome.Err("The manager has not connected this phone yet.")
        val nonce = SyncCodec.newKeyHex().take(12)
        val seq = nextSeq(workerId, SyncCodec.W2M)
        audit.event("WORKER_RESET_REQUESTED", workerId)
        val code = SyncCodec.seal(k.keyHex, TYPE_RESET_REQ, workerId, SyncCodec.W2M, seq, now(), JSONObject().put("n", nonce))
        return Outcome.Ok(Pair(code, resetCheckCode(nonce)))
    }

    /** Manager phone, one tap: approve a request shown by [receiveAll]. Returns the reset code to send back. */
    suspend fun approveReset(text: String, actor: String): Outcome<String> {
        val env = SyncCodec.parseAll(text).firstOrNull { it.type == TYPE_RESET_REQ } ?: return Outcome.Err("Not a reset request.")
        val k = dao.key(env.workerId) ?: return Outcome.Err("This worker is not connected.")
        if (env.direction != SyncCodec.W2M || !SyncCodec.verify(k.keyHex, env)) return Outcome.Err("The request does not match this worker's key.")
        if (kotlin.math.abs(now() - env.ts) > REQUEST_VALID_MS) return Outcome.Err("The request is too old. Ask the worker to make a new one.")
        return db.withTransaction<Outcome<String>> {
            if (dao.markSeen(SyncSeenEntity(env.workerId, env.direction, env.seq, TYPE_RESET_REQ, now())) == -1L)
                return@withTransaction Outcome.Err("This request was already approved.")
            makeResetCode(env.workerId, actor)
        }
    }

    /** Manager phone: a one-time code that lets this worker choose a new password and PIN. Give it only to the real worker. */
    suspend fun makeResetCode(workerId: String, actor: String): Outcome<String> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val seq = nextSeq(workerId, SyncCodec.M2W)
        audit.log(actor, "SYNC_RESET_CODE_MADE", "worker", workerId, "seq=$seq")
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_RESET, workerId, SyncCodec.M2W, seq, now(), JSONObject().put("purpose", "RESET")))
    }

    /** True once this phone has accepted anything from the manager, i.e. the manager really has this worker's key. */
    suspend fun hasHeardFromManager(workerId: String): Boolean = dao.seenCount(workerId, SyncCodec.M2W) > 0

    /** Worker phone: forgot password/PIN, with a manager-made reset code. Wrong code = [Auth.Wrong] (counts toward the lock). */
    suspend fun recoverWithCode(workerId: String, text: String, newPassword: String, newPin: String): Auth<Unit> {
        val env = SyncCodec.parseAll(text).firstOrNull { it.type == TYPE_RESET }
            ?: return Auth.Denied("No reset code found in what you pasted. Copy the whole code from the manager.")
        val key = dao.key(workerId) ?: return Auth.Denied("This phone has no sync key, so a reset code cannot be checked.")
        if (env.direction != SyncCodec.M2W || env.workerId != workerId || !SyncCodec.verify(key.keyHex, env)) {
            audit.event("WORKER_RESET_CODE_BAD", workerId)
            return Auth.Wrong("This code was not made for this account, or it was changed.")
        }
        val at = now()
        if (kotlin.math.abs(at - env.ts) > CODE_VALID_MS)
            return Auth.Denied("This code has expired (or the date and time on this phone are wrong). Ask the manager for a new one.")
        Secrets.passwordError(newPassword)?.let { return Auth.Denied(it) }
        Secrets.pinError(newPin, Secrets.WORKER_PIN_MIN, Secrets.WORKER_PIN_MAX)?.let { return Auth.Denied(it) }
        val sec = db.securityDao()
        return db.withTransaction<Auth<Unit>> {
            val c = sec.workerCred(workerId) ?: return@withTransaction Auth.Denied("No login has been created on this phone yet.")
            if (dao.seenCountOf(workerId, SyncCodec.M2W, env.seq) > 0)
                return@withTransaction Auth.Denied("This reset code was already used. Ask the manager for a new one.")
            dao.markSeen(SyncSeenEntity(workerId, SyncCodec.M2W, env.seq, TYPE_RESET, at))
            val ps = Secrets.newSaltHex()
            val pn = Secrets.newSaltHex()
            val u = c.copy(
                passSalt = ps, passHash = Secrets.hashPassword(newPassword, ps),
                pinSalt = pn, pinHash = Secrets.hashPin(newPin, pn), iterations = Secrets.PIN_ITERATIONS,
                credVersion = c.credVersion + 1, updatedAt = at
            )
            sec.updateWorkerCred(u)
            sec.putTrust(DeviceTrustEntity(workerId, "WORKER", at, u.credVersion))
            audit.log("worker:$workerId", "WORKER_LOGIN_RESET_BY_CODE", "worker", workerId, "seq=${env.seq}", at)
            Auth.Ok(Unit)
        }
    }

    /** Manager phone: a code that moves a connected worker to a new phone (reinstall / lost phone). Send privately. */
    suspend fun makeJoinCode(workerId: String, actor: String): Outcome<String> {
        val k = dao.key(workerId) ?: return Outcome.Err("This worker is not connected yet.")
        val w = db.workerDao().get(workerId) ?: return Outcome.Err("Worker not found.")
        val body = JSONObject()
            .put("nin", w.nationalId).put("fn", w.firstName).put("mn", w.middleName).put("ln", w.lastName)
            .put("ph", w.phone).put("nw", w.network).put("ca", w.createdAt).put("ac", w.active)
            .put("k", k.keyHex).put("s", dao.maxSeen(workerId, SyncCodec.W2M))
        audit.log(actor, "SYNC_JOIN_CODE_MADE", "worker", workerId, "keycheck=${SyncCodec.keyCheck(k.keyHex)}")
        return Outcome.Ok(SyncCodec.seal(k.keyHex, TYPE_JOIN, workerId, SyncCodec.M2W, 0L, now(), body))
    }

    private suspend fun joinPreviewOf(env: Envelope): JoinPreview {
        val keyHex = env.body.optString("k")
        val first = env.body.optString("fn").trim()
        val last = env.body.optString("ln").trim()
        val full = listOf(first, env.body.optString("mn").trim(), last).filter { it.isNotBlank() }.joinToString(" ")
        val phone = PhoneUtil.parse(env.body.optString("ph"))
        val check = if (SyncCodec.isKeyHex(keyHex)) SyncCodec.keyCheck(keyHex) else "?"
        fun bad(msg: String) = JoinPreview(env.workerId, full.ifBlank { "?" }, phone?.national ?: "?", phone?.network ?: "?", check, msg)

        if (env.type != TYPE_JOIN || env.direction != SyncCodec.M2W) return bad("This is not a JOIN code.")
        if (!ID_RULE.matches(env.workerId)) return bad("The worker id in this code is not valid.")
        if (!SyncCodec.isKeyHex(keyHex)) return bad("The key in this code is not valid.")
        if (!SyncCodec.verify(keyHex, env)) return bad("The code is damaged or was changed after it was made.")
        if (kotlin.math.abs(now() - env.ts) > CODE_VALID_MS) return bad("This code is too old (or this phone's date and time are wrong). Ask the manager for a new one.")
        val nin = env.body.optString("nin").trim().uppercase()
        if (nin.length != WorkerRepository.NIN_LENGTH || !nin.all { it.isLetterOrDigit() }) return bad("The National ID in this code is not valid.")
        if (first.isBlank() || last.isBlank()) return bad("The worker's name is missing.")
        if (phone == null) return bad("The payout number in this code is not valid.")
        if (db.workerDao().get(env.workerId) != null || db.workerDao().getByNationalId(nin) != null || db.workerDao().getByPhone(phone.digits) != null)
            return bad("This phone already has a worker with this identity. A JOIN code is only for a phone where the worker is not registered yet.")
        return JoinPreview(env.workerId, full, phone.national, phone.network, check, null)
    }

    /** Worker phone: look at a JOIN code without changing anything. */
    suspend fun previewJoin(text: String): Outcome<JoinPreview> {
        val env = SyncCodec.parseAll(text).firstOrNull { it.type == TYPE_JOIN }
            ?: return Outcome.Err("No JOIN code found in what you pasted. Copy the whole code from the manager.")
        return Outcome.Ok(joinPreviewOf(env))
    }

    /** Worker phone: the worker confirmed the key code. Creates the worker record and key; the login is created next (Setup screen). */
    suspend fun acceptJoin(text: String): Outcome<String> {
        val env = SyncCodec.parseAll(text).firstOrNull { it.type == TYPE_JOIN }
            ?: return Outcome.Err("No JOIN code found.")
        return db.withTransaction<Outcome<String>> {
            val p = joinPreviewOf(env)
            if (p.problem != null) return@withTransaction Outcome.Err(p.problem)
            val phone = PhoneUtil.parse(env.body.optString("ph")) ?: return@withTransaction Outcome.Err("The payout number is not valid.")
            val at = now()
            val created = env.body.optLong("ca", at).let { if (it in 1..at) it else at }
            db.workerDao().insert(
                WorkerEntity(
                    id = env.workerId, nationalId = env.body.optString("nin").trim().uppercase(),
                    firstName = env.body.optString("fn").trim(), middleName = env.body.optString("mn").trim(),
                    lastName = env.body.optString("ln").trim(), phone = phone.digits, network = phone.network,
                    active = env.body.optBoolean("ac", true), createdAt = created
                )
            )
            db.workerDao().insertPhone(PhoneHistoryEntity(workerId = env.workerId, phone = phone.digits, network = phone.network, changedAt = at, reason = "JOINED NEW PHONE"))
            dao.putKey(SyncKeyEntity(env.workerId, env.body.optString("k"), at))
            // reports from this phone must continue AFTER the numbers the manager already accepted
            meta.put(MetaEntity("sync:out:" + SyncCodec.W2M + ":" + env.workerId, env.body.optLong("s", 0L).coerceAtLeast(0L).toString()))
            audit.log("worker:${env.workerId}", "SYNC_JOINED", "worker", env.workerId, "keycheck=${p.keyCheck}", at)
            Outcome.Ok(env.workerId)
        }
    }

    // ---------------------------------------------------------------- enrollment (Piece 5A, unchanged)

    private suspend fun previewCore(env: Envelope): EnrollPreview {
        val keyHex = env.body.optString("k")
        val nin = env.body.optString("nin").trim().uppercase()
        val first = env.body.optString("fn").trim()
        val middle = env.body.optString("mn").trim()
        val last = env.body.optString("ln").trim()
        val full = listOf(first, middle, last).filter { it.isNotBlank() }.joinToString(" ")
        val phone = PhoneUtil.parse(env.body.optString("ph"))

        fun bad(msg: String) = EnrollPreview(
            env.workerId, full.ifBlank { "?" }, nin, phone?.national ?: "?", phone?.network ?: "?",
            if (SyncCodec.isKeyHex(keyHex)) SyncCodec.keyCheck(keyHex) else "?", "NONE", msg, null
        )

        if (!ID_RULE.matches(env.workerId)) return bad("The worker id in this message is not valid.")
        if (!SyncCodec.isKeyHex(keyHex)) return bad("The key in this message is not valid.")
        if (!SyncCodec.verify(keyHex, env)) return bad("The code is damaged or was changed after it was made.")
        if (nin.length != WorkerRepository.NIN_LENGTH || !nin.all { it.isLetterOrDigit() }) return bad("The National ID in this message is not valid.")
        if (first.isBlank() || last.isBlank()) return bad("The worker's name is missing.")
        if (phone == null) return bad("The payout number in this message is not a valid MTN/Airtel number.")

        val check = SyncCodec.keyCheck(keyHex)
        fun pv(mode: String, problem: String? = null, warning: String? = null) =
            EnrollPreview(env.workerId, full, nin, phone.national, phone.network, check, mode, problem, warning)

        val existingKey = dao.key(env.workerId)
        if (existingKey != null) {
            return if (existingKey.keyHex == keyHex) pv("ALREADY", warning = "This worker is already connected with this same key. Nothing to do.")
            else pv("NONE", problem = "This worker is already connected with a DIFFERENT key. Do not accept. If the worker reinstalled the app, open the worker in Sync and use RESET SYNC KEY first, then check the key code by voice.")
        }

        val byId = db.workerDao().get(env.workerId)
        val byNin = db.workerDao().getByNationalId(nin)
        val byPhone = db.workerDao().getByPhone(phone.digits)

        if (byNin != null && byNin.id != env.workerId) {
            if (dao.key(byNin.id) != null)
                return pv("NONE", problem = "This National ID already belongs to another connected worker (${byNin.fullName()}).")
            val phoneClash = byPhone != null && byPhone.id != byNin.id
            if (phoneClash) return pv("NONE", problem = "The payout number already belongs to another worker (${byPhone?.fullName()}).")
            val warn = "Worker \"${byNin.fullName()}\" was already added on this phone with this National ID. Approving links the two. The existing record and its history are kept." +
                (if (byNin.phone != phone.digits) "\nPayout numbers differ: this phone has 0" + byNin.phone.substring(3) + ", the worker's phone has " + phone.national + ". The number on this phone stays; payout requests will show the number the worker used." else "")
            return pv("LINK", warning = warn)
        }
        if (byId != null) return pv("ATTACH", warning = "This worker already exists on this phone. Approving only adds the secret key.")
        if (byPhone != null) return pv("NONE", problem = "The payout number already belongs to another worker (${byPhone.fullName()}).")
        return pv("NEW")
    }

    /** Piece 5D: same checks as before, plus the worker's username must not belong to another worker. */
    private suspend fun previewOf(env: Envelope): EnrollPreview {
        val p = previewCore(env)
        if (p.problem != null || p.mode == "ALREADY") return p
        val un = env.body.optString("un").trim().lowercase()
        if (un.isBlank()) return p
        if (!USERNAME_RULE.matches(un))
            return EnrollPreview(p.workerId, p.fullName, p.nationalId, p.phoneLocal, p.network, p.keyCheck, "NONE", "The username in this message is not valid.", null)
        val owner = dao.usernameOwner(un)
        if (owner != null && owner.workerId != env.workerId) {
            val other = db.workerDao().get(owner.workerId)?.fullName() ?: "another worker"
            return EnrollPreview(
                p.workerId, p.fullName, p.nationalId, p.phoneLocal, p.network, p.keyCheck, "NONE",
                "The username \"" + un + "\" already belongs to " + other + ". The worker must change their username first (Connect to the manager > Change my username) and send a new connection code.", null
            )
        }
        return p
    }

    /** Manager approved the enrollment shown by [previewOf]. Everything is checked again inside one transaction. */
    suspend fun acceptEnrollment(text: String, actor: String): Outcome<String> {
        val env = SyncCodec.parse(text) ?: return Outcome.Err("Not a CT Team message.")
        if (env.type != TYPE_ENROLL || env.direction != SyncCodec.W2M) return Outcome.Err("This is not an enrollment message.")
        return db.withTransaction<Outcome<String>> {
            val p = previewOf(env)
            if (p.problem != null) return@withTransaction Outcome.Err(p.problem)
            if (p.mode == "ALREADY") return@withTransaction Outcome.Ok("Already connected. Nothing changed.")
            val keyHex = env.body.optString("k")
            val phone = PhoneUtil.parse(env.body.optString("ph"))
                ?: return@withTransaction Outcome.Err("The payout number is not valid.")
            val at = now()
            when (p.mode) {
                "NEW" -> {
                    val created = env.body.optLong("ca", 0L).let { if (it in 1..at) it else at }
                    db.workerDao().insert(
                        WorkerEntity(
                            id = env.workerId, nationalId = p.nationalId,
                            firstName = env.body.optString("fn").trim(), middleName = env.body.optString("mn").trim(),
                            lastName = env.body.optString("ln").trim(), phone = phone.digits, network = phone.network,
                            createdAt = created
                        )
                    )
                    db.workerDao().insertPhone(PhoneHistoryEntity(workerId = env.workerId, phone = phone.digits, network = phone.network, changedAt = at, reason = "REGISTRATION"))
                }
                "LINK" -> {
                    val old = db.workerDao().getByNationalId(p.nationalId)
                        ?: return@withTransaction Outcome.Err("The existing worker record disappeared. Try again.")
                    dao.relinkWorkerRow(old.id, env.workerId)
                    dao.relinkPhoneHistory(old.id, env.workerId)
                    dao.relinkSubmissions(old.id, env.workerId)
                    dao.relinkPayouts(old.id, env.workerId)
                    dao.relinkClaims(old.id, env.workerId)
                    dao.relinkSupport(old.id, env.workerId)
                }
                "ATTACH" -> Unit
                else -> return@withTransaction Outcome.Err("Cannot approve this message.")
            }
            dao.putKey(SyncKeyEntity(env.workerId, keyHex, at))
            val un = env.body.optString("un").trim().lowercase()
            if (USERNAME_RULE.matches(un)) {
                dao.deleteUsernamesOf(env.workerId)
                dao.putUsername(WorkerUsernameEntity(un, env.workerId))
            }
            audit.log(actor, "SYNC_ENROLLED", "worker", env.workerId, "mode=${p.mode} keycheck=${p.keyCheck}", at)
            Outcome.Ok(p.fullName + " is now connected (key code " + p.keyCheck + ").")
        }
    }

    /** Main recovery tool: forget a worker's key and message history so they can enroll again (new phone / reinstall). */
    suspend fun resetKey(workerId: String, actor: String): Outcome<Unit> {
        db.withTransaction {
            dao.deleteKey(workerId)
            dao.deleteSeen(workerId)
        }
        audit.log(actor, "SYNC_KEY_RESET", "worker", workerId, "key and message history cleared; worker must enroll again")
        return Outcome.Ok(Unit)
    }
}
