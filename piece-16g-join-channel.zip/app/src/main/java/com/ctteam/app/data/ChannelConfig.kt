package com.ctteam.app.data

/**
 * The public CT Team Telegram channel (help, tips and news). One place to change the link.
 * It is a PUBLIC channel: the app tells workers never to post their connection code, PIN or password there.
 */
object ChannelConfig {
    const val URL = "https://t.me/ctteamtask"
    const val TITLE = "CT Team Telegram channel"
}
