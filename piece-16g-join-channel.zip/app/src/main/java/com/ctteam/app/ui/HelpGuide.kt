package com.ctteam.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Piece H1 — the in-app help: short answers to the questions people ask most, written in plain words.
 * Nothing is stored and nothing is sent: it is text inside the app, so it also works with no internet.
 * [HelpGuideCard] shows a search box and a list of topics; a tap opens one answer.
 * To add or change an answer, edit the lists below (one HelpTopic per answer).
 */
class HelpTopic(
    val title: String,
    val forWorker: Boolean,
    val forManager: Boolean,
    /** extra words people might type that are not in the title or the answer */
    val words: String,
    val body: String
)

object HelpGuide {
    val topics: List<HelpTopic> = listOf(
        // ---------------------------------------------------------------- both
        HelpTopic(
            "Where can I get more help? (Telegram channel)", true, true, "telegram channel group help news tips announcements join community",
            "Join the CT Team Telegram channel for quick help, tips and news from the team: t.me/ctteamtask\n" +
                "Workers: tap JOIN THE CHANNEL in the connect window or on the home screen, or use the menu item Telegram channel.\n" +
                "The channel is public. Never post your connection code, your PIN or your password there, and never send screenshots of your accounts."
        ),
        HelpTopic(
            "How do I connect to the manager?", true, false, "connect enroll code key start telegram bot link join signup automatic",
            "A window opens by itself when you create your account, and again each time you open the app, until you are connected. A card called Connect to the manager stays on your home screen too.\n" +
                "1. Tap OPEN THE BOT, TAP START. Telegram opens the bot. Tap START once (Telegram's rule).\n" +
                "2. Come back to the app. If a friend invited you, type their referral code. Then tap SEND MY CONNECTION.\n" +
                "3. In Telegram pick the bot and tap send.\n" +
                "That is all. If your manager uses auto-connect you are connected in a moment and the card disappears. Otherwise the manager may phone you to compare a KEY CODE: read the one under Sync aloud.\n" +
                "Never send your code in a group."
        ),
        HelpTopic(
            "The bot does not answer me", true, false, "telegram start bot silent no reply message not received connecting stuck",
            "1. Open the bot in Telegram and tap START. Without START the bot cannot reach you.\n" +
                "2. Tap SEND MY CONNECTION again and send it in the bot's private chat, not a group.\n" +
                "3. The manager's phone reads messages while its app is open, so it can take a while if the manager has not opened the app. Wait a little, then ask the manager.\n" +
                "4. The card still shows? It goes away after the manager's first message reaches you."
        ),
        HelpTopic(
            "How do I open an update from the manager?", true, false, "update import share paste task notice reply",
            "In Telegram, open the message, press Share and choose CT Team. The app reads it by itself.\n" +
                "You can also copy the message and press USE IT when the app offers it, or paste it in Sync > Updates.\n" +
                "Each message works only once. If it says it was already used, you already have it."
        ),
        HelpTopic(
            "How do I do a task and send proof?", true, false, "task proof screenshot submit upload picture",
            "1. Open Tasks and tap a task to read what is needed.\n" +
                "2. Do the task, then add your proof (a screenshot) and press submit.\n" +
                "3. To reach the manager, make a report in Sync (MAKE REPORT) and send it to the bot.\n" +
                "Send the ORIGINAL picture as a FILE. Pictures sent as normal photos are shrunk and may fail the check."
        ),
        HelpTopic(
            "Why can I not open a task (locked)?", true, false, "locked status builder leader champion level lock",
            "Some tasks need a higher status. The task shows which status it needs. You move up by getting referrals awarded: open the menu > Referrals & status to see how far you are from the next status."
        ),
        HelpTopic(
            "Why is my payout waiting? (not verified)", true, false, "verified verify payout blocked wait unverified paid waiting",
            "When you connect by yourself, the manager has not yet checked who you are. You can do tasks and send reports, but payouts and referral points wait until a manager verifies you. Contact your manager and tell them your full name so they can verify you."
        ),
        HelpTopic(
            "My submission was rejected", true, false, "rejected reject declined fail duplicate original",
            "Open History and tap the submission to read the manager's reason. Common reasons: the screenshot was edited or copied, it is a duplicate, or it does not show what the task needs. Do the task again with a new, original screenshot. If you think it was a mistake, write to the manager in Support."
        ),
        HelpTopic(
            "When do I get paid?", true, false, "payout pay money mtn airtel withdraw paid status",
            "1. Only approved submissions count. See Earnings and History.\n" +
                "2. Press the payout button and send your next report so the manager sees the request.\n" +
                "3. The status changes to PAID after the manager pays. You see it after you open the manager's next update.\n" +
                "Check that your payout number is correct (menu > Change payout number)."
        ),
        HelpTopic(
            "I changed my phone number", true, false, "number change phone mtn airtel payout new sim",
            "Open the menu > Change payout number and save the new number, then send a report so the manager gets it. Pay-outs go to the number the manager sees."
        ),
        HelpTopic(
            "How do referrals and points work?", true, false, "referral refer code friend points status invite share reward",
            "1. Menu > Referrals & status shows your personal code. COPY or SHARE it.\n" +
                "2. A friend types it when they connect to the manager.\n" +
                "3. When your friend has enough approved work, the manager awards you points.\n" +
                "Early referrals earn more points: each earlier referral lowers the next reward a little. More awarded referrals raise your status. Spending points never lowers your status."
        ),
        HelpTopic(
            "How do I use my points?", true, false, "points cash gift spend redeem request money use",
            "Menu > Referrals & status > Use my points. Choose cash-out or a gift, type how many points, and press SEND REQUEST. Then send your report. The manager approves or rejects it, and you see the answer under My requests."
        ),
        HelpTopic(
            "What is Team mining?", true, true, "team mining share goal leaderboard level streak badge gift",
            "A page showing how the team is doing: the weekly goal, your share, your level, your streak, badges and the leaderboard. Your share follows your recent work, so steady daily work counts."
        ),
        HelpTopic(
            "How do I learn and earn?", true, false, "learn lesson read video category",
            "Open the menu > Learn & Earn. Lessons your manager sent are listed by category. Read, open the video or picture link if there is one, and tick Read."
        ),
        HelpTopic(
            "How do I forget my password or PIN?", true, true, "forgot password pin reset login locked username",
            "Workers: ask the manager for a reset code. They send it to you, and the app fills it in when you open it.\n" +
                "Managers: the main manager can reset your PIN and password. Quick unlock lasts 30 days, then the app asks for your password again."
        ),
        HelpTopic(
            "I got a new phone", true, true, "new phone reinstall lost move transfer restore backup",
            "Workers: tell your manager. They reset your key, then you connect again and compare the key code by voice. Your submissions are on your old phone only, so send a report with everything first if you still have it.\n" +
                "Managers: use Move to a new phone in the menu. Take a backup first."
        ),
        HelpTopic(
            "How do I update the app?", true, true, "update version download install apk new",
            "When the manager announces a new version, a banner appears with DOWNLOAD UPDATE. Download it and open it. It installs over the old app and keeps your data. Never uninstall to update."
        ),
        HelpTopic(
            "Staying safe", true, true, "safe security scam password pin share never code token",
            "Never share your password, PIN, key code or the bot token. Send connection codes only in a private chat. Install the app only from your team lead. Do not post screenshots that show IDs, numbers or codes."
        ),
        // ---------------------------------------------------------------- manager
        HelpTopic(
            "How do I set up the Telegram bot?", false, true, "telegram bot token botfather setup connect",
            "1. In Telegram, open @BotFather and send /newbot. Choose a name.\n" +
                "2. Copy the token it gives you. Keep it secret.\n" +
                "3. In the app open the menu > Telegram and paste the token.\n" +
                "4. Tell your workers the bot name. Each worker must open it and press START."
        ),
        HelpTopic(
            "How do I approve a new worker?", false, true, "approve enroll connection request key code worker add auto automatic verify unverified",
            "Option 1 (automatic): menu > Auto-connect > ON (main manager only). New workers who send their code to your bot are connected at once and listed under Not verified. Check who they are, then press VERIFY. Until then their payouts and referral points are blocked.\n" +
                "Option 2 (by hand, always used for a worker you already added or a code with a problem): open Sync or the inbox. The request shows the name, National ID, payout number and a KEY CODE. Phone the worker and ask for their key code. Press APPROVE only if it is identical."
        ),
        HelpTopic(
            "How do I create and send tasks?", false, true, "task create daily pay proof send worker status lock",
            "Menu > Tasks > add a task: name, pay, daily or one-time, example link and the proof needed. You can set who can do it (Everyone, Builder, Leader, Champion). Then send updates to your workers in Sync or by Telegram."
        ),
        HelpTopic(
            "How do I review submissions?", false, true, "review approve reject submission screenshot original verify",
            "Import worker reports (Telegram does it while the app is open, or paste in Sync). Open Review. Each screenshot shows the checks. Use ASK FOR THE ORIGINAL to request the file from the worker. Approve or reject with a reason."
        ),
        HelpTopic(
            "How do I pay workers?", false, true, "payout pay statement import nc wallet match paid",
            "Menu > Payouts shows the requests. Pay by your usual way, then mark it paid so the worker sees it. Import wallet statements so the app can match claims to real payments."
        ),
        HelpTopic(
            "How do referrals work for managers?", false, true, "referral award reject rules points main manager request",
            "Menu > Referrals. Referrals tab: award or reject a referral once the new worker has enough approved work. Points tab: balances. Codes tab: add or fix a referral by hand. Requests tab: approve or reject points cash-outs and gifts. Only the main manager can change the rules."
        ),
        HelpTopic(
            "How do I back up my data?", false, true, "backup restore passphrase telegram drive file export",
            "Menu > Backup. Choose a passphrase and save the file. Send a copy to Telegram, Drive or an SD card. Without the passphrase the backup cannot be opened, so keep it safe. The data lives only on your phone, so back up often."
        ),
        HelpTopic(
            "How do I answer a worker's question?", false, true, "support chat reply message question worker",
            "Menu > Support lists the chats, with a badge for unread ones. Open one and reply. The reply goes on Telegram, or is copied as a code you can send any other way."
        )
    )

    /** Topics for this person, filtered by the typed words (every word must appear in the title, the extra words or the answer). */
    fun find(isManager: Boolean, query: String): List<HelpTopic> {
        val mine = topics.filter { if (isManager) it.forManager else it.forWorker }
        val terms = query.lowercase().split(" ", ",", ".").map { it.trim() }.filter { it.length >= 2 }
        if (terms.isEmpty()) return mine
        return mine.filter { t ->
            val hay = (t.title + " " + t.words + " " + t.body).lowercase()
            terms.all { hay.contains(it) }
        }
    }
}

/** The card: a search box and the topics. Put it anywhere inside a column. */
@Composable
fun HelpGuideCard(isManager: Boolean, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var openTitle by remember { mutableStateOf<String?>(null) }
    val shown = HelpGuide.find(isManager, query)

    GlassCard(modifier = modifier.fillMaxWidth()) {
        Text("📖 Quick answers", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(
            "Type a word (for example payout, telegram, referral) or tap a question. Most answers are here.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        CTField(query, { query = it; openTitle = null }, "Search the help")
        Spacer(Modifier.height(6.dp))
        if (shown.isEmpty()) {
            Text("Nothing found. Try another word, or ask the manager below.", color = CT.TextSoft, fontSize = 13.sp)
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            for (t in shown) {
                val isOpen = openTitle == t.title
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { openTitle = if (isOpen) null else t.title }
                        .padding(vertical = 8.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            t.title, color = if (isOpen) CT.GoldLight else Color.White,
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                        Text(if (isOpen) "–" else "+", color = CT.Gold, fontSize = 18.sp)
                    }
                    if (isOpen) {
                        Spacer(Modifier.height(4.dp))
                        Text(t.body, color = CT.TextSoft, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
    }
}
