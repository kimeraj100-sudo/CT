package com.ctteam.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.ChannelConfig
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Repos
import kotlinx.coroutines.launch

/**
 * Piece 16g — "Join our Telegram channel for better help".
 *  - the connect window (ConnectPopup.kt) shows the same button at the same time,
 *  - this card sits on the worker home until the worker has tapped JOIN (meta `ch:opened:<worker>` = 1),
 *  - the worker menu keeps a "Telegram channel" item for good.
 * The link opens in Telegram (or the browser when Telegram is not installed). Nothing is sent from the app.
 */
const val CHANNEL_OPENED_KEY = "ch:opened:"

fun openTelegramChannel(ctx: Context): Boolean {
    val view = Intent(Intent.ACTION_VIEW, Uri.parse(ChannelConfig.URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try {
        ctx.startActivity(view)
        true
    } catch (e: Exception) {
        false
    }
}

@Composable
fun ChannelJoinCard(repos: Repos, workerId: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var opened by remember { mutableStateOf<Boolean?>(null) }
    var later by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    LaunchedEffect(workerId) { opened = repos.db.metaDao().get(CHANNEL_OPENED_KEY + workerId) == "1" }
    if (opened != false || later) return

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("📣 Join our Telegram channel", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(
            "Quick help, tips and news from the team: " + ChannelConfig.URL.removePrefix("https://") +
                ". It is a public channel: never post your connection code, PIN or password there.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        GoldButton(text = "JOIN THE CHANNEL", modifier = Modifier.fillMaxWidth(), onClick = {
            if (openTelegramChannel(ctx)) {
                scope.launch {
                    repos.db.metaDao().put(MetaEntity(CHANNEL_OPENED_KEY + workerId, "1"))
                    opened = true
                }
            } else {
                msg = "Could not open Telegram. Is it installed?"
            }
        })
        Spacer(Modifier.height(6.dp))
        GhostButton(text = "NOT NOW", modifier = Modifier.fillMaxWidth(), onClick = { later = true })
        if (msg.isNotEmpty()) Text(msg, color = CT.Gold, fontSize = 12.sp)
    }
}
