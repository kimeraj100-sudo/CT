package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos
import com.ctteam.app.data.SyncIncoming
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Piece 9B — worker home: the manager's updates arrive with one tap.
 *  - Shared INTO the app (Telegram: open the file or message, Share, CT Team): used at once, no button.
 *  - Copied from a Telegram message: when the worker opens their home screen the app notices a manager update for them on the
 *    clipboard and offers USE IT (a tap is needed so the app never acts on the clipboard by itself).
 * The checks are the same as pasting into "Updates from the manager": signature, made for this worker, each message only once.
 */
private val IN_OK = Color(0xFF3DDC97)
private val IN_BAD = Color(0xFFFF8A8A)
private const val SHOW_LINES = 10
private const val CLIPBOARD_GAP_MS = 60_000L

@Composable
fun WorkerIncomingCard(repos: Repos, workerId: String) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val shared by ShareInbox.pending.collectAsState()

    var results by remember { mutableStateOf<List<SyncIncoming.Done>>(emptyList()) }
    var source by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var offerText by remember { mutableStateOf<String?>(null) }
    var offerCount by remember { mutableStateOf(0) }

    fun run(text: String, from: String) {
        if (busy) return
        busy = true
        source = from
        results = emptyList()
        scope.launch {
            results = repos.sync.receiveFromManager(workerId, text)
            busy = false
        }
    }

    // shared into the app: used at once (the worker chose CT Team in the share list on purpose)
    LaunchedEffect(shared) {
        val t = shared ?: return@LaunchedEffect
        if (ShareInbox.anyForWorkers(t)) {
            ShareInbox.clear()
            offerText = null
            run(t, "Received through Share")
        }
    }

    // copied from a chat: offered, not used silently. Looked at every time this window gets the focus (16d: the worker copies the
    // manager's reply in Telegram and comes back), at most every 2 s while the manager has not been heard from yet, otherwise once a minute.
    val windowInfo = LocalWindowInfo.current
    LaunchedEffect(workerId) {
        snapshotFlow { windowInfo.isWindowFocused }.collect { focused ->
            if (!focused) return@collect
            delay(400)   // Android hands the clipboard to a window a moment after it gets the focus
            val nowMs = System.currentTimeMillis()
            val waiting = repos.sync.managerMessagesReceived(workerId) == 0
            if (nowMs - ShareInbox.lastClipboardCheckAt < (if (waiting) 2_000L else CLIPBOARD_GAP_MS)) return@collect
            ShareInbox.lastClipboardCheckAt = nowMs
            val t = clipboard.getText()?.text ?: return@collect
            if (!t.contains("CT1.") || t.hashCode() == ShareInbox.lastClipboardHash) return@collect
            val n = ShareInbox.countUpdatesFor(t, workerId)
            if (n > 0) { offerText = t; offerCount = n }
        }
    }

    val offer = offerText
    if (offer == null && results.isEmpty() && !busy) return

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        if (offer != null) {
            Text("🔔 The manager sent you an update", color = CT.Gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(
                offerCount.toString() + " message(s) for you are on your clipboard. Tap USE IT to add them to your app.",
                color = CT.TextSoft, fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            GoldButton(text = if (busy) "PLEASE WAIT" else "USE IT", modifier = Modifier.fillMaxWidth(), onClick = {
                ShareInbox.lastClipboardHash = offer.hashCode()
                offerText = null
                run(offer, "Copied from a message")
            })
            Spacer(Modifier.height(6.dp))
            GhostButton(text = "NOT NOW", modifier = Modifier.fillMaxWidth(), onClick = {
                ShareInbox.lastClipboardHash = offer.hashCode()
                offerText = null
            })
        } else if (busy) {
            Text("Checking the manager's update…", color = CT.TextSoft, fontSize = 13.sp)
        } else {
            val good = results.count { it.ok }
            val added = results.count { it.imported }
            Text(
                (if (source.isNotEmpty()) "$source: " else "") + results.size + " checked, " + good + " accepted" +
                    (if (added > 0) " ($added new)" else "") + (if (results.size - good > 0) ", " + (results.size - good) + " not accepted" else "") + ".",
                color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                // problems first, then what was new, then "already had it"
                val ordered = results.sortedBy { if (!it.ok) 0 else if (it.imported) 1 else 2 }
                for (r in ordered.take(SHOW_LINES)) {
                    Text((if (r.ok) "✔ " else "✖ ") + r.title, color = if (r.ok) IN_OK else IN_BAD, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    if (!r.ok || r.imported) Text(r.detail, color = Color.White, fontSize = 12.sp)
                }
                if (ordered.size > SHOW_LINES) Text("… and " + (ordered.size - SHOW_LINES) + " more.", color = CT.TextSoft, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            GhostButton(text = "OK", modifier = Modifier.fillMaxWidth(), onClick = { results = emptyList() })
        }
    }
}
