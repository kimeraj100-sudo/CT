package com.ctteam.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.Repos
import com.ctteam.app.data.SyncCodec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Piece 16d — one line on the worker home that says where the connection to the manager stands:
 *   red    : not connected yet (nothing sent)
 *   yellow : connection sent, the manager's first reply has not been used on this phone yet
 *   green  : connected, with the time of the last message from the manager
 * It looks again every 3 s. Reads only what is already on the phone (accepted messages and the "I sent it" mark).
 * 16d2 adds a button for the waiting state: "I COPIED THE REPLY - USE IT".
 */
private val CS_GOOD = Color(0xFF5FD6A5)
private val CS_WAIT = Color(0xFFFFD166)
private val CS_BAD = Color(0xFFFF8A8A)

private suspend fun csLastFromManager(repos: Repos, workerId: String): Long = withContext(Dispatchers.IO) {
    val c = repos.db.query(
        "SELECT COALESCE(MAX(receivedAt), 0) FROM sync_seen WHERE workerId = ? AND direction = ?",
        arrayOf<Any?>(workerId, SyncCodec.M2W)
    )
    try {
        if (c.moveToFirst()) c.getLong(0) else 0L
    } finally {
        c.close()
    }
}

// 16d2-begin
/**
 * The worker tapped "I copied the reply": the tap is the consent, so a manager update on the clipboard is used at once
 * (same checks as always: signature, made for this worker, each message only once). Returns the message to show.
 */
fun useReplyFromClipboard(clipboardText: String?, workerId: String): String {
    val t = clipboardText ?: ""
    if (!t.contains("CT1.")) {
        return "There is nothing to use on your clipboard yet. In Telegram, tap and hold the bot's reply, tap Copy, then come back here and tap this button again."
    }
    if (ShareInbox.countUpdatesFor(t, workerId) == 0) {
        return "The text on your clipboard is not an update for you. Copy the bot's reply to YOUR connection and try again."
    }
    ShareInbox.offer(t)
    return "Checking the reply…"
}
// 16d2-end

@Composable
fun ConnectStatusLine(repos: Repos, workerId: String) {
    var received by remember { mutableStateOf(-1) }
    var sent by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf(0L) }
    // 16d2-begin
    val clipboard = LocalClipboardManager.current
    var msg by remember { mutableStateOf("") }
    // 16d2-end

    LaunchedEffect(workerId) {
        while (true) {
            received = repos.sync.managerMessagesReceived(workerId)
            sent = repos.db.metaDao().get("qc:sent:" + workerId) == "1"
            last = if (received > 0) csLastFromManager(repos, workerId) else 0L
            delay(3000)
        }
    }
    if (received < 0) return

    val colour = if (received > 0) CS_GOOD else if (sent) CS_WAIT else CS_BAD
    val title = if (received > 0) "Connected to the manager" else if (sent) "Connection sent. Waiting for the manager's reply" else "Not connected to the manager yet"
    val detail = if (received > 0) {
        if (last > 0L) "Last message from the manager: " + fmtTime(last) else "The manager's messages are reaching this phone."
    } else if (sent) {
        "When the bot replies in Telegram: tap its message, Share, CT Team. Or copy it and come back here."
    } else {
        "Open the menu, then Sync, and tap SEND MY CONNECTION."
    }

    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Text("●", color = colour, fontSize = 14.sp)
            Spacer(Modifier.width(8.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        Text(detail, color = CT.TextSoft, fontSize = 12.sp, modifier = Modifier.padding(start = 22.dp))
        // 16d2-begin
        if (received == 0 && sent) {
            GhostButton(text = "I COPIED THE REPLY — USE IT", modifier = Modifier.fillMaxWidth().padding(top = 6.dp), onClick = {
                msg = useReplyFromClipboard(clipboard.getText()?.text, workerId)
            })
            if (msg.isNotEmpty()) Text(msg, color = CT.GoldLight, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        // 16d2-end
    }
}
