package com.ctteam.app.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Up to 20 manager accounts. Each has a code name and a personal PIN.
 * Exactly one is the MAIN manager (isMain = true). The main manager can add managers,
 * reset PINs, and disable / enable other managers for a chosen period.
 * The main manager can never be disabled.
 */
@Entity(tableName = "manager_accounts", indices = [Index(value = ["codeName"], unique = true)])
data class ManagerAccountEntity(
    @PrimaryKey val id: String,
    val codeName: String,              // always stored UPPERCASE
    val pinSalt: String,               // hex
    val pinHash: String,               // hex, PBKDF2-HMAC-SHA256
    val iterations: Int,
    val isMain: Boolean,
    val suspendedUntil: Long?,         // UTC millis; null = not suspended; Long.MAX_VALUE = until re-enabled
    val accessExpiresAt: Long?,        // UTC millis; null = no limit; after this the manager is blocked
    val note: String,
    val createdAt: Long
)

@Dao
interface ManagerAccountDao {
    @Insert suspend fun insert(a: ManagerAccountEntity)
    @Update suspend fun update(a: ManagerAccountEntity)
    @Query("DELETE FROM manager_accounts WHERE id = :id AND isMain = 0") suspend fun deleteNonMain(id: String)
    @Query("SELECT * FROM manager_accounts WHERE id = :id") suspend fun get(id: String): ManagerAccountEntity?
    @Query("SELECT * FROM manager_accounts WHERE isMain = 1 LIMIT 1") suspend fun main(): ManagerAccountEntity?
    @Query("SELECT * FROM manager_accounts ORDER BY isMain DESC, createdAt ASC") suspend fun all(): List<ManagerAccountEntity>
    @Query("SELECT * FROM manager_accounts ORDER BY isMain DESC, createdAt ASC") fun observeAll(): Flow<List<ManagerAccountEntity>>
}

/** Units the main manager can pick when disabling / allowing a manager for a period. */
enum class AccessUnit(val label: String, val millis: Long) {
    HOURS("Hours", 3_600_000L),
    DAYS("Days", 86_400_000L),
    WEEKS("Weeks", 7L * 86_400_000L),
    MONTHS("Months", 30L * 86_400_000L),   // 1 month = 30 days
    YEARS("Years", 365L * 86_400_000L);    // 1 year = 365 days

    fun toMillis(amount: Int): Long = amount.toLong() * millis
}

sealed class LoginResult {
    data class Success(val account: ManagerAccountEntity) : LoginResult()
    data class Blocked(val account: ManagerAccountEntity, val reason: String) : LoginResult()
    object WrongPin : LoginResult()
}

object PinHasher {
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    fun newSaltHex(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return hex(b)
    }

    fun hashHex(pin: String, saltHex: String, iterations: Int): String =
        hex(
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(PBEKeySpec(pin.toCharArray(), unhex(saltHex), iterations, 256))
                .encoded
        )

    fun matches(pin: String, a: ManagerAccountEntity): Boolean =
        MessageDigest.isEqual(
            hashHex(pin, a.pinSalt, a.iterations).toByteArray(Charsets.UTF_8),
            a.pinHash.toByteArray(Charsets.UTF_8)
        )
}

private fun nowMs() = System.currentTimeMillis()

private fun fmtEat(ms: Long): String {
    val f = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US)
    f.timeZone = TimeZone.getTimeZone("GMT+03:00")
    return f.format(Date(ms))
}

class ManagerAccountRepository(private val db: CTDatabase, private val audit: AuditRepository) {
    private val dao = db.managerAccountDao()

    companion object {
        const val MAX_MANAGERS = 20
        const val ITERATIONS = 40_000
        const val MIN_PIN = 6
        const val MAIN_CODE_NAME = "MAIN"
        const val FOREVER = Long.MAX_VALUE

        // The main manager PIN is NOT stored in the app as text, only as this salted hash.
        // Change it from Manager > Managers > MAIN > Change PIN.
        private const val SEED_SALT = "c7a1e93b5d204f68b1d3a9e7042c85f6"
        private const val SEED_HASH = "b10e626acdb842e8f97ed0b61aadfb303535e60b07d2758df44f513ea42f6fe3"
    }

    private fun actorOf(a: ManagerAccountEntity) = "manager:" + a.codeName

    /** Makes sure the main manager account exists (created the first time the app needs it). */
    suspend fun ensureMain(at: Long = nowMs()) {
        db.withTransaction<Unit> {
            if (dao.main() == null) {
                dao.insert(
                    ManagerAccountEntity(
                        id = "main", codeName = MAIN_CODE_NAME,
                        pinSalt = SEED_SALT, pinHash = SEED_HASH, iterations = ITERATIONS,
                        isMain = true, suspendedUntil = null, accessExpiresAt = null,
                        note = "", createdAt = at
                    )
                )
                audit.log("system", "MAIN_MANAGER_CREATED", "manager_account", "main", "", at)
            }
        }
    }

    /** Why this manager cannot work right now, or null if they can. The main manager is never blocked. */
    fun blockReason(a: ManagerAccountEntity, at: Long = nowMs()): String? {
        if (a.isMain) return null
        val s = a.suspendedUntil
        if (s != null && at < s) {
            return if (s == FOREVER) "Your manager access was disabled by the main manager until it is re-enabled."
            else "Your manager access is disabled until " + fmtEat(s) + " (East Africa Time)."
        }
        val e = a.accessExpiresAt
        if (e != null && at >= e) return "Your allowed access period ended on " + fmtEat(e) + "."
        return null
    }

    /** Short status line for lists. */
    fun statusText(a: ManagerAccountEntity, at: Long = nowMs()): String {
        if (a.isMain) return "Main manager · always active"
        val s = a.suspendedUntil
        if (s != null && at < s) {
            return if (s == FOREVER) "Disabled until re-enabled" else "Disabled until " + fmtEat(s)
        }
        val e = a.accessExpiresAt
        if (e != null) {
            return if (at >= e) "Access ended " + fmtEat(e) else "Active until " + fmtEat(e)
        }
        return "Active"
    }

    fun isBlocked(a: ManagerAccountEntity, at: Long = nowMs()): Boolean = blockReason(a, at) != null

    /** PIN check against every account (PINs are unique). Call from a background dispatcher. */
    suspend fun login(pin: String, at: Long = nowMs()): LoginResult {
        ensureMain(at)
        for (a in dao.all()) {
            if (PinHasher.matches(pin, a)) {
                val reason = blockReason(a, at)
                if (reason != null) {
                    audit.log(actorOf(a), "MANAGER_LOGIN_BLOCKED", "manager_account", a.id, reason, at)
                    return LoginResult.Blocked(a, reason)
                }
                audit.log(actorOf(a), "MANAGER_LOGIN", "manager_account", a.id, "", at)
                return LoginResult.Success(a)
            }
        }
        audit.event("MANAGER_LOGIN_FAILED", "", at)
        return LoginResult.WrongPin
    }

    private fun normalizeCode(raw: String): String? {
        val c = raw.trim().replace(Regex("\\s+"), " ").uppercase()
        if (c.length < 2 || c.length > 20) return null
        if (!c.all { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '_' }) return null
        return c
    }

    private fun pinError(pin: String): String? {
        if (pin.length < MIN_PIN) return "PIN must be at least $MIN_PIN digits."
        if (!pin.all { it.isDigit() }) return "PIN can only contain digits."
        return null
    }

    suspend fun add(by: ManagerAccountEntity, codeNameRaw: String, pin: String, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can add managers.")
        val code = normalizeCode(codeNameRaw)
            ?: return Outcome.Err("Code name must be 2 to 20 letters, digits, spaces, - or _.")
        val pe = pinError(pin)
        if (pe != null) return Outcome.Err(pe)
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val all = dao.all()
            if (all.size >= MAX_MANAGERS) return@withTransaction Outcome.Err("The limit of $MAX_MANAGERS managers is reached.")
            if (all.any { it.codeName == code }) return@withTransaction Outcome.Err("That code name is already used.")
            if (all.any { PinHasher.matches(pin, it) }) return@withTransaction Outcome.Err("That PIN is already used by another manager. Choose a different PIN.")
            val salt = PinHasher.newSaltHex()
            val a = ManagerAccountEntity(
                id = UUID.randomUUID().toString(), codeName = code,
                pinSalt = salt, pinHash = PinHasher.hashHex(pin, salt, ITERATIONS), iterations = ITERATIONS,
                isMain = false, suspendedUntil = null, accessExpiresAt = null, note = "", createdAt = at
            )
            dao.insert(a)
            audit.log(actorOf(by), "MANAGER_ADDED", "manager_account", a.id, code, at)
            Outcome.Ok(a)
        }
    }

    /** Disable a manager for durationMs, or until re-enabled when durationMs is null. */
    suspend fun disable(by: ManagerAccountEntity, targetId: String, durationMs: Long?, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can disable managers.")
        if (durationMs != null && durationMs <= 0) return Outcome.Err("Choose a period longer than zero.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager cannot be disabled.")
            val until = if (durationMs == null) FOREVER else at + durationMs
            val u = t.copy(suspendedUntil = until, accessExpiresAt = null)
            dao.update(u)
            val shown = if (until == FOREVER) "until re-enabled" else "until " + fmtEat(until)
            audit.log(actorOf(by), "MANAGER_DISABLED", "manager_account", t.id, t.codeName + " " + shown, at)
            Outcome.Ok(u)
        }
    }

    /** Allow a manager to work only for durationMs from now; after that they are blocked. */
    suspend fun allowFor(by: ManagerAccountEntity, targetId: String, durationMs: Long, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can change access.")
        if (durationMs <= 0) return Outcome.Err("Choose a period longer than zero.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager is always active.")
            val end = at + durationMs
            val u = t.copy(suspendedUntil = null, accessExpiresAt = end)
            dao.update(u)
            audit.log(actorOf(by), "MANAGER_ALLOWED_FOR_PERIOD", "manager_account", t.id, t.codeName + " until " + fmtEat(end), at)
            Outcome.Ok(u)
        }
    }

    /** Remove every restriction now. */
    suspend fun enableNow(by: ManagerAccountEntity, targetId: String, at: Long = nowMs()): Outcome<ManagerAccountEntity> {
        if (!by.isMain) return Outcome.Err("Only the main manager can enable managers.")
        return db.withTransaction<Outcome<ManagerAccountEntity>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            val u = t.copy(suspendedUntil = null, accessExpiresAt = null)
            dao.update(u)
            audit.log(actorOf(by), "MANAGER_ENABLED", "manager_account", t.id, t.codeName, at)
            Outcome.Ok(u)
        }
    }

    suspend fun setPin(by: ManagerAccountEntity, targetId: String, newPin: String, at: Long = nowMs()): Outcome<Unit> {
        if (!by.isMain) return Outcome.Err("Only the main manager can change PINs.")
        val pe = pinError(newPin)
        if (pe != null) return Outcome.Err(pe)
        return db.withTransaction<Outcome<Unit>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (dao.all().any { it.id != t.id && PinHasher.matches(newPin, it) })
                return@withTransaction Outcome.Err("That PIN is already used by another manager. Choose a different PIN.")
            val salt = PinHasher.newSaltHex()
            dao.update(t.copy(pinSalt = salt, pinHash = PinHasher.hashHex(newPin, salt, ITERATIONS), iterations = ITERATIONS))
            audit.log(actorOf(by), "MANAGER_PIN_CHANGED", "manager_account", t.id, t.codeName, at)
            Outcome.Ok(Unit)
        }
    }

    suspend fun rename(by: ManagerAccountEntity, targetId: String, newCodeRaw: String, at: Long = nowMs()): Outcome<Unit> {
        if (!by.isMain) return Outcome.Err("Only the main manager can rename managers.")
        val code = normalizeCode(newCodeRaw)
            ?: return Outcome.Err("Code name must be 2 to 20 letters, digits, spaces, - or _.")
        return db.withTransaction<Outcome<Unit>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (dao.all().any { it.id != t.id && it.codeName == code }) return@withTransaction Outcome.Err("That code name is already used.")
            dao.update(t.copy(codeName = code))
            audit.log(actorOf(by), "MANAGER_RENAMED", "manager_account", t.id, t.codeName + " -> " + code, at)
            Outcome.Ok(Unit)
        }
    }

    suspend fun remove(by: ManagerAccountEntity, targetId: String, at: Long = nowMs()): Outcome<Unit> {
        if (!by.isMain) return Outcome.Err("Only the main manager can remove managers.")
        return db.withTransaction<Outcome<Unit>> {
            val t = dao.get(targetId) ?: return@withTransaction Outcome.Err("Manager not found.")
            if (t.isMain) return@withTransaction Outcome.Err("The main manager cannot be removed.")
            dao.deleteNonMain(t.id)
            audit.log(actorOf(by), "MANAGER_REMOVED", "manager_account", t.id, t.codeName, at)
            Outcome.Ok(Unit)
        }
    }
}
