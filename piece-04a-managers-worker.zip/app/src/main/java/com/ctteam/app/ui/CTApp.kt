package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

enum class Screen { Splash, Roles, Manager, Worker }

/**
 * Root of the app. Very small navigation for now; later pieces replace the
 * Manager / Worker placeholders with the real areas.
 * Each destination has its own transition effect.
 */
@Composable
fun CTApp() {
    var screen by remember { mutableStateOf(Screen.Splash) }

    BackHandler(enabled = screen == Screen.Manager || screen == Screen.Worker) {
        screen = Screen.Roles
    }

    CTBackground {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                when (targetState) {
                    Screen.Manager ->
                        (slideInVertically(tween(550)) { it / 3 } + fadeIn(tween(550))) togetherWith
                            fadeOut(tween(300))
                    Screen.Worker ->
                        (slideInHorizontally(tween(550)) { it } + fadeIn(tween(550))) togetherWith
                            (slideOutHorizontally(tween(550)) { -it / 3 } + fadeOut(tween(400)))
                    else ->
                        fadeIn(tween(700)) togetherWith fadeOut(tween(500))
                }
            },
            label = "nav"
        ) { current ->
            when (current) {
                Screen.Splash -> SplashScreen(onDone = { screen = Screen.Roles })
                Screen.Roles -> RoleScreen(
                    onManager = { screen = Screen.Manager },
                    onWorker = { screen = Screen.Worker }
                )
                Screen.Manager -> ManagerArea(onExit = { screen = Screen.Roles })
                Screen.Worker -> WorkerArea(onExit = { screen = Screen.Roles })
            }
        }
    }
}
