package com.ctteam.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.MetaEntity
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import com.ctteam.app.data.ServiceLocator
import com.ctteam.app.data.SubStatus
import com.ctteam.app.data.TimeUtil
import kotlinx.coroutines.launch

/** Key in the `meta` table that remembers which worker is registered on THIS phone. */
const val WORKER_META_KEY = "this_device_worker_id"

/** Entry point of Worker mode: register once on this phone, then the worker home. */
@Composable
fun WorkerArea(onExit: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val repos = remember { ServiceLocator.get(context) }

    var loaded by remember { mutableStateOf(false) }
    var workerId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        workerId = repos.db.metaDao().get(WORKER_META_KEY)
        loaded = true
    }

    if (!loaded) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Opening…", color = CT.TextSoft)
        }
        return
    }
    val id = workerId
    if (id == null) {
        RegisterWorkerScreen(repos = repos, onExit = onExit, onRegistered = { newId -> workerId = newId })
    } else {
        WorkerHomeScreen(repos = repos, workerId = id, onExit = onExit)
    }
}

// ------------------------------------------------------------------ REGISTRATION

@Composable
private fun RegisterWorkerScreen(repos: Repos, onExit: () -> Unit, onRegistered: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var nin by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var middle by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var ownName by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Register as a worker", onExit)
        Text(
            "Fill in your details exactly as they appear on your National ID. You only do this once on this phone.",
            color = CT.TextSoft, fontSize = 13.sp
        )
        CTField(nin, { nin = it.uppercase().filter { c -> c.isLetterOrDigit() }.take(14) }, "National ID number")
        CTField(first, { first = it }, "First name")
        CTField(middle, { middle = it }, "Middle name (optional)")
        CTField(last, { last = it }, "Last name")
        CTField(phone, { phone = it }, "MTN or Airtel number (e.g. 0772123456)", keyboard = KeyboardType.Phone)
        Text(
            "Payouts go to this number. It must be registered in your own name. " +
                "You can change it only once a week, and never while a payout is in progress.",
            color = CT.TextSoft, fontSize = 12.sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("This number is in my own name", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(checked = ownName, onCheckedChange = { ownName = it })
        }
        if (message.isNotEmpty()) Text(message, color = Color(0xFFFF8A8A), fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "REGISTER",
            onClick = {
                if (!busy) {
                    message = ""
                    if (!ownName) {
                        message = "Please confirm the number is registered in your own name."
                    } else {
                        busy = true
                        scope.launch {
                            val r = repos.workers.register(nin, first, middle, last, phone)
                            busy = false
                            if (r is Outcome.Err) {
                                message = r.message
                            } else if (r is Outcome.Ok) {
                                repos.db.metaDao().put(MetaEntity(WORKER_META_KEY, r.value.id))
                                onRegistered(r.value.id)
                            }
                        }
                    }
                }
            }
        )
        Spacer(Modifier.height(8.dp))
    }
}

// ------------------------------------------------------------------ HOME

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier) {
    GlassCard(modifier = modifier) {
        Text(value, color = CT.GoldLight, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CT.TextSoft, fontSize = 12.sp)
    }
}

@Composable
private fun WorkerHomeScreen(repos: Repos, workerId: String, onExit: () -> Unit) {
    val scope = rememberCoroutineScope()
    val workerFlow = remember(repos) { repos.db.workerDao().observeAll() }
    val workers by workerFlow.collectAsState(initial = emptyList())
    val worker = workers.firstOrNull { it.id == workerId }

    val subFlow = remember(repos, workerId) { repos.db.submissionDao().observeForWorker(workerId) }
    val subs by subFlow.collectAsState(initial = emptyList())

    var expected by remember { mutableStateOf(0L) }
    var newPhone by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val week = TimeUtil.weekKey(System.currentTimeMillis())
    LaunchedEffect(subs, workerId) { expected = repos.submissions.expectedForWeek(workerId, week) }

    if (worker == null) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            ScreenHeader("Worker", onExit)
            Text("Loading…", color = CT.TextSoft)
        }
        return
    }

    val pending = subs.count { it.status == SubStatus.PENDING }
    val approved = subs.count { it.status == SubStatus.APPROVED }
    val rejected = subs.count { it.status == SubStatus.REJECTED }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Hello, " + worker.firstName, onExit)
        if (!worker.active) {
            Text("Your account is disabled by the manager. Contact support.", color = Color(0xFFFF8A8A), fontSize = 13.sp)
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Name", worker.fullName())
            InfoRow("National ID", worker.nationalId)
            InfoRow("Payout number", "0" + worker.phone.substring(3) + " (" + worker.network + ")")
            InfoRow("Registered", fmtTime(worker.createdAt))
        }

        Text("This week (Mon–Sun)", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryTile("Expected payout", ugx(expected), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SummaryTile("Pending", pending.toString(), Modifier.weight(1f))
            SummaryTile("Approved", approved.toString(), Modifier.weight(1f))
            SummaryTile("Rejected", rejected.toString(), Modifier.weight(1f))
        }

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Coming next (Piece 4B)", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Your task list, submitting proof, full earnings history and requesting your weekly payout.",
                color = CT.TextSoft, fontSize = 13.sp
            )
        }

        Text("Change payout number", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        Text("Allowed once per week, and not while a payout is in progress. The number must be in your own name.", color = CT.TextSoft, fontSize = 12.sp)
        CTField(newPhone, { newPhone = it }, "New MTN / Airtel number", keyboard = KeyboardType.Phone)
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)
        GhostButton(text = "CHANGE NUMBER", onClick = {
            scope.launch {
                val r = repos.workers.changePhone(worker.id, newPhone, "worker:" + worker.id)
                if (r is Outcome.Err) {
                    message = r.message
                } else {
                    message = "Phone number changed."
                    newPhone = ""
                }
            }
        })
        Spacer(Modifier.height(8.dp))
    }
}
