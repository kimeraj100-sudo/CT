package com.ctteam.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ctteam.app.data.AccessUnit
import com.ctteam.app.data.LoginResult
import com.ctteam.app.data.ManagerAccountEntity
import com.ctteam.app.data.ManagerAccountRepository
import com.ctteam.app.data.Outcome
import com.ctteam.app.data.Repos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Who is signed in right now. Audit-log actions use this as the actor, e.g. "manager:KINGFISHER". */
object ManagerSession {
    @Volatile var actor: String = "manager"
}

private val RED = Color(0xFFFF8A8A)

// ------------------------------------------------------------------ LOGIN

/** PIN-only sign-in. Each manager has a personal PIN; the code name is shown after sign-in. */
@Composable
fun ManagerAccessGate(
    repos: Repos,
    notice: String,
    onUnlocked: (ManagerAccountEntity) -> Unit,
    onExit: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(notice) }
    var fails by remember { mutableStateOf(0) }
    var lockedUntil by remember { mutableStateOf(0L) }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ShimmerLogo(modifier = Modifier.height(120.dp))
        Spacer(Modifier.height(16.dp))
        Text(
            "Manager access",
            color = CT.Gold, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Enter your personal PIN. Every manager has their own PIN and code name.",
            color = CT.TextSoft, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        CTField(pin, { pin = it.filter { c -> c.isDigit() } }, "PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        if (error.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = RED, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(20.dp))
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "UNLOCK",
            onClick = {
                if (!busy) {
                    error = ""
                    val t = System.currentTimeMillis()
                    if (t < lockedUntil) {
                        error = "Too many tries. Wait " + ((lockedUntil - t) / 1000 + 1) + " seconds."
                    } else if (pin.length < ManagerAccountRepository.MIN_PIN) {
                        error = "Enter your PIN."
                    } else {
                        busy = true
                        val entered = pin
                        scope.launch {
                            val result = withContext(Dispatchers.Default) { repos.managerAccounts.login(entered) }
                            busy = false
                            when (result) {
                                is LoginResult.Success -> {
                                    pin = ""
                                    onUnlocked(result.account)
                                }
                                is LoginResult.Blocked -> {
                                    pin = ""
                                    error = result.reason
                                }
                                is LoginResult.WrongPin -> {
                                    fails += 1
                                    error = "Wrong PIN."
                                    if (fails >= 5) {
                                        lockedUntil = System.currentTimeMillis() + 30_000
                                        fails = 0
                                        error = "Too many wrong tries. Locked for 30 seconds."
                                    }
                                }
                            }
                        }
                    }
                }
            }
        )
        Spacer(Modifier.height(12.dp))
        GhostButton(text = "BACK", onClick = onExit)
    }
}

// ------------------------------------------------------------------ MANAGERS (main manager only)

@Composable
fun ManagersScreen(repos: Repos, me: ManagerAccountEntity, onBack: () -> Unit) {
    val flow = remember(repos) { repos.db.managerAccountDao().observeAll() }
    val accounts by flow.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var openId by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = adding || openId != null) {
        adding = false
        openId = null
    }

    if (adding) {
        AddManagerForm(repos = repos, me = me, onDone = { adding = false })
        return
    }
    val open = accounts.firstOrNull { it.id == openId }
    if (open != null) {
        ManagerDetail(repos = repos, me = me, target = open, onBack = { openId = null })
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Managers", onBack)
        Text(
            accounts.size.toString() + " of " + ManagerAccountRepository.MAX_MANAGERS + " manager accounts used",
            color = CT.TextSoft, fontSize = 13.sp
        )
        if (accounts.size < ManagerAccountRepository.MAX_MANAGERS) {
            GoldButton(text = "ADD MANAGER", onClick = { adding = true })
        }
        for (a in accounts) {
            val blocked = repos.managerAccounts.isBlocked(a)
            GlassCard(modifier = Modifier.fillMaxWidth(), onClick = { openId = a.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(a.codeName, color = CT.GoldLight, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    if (a.isMain) Text("MAIN", color = CT.Teal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Text(
                    repos.managerAccounts.statusText(a),
                    color = if (blocked) RED else CT.TextSoft, fontSize = 13.sp
                )
            }
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Good to know", color = CT.GoldLight, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Disabling or enabling a manager takes effect on this phone straight away. " +
                    "For other managers' phones the rule travels with the signed sync added in Piece 5. " +
                    "The main manager can never be disabled.",
                color = CT.TextSoft, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AddManagerForm(repos: Repos, me: ManagerAccountEntity, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Add manager", onDone)
        Text("Choose a code name and a personal PIN of at least 6 digits. Every PIN must be different.", color = CT.TextSoft, fontSize = 13.sp)
        CTField(code, { code = it }, "Code name (e.g. EAGLE)")
        CTField(pin, { pin = it.filter { c -> c.isDigit() } }, "PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        CTField(pin2, { pin2 = it.filter { c -> c.isDigit() } }, "Repeat PIN", keyboard = KeyboardType.NumberPassword, secret = true)
        if (message.isNotEmpty()) Text(message, color = RED, fontSize = 13.sp)
        GoldButton(
            text = if (busy) "PLEASE WAIT" else "SAVE MANAGER",
            onClick = {
                if (!busy) {
                    message = ""
                    if (pin != pin2) {
                        message = "The two PINs do not match."
                    } else {
                        busy = true
                        val c = code
                        val p = pin
                        scope.launch {
                            val r = withContext(Dispatchers.Default) { repos.managerAccounts.add(me, c, p) }
                            busy = false
                            if (r is Outcome.Err) message = r.message else onDone()
                        }
                    }
                }
            }
        )
    }
}

@Composable
private fun UnitPicker(selected: AccessUnit, onPick: (AccessUnit) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (u in AccessUnit.values()) {
            CTChip(text = u.label, selected = u == selected, onClick = { onPick(u) })
        }
    }
}

@Composable
private fun ManagerDetail(repos: Repos, me: ManagerAccountEntity, target: ManagerAccountEntity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var amountText by remember(target.id) { mutableStateOf("1") }
    var unit by remember(target.id) { mutableStateOf(AccessUnit.DAYS) }
    var newPin by remember(target.id) { mutableStateOf("") }
    var newName by remember(target.id) { mutableStateOf(target.codeName) }
    var confirmRemove by remember(target.id) { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun amountOrNull(): Int? {
        val n = amountText.toIntOrNull()
        return if (n != null && n in 1..1000) n else null
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(target.codeName, onBack)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            InfoRow("Role", if (target.isMain) "Main manager" else "Manager")
            InfoRow("Status", repos.managerAccounts.statusText(target))
            InfoRow("Added", fmtTime(target.createdAt))
        }
        if (message.isNotEmpty()) Text(message, color = CT.GoldLight, fontSize = 13.sp)

        if (!target.isMain) {
            Text("Period", color = CT.GoldLight, fontWeight = FontWeight.Bold)
            Text("1 month = 30 days, 1 year = 365 days.", color = CT.TextSoft, fontSize = 12.sp)
            CTField(amountText, { amountText = it.filter { c -> c.isDigit() }.take(4) }, "Amount (1 to 1000)", keyboard = KeyboardType.Number)
            UnitPicker(selected = unit, onPick = { unit = it })

            GoldButton(text = "DISABLE FOR THIS PERIOD", onClick = {
                val n = amountOrNull()
                if (n == null) {
                    message = "Enter an amount from 1 to 1000."
                } else {
                    scope.launch {
                        val r = repos.managerAccounts.disable(me, target.id, unit.toMillis(n))
                        message = if (r is Outcome.Err) r.message else target.codeName + " is disabled for " + n + " " + unit.label.lowercase() + "."
                    }
                }
            })
            GhostButton(text = "DISABLE UNTIL I RE-ENABLE", danger = true, onClick = {
                scope.launch {
                    val r = repos.managerAccounts.disable(me, target.id, null)
                    message = if (r is Outcome.Err) r.message else target.codeName + " is disabled until you enable them again."
                }
            })
            GhostButton(text = "ALLOW ONLY FOR THIS PERIOD", onClick = {
                val n = amountOrNull()
                if (n == null) {
                    message = "Enter an amount from 1 to 1000."
                } else {
                    scope.launch {
                        val r = repos.managerAccounts.allowFor(me, target.id, unit.toMillis(n))
                        message = if (r is Outcome.Err) r.message else target.codeName + " can work for " + n + " " + unit.label.lowercase() + ", then is blocked."
                    }
                }
            })
            GoldButton(text = "ENABLE NOW", onClick = {
                scope.launch {
                    val r = repos.managerAccounts.enableNow(me, target.id)
                    message = if (r is Outcome.Err) r.message else target.codeName + " is enabled with no time limit."
                }
            })
        }

        Text("Code name", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        CTField(newName, { newName = it }, "Code name")
        GhostButton(text = "SAVE CODE NAME", onClick = {
            scope.launch {
                val r = repos.managerAccounts.rename(me, target.id, newName)
                message = if (r is Outcome.Err) r.message else "Code name saved."
            }
        })

        Text(if (target.isMain) "Change my PIN" else "Reset PIN", color = CT.GoldLight, fontWeight = FontWeight.Bold)
        CTField(newPin, { newPin = it.filter { c -> c.isDigit() } }, "New PIN (6+ digits)", keyboard = KeyboardType.NumberPassword, secret = true)
        GhostButton(text = "SAVE NEW PIN", onClick = {
            val p = newPin
            scope.launch {
                val r = withContext(Dispatchers.Default) { repos.managerAccounts.setPin(me, target.id, p) }
                if (r is Outcome.Err) {
                    message = r.message
                } else {
                    message = "PIN changed."
                    newPin = ""
                }
            }
        })

        if (!target.isMain) {
            GhostButton(
                text = if (confirmRemove) "TAP AGAIN TO REMOVE FOR GOOD" else "REMOVE MANAGER",
                danger = true,
                onClick = {
                    if (!confirmRemove) {
                        confirmRemove = true
                    } else {
                        scope.launch {
                            val r = repos.managerAccounts.remove(me, target.id)
                            if (r is Outcome.Err) message = r.message else onBack()
                        }
                    }
                }
            )
        }
    }
}
