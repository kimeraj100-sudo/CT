package com.ctteam.app.data

import java.time.LocalDateTime

/**
 * PIECE 7 — reading a payout statement (text / CSV pasted or opened as a file) and matching its lines to the payouts
 * that are waiting ("In progress").
 *
 * HONESTY RULE: a match is a suggestion. The manager always confirms (or confirms by hand without any statement).
 * Statement layouts differ between MTN and Airtel, so the reader is tolerant: it looks at each line for a Uganda
 * phone number, amounts, a date and name words instead of expecting fixed columns.
 */

object Conf {
    const val STRONG = "STRONG"      // phone + name + amount all agree
    const val POSSIBLE = "POSSIBLE"  // two of the three agree, or more than one line fits
    const val NONE = "NONE"          // not enough evidence
}

/** One payment line read from a statement. */
class StatementRow(
    val raw: String,
    val phones: List<String>,        // normalized 2567XXXXXXXX
    val amounts: List<Long>,         // every whole-shilling amount found on the line (amount, fee, balance...)
    val nameTokens: Set<String>,     // lower-case words that could be part of a name
    val time: Long?,                 // statement time (taken as East Africa Time) if the line has one
    val key: String                  // stable id of this line, remembered after it was used
)

class StatementParse(val rows: List<StatementRow>, val skippedLines: Int)

object StatementParser {
    private val PHONE = Regex("(?<![0-9])(\\+?256[0-9]{9}|0[0-9]{9})(?![0-9])")
    private val DATE_B = Regex("(20[0-9]{2})[/.-]([0-1]?[0-9])[/.-]([0-3]?[0-9])(?:[ T,]+([0-2]?[0-9]):([0-5][0-9])(?::([0-5][0-9]))?)?")
    private val DATE_A = Regex("(?<![0-9])([0-3]?[0-9])[/.-]([0-1]?[0-9])[/.-](20[0-9]{2})(?:[ T,]+([0-2]?[0-9]):([0-5][0-9])(?::([0-5][0-9]))?)?")
    private val TIME_ONLY = Regex("(?<![0-9])[0-2]?[0-9]:[0-5][0-9](?::[0-5][0-9])?(?![0-9])")
    private val NUMBER = Regex("(?<![0-9A-Za-z])[0-9]{1,3}(?:,[0-9]{3})+(?:\\.[0-9]+)?(?![0-9A-Za-z])|(?<![0-9A-Za-z.])[0-9]+(?:\\.[0-9]+)?(?![0-9A-Za-z])")
    private val WORD = Regex("\\p{L}{2,}")

    /** Words that appear in statements but are not part of a person's name. */
    private val STOP = setOf(
        "ugx", "shs", "sh", "sent", "to", "from", "payment", "payments", "transfer", "transferred", "mobile", "money",
        "balance", "fee", "fees", "charge", "charges", "transaction", "trans", "id", "ref", "reference", "confirmed",
        "completed", "complete", "success", "successful", "airtel", "mtn", "momo", "withdraw", "withdrawal", "deposit",
        "cash", "out", "in", "paid", "amount", "date", "time", "tid", "txn", "status", "send", "received", "receive",
        "uganda", "ltd", "limited", "the", "and", "for", "of", "on", "at", "by", "tax", "excise", "duty", "net", "total",
        "debit", "credit", "dr", "cr", "wallet", "account", "number", "no", "phone", "name", "details", "description",
        "type", "bill", "airtime", "data", "bundle", "merchant", "agent", "customer", "user", "approved", "pending"
    )

    private fun toMillis(y: String, mo: String, d: String, h: String?, mi: String?, s: String?): Long? {
        return try {
            LocalDateTime.of(
                y.toInt(), mo.toInt(), d.toInt(),
                if (h.isNullOrEmpty()) 0 else h.toInt(),
                if (mi.isNullOrEmpty()) 0 else mi.toInt(),
                if (s.isNullOrEmpty()) 0 else s.toInt()
            ).atZone(TimeUtil.EAT).toInstant().toEpochMilli()
        } catch (e: Exception) {
            null
        }
    }

    fun parse(text: String): StatementParse {
        val rows = ArrayList<StatementRow>()
        var skipped = 0
        val seen = HashMap<String, Int>()

        for (rawLine in text.split('\n', '\r')) {
            val line = rawLine.trim()
            if (line.length < 8) continue

            // phone numbers
            val phones = ArrayList<String>()
            for (m in PHONE.findAll(line)) {
                val p = PhoneUtil.parse(m.value)
                if (p != null && !phones.contains(p.digits)) phones.add(p.digits)
            }
            var rest = PHONE.replace(line, " ")

            // date and time (year first, then day first)
            var time: Long? = null
            val b = DATE_B.find(rest)
            if (b != null) {
                val g = b.groupValues
                time = toMillis(g[1], g[2], g[3], g[4], g[5], g[6])
                rest = rest.replace(b.value, " ")
            } else {
                val a = DATE_A.find(rest)
                if (a != null) {
                    val g = a.groupValues
                    time = toMillis(g[3], g[2], g[1], g[4], g[5], g[6])
                    rest = rest.replace(a.value, " ")
                }
            }
            rest = TIME_ONLY.replace(rest, " ")

            // amounts: every whole number found on the line (the amount, but also fee / balance). The matcher only
            // asks "is the payout amount among them?", so we never have to guess which column is the amount.
            val amounts = LinkedHashSet<Long>()
            for (m in NUMBER.findAll(rest)) {
                val v = m.value.replace(",", "").toDoubleOrNull() ?: continue
                if (v < 1.0 || v > 1.0e10) continue
                if (v != Math.floor(v)) continue
                amounts.add(v.toLong())
            }

            // name words
            val tokens = LinkedHashSet<String>()
            for (m in WORD.findAll(NUMBER.replace(rest, " "))) {
                val w = m.value.lowercase()
                if (w !in STOP) tokens.add(w)
            }

            val looksLikePayment = amounts.isNotEmpty() && (phones.isNotEmpty() || tokens.size >= 2)
            if (!looksLikePayment) {
                skipped++
                continue
            }

            val norm = line.lowercase().replace(Regex("\\s+"), " ")
            val base = Hashing.sha256Hex(phones.joinToString(",") + "|" + amounts.joinToString(",") + "|" + (time ?: 0L) + "|" + norm).take(16)
            val n = seen[base] ?: 0
            seen[base] = n + 1
            val key = "ST:" + base + (if (n > 0) "-$n" else "")
            rows.add(StatementRow(line, phones, amounts.toList(), tokens, time, key))
        }
        return StatementParse(rows, skipped)
    }
}

/** A waiting payout, as the matcher needs it. */
class PayoutInfo(val id: String, val workerName: String, val phone: String, val amount: Long)

/** [row] is null when confidence is NONE. [reasons] explains in plain words what agreed and what did not. */
class MatchResult(val payoutId: String, val row: StatementRow?, val confidence: String, val reasons: List<String>)

object PayoutMatcher {
    private class Cand(val row: StatementRow, val score: Int, val reasons: List<String>)

    /** Name words of the worker (lower case, no punctuation, order does not matter). */
    fun workerTokens(name: String): List<String> = NameUtil.key(name).split(" ").filter { it.length >= 2 }

    /** Two or more of the worker's name words appear on the line. */
    fun nameAgrees(workerName: String, rowTokens: Set<String>): Boolean {
        val w = workerTokens(workerName)
        if (w.size < 2) return false
        return w.count { it in rowTokens } >= 2
    }

    private fun evaluate(p: PayoutInfo, r: StatementRow): Cand {
        val phoneOk = r.phones.contains(p.phone)
        val amountOk = r.amounts.contains(p.amount)
        val nameOk = nameAgrees(p.workerName, r.nameTokens)
        val reasons = ArrayList<String>()
        reasons.add(if (phoneOk) "✔ phone number agrees" else "✖ phone number does not agree")
        reasons.add(if (nameOk) "✔ name agrees" else "✖ name does not agree")
        reasons.add(if (amountOk) "✔ amount agrees" else "✖ amount does not agree")
        val score = (if (phoneOk) 1 else 0) + (if (nameOk) 1 else 0) + (if (amountOk) 1 else 0)
        return Cand(r, score, reasons)
    }

    /**
     * Strict one-to-one: a statement line is used for at most one payout, and a payout takes at most one line.
     * Lines whose key is in [usedKeys] were already used for an earlier confirmed payout and are ignored.
     * If more than one line fits a payout (or more than one payout fits a line) equally well, the result is
     * downgraded to POSSIBLE and says so, so the manager looks at it.
     */
    fun match(payouts: List<PayoutInfo>, rows: List<StatementRow>, usedKeys: Set<String>): List<MatchResult> {
        val free = rows.filter { it.key !in usedKeys }

        // every candidate with at least two agreements, per payout
        val cands = HashMap<String, List<Cand>>()
        for (p in payouts) {
            cands[p.id] = free.map { evaluate(p, it) }.filter { it.score >= 2 }.sortedByDescending { it.score }
        }
        // how many payouts compete for each line at its best score
        val contenders = HashMap<String, Int>()
        for (p in payouts) {
            val list = cands[p.id] ?: continue
            if (list.isEmpty()) continue
            val best = list[0].score
            for (c in list) if (c.score == best) contenders[c.row.key] = (contenders[c.row.key] ?: 0) + 1
        }

        val order = payouts.sortedByDescending { cands[it.id]?.firstOrNull()?.score ?: 0 }
        val taken = HashSet<String>()
        val out = HashMap<String, MatchResult>()

        for (p in order) {
            val list = cands[p.id] ?: emptyList()
            if (list.isEmpty()) {
                out[p.id] = MatchResult(p.id, null, Conf.NONE, listOf("No statement line has two of: phone number, name, amount."))
                continue
            }
            val best = list[0].score
            val top = list.filter { it.score == best }
            val choice = top.firstOrNull { it.row.key !in taken }
            if (choice == null) {
                out[p.id] = MatchResult(p.id, null, Conf.NONE, listOf("The only fitting statement line was already given to another payout."))
                continue
            }
            val reasons = ArrayList<String>(choice.reasons)
            var conf = if (best == 3) Conf.STRONG else Conf.POSSIBLE
            if (top.size > 1) {
                conf = Conf.POSSIBLE
                reasons.add("⚠ " + top.size + " statement lines fit this payout equally well; check this is the right one.")
            }
            if ((contenders[choice.row.key] ?: 0) > 1) {
                conf = Conf.POSSIBLE
                reasons.add("⚠ More than one waiting payout fits this statement line; it can only be used once.")
            }
            taken.add(choice.row.key)
            out[p.id] = MatchResult(p.id, choice.row, conf, reasons)
        }
        return payouts.map { out[it.id] ?: MatchResult(it.id, null, Conf.NONE, listOf("Not checked.")) }
    }
}
